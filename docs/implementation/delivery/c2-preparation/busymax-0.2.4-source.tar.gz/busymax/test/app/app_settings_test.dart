import 'package:busymax/src/app/app_settings.dart';
import 'package:busymax/src/schedule/schedule_sidebar_order.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('creation destinations persist and prefer selected over Last used', () {
    const first = CreationDestination(accountId: 'a', id: 'shared');
    const second = CreationDestination(accountId: 'b', id: 'shared');
    final settings = AppSettings.defaults().copyWith(
      defaultCalendar: first,
      lastUsedCalendar: second,
      lastUsedTaskList: first,
    );
    final restored = AppSettings.fromJson(settings.toJson());
    expect(restored.defaultCalendar, first);
    expect(restored.defaultTaskList, isNull);
    expect(restored.lastUsedCalendar, second);
    expect(restored.lastUsedTaskList, first);
    expect(
      preferredCreationDestination(
        [second, first],
        selected: restored.defaultCalendar,
        lastUsed: restored.lastUsedCalendar,
        destinationOf: (value) => value,
      ),
      first,
    );
    expect(
      preferredCreationDestination(
        [second],
        selected: restored.defaultCalendar,
        lastUsed: restored.lastUsedCalendar,
        destinationOf: (value) => value,
      ),
      second,
    );
    expect(restored.copyWith(defaultCalendar: null).defaultCalendar, isNull);
    expect(
      AppSettings.fromJson({
        'defaultCalendar': {'id': 'shared'},
      }).defaultCalendar,
      isNull,
    );
  });

  test(
    'clock preference persists independently of language and canonical data',
    () {
      final initial = AppSettings.defaults().copyWith(
        quietHoursStart: '23:05',
        quietHoursEnd: '06:05',
        scheduleDayEndMinute: 1440,
      );
      for (final preference in BusyMaxTimeFormatPreference.values) {
        for (final locale in ['en', 'de']) {
          final settings = initial.copyWith(
            timeFormatPreference: preference,
            localeTag: locale,
          );
          final restored = AppSettings.fromJson(settings.toJson());
          expect(restored.timeFormatPreference, preference);
          expect(restored.localeTag, locale);
          expect(restored.quietHoursStart, '23:05');
          expect(restored.quietHoursEnd, '06:05');
          expect(restored.scheduleDayEndMinute, 1440);
        }
      }
      for (final value in [null, 'unknown', 12]) {
        expect(
          AppSettings.fromJson({
            'timeFormatPreference': value,
          }).timeFormatPreference,
          BusyMaxTimeFormatPreference.system,
        );
      }
      expect(
        AppSettings.fromJson({}).timeFormatPreference,
        BusyMaxTimeFormatPreference.system,
      );
    },
  );
  test('all first-day preferences persist by stable name', () {
    for (final preference in BusyMaxFirstDayOfWeekPreference.values) {
      final settings = AppSettings.defaults().copyWith(
        firstDayOfWeekPreference: preference,
        localeTag: 'en',
      );
      final json = settings.toJson();
      expect(json['firstDayOfWeekPreference'], preference.name);
      expect(AppSettings.fromJson(json).firstDayOfWeekPreference, preference);
      expect(AppSettings.fromJson(json).localeTag, 'en');
    }
    for (final invalid in [null, 'Monday', 'unknown', 1]) {
      expect(
        AppSettings.fromJson({
          'firstDayOfWeekPreference': invalid,
        }).firstDayOfWeekPreference,
        BusyMaxFirstDayOfWeekPreference.system,
      );
    }
  });
  test('sidebar order defaults, serialization and copyWith are immutable', () {
    expect(AppSettings.defaults().sidebarOrder.accountIds, isEmpty);
    expect(AppSettings.fromJson(const {}).sidebarOrder.accountIds, isEmpty);
    final ids = ['b', 'a', 'b'];
    final calendars = {
      'a': ['second', 'first'],
    };
    final order = ScheduleSidebarOrder(
      accountIds: ids,
      calendarSourceIdsByAccount: calendars,
      taskListIdsByAccount: const {
        'b': ['tasks'],
      },
      subscriptionSourceIds: const ['feed-2', 'feed-1'],
    );
    ids.clear();
    calendars['a']!.clear();
    expect(order.accountIds, ['b', 'a']);
    expect(order.calendarSourceIdsByAccount['a'], ['second', 'first']);
    expect(() => order.accountIds.add('c'), throwsUnsupportedError);
    expect(
      () => order.calendarSourceIdsByAccount['a']!.clear(),
      throwsUnsupportedError,
    );
    expect(() => order.taskListIdsByAccount.clear(), throwsUnsupportedError);
    final settings = AppSettings.defaults().copyWith(sidebarOrder: order);
    expect(
      AppSettings.fromJson(settings.toJson()).sidebarOrder.toJson(),
      order.toJson(),
    );
    expect(settings.copyWith(notifyConflicts: false).sidebarOrder, same(order));
    final malformed = AppSettings.fromJson(const {
      'sidebarOrder': {
        'accountIds': [null, 1, 'a', 'a'],
        'taskListIdsByAccount': false,
      },
    });
    expect(malformed.sidebarOrder.accountIds, ['a']);
    expect(malformed.sidebarOrder.taskListIdsByAccount, isEmpty);
  });

  test('language defaults to the complete system locale preference list', () {
    final settings = AppSettings.defaults();

    expect(settings.localeTag, isNull);
    expect(settings.locale, isNull);
    expect(settings.toJson()['localeTag'], isNull);
  });

  test('language override persists as a canonical supported locale tag', () {
    final regionalEnglish = AppSettings.fromJson(const {'localeTag': 'en_CA'});
    final traditionalChinese = AppSettings.fromJson(const {
      'localeTag': 'zh-TW',
    });
    final unsupported = AppSettings.fromJson(const {'localeTag': 'xx-ZZ'});

    expect(regionalEnglish.localeTag, 'en');
    expect(regionalEnglish.locale, const Locale('en'));
    expect(traditionalChinese.localeTag, 'zh-Hant');
    expect(
      traditionalChinese.locale,
      const Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hant'),
    );
    expect(unsupported.localeTag, isNull);
    expect(unsupported.locale, isNull);
  });

  test('language preference can be persisted and reset to system', () async {
    final store = _MemorySettingsStore();
    final controller = AppSettingsController(store);
    addTearDown(controller.dispose);
    await controller.ready;

    await controller.setLocaleTag('it');
    expect(controller.state.localeTag, 'it');
    expect(store.value['localeTag'], 'it');

    await controller.setLocaleTag(null);
    expect(controller.state.localeTag, isNull);
    expect(store.value['localeTag'], isNull);
  });

  test(
    'notification detail level is the only persisted runtime setting',
    () async {
      final store = _MemorySettingsStore();
      final controller = AppSettingsController(store);
      addTearDown(controller.dispose);
      await controller.ready;

      await controller.setNotificationDetailLevel(
        NotificationDetailLevel.private,
      );

      expect(
        controller.state.notificationDetailLevel,
        NotificationDetailLevel.private,
      );
      expect(store.value['notificationDetailLevel'], 'private');
      expect(store.value, isNot(contains('detailedNotifications')));
    },
  );

  test(
    'legacy notification privacy data migrates without overriding new data',
    () {
      final currentFormatWins = AppSettings.fromJson(const {
        'detailedNotifications': true,
        'notificationDetailLevel': 'private',
      });
      final legacyDetailed = AppSettings.fromJson(const {
        'detailedNotifications': true,
      });
      final legacyPrivate = AppSettings.fromJson(const {
        'detailedNotifications': false,
      });

      expect(
        currentFormatWins.notificationDetailLevel,
        NotificationDetailLevel.private,
      );
      expect(
        legacyDetailed.notificationDetailLevel,
        NotificationDetailLevel.normal,
      );
      expect(
        legacyPrivate.notificationDetailLevel,
        NotificationDetailLevel.private,
      );
    },
  );

  test('quiet hours persist only normalized, distinct times', () async {
    final store = _MemorySettingsStore();
    final first = AppSettingsController(store);
    addTearDown(first.dispose);
    await first.ready;

    await first.setQuietHoursStart('21:5');
    await first.setQuietHoursEnd('6:45');
    expect(first.state.quietHoursStart, '21:05');
    expect(first.state.quietHoursEnd, '06:45');

    await first.setQuietHoursStart('invalid');
    await first.setQuietHoursEnd('21:05');
    expect(first.state.quietHoursStart, '21:05');
    expect(first.state.quietHoursEnd, '06:45');

    final second = AppSettingsController(store);
    addTearDown(second.dispose);
    await second.ready;
    expect(second.state.quietHoursStart, '21:05');
    expect(second.state.quietHoursEnd, '06:45');
  });

  test('invalid persisted quiet-hour ranges fall back safely', () {
    final invalidFormat = AppSettings.fromJson(const {
      'quietHoursStart': '25:00',
      'quietHoursEnd': 'not-a-time',
    });
    final equalRange = AppSettings.fromJson(const {
      'quietHoursStart': '08:00',
      'quietHoursEnd': '08:00',
    });

    expect(invalidFormat.quietHoursStart, '22:00');
    expect(invalidFormat.quietHoursEnd, '07:00');
    expect(equalRange.quietHoursStart, '22:00');
    expect(equalRange.quietHoursEnd, '07:00');
  });

  test('tray-dependent preferences remain internally consistent', () async {
    final controller = AppSettingsController(_MemorySettingsStore());
    addTearDown(controller.dispose);
    await controller.ready;

    await controller.setShowTrayIcon(false);
    expect(controller.state.showTrayIcon, isFalse);
    expect(controller.state.runInBackgroundWhenClosed, isFalse);
    expect(controller.state.startMinimizedToTray, isFalse);

    await controller.setRunInBackgroundWhenClosed(true);
    expect(controller.state.showTrayIcon, isTrue);
    expect(controller.state.runInBackgroundWhenClosed, isTrue);

    await controller.setShowTrayIcon(false);
    await controller.setStartMinimizedToTray(true);
    expect(controller.state.showTrayIcon, isTrue);
    expect(controller.state.startMinimizedToTray, isTrue);
  });

  test(
    'legacy background preferences retain a recoverable tray entry point',
    () {
      final migrated = AppSettings.fromJson(const {
        'showTrayIcon': false,
        'runInBackgroundWhenClosed': true,
      });

      expect(migrated.showTrayIcon, isTrue);
      expect(migrated.runInBackgroundWhenClosed, isTrue);
    },
  );

  test(
    'preloaded settings are available before the first provider frame',
    () async {
      final store = _MemorySettingsStore()
        ..value = <String, Object?>{'themeModePreference': 'dark'};
      final initialSettings = await loadInitialAppSettings(store);
      final controller = AppSettingsController(
        store,
        initialSettings: initialSettings,
      );
      addTearDown(controller.dispose);

      expect(
        controller.state.themeModePreference,
        BusyMaxThemeModePreference.dark,
      );
      await controller.ready;
      expect(
        controller.state.themeModePreference,
        BusyMaxThemeModePreference.dark,
      );
    },
  );

  test('preloading malformed settings falls back to defaults', () async {
    final settings = await loadInitialAppSettings(_ThrowingSettingsStore());

    expect(settings.themeModePreference, BusyMaxThemeModePreference.system);
  });
}

class _MemorySettingsStore implements LocalSettingsStore {
  Map<String, Object?> value = <String, Object?>{};

  @override
  Future<Map<String, Object?>> load() async => value;

  @override
  Future<void> save(Map<String, Object?> json) async {
    value = Map<String, Object?>.from(json);
  }
}

class _ThrowingSettingsStore implements LocalSettingsStore {
  @override
  Future<Map<String, Object?>> load() => Future.error(const FormatException());

  @override
  Future<void> save(Map<String, Object?> json) async {}
}
