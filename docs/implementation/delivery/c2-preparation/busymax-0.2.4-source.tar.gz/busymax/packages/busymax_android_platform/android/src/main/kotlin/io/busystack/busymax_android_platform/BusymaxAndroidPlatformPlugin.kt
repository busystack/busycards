package io.busystack.busymax_android_platform

import android.accounts.Account
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.pm.PackageManager
import android.util.Base64
import java.security.MessageDigest
import java.util.UUID
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import androidx.core.text.util.LocalePreferences
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.ClearTokenRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.RevokeAccessRequest
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.Scope
import com.microsoft.identity.client.AcquireTokenParameters
import com.microsoft.identity.client.AcquireTokenSilentParameters
import com.microsoft.identity.client.AuthenticationCallback
import com.microsoft.identity.client.IAuthenticationResult
import com.microsoft.identity.client.IMultipleAccountPublicClientApplication
import com.microsoft.identity.client.Prompt
import com.microsoft.identity.client.PublicClientApplication
import com.microsoft.identity.client.claims.ClaimsRequest
import com.microsoft.identity.client.exception.MsalClientException
import com.microsoft.identity.client.exception.MsalException
import com.microsoft.identity.client.exception.MsalServiceException
import com.microsoft.identity.client.exception.MsalUiRequiredException
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.PluginRegistry
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

internal object EngineOwnedAccountGateRegistry {
    internal data class Lease(val ownerId: String, val semaphore: Semaphore)

    private val accountGates = ConcurrentHashMap<String, Semaphore>()
    private val leases = ConcurrentHashMap<String, Lease>()

    fun acquire(accountId: String, ownerId: String, timeoutMillis: Long): String? {
        val semaphore = accountGates.computeIfAbsent(accountId) { Semaphore(1, true) }
        if (!semaphore.tryAcquire(timeoutMillis, TimeUnit.MILLISECONDS)) return null
        val leaseId = UUID.randomUUID().toString()
        leases[leaseId] = Lease(ownerId, semaphore)
        return leaseId
    }

    fun release(leaseId: String?, ownerId: String): Boolean {
        if (leaseId == null) return false
        var released = false
        leases.computeIfPresent(leaseId) { _, lease ->
            if (lease.ownerId == ownerId) {
                lease.semaphore.release()
                released = true
                null
            } else {
                lease
            }
        }
        return released
    }

    fun releaseOwned(ownerId: String) {
        for ((leaseId, lease) in leases.entries) {
            if (lease.ownerId == ownerId && leases.remove(leaseId, lease)) {
                lease.semaphore.release()
            }
        }
    }
}

internal data class MicrosoftSilentFailure(
    val code: String,
    val message: String,
)

internal class MicrosoftAccountMissingException : IllegalStateException()

internal fun dartWeekday(firstDay: String?): Int? = when (firstDay) {
    LocalePreferences.FirstDayOfWeek.MONDAY -> 1
    LocalePreferences.FirstDayOfWeek.TUESDAY -> 2
    LocalePreferences.FirstDayOfWeek.WEDNESDAY -> 3
    LocalePreferences.FirstDayOfWeek.THURSDAY -> 4
    LocalePreferences.FirstDayOfWeek.FRIDAY -> 5
    LocalePreferences.FirstDayOfWeek.SATURDAY -> 6
    LocalePreferences.FirstDayOfWeek.SUNDAY -> 7
    else -> null
}

internal fun androidxFirstWeekday(): Int? =
    dartWeekday(LocalePreferences.getFirstDayOfWeek(true))

internal class SystemSettingsReceiverLifecycle(
    private val register: () -> Unit,
    private val unregister: () -> Unit,
    private val clearListener: () -> Unit,
) {
    private var registered = false

    fun attach() {
        if (registered) return
        register()
        registered = true
    }

    fun detach() {
        clearListener()
        if (!registered) return
        registered = false
        unregister()
    }
}

internal class ActivityListenerLifecycle<T : Any>(
    private val add: (T) -> Unit,
    private val remove: (T) -> Unit,
) {
    private var attached: T? = null

    fun attach(next: T) {
        detach()
        add(next)
        attached = next
    }

    fun detach() {
        val current = attached ?: return
        attached = null
        remove(current)
    }
}

/** Maps MSAL failures without turning transport or configuration faults into logout state. */
internal fun classifyMicrosoftSilentFailure(error: Throwable): MicrosoftSilentFailure = when (error) {
    is MicrosoftAccountMissingException,
    is MsalUiRequiredException -> MicrosoftSilentFailure(
        "android/auth-interaction-required",
        "Microsoft authorization must be reconnected.",
    )
    is MsalServiceException -> {
        val configurationCodes = setOf(
            MsalServiceException.INVALID_REQUEST,
            MsalServiceException.UNAUTHORIZED_CLIENT,
            MsalServiceException.INVALID_SCOPE,
            MsalServiceException.INVALID_INSTANCE,
        )
        if (error.errorCode in configurationCodes) {
            MicrosoftSilentFailure(
                "android/microsoft-not-configured",
                "Microsoft authorization is not configured for this account.",
            )
        } else {
            MicrosoftSilentFailure(
                "android/auth-temporary-failure",
                "Microsoft authorization is temporarily unavailable.",
            )
        }
    }
    is MsalClientException -> {
        val configurationCodes = setOf(
            MsalClientException.INVALID_PARAMETER,
            MsalClientException.SCOPE_EMPTY_OR_NULL,
            MsalClientException.JSON_PARSE_FAILURE,
            MsalClientException.MALFORMED_URL,
            MsalClientException.UNKNOWN_AUTHORITY,
            MsalClientException.APP_MANIFEST_VALIDATION_ERROR,
            MsalClientException.REDIRECT_URI_VALIDATION_ERROR,
        )
        if (error.errorCode in configurationCodes) {
            MicrosoftSilentFailure(
                "android/microsoft-not-configured",
                "Microsoft authorization is not configured correctly.",
            )
        } else {
            MicrosoftSilentFailure(
                "android/auth-temporary-failure",
                "Microsoft authorization is temporarily unavailable.",
            )
        }
    }
    else -> MicrosoftSilentFailure(
        "android/microsoft-authorization-failed",
        "Microsoft authorization failed.",
    )
}

/** BusyMax-owned Android integration. Provider refresh tokens never enter Dart. */
class BusymaxAndroidPlatformPlugin : FlutterPlugin,
    MethodChannel.MethodCallHandler,
    EventChannel.StreamHandler,
    ActivityAware,
    PluginRegistry.ActivityResultListener,
    PluginRegistry.NewIntentListener,
    PluginRegistry.RequestPermissionsResultListener {

    private lateinit var context: Context
    private lateinit var channel: MethodChannel
    private lateinit var eventChannel: EventChannel
    private var activity: Activity? = null
    private var eventSink: EventChannel.EventSink? = null
    private val main by lazy { Handler(Looper.getMainLooper()) }
    private val executor = Executors.newCachedThreadPool()
    private var pendingInteractive: PendingInteractive? = null
    private var interactiveSequence = 0
    private var pendingDocument: PendingDocument? = null
    private var pendingPermission: MethodChannel.Result? = null
    private val engineId = UUID.randomUUID().toString()
    @Volatile private var detached = false
    private val msalClients = MicrosoftRegistrationClients<IMultipleAccountPublicClientApplication>()
    private var initialActivation: Map<String, Any?>? = null

    private val settingsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            eventSink?.success(mapOf("kind" to "systemSettingsChanged"))
        }
    }
    private val settingsReceiverLifecycle by lazy {
        SystemSettingsReceiverLifecycle(
            register = {
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    context,
                    settingsReceiver,
                    filter,
                    ContextCompat.RECEIVER_NOT_EXPORTED,
                )
            },
            unregister = {
                try { context.unregisterReceiver(settingsReceiver) } catch (_: Exception) {}
            },
            clearListener = { eventSink = null },
        )
    }
    private val activityListenerLifecycle = ActivityListenerLifecycle<ActivityPluginBinding>(
        add = { binding ->
            binding.addActivityResultListener(this)
            binding.addOnNewIntentListener(this)
            binding.addRequestPermissionsResultListener(this)
        },
        remove = { binding ->
            binding.removeActivityResultListener(this)
            binding.removeOnNewIntentListener(this)
            binding.removeRequestPermissionsResultListener(this)
        },
    )

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        detached = false
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, METHOD_CHANNEL)
        eventChannel = EventChannel(binding.binaryMessenger, EVENT_CHANNEL)
        channel.setMethodCallHandler(this)
        eventChannel.setStreamHandler(this)
        activePlugins.add(this)
        settingsReceiverLifecycle.attach()
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        detached = true
        EngineOwnedAccountGateRegistry.releaseOwned(engineId)
        activePlugins.remove(this)
        channel.setMethodCallHandler(null)
        eventChannel.setStreamHandler(null)
        settingsReceiverLifecycle.detach()
        executor.shutdown()
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { eventSink = events }
    override fun onCancel(arguments: Any?) { eventSink = null }
    override fun onAttachedToActivity(binding: ActivityPluginBinding) = attachActivity(binding)
    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) = attachActivity(binding)

    private fun attachActivity(binding: ActivityPluginBinding) {
        activityListenerLifecycle.attach(binding)
        activity = binding.activity
        captureActivation(binding.activity.intent)
    }

    override fun onDetachedFromActivityForConfigChanges() = detachActivity()
    override fun onDetachedFromActivity() = detachActivity()

    private fun detachActivity() {
        activityListenerLifecycle.detach()
        activity = null
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "currentTimeZoneId" -> result.success(TimeZone.getDefault().id)
            "uses24HourFormat" -> result.success(DateFormat.is24HourFormat(context))
            "getFirstWeekday" -> result.success(firstWeekday())
            "googleAuthorizationAvailable" -> result.success(GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == 0)
            "microsoftAuthorizationAvailable" -> result.success(
                runCatching { nativeMicrosoftIdentity(); true }.getOrDefault(false),
            )
            "authorizeGoogleInteractive" -> authorizeGoogle(call, result, true)
            "authorizeGoogleSilent" -> authorizeGoogle(call, result, false)
            "authorizeMicrosoftInteractive" -> authorizeMicrosoft(call, result, true)
            "authorizeMicrosoftSilent" -> authorizeMicrosoft(call, result, false)
            "microsoftRegistrationIdentity" -> try { result.success(nativeMicrosoftIdentity()) } catch (_: Exception) {
                result.error("android/microsoft-redirect-invalid", "The installed signing identity does not match the MSAL manifest redirect.", null)
            }
            "readAuthorizationBinding" -> {
                val provider = call.argument<String>("provider").orEmpty()
                val binding = readBinding(provider, call.argument<String>("accountId").orEmpty())
                if (binding != null && provider == "microsoft" && !binding.has("clientId")) {
                    val resourceId = context.resources.getIdentifier("busymax_msal_config", "raw", context.packageName)
                    if (resourceId != 0) {
                        val original = JSONObject(context.resources.openRawResource(resourceId).bufferedReader().use { it.readText() })
                        binding.put("clientId", original.getString("client_id"))
                        binding.put("authorityTenant", original.getJSONArray("authorities").getJSONObject(0).getJSONObject("audience").getString("tenant_id"))
                    }
                }
                if (binding != null && provider == "microsoft") {
                    val resourceId = context.resources.getIdentifier("busymax_msal_config", "raw", context.packageName)
                    val originalId = if (resourceId == 0) null else runCatching {
                        JSONObject(context.resources.openRawResource(resourceId).bufferedReader().use { it.readText() }).getString("client_id")
                    }.getOrNull()
                    binding.put("originalRegistration", originalId != null && originalId.equals(binding.optString("clientId"), ignoreCase = true))
                }
                result.success(binding?.let { value -> value.keys().asSequence().associateWith { key -> value.opt(key).takeUnless { it == JSONObject.NULL } } })
            }
            "clearAuthorizationBinding" -> {
                val cleared = bindingPreferences().edit().remove(bindingKey(call.argument<String>("provider").orEmpty(), call.argument<String>("accountId").orEmpty())).commit()
                if (cleared) result.success(null) else result.error("android/auth-storage-failed", "Native account binding could not be saved.", null)
            }
            "bindAuthorization" -> bindAuthorization(call, result)
            "clearRejectedGoogleToken" -> clearGoogleToken(call, result)
            "removeAuthorization" -> removeAuthorization(call, result)
            "cancelInteractiveAuthorization" -> cancelInteractive(call, result)
            "openDocument" -> openDocument(call, result)
            "readDocumentUri" -> readDocumentUri(call, result)
            "createDocument" -> createDocument(call, result)
            "exportDocumentTree" -> exportDocumentTree(call, result)
            "launchExternalUri" -> launchExternalUri(call, result)
            "hasLocalNetworkAccess" -> result.success(hasLocalNetworkAccess())
            "requestLocalNetworkAccess" -> requestLocalNetworkAccess(result)
            "openNotificationSettings" -> {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                result.success(null)
            }
            "acquireAccountGate" -> acquireAccountGate(call, result)
            "releaseAccountGate" -> releaseAccountGate(call, result)
            "releaseOwnedAccountGates" -> {
                EngineOwnedAccountGateRegistry.releaseOwned(engineId)
                result.success(null)
            }
            "notifyDataChanged" -> {
                activePlugins.forEach { plugin ->
                    plugin.eventSink?.success(mapOf("kind" to "dataChanged"))
                }
                result.success(null)
            }
            "takeInitialActivation" -> {
                val activation = initialActivation
                initialActivation = null
                result.success(activation)
            }
            else -> result.notImplemented()
        }
    }

    private fun firstWeekday(): Int? =
        androidxFirstWeekday()

    private fun authorizeGoogle(call: MethodCall, result: MethodChannel.Result, interactive: Boolean) {
        val scopes = stringList(call.argument<List<*>>("scopes"))
        if (scopes.isEmpty()) return result.error("android/invalid-arguments", "Scopes are required.", null)
        if (interactive && !reserveInteractive("google", result, call.argument<String>("authorizationAttemptId"))) return
        val attempt = if (interactive) pendingInteractive else null
        val builder = AuthorizationRequest.builder()
            .setRequestedScopes(scopes.map(::Scope))
            .setPrompt(if (interactive) AuthorizationRequest.Prompt.SELECT_ACCOUNT else AuthorizationRequest.Prompt.NOT_SET)
        if (!interactive) {
            val binding = readBinding("google", call.argument<String>("accountId").orEmpty())
            val username = binding?.optString("username")?.takeIf { it.isNotBlank() }
            if (username == null) return result.error("android/auth-interaction-required", "Google authorization must be reconnected.", null)
            builder.setAccount(Account(username, GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE))
        }
        Identity.getAuthorizationClient(context).authorize(builder.build())
            .addOnSuccessListener { authorization ->
                if (interactive && pendingInteractive !== attempt) return@addOnSuccessListener
                if (authorization.hasResolution()) {
                    val host = activity
                    if (!interactive || host == null) {
                        if (interactive) clearPendingInteractive(attempt)
                        result.error("android/auth-interaction-required", "Authorization requires user interaction.", null)
                        return@addOnSuccessListener
                    }
                    try {
                        host.startIntentSenderForResult(authorization.pendingIntent!!.intentSender, attempt!!.requestCode, null, 0, 0, 0)
                    } catch (error: Exception) {
                        clearPendingInteractive(attempt)
                        result.error("android/auth-launch-failed", "Google authorization could not be opened.", safeError(error))
                    }
                } else {
                    if (interactive) clearPendingInteractive(attempt)
                    completeGoogleAuthorization(authorization, result)
                }
            }
            .addOnFailureListener { error ->
                if (interactive && pendingInteractive !== attempt) return@addOnFailureListener
                if (interactive) clearPendingInteractive(attempt)
                result.error("android/google-authorization-failed", "Google authorization failed.", safeError(error))
            }
    }

    private fun completeGoogleAuthorization(authorization: AuthorizationResult, result: MethodChannel.Result) {
        val token = authorization.accessToken.orEmpty()
        val account = authorization.toGoogleSignInAccount()
        val nativeId = account?.id ?: account?.email
        if (token.isBlank() || nativeId.isNullOrBlank()) {
            result.error("android/google-result-invalid", "Google returned an incomplete authorization result.", null)
            return
        }
        result.success(mapOf(
            "accessToken" to token,
            // AuthorizationResult exposes the concrete granted scopes as
            // Scope values; Scope.toString() is its canonical URI.
            "scopes" to authorization.grantedScopes.map { it.toString() },
            "nativeAccountId" to nativeId,
            "username" to account?.email,
        ))
    }

    private fun authorizeMicrosoft(call: MethodCall, result: MethodChannel.Result, interactive: Boolean) {
        val scopes = stringList(call.argument<List<*>>("scopes"))
        if (scopes.isEmpty()) return result.error("android/invalid-arguments", "Scopes are required.", null)
        if (interactive && !reserveInteractive("microsoft", result, call.argument<String>("authorizationAttemptId"))) return
        val attempt = if (interactive) pendingInteractive else null
        val selectedBinding = if (interactive) null else readBinding("microsoft", call.argument<String>("accountId").orEmpty())
        val explicitClient = call.argument<String>("clientId")
        val selectedClientId = if (interactive || explicitClient != null) explicitClient else selectedBinding?.optString("clientId")?.takeIf { it.isNotBlank() }
        val selectedTenant = if (interactive || explicitClient != null) call.argument<String>("authorityTenant") else selectedBinding?.optString("authorityTenant")?.takeIf { it.isNotBlank() }
        if (!interactive && explicitClient != null &&
            (explicitClient.isBlank() || selectedTenant.isNullOrBlank() || call.argument<String>("nativeAccountId").isNullOrBlank())) {
            return result.error("android/microsoft-not-configured", "The selected native registration binding is incomplete.", null)
        }
        if (interactive && selectedClientId.isNullOrBlank()) {
            clearPendingInteractive(attempt)
            return result.error("android/microsoft-setup-required", "Set up a user-owned Microsoft registration.", null)
        }
        ensureMsal(clientId = selectedClientId, tenant = selectedTenant,
            onSuccess = { application ->
                if (interactive && pendingInteractive !== attempt) return@ensureMsal
                if (interactive) {
                    val host = activity
                    if (host == null) {
                        clearPendingInteractive(attempt)
                        result.error("android/activity-unavailable", "Microsoft sign-in requires a visible Activity.", null)
                        return@ensureMsal
                    }
                    val parameters = AcquireTokenParameters.Builder()
                        .startAuthorizationFromActivity(host)
                        .withScopes(scopes)
                        .withPrompt(Prompt.SELECT_ACCOUNT)
                        .withCallback(object : AuthenticationCallback {
                            override fun onSuccess(authenticationResult: IAuthenticationResult) {
                                if (takePendingInteractive("microsoft", attempt) == null) return
                                result.success(msalResult(authenticationResult))
                            }
                            override fun onError(exception: MsalException) {
                                if (takePendingInteractive("microsoft", attempt) == null) return
                                result.error("android/microsoft-authorization-failed", "Microsoft authorization failed.", safeError(exception))
                            }
                            override fun onCancel() {
                                if (takePendingInteractive("microsoft", attempt) == null) return
                                result.error("android/auth-cancelled", "Microsoft sign-in was cancelled.", null)
                            }
                        }).build()
                    application.acquireToken(parameters)
                } else {
                    val nativeId = if (explicitClient != null) call.argument<String>("nativeAccountId").orEmpty()
                        else selectedBinding?.optString("nativeAccountId").orEmpty()
                    val selectedAuthority = if (explicitClient != null) call.argument<String>("authority") else selectedBinding?.optString("authority")?.takeIf { it.isNotBlank() }
                    executor.execute {
                        try {
                            val account = application.accounts.firstOrNull { it.id == nativeId }
                                ?: throw MicrosoftAccountMissingException()
                            val parametersBuilder = AcquireTokenSilentParameters.Builder()
                                .withScopes(scopes).forAccount(account).fromAuthority(selectedAuthority ?: account.authority)
                            call.argument<String>("claims")?.takeIf { it.isNotBlank() }?.let {
                                parametersBuilder.withClaims(ClaimsRequest.getClaimsRequestFromJsonString(it))
                            }
                            val parameters = parametersBuilder.build()
                            postSuccess(result, msalResult(application.acquireTokenSilent(parameters)))
                        } catch (error: Exception) {
                            val failure = classifyMicrosoftSilentFailure(error)
                            postError(result, failure.code, failure.message, error)
                        }
                    }
                }
            },
            onError = { error ->
                if (interactive && pendingInteractive !== attempt) return@ensureMsal
                if (interactive) clearPendingInteractive(attempt)
                result.error("android/microsoft-not-configured", "Microsoft sign-in is not configured for this build.", safeError(error))
            },
        )
    }

    @Suppress("DEPRECATION")
    private fun nativeMicrosoftIdentity(): Map<String, String> {
        val info = if (android.os.Build.VERSION.SDK_INT >= 28) {
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        } else context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
        val signatures = if (android.os.Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
        require(signatures?.size == 1) { "Ambiguous installed signature." }
        val hash = Base64.encodeToString(MessageDigest.getInstance("SHA-1").digest(signatures!![0].toByteArray()), Base64.NO_WRAP)
        val redirect = "msauth://${context.packageName}/${URLEncoder.encode(hash, StandardCharsets.UTF_8.name())}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(redirect)).addCategory(Intent.CATEGORY_BROWSABLE).addCategory(Intent.CATEGORY_DEFAULT)
        require(context.packageManager.queryIntentActivities(intent, 0).any {
            it.activityInfo.packageName == context.packageName && it.activityInfo.name == "com.microsoft.identity.client.BrowserTabActivity"
        }) { "Installed signature and manifest redirect differ." }
        val resourceId = context.resources.getIdentifier("busymax_msal_config", "raw", context.packageName)
        val originalId = if (resourceId == 0) null else runCatching {
            JSONObject(context.resources.openRawResource(resourceId).bufferedReader().use { it.readText() }).getString("client_id")
        }.getOrNull()
        return mapOf("packageName" to context.packageName, "signatureHash" to hash, "redirectUri" to redirect) +
            (originalId?.let { mapOf("retiringClientId" to it) } ?: emptyMap())
    }

    private fun ensureMsal(clientId: String? = null, tenant: String? = null,
        onSuccess: (IMultipleAccountPublicClientApplication) -> Unit, onError: (Throwable) -> Unit) {
        executor.execute {
            try {
                val registration = clientId?.let { MicrosoftRegistration(it, tenant ?: "common") }
                val application = msalClients.getOrCreate(registration) {
                        val created = if (clientId == null) {
                            val resourceId = context.resources.getIdentifier("busymax_msal_config", "raw", context.packageName)
                            require(resourceId != 0) { "Original registration unavailable." }
                            PublicClientApplication.createMultipleAccountPublicClientApplication(context, resourceId)
                        } else {
                            val selectedTenant = registration!!.tenant
                            val audienceType = registration.audienceType
                            val config = JSONObject().put("client_id", clientId)
                                .put("redirect_uri", nativeMicrosoftIdentity().getValue("redirectUri"))
                                .put("authorization_user_agent", "BROWSER").put("account_mode", "MULTIPLE")
                                .put("broker_redirect_uri_registered", false)
                                .put("logging", JSONObject().put("pii_enabled", false).put("log_level", "WARNING"))
                                .put("authorities", org.json.JSONArray().put(JSONObject().put("type", "AAD").put("default", true)
                                    .put("audience", JSONObject().put("type", audienceType).put("tenant_id", selectedTenant))))
                            val file = java.io.File.createTempFile("busymax-msal-", ".json", context.cacheDir)
                            try {
                                file.writeText(config.toString())
                                PublicClientApplication.createMultipleAccountPublicClientApplication(context, file)
                            } finally { file.delete() }
                        }
                        created
                }
                main.post { onSuccess(application) }
            } catch (error: Throwable) { main.post { onError(error) } }
        }
    }

    private fun msalResult(token: IAuthenticationResult): Map<String, Any?> = mapOf(
        "accessToken" to token.accessToken,
        "scopes" to token.scope.toList(),
        "nativeAccountId" to token.account.id,
        "username" to token.account.username,
        "authority" to "https://login.microsoftonline.com/${token.tenantId}",
        "expiresAtEpochMillis" to token.expiresOn.time,
    )

    private fun bindAuthorization(call: MethodCall, result: MethodChannel.Result) {
        val provider = call.argument<String>("provider").orEmpty()
        val accountId = call.argument<String>("accountId").orEmpty()
        val nativeId = call.argument<String>("nativeAccountId").orEmpty()
        if (provider !in setOf("google", "microsoft") || accountId.isBlank() || nativeId.isBlank()) {
            result.error("android/invalid-arguments", "Authorization binding is incomplete.", null)
            return
        }
        val value = JSONObject().put("provider", provider).put("accountId", accountId)
            .put("nativeAccountId", nativeId).put("username", call.argument<String>("username"))
            .put("authority", call.argument<String>("authority"))
            .put("clientId", call.argument<String>("clientId"))
            .put("authorityTenant", call.argument<String>("authorityTenant"))
        if (!bindingPreferences().edit().putString(bindingKey(provider, accountId), value.toString()).commit()) {
            return result.error("android/binding-storage-unavailable", "Native account binding could not be saved.", null)
        }
        result.success(null)
    }

    private fun clearGoogleToken(call: MethodCall, result: MethodChannel.Result) {
        val token = call.argument<String>("token").orEmpty()
        if (token.isBlank()) return result.success(null)
        Identity.getAuthorizationClient(context).clearToken(ClearTokenRequest.builder().setToken(token).build())
            .addOnSuccessListener { result.success(null) }
            .addOnFailureListener { result.error("android/google-clear-failed", "Rejected Google token could not be cleared.", safeError(it)) }
    }

    private fun removeAuthorization(call: MethodCall, result: MethodChannel.Result) {
        val provider = call.argument<String>("provider").orEmpty()
        val accountId = call.argument<String>("accountId").orEmpty()
        val binding = readBinding(provider, accountId)
        fun removeBinding() { bindingPreferences().edit().remove(bindingKey(provider, accountId)).apply() }
        if (provider == "google" && call.argument<Boolean>("revoke") == true) {
            val username = binding?.optString("username").orEmpty()
            if (username.isBlank()) { removeBinding(); return result.success(null) }
            Identity.getAuthorizationClient(context).revokeAccess(
                RevokeAccessRequest.builder().setAccount(Account(username, GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE)).build(),
            ).addOnSuccessListener { removeBinding(); result.success(null) }
                .addOnFailureListener { result.error("android/google-revoke-failed", "Google access could not be revoked.", safeError(it)) }
            return
        }
        if (provider == "microsoft" && binding != null) {
            val nativeId = binding.optString("nativeAccountId")
            ensureMsal(clientId = binding.optString("clientId").takeIf { it.isNotBlank() },
                tenant = binding.optString("authorityTenant").takeIf { it.isNotBlank() }, onSuccess = { application -> executor.execute {
                try {
                    application.accounts.firstOrNull { it.id == nativeId }?.let(application::removeAccount)
                    removeBinding(); postSuccess(result, null)
                } catch (error: Exception) { postError(result, "android/microsoft-remove-failed", "Microsoft account could not be removed.", error) }
            } }, onError = { result.error("android/microsoft-not-configured", "Microsoft sign-in is not configured.", safeError(it)) })
            return
        }
        removeBinding(); result.success(null)
    }

    private fun reserveInteractive(provider: String, result: MethodChannel.Result, authorizationAttemptId: String?): Boolean {
        if (activity == null) { result.error("android/activity-unavailable", "Sign-in requires a visible Activity.", null); return false }
        if (pendingInteractive != null) { result.error("android/auth-in-progress", "Another sign-in is already in progress.", null); return false }
        pendingInteractive = PendingInteractive(provider, result, 0x5200 + (++interactiveSequence % 0x1000), authorizationAttemptId)
        return true
    }

    private fun takePendingInteractive(provider: String, expected: PendingInteractive? = pendingInteractive): PendingInteractive? {
        val pending = pendingInteractive
        if (pending?.provider != provider || pending !== expected) return null
        pendingInteractive = null
        return pending
    }

    private fun clearPendingInteractive(expected: PendingInteractive? = pendingInteractive) { if (pendingInteractive === expected) pendingInteractive = null }
    private fun cancelInteractive(call: MethodCall, result: MethodChannel.Result) {
        val pending = pendingInteractive
        val requestedId = call.argument<String>("authorizationAttemptId")
        if (requestedId != null && pending?.authorizationAttemptId != requestedId) { result.success(null); return }
        pendingInteractive = null
        pending?.result?.error("android/auth-cancelled", "Sign-in was cancelled.", null)
        result.success(null)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (pendingInteractive?.provider == "google" && requestCode == pendingInteractive?.requestCode) {
            val pending = takePendingInteractive("google") ?: return true
            if (resultCode != Activity.RESULT_OK || data == null) {
                pending.result.error("android/auth-cancelled", "Google sign-in was cancelled.", null)
                return true
            }
            try { completeGoogleAuthorization(Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(data), pending.result) }
            catch (error: Exception) { pending.result.error("android/google-authorization-failed", "Google authorization failed.", safeError(error)) }
            return true
        }
        val pending = pendingDocument ?: return false
        if (requestCode != pending.requestCode) return false
        pendingDocument = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) { pending.result.success(null); return true }
        val uri = data.data!!
        executor.execute {
            try {
                when (pending) {
                    is PendingDocument.Open -> finishOpenDocument(uri, pending)
                    is PendingDocument.Create -> finishCreateDocument(uri, pending)
                    is PendingDocument.Tree -> finishTreeExport(uri, pending)
                }
            } catch (error: Exception) {
                postError(pending.result, "android/document-failed", "The selected document could not be processed.", error)
            }
        }
        return true
    }

    private fun openDocument(call: MethodCall, result: MethodChannel.Result) {
        val host = requireDocumentActivity(result) ?: return
        if (pendingDocument != null) return result.error("android/document-in-progress", "A document picker is already open.", null)
        val types = stringList(call.argument<List<*>>("mimeTypes")).ifEmpty { listOf("text/calendar") }
        val max = (call.argument<Number>("maximumBytes")?.toLong() ?: MAX_IMPORT_BYTES).coerceIn(1, MAX_IMPORT_BYTES)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = if (types.size == 1) types.first() else "*/*"
            if (types.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, types.toTypedArray())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pendingDocument = PendingDocument.Open(result, max)
        host.startActivityForResult(intent, OPEN_DOCUMENT_REQUEST)
    }

    private fun finishOpenDocument(uri: Uri, pending: PendingDocument.Open) {
        tryPersistPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        postSuccess(pending.result, readDocument(uri, pending.maximumBytes))
    }

    private fun readDocumentUri(call: MethodCall, result: MethodChannel.Result) {
        val uri = Uri.parse(call.argument<String>("uri").orEmpty())
        if (uri.scheme != "content") return result.error("android/invalid-document-uri", "Only content document URIs are supported.", null)
        val max = (call.argument<Number>("maximumBytes")?.toLong() ?: MAX_IMPORT_BYTES).coerceIn(1, MAX_IMPORT_BYTES)
        executor.execute {
            try { postSuccess(result, readDocument(uri, max)) }
            catch (error: Exception) { postError(result, "android/document-failed", "The shared document could not be read.", error) }
        }
    }

    private fun readDocument(uri: Uri, maximumBytes: Long): Map<String, Any?> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val output = ByteArrayOutputStream(); val buffer = ByteArray(16 * 1024); var total = 0L
            while (true) { val count = input.read(buffer); if (count < 0) break; total += count
                if (total > maximumBytes) throw IllegalArgumentException("Document exceeds the import size limit.")
                output.write(buffer, 0, count) }
            output.toByteArray()
        } ?: throw IllegalArgumentException("Document could not be opened.")
        return mapOf("uri" to uri.toString(), "bytes" to bytes, "name" to displayName(uri), "mimeType" to context.contentResolver.getType(uri))
    }

    private fun createDocument(call: MethodCall, result: MethodChannel.Result) {
        val host = requireDocumentActivity(result) ?: return
        if (pendingDocument != null) return result.error("android/document-in-progress", "A document picker is already open.", null)
        val bytes = call.argument<ByteArray>("bytes") ?: return result.error("android/invalid-arguments", "Export bytes are required.", null)
        if (bytes.size > MAX_EXPORT_BYTES) return result.error("android/export-too-large", "Export exceeds the size limit.", null)
        pendingDocument = PendingDocument.Create(result, bytes)
        host.startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = call.argument<String>("mimeType")?.takeIf { it.isNotBlank() } ?: "text/calendar"
            putExtra(Intent.EXTRA_TITLE, safeFileName(call.argument<String>("suggestedName").orEmpty(), "busymax.ics"))
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, CREATE_DOCUMENT_REQUEST)
    }

    private fun finishCreateDocument(uri: Uri, pending: PendingDocument.Create) {
        tryPersistPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(pending.bytes) }
            ?: throw IllegalArgumentException("Document could not be created.")
        postSuccess(pending.result, uri.toString())
    }

    private fun exportDocumentTree(call: MethodCall, result: MethodChannel.Result) {
        val host = requireDocumentActivity(result) ?: return
        if (pendingDocument != null) return result.error("android/document-in-progress", "A document picker is already open.", null)
        val raw = call.argument<List<*>>("resources") ?: emptyList<Any>()
        if (raw.size > MAX_EXPORT_RESOURCES) return result.error("android/export-too-large", "Export contains too many resources.", null)
        var total = 0L
        val resources = raw.mapIndexed { index, value ->
            val map = value as? Map<*, *> ?: throw IllegalArgumentException("Invalid export resource.")
            val bytes = map["bytes"] as? ByteArray ?: throw IllegalArgumentException("Missing export bytes.")
            total += bytes.size
            ExportResource(safeFileName(map["name"]?.toString().orEmpty(), "resource-${index + 1}.ics"), bytes)
        }
        if (total > MAX_TREE_EXPORT_BYTES) return result.error("android/export-too-large", "Export exceeds the size limit.", null)
        pendingDocument = PendingDocument.Tree(result, safeFileName(call.argument<String>("folderName").orEmpty(), "BusyMax export"), resources)
        host.startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }, OPEN_TREE_REQUEST)
    }

    private fun finishTreeExport(uri: Uri, pending: PendingDocument.Tree) {
        tryPersistPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        val resolver = context.contentResolver
        val root = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
        val folder = DocumentsContract.createDocument(resolver, root, DocumentsContract.Document.MIME_TYPE_DIR, pending.folderName)
            ?: throw IllegalStateException("Could not create the export folder.")
        for (resource in pending.resources) {
            val output = DocumentsContract.createDocument(resolver, folder, "text/calendar", resource.name)
                ?: throw IllegalStateException("Could not create ${resource.name}.")
            resolver.openOutputStream(output, "wt")?.use { it.write(resource.bytes) }
                ?: throw IllegalStateException("Could not write ${resource.name}.")
        }
        postSuccess(pending.result, folder.toString())
    }

    private fun launchExternalUri(call: MethodCall, result: MethodChannel.Result) {
        val uri = Uri.parse(call.argument<String>("uri").orEmpty())
        if (uri.scheme?.lowercase() !in setOf("https", "http", "geo", "mailto")) return result.error("android/uri-not-allowed", "This link type is not allowed.", null)
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) == null) return result.success(false)
        context.startActivity(intent); result.success(true)
    }

    private fun hasLocalNetworkAccess() = Build.VERSION.SDK_INT < 37 || ContextCompat.checkSelfPermission(context, ACCESS_LOCAL_NETWORK) == PackageManager.PERMISSION_GRANTED
    private fun requestLocalNetworkAccess(result: MethodChannel.Result) {
        if (hasLocalNetworkAccess()) return result.success(true)
        val host = activity ?: return result.error("android/activity-unavailable", "Local network permission requires a visible Activity.", null)
        if (pendingPermission != null) return result.error("android/permission-in-progress", "Another permission request is active.", null)
        pendingPermission = result
        host.requestPermissions(arrayOf(ACCESS_LOCAL_NETWORK), LOCAL_NETWORK_REQUEST)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray): Boolean {
        if (requestCode != LOCAL_NETWORK_REQUEST) return false
        val result = pendingPermission ?: return true
        pendingPermission = null; result.success(grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED); return true
    }

    private fun acquireAccountGate(call: MethodCall, result: MethodChannel.Result) {
        val accountId = call.argument<String>("accountId").orEmpty()
        val timeout = (call.argument<Number>("timeoutMillis")?.toLong() ?: 30_000L).coerceIn(1_000L, 120_000L)
        if (accountId.isBlank()) return result.error("android/invalid-arguments", "Account id is required.", null)
        executor.execute {
            try {
                val lease = EngineOwnedAccountGateRegistry.acquire(accountId, engineId, timeout)
                    ?: return@execute postError(result, "android/account-busy", "This account is already synchronizing.", null)
                if (detached) {
                    EngineOwnedAccountGateRegistry.release(lease, engineId)
                    return@execute
                }
                postSuccess(result, lease)
            } catch (error: InterruptedException) {
                Thread.currentThread().interrupt(); postError(result, "android/account-gate-interrupted", "Account synchronization was interrupted.", error)
            }
        }
    }

    private fun releaseAccountGate(call: MethodCall, result: MethodChannel.Result) {
        EngineOwnedAccountGateRegistry.release(call.argument<String>("leaseId"), engineId)
        result.success(null)
    }
    override fun onNewIntent(intent: Intent): Boolean = captureActivation(intent)
    private fun captureActivation(intent: Intent?): Boolean {
        if (intent == null) return false
        val activation = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.let { mapOf("kind" to "document", "uri" to it.toString(), "mimeType" to intent.type) }
            Intent.ACTION_SEND -> sharedStreamUri(intent)?.let { mapOf("kind" to "document", "uri" to it.toString(), "mimeType" to intent.type) }
            else -> null
        } ?: return false
        intent.action = null
        initialActivation = activation; eventSink?.success(activation); return true
    }

    private fun sharedStreamUri(intent: Intent): Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    } else {
        @Suppress("DEPRECATION")
        intent.getParcelableExtra(Intent.EXTRA_STREAM)
    }

    private fun requireDocumentActivity(result: MethodChannel.Result): Activity? = activity.also {
        if (it == null) result.error("android/activity-unavailable", "A document picker requires a visible Activity.", null)
    }
    private fun bindingPreferences() = context.getSharedPreferences("busymax_android_authorization", Context.MODE_PRIVATE)
    private fun bindingKey(provider: String, accountId: String) = "$provider|$accountId"
    private fun readBinding(provider: String, accountId: String): JSONObject? = bindingPreferences().getString(bindingKey(provider, accountId), null)?.let {
        try { JSONObject(it) } catch (_: Exception) { null }
    }
    private fun tryPersistPermission(uri: Uri, flags: Int) { try { context.contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {} }
    private fun displayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try { cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null); if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else null }
        finally { cursor?.close() }
    }
    private fun safeFileName(value: String, fallback: String): String = value.trim().replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").take(120).ifBlank { fallback }
    private fun stringList(values: List<*>?) = values.orEmpty().mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotEmpty) }.distinct()
    private fun safeError(error: Throwable) = error.javaClass.simpleName
    private fun postSuccess(result: MethodChannel.Result, value: Any?) { main.post { result.success(value) } }
    private fun postError(result: MethodChannel.Result, code: String, message: String, error: Throwable?) { main.post { result.error(code, message, error?.let(::safeError)) } }

    private data class PendingInteractive(val provider: String, val result: MethodChannel.Result, val requestCode: Int, val authorizationAttemptId: String?)
    private data class ExportResource(val name: String, val bytes: ByteArray)
    private sealed class PendingDocument(val result: MethodChannel.Result, val requestCode: Int) {
        class Open(result: MethodChannel.Result, val maximumBytes: Long) : PendingDocument(result, OPEN_DOCUMENT_REQUEST)
        class Create(result: MethodChannel.Result, val bytes: ByteArray) : PendingDocument(result, CREATE_DOCUMENT_REQUEST)
        class Tree(result: MethodChannel.Result, val folderName: String, val resources: List<ExportResource>) : PendingDocument(result, OPEN_TREE_REQUEST)
    }

    companion object {
        private const val METHOD_CHANNEL = "io.busystack.busymax/android"
        private const val EVENT_CHANNEL = "io.busystack.busymax/events"
        private const val GOOGLE_AUTH_REQUEST = 7101
        private const val OPEN_DOCUMENT_REQUEST = 7102
        private const val CREATE_DOCUMENT_REQUEST = 7103
        private const val OPEN_TREE_REQUEST = 7104
        private const val LOCAL_NETWORK_REQUEST = 7105
        private const val ACCESS_LOCAL_NETWORK = "android.permission.ACCESS_LOCAL_NETWORK"
        private const val MAX_IMPORT_BYTES = 16L * 1024L * 1024L
        private const val MAX_EXPORT_BYTES = 32 * 1024 * 1024
        private const val MAX_TREE_EXPORT_BYTES = 64L * 1024L * 1024L
        private const val MAX_EXPORT_RESOURCES = 512
        private val activePlugins = ConcurrentHashMap.newKeySet<BusymaxAndroidPlatformPlugin>()
    }
}
