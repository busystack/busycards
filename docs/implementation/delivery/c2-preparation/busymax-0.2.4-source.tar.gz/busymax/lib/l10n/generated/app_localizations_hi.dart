// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax आपके डेस्कटॉप की स्टार्टअप सेटिंग से शुरू हुआ था। वहाँ से इसकी प्रविष्टि हटाएँ, फिर इस स्विच का उपयोग करने के लिए BusyMax से बाहर निकलें और इसे दोबारा खोलें।';

  @override
  String get timeFormat => 'समय प्रारूप';

  @override
  String get firstDayOfWeek => 'सप्ताह का पहला दिन';

  @override
  String get systemDefault => 'सिस्टम डिफ़ॉल्ट';

  @override
  String systemDefaultResolved(String weekday) {
    return 'सिस्टम डिफ़ॉल्ट ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 घंटे';

  @override
  String get timeFormatTwentyFourHour => '24 घंटे';

  @override
  String get timeEndOfDay => 'दिन का अंत';

  @override
  String get timePeriod => 'दिन की अवधि';

  @override
  String get launchAtLoginReadFailed =>
      'लॉगिन पर शुरू होने की स्थिति का पता नहीं चल सका।';

  @override
  String get launchAtLoginUnavailable =>
      'इस सिस्टम पर लॉगिन के समय शुरू करना उपलब्ध नहीं है।';

  @override
  String get windowsStartupEnabledByPolicy =>
      'आपके व्यवस्थापक ने स्वचालित शुरुआत चालू की है और इसे यहाँ बदला नहीं जा सकता।';

  @override
  String get settingsSaveFailed =>
      'सेटिंग्स सहेजी नहीं जा सकीं। BusyMax फिर से शुरू होने पर आपके बदलाव खो सकते हैं।';

  @override
  String get nextcloudExportCollection => 'संग्रह के संसाधन निर्यात करें';

  @override
  String nextcloudImportItems(int count) {
    return '$count इवेंट/कार्य संसाधन मिले';
  }

  @override
  String get nextcloudSchedulingInbox => 'निमंत्रण इनबॉक्स';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud इन संदेशों को आपके कैलेंडर में संसाधित करता है। पुष्टि करने पर केवल संदेश हटता है, इवेंट नहीं।';

  @override
  String get nextcloudInboxEmpty => 'कोई शेड्यूलिंग संदेश नहीं।';

  @override
  String get nextcloudAcknowledge => 'संदेश की प्राप्ति स्वीकारें';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'यह संदेश इनबॉक्स से हटाएँ? कैलेंडर इवेंट बना रहेगा।';

  @override
  String get nextcloudGuestAvailability => 'अतिथियों की उपलब्धता जाँचें';

  @override
  String nextcloudTrashRetention(int days) {
    return 'सर्वर के कूड़ेदान में रखने की अवधि: $days दिन';
  }

  @override
  String get nextcloudCancelMeeting => 'मीटिंग रद्द करें';

  @override
  String get nextcloudDeclineAndRemove => 'निमंत्रण अस्वीकार करके हटाएँ';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'सिंक होने पर अस्वीकृति भेजी जाएगी। आयोजक की मीटिंग रद्द नहीं होगी।';

  @override
  String get nextcloudAvailabilityUnknown => 'उपलब्धता अज्ञात';

  @override
  String get nextcloudAvailabilityFree =>
      'इस अंतराल में व्यस्त समय की सूचना नहीं मिली';

  @override
  String get nextcloudAvailabilityBusy => 'व्यस्त समय';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud सिंक होने पर मीटिंग के अपडेट भेजेगा। स्थानीय रूप से सहेजना डिलीवरी की पुष्टि नहीं है।';

  @override
  String get nextcloudAttendeeRestrictions =>
      'केवल आयोजक या अधिकृत प्रतिनिधि मीटिंग के विवरण बदल सकता है। निमंत्रण के विवरण से उत्तर दिया जा सकता है।';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'इस मीटिंग को कॉपी करके हटाने के तरीके से स्थानांतरित नहीं किया जा सकता। उसी शेड्यूलिंग पहचान वाला कैलेंडर इस्तेमाल करें।';

  @override
  String get nextcloudSchedulingStatus => 'सर्वर की शेड्यूलिंग स्थिति';

  @override
  String get nextcloudImportFollowUp =>
      'आयातित संसाधन स्थानीय रूप से सहेजे गए। रिमाइंडर रीफ़्रेश होना बाकी है; दोबारा आयात न करें।';

  @override
  String get nextcloudNativeImport =>
      'निमंत्रण भेजे बिना पूर्ण इवेंट और कार्य आयात करें। नई प्रतियाँ न चुनने पर मौजूदा UID छोड़ दिए जाते हैं। असमर्थित संसाधनों की अलग-अलग सूचना दी जाती है।';

  @override
  String get nextcloudImportMethod =>
      'इस फ़ाइल में शेड्यूलिंग संदेश हैं। आयात सामग्री सहेजता है और METHOD हटाता है; निमंत्रण या उत्तर संसाधित नहीं करता।';

  @override
  String get nextcloudImportCopies =>
      'नई पहचान वाली नई प्रतियों के रूप में आयात करें';

  @override
  String get nextcloudCollectionSettings => 'संग्रह की सेटिंग';

  @override
  String get nextcloudSharing => 'साझा करना';

  @override
  String get nextcloudOwned => 'स्वयं का';

  @override
  String get nextcloudShared => 'साझा किया गया';

  @override
  String get nextcloudDelegated => 'प्रत्यायोजित';

  @override
  String get nextcloudSubscription => 'सदस्यता';

  @override
  String get nextcloudDeleted => 'हटाया गया';

  @override
  String get nextcloudMetadataEditable =>
      'कैलेंडर सामग्री केवल पढ़ने योग्य है; संग्रह के गुण बदले जा सकते हैं।';

  @override
  String get nextcloudServerOrder => 'सर्वर का क्रम (साइडबार के क्रम से अलग)';

  @override
  String get nextcloudCalendarEnabled => 'सर्वर पर सक्षम';

  @override
  String get nextcloudAvailability => 'इस संग्रह को उपलब्धता में शामिल करें';

  @override
  String get nextcloudCalendarTimezone =>
      'कैलेंडर का समय क्षेत्र (VTIMEZONE दस्तावेज़)';

  @override
  String get nextcloudRefreshPending =>
      'बदलाव Nextcloud पर सहेजा गया। रीफ़्रेश होना बाकी है; बदलाव न दोहराएँ।';

  @override
  String get nextcloudOutcomeUnknown =>
      'सर्वर के परिणाम की पुष्टि नहीं हो सकी। फिर कोशिश करने से पहले रीफ़्रेश करें।';

  @override
  String get nextcloudRemoveShared => 'साझा कैलेंडर/सूची हटाएँ';

  @override
  String get nextcloudRemoveMixed =>
      'इस संग्रह में इवेंट और कार्य हैं। इसे हटाने से दोनों हटेंगे।';

  @override
  String get nextcloudReadAccess => 'केवल पढ़ें';

  @override
  String get nextcloudWriteAccess => 'पढ़ें और लिखें';

  @override
  String get nextcloudRecipientSearch => 'लोग या समूह खोजें';

  @override
  String get nextcloudNoRecipients => 'कोई मेल खाता व्यक्ति या समूह नहीं।';

  @override
  String get nextcloudRevokeShare => 'पहुँच रद्द करें';

  @override
  String get nextcloudPublish => 'लिंक प्रकाशित करें';

  @override
  String get nextcloudUnpublish => 'प्रकाशन बंद करें';

  @override
  String get nextcloudPublishWarning =>
      'प्रकाशित लिंक वाला कोई भी व्यक्ति यह कैलेंडर पढ़ सकता है। प्रकाशित करें?';

  @override
  String get nextcloudTrash => 'हटाए गए कैलेंडर और कार्य';

  @override
  String get nextcloudTrashEmpty => 'कैलेंडर का कोई हटाया गया आइटम नहीं।';

  @override
  String get nextcloudRestore => 'पुनर्स्थापित करें';

  @override
  String get nextcloudPermanentDelete => 'हमेशा के लिए हटाएँ';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'यह आइटम हमेशा के लिए हटाएँ? इसे Nextcloud के कैलेंडर कूड़ेदान से पुनर्स्थापित नहीं किया जा सकेगा।';

  @override
  String get nextcloudOperationDenied =>
      'Nextcloud ने इस कार्रवाई की अनुमति नहीं दी।';

  @override
  String get nextcloudUnsupported => 'सर्वर इस कार्रवाई का समर्थन नहीं करता।';

  @override
  String get nextcloudPendingChanges =>
      'बंद करने से पहले संग्रह के बदलाव सहेजें या छोड़ें।';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud से संपर्क नहीं हो सका। कैश किए गए आइटम और लंबित काम सुरक्षित हैं।';

  @override
  String get mapsShow => 'मानचित्र पर दिखाएँ';

  @override
  String get openLink => 'लिंक खोलें';

  @override
  String get externalLocationOpenFailed =>
      'स्थान को किसी बाहरी ऐप में नहीं खोला जा सका।';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'इवेंट का समय नहीं बदला जा सका। उसका सहेजा गया समय नहीं बदला है।';

  @override
  String get scheduleRescheduleStale =>
      'खींचते समय यह इवेंट बदल गया। कृपया फिर से कोशिश करें।';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'नया समय सहेज लिया गया, लेकिन रिमाइंडर अपडेट नहीं हो सके।';

  @override
  String get moveUp => 'ऊपर ले जाएँ';

  @override
  String get moveDown => 'नीचे ले जाएँ';

  @override
  String get windowsSupport => 'सहायता';

  @override
  String get windowsThirdPartyLicenses => 'तृतीय-पक्ष लाइसेंस';

  @override
  String get windowsSearch => 'खोजें';

  @override
  String get windowsStartupDisabledByUser =>
      'उपयोगकर्ता ने Windows सेटिंग में इसे बंद किया है।';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Windows नीति द्वारा बंद किया गया है।';

  @override
  String get windowsStartupUnavailable =>
      'BusyMax को MSIX पैकेज से इंस्टॉल करने के बाद उपलब्ध होगा।';

  @override
  String get windowsReminderExitNotice =>
      'BusyMax को पूरी तरह बंद करने पर रिमाइंडर रुक जाते हैं। उन्हें पाने के लिए इसे पृष्ठभूमि में चलने दें।';

  @override
  String get windowsProductVersionLabel => 'उत्पाद संस्करण';

  @override
  String get windowsPackageVersionLabel => 'Windows पैकेज संस्करण';

  @override
  String get windowsUnpackaged => 'पैकेज रहित';

  @override
  String get windowsAgendaLoadMore => 'एजेंडा के और आइटम लोड करें';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'सोमवार',
      'TU': 'मंगलवार',
      'WE': 'बुधवार',
      'TH': 'गुरुवार',
      'FR': 'शुक्रवार',
      'SA': 'शनिवार',
      'SU': 'रविवार',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'की $first और $second तारीखों को';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $month की $firstDay और $secondDay तारीखों को';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency $firstMonth और $secondMonth की $day तारीख को';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $firstMonth और $secondMonth की $firstDay और $secondDay तारीखों को';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency $firstMonth और $secondMonth की $days तारीखों को';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Google, Microsoft, Apple iCloud Calendar या Nextcloud खाते कनेक्ट करें।';

  @override
  String get googlePermissionsConsentNotice =>
      'Google अनुमति स्क्रीन पर, कैलेंडर और कार्य दोनों अनुमतियाँ चुनें।';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google Calendar और Google Tasks की अनुमतियाँ आवश्यक हैं। फिर से कोशिश करें और दोनों चेकबॉक्स चुनें।';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'यह प्रदाता कॉन्फ़िगर नहीं किया गया है।';

  @override
  String get waitingForGoogleSignIn =>
      'Google साइन-इन की प्रतीक्षा हो रही है...';

  @override
  String get waitingForMicrosoftSignIn =>
      'Microsoft साइन-इन की प्रतीक्षा हो रही है...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsoft साइन-इन कॉन्फ़िगर नहीं है। MICROSOFT_OAUTH_CLIENT_ID सेट करें।';

  @override
  String get cancel => 'रद्द करें';

  @override
  String get close => 'बंद करें';

  @override
  String get windowMinimize => 'छोटा करें';

  @override
  String get windowMaximize => 'अधिकतम करें';

  @override
  String get windowRestore => 'पुनर्स्थापित करें';

  @override
  String get exit => 'बाहर निकलें';

  @override
  String get options => 'विकल्प';

  @override
  String get hide => 'छिपाएँ';

  @override
  String get show => 'दिखाएँ';

  @override
  String get export => 'निर्यात करें';

  @override
  String get save => 'सहेजें';

  @override
  String get settings => 'सेटिंग्स';

  @override
  String get all => 'सभी';

  @override
  String get calendarEvents => 'इवेंट';

  @override
  String get calendarTasks => 'कार्य';

  @override
  String get calendar => 'कैलेंडर';

  @override
  String get calendars => 'कैलेंडर';

  @override
  String get newCalendar => 'नया कैलेंडर';

  @override
  String get calendarColor => 'कैलेंडर का रंग';

  @override
  String calendarColorOption(int number) {
    return 'रंग $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'यह प्रदाता BusyMax में कैलेंडर प्रबंधन का समर्थन नहीं करता है।';

  @override
  String get primaryCalendarCannotDelete =>
      'प्राथमिक कैलेंडर को हटाया नहीं जा सकता।';

  @override
  String calendarCreateFailed(String error) {
    return 'कैलेंडर नहीं बनाया जा सका: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'कैलेंडर बन गया, लेकिन BusyMax खाते को रीफ़्रेश नहीं कर सका। यह अगली सिंक के बाद दिखाई देगा।';

  @override
  String calendarUpdateFailed(String error) {
    return 'कैलेंडर अपडेट नहीं किया जा सका: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'कैलेंडर हटाया नहीं जा सका: $error';
  }

  @override
  String get newEvent => 'नया इवेंट';

  @override
  String get refreshCalendar => 'कैलेंडर रीफ़्रेश करें';

  @override
  String get openInProvider => 'सेवा में खोलें';

  @override
  String get linkedResources => 'लिंक किए गए संसाधन';

  @override
  String get noLinkedResources => 'कोई लिंक किया गया संसाधन नहीं';

  @override
  String get attachments => 'अटैचमेंट';

  @override
  String get attachmentsNotLoaded => 'अटैचमेंट लोड नहीं हुए';

  @override
  String get hideFromSchedule => 'शेड्यूल से छिपाएँ';

  @override
  String get showInSchedule => 'शेड्यूल में दिखाएँ';

  @override
  String get noCalendarsSynced => 'अभी तक कोई कैलेंडर सिंक नहीं हुआ है।';

  @override
  String get allDay => 'पूरे दिन';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString और';
  }

  @override
  String get noEventsOrTasks => 'कोई इवेंट या कार्य नहीं';

  @override
  String get scheduleLoading => 'शेड्यूल लोड हो रहा है...';

  @override
  String get scheduleUnavailable => 'शेड्यूल उपलब्ध नहीं है';

  @override
  String get scheduleNoSources =>
      'कोई दिखाई देने वाला कैलेंडर या कार्य सूची नहीं';

  @override
  String get scheduleNoSourcesDescription =>
      'सेटिंग्स में चुनें कि क्या दिखाना है, फिर रीफ़्रेश करें।';

  @override
  String get scheduleNoSearchResults => 'कोई मिलता-जुलता इवेंट या कार्य नहीं';

  @override
  String get scheduleNoSearchResultsDescription =>
      'कोई दूसरी खोज आज़माएँ या मौजूदा फ़िल्टर हटाएँ।';

  @override
  String get refresh => 'रीफ़्रेश करें';

  @override
  String get trayOpenBusyMax => 'BusyMax खोलें';

  @override
  String get trayShowBusyMax => 'BusyMax दिखाएँ';

  @override
  String get trayNewEvent => 'नया इवेंट…';

  @override
  String get trayNewTask => 'नया कार्य…';

  @override
  String get trayToday => 'आज';

  @override
  String get trayAllDay => 'पूरा दिन';

  @override
  String get trayNow => 'अभी';

  @override
  String get trayCalendarEvent => 'कैलेंडर इवेंट';

  @override
  String get trayUntitledEvent => 'बिना शीर्षक का इवेंट';

  @override
  String get trayNothingElseToday => 'आज और कुछ नहीं';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'आज $count कार्यों की नियत तारीख है',
      one: 'आज 1 कार्य की नियत तारीख है',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'आज का एजेंडा खोलें';

  @override
  String get traySyncNow => 'अभी सिंक करें';

  @override
  String get traySyncing => 'सिंक हो रहा है…';

  @override
  String get trayNotConnected => 'कनेक्ट नहीं है';

  @override
  String get trayNotYetSynced => 'अभी तक सिंक नहीं हुआ';

  @override
  String get trayLastSyncedJustNow => 'अभी-अभी सिंक हुआ';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count मिनट पहले सिंक हुआ',
      one: '1 मिनट पहले सिंक हुआ',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count घंटे पहले सिंक हुआ',
      one: '1 घंटे पहले सिंक हुआ',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count दिन पहले सिंक हुआ',
      one: '1 दिन पहले सिंक हुआ',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'सेटिंग्स';

  @override
  String get trayQuitBusyMax => 'BusyMax बंद करें';

  @override
  String get agendaLoadMoreOverdue =>
      'समय-सीमा पार कर चुके अतिरिक्त कार्य लोड करें';

  @override
  String get agendaLoadMoreNoDate => 'बिना तारीख वाले और कार्य लोड करें';

  @override
  String get viewDay => 'दिन';

  @override
  String get viewWeek => 'सप्ताह';

  @override
  String get viewMonth => 'महीना';

  @override
  String get viewYear => 'वर्ष';

  @override
  String get viewAgenda => 'कार्यसूची';

  @override
  String get scheduleSettings => 'शेड्यूल';

  @override
  String get scheduleDisplaySettings => 'शेड्यूल प्रदर्शन';

  @override
  String get newEventsAndTasks => 'नए इवेंट और कार्य';

  @override
  String get defaultCalendar => 'डिफ़ॉल्ट कैलेंडर';

  @override
  String get defaultTaskList => 'डिफ़ॉल्ट कार्य सूची';

  @override
  String get lastUsed => 'पिछली बार उपयोग किया गया';

  @override
  String get scheduleDisplayHoursDescription =>
      'दिन और सप्ताह दृश्य शुरू में यह समयावधि दिखाते हैं। आवश्यकता होने पर पहले या बाद के आइटम इस सीमा को बढ़ाते हैं।';

  @override
  String get scheduleDayStartsAt => 'दिन शुरू होता है';

  @override
  String get scheduleDayEndsAt => 'दिन समाप्त होता है';

  @override
  String get sourceCalendar => 'कैलेंडर';

  @override
  String get sourceTaskList => 'कार्य सूची';

  @override
  String get createChoiceTitle => 'बनाएँ';

  @override
  String get createEventAtTime => 'इवेंट';

  @override
  String get createTaskAtDate => 'कार्य';

  @override
  String get editEvent => 'इवेंट संपादित करें';

  @override
  String get eventTitle => 'इवेंट का शीर्षक';

  @override
  String get location => 'स्थान';

  @override
  String get timeSlot => 'समयावधि';

  @override
  String get startDateTime => 'शुरू होने की तारीख/समय';

  @override
  String get endDateTime => 'समाप्त होने की तारीख/समय';

  @override
  String get doesNotRepeat => 'दोहराया नहीं जाता';

  @override
  String get defaultReminder => 'डिफ़ॉल्ट रिमाइंडर';

  @override
  String get guests => 'अतिथि';

  @override
  String get noGuests => 'कोई अतिथि नहीं';

  @override
  String get attendeeRequired => 'ज़रूरी';

  @override
  String get attendeeOptional => 'वैकल्पिक';

  @override
  String get meetingSection => 'मीटिंग';

  @override
  String get addGoogleMeet => 'Google Meet जोड़ें';

  @override
  String get addTeamsMeeting => 'Microsoft Teams मीटिंग जोड़ें';

  @override
  String get onlineMeetingAdded => 'ऑनलाइन मीटिंग जोड़ी गई';

  @override
  String get requestResponses => 'जवाब माँगें';

  @override
  String get requestResponsesDescription =>
      'अतिथियों से आमंत्रण का जवाब देने को कहें।';

  @override
  String get hideGuestList => 'अतिथि सूची छिपाएँ';

  @override
  String get hideGuestListDescription =>
      'अतिथि यह नहीं देख सकते कि और किसे आमंत्रित किया गया है।';

  @override
  String get allowNewTimeProposals => 'नए समय प्रस्तावों की अनुमति दें';

  @override
  String get allowNewTimeProposalsDescription =>
      'अतिथि मीटिंग का अलग समय सुझा सकते हैं।';

  @override
  String get notifyGuestsTitle => 'अतिथियों को सूचित करें?';

  @override
  String get notifyGuestsSaveMessage =>
      'इस मीटिंग में अतिथि हैं। सहेजते समय आमंत्रण या इवेंट अपडेट भेजें?';

  @override
  String get notifyGuestsDeleteMessage =>
      'इस मीटिंग में अतिथि हैं। हटाते समय रद्दीकरण भेजें?';

  @override
  String get sendUpdates => 'अपडेट भेजें';

  @override
  String get sendCancellation => 'रद्दीकरण भेजें';

  @override
  String get doNotSend => 'न भेजें';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'मीटिंग सहेजें?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft अतिथियों को आमंत्रण या इवेंट अपडेट भेजेगा।';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'मीटिंग हटाएँ?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft अतिथियों को रद्दीकरण भेजेगा।';

  @override
  String get organizer => 'आयोजक';

  @override
  String get yourResponse => 'आपका जवाब';

  @override
  String get guestResponses => 'अतिथियों के जवाब';

  @override
  String get respond => 'जवाब दें';

  @override
  String get acceptInvitation => 'स्वीकार करें';

  @override
  String get tentativeInvitation => 'अनिश्चित';

  @override
  String get declineInvitation => 'अस्वीकार करें';

  @override
  String get joinMeeting => 'मीटिंग में शामिल हों';

  @override
  String get responseAccepted => 'स्वीकृत';

  @override
  String get responseTentative => 'अनिश्चित';

  @override
  String get responseDeclined => 'अस्वीकृत';

  @override
  String get responseNeedsAction => 'जवाब की प्रतीक्षा है';

  @override
  String get responseNotResponded => 'जवाब नहीं दिया';

  @override
  String get responseOrganizer => 'आयोजक';

  @override
  String invitationResponseFailed(String error) {
    return 'आपका जवाब भेजा नहीं जा सका: $error';
  }

  @override
  String get joinMeetingFailed => 'मीटिंग लिंक खोला नहीं जा सका।';

  @override
  String get description => 'विवरण';

  @override
  String get availabilityShowAs => 'उपलब्धता / इस रूप में दिखाएँ';

  @override
  String get busy => 'व्यस्त';

  @override
  String get visibility => 'दृश्यता';

  @override
  String get defaultVisibility => 'डिफ़ॉल्ट दृश्यता';

  @override
  String get conference => 'कॉन्फ़्रेंस';

  @override
  String get noConference => 'कोई कॉन्फ़्रेंस नहीं';

  @override
  String get providerCalendar => 'प्रदाता कैलेंडर';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => 'बोल्ड';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => 'इटैलिक';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => 'रेखांकित';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString मिनट पहले',
      one: '1 मिनट पहले',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'शुरू होने पर';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString घंटे पहले',
      one: '1 घंटा पहले',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString दिन पहले',
      one: '1 दिन पहले',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'खाली';

  @override
  String get availabilityTentative => 'अस्थायी';

  @override
  String get availabilityOutOfOffice => 'कार्यालय से बाहर';

  @override
  String get availabilityWorkingElsewhere => 'किसी अन्य स्थान पर कार्यरत';

  @override
  String get visibilityDefault => 'डिफ़ॉल्ट';

  @override
  String get visibilityPublic => 'सार्वजनिक';

  @override
  String get visibilityPrivate => 'निजी';

  @override
  String get visibilityConfidential => 'गोपनीय';

  @override
  String get sensitivityNormal => 'सामान्य';

  @override
  String get sensitivityPersonal => 'व्यक्तिगत';

  @override
  String get tasks => 'कार्य';

  @override
  String get allTasks => 'सभी कार्य';

  @override
  String tasksInList(String title) {
    return '$title में कार्य';
  }

  @override
  String get taskLists => 'कार्य सूचियाँ';

  @override
  String get navigation => 'नेविगेशन';

  @override
  String get mainMenu => 'मुख्य मेन्यू';

  @override
  String get keyboardShortcuts => 'कीबोर्ड शॉर्टकट';

  @override
  String get shortcutGroupGeneral => 'सामान्य';

  @override
  String get shortcutKeyboardShortcutsDescription => 'यह शॉर्टकट संदर्भ दिखाएँ';

  @override
  String get shortcutGroupNavigation => 'नेविगेशन';

  @override
  String get shortcutNextPeriod => 'अगली अवधि';

  @override
  String get shortcutNextPeriodDescription =>
      'सप्ताह दृश्य में अगला सप्ताह, महीने के दृश्य में अगला महीना, इत्यादि';

  @override
  String get shortcutPreviousPeriod => 'पिछली अवधि';

  @override
  String get shortcutPreviousPeriodDescription =>
      'सप्ताह दृश्य में पिछला सप्ताह, महीने के दृश्य में पिछला महीना, इत्यादि';

  @override
  String get shortcutJumpToToday => 'आज की तारीख पर जाएँ';

  @override
  String get shortcutGroupView => 'दृश्य';

  @override
  String get viewSelector => 'दृश्य';

  @override
  String get shortcutDayView => 'दिन का दृश्य';

  @override
  String get shortcutWeekView => 'सप्ताह का दृश्य';

  @override
  String get shortcutMonthView => 'महीने का दृश्य';

  @override
  String get shortcutYearView => 'वर्ष का दृश्य';

  @override
  String get shortcutAgendaView => 'कार्यसूची दृश्य';

  @override
  String get shortcutGroupCreateAndEdit => 'बनाएँ और संपादित करें';

  @override
  String get shortcutSaveItem => 'इवेंट या कार्य सहेजें';

  @override
  String get shortcutDeleteItem => 'इवेंट या कार्य मिटाएँ';

  @override
  String get shortcutGroupTaskEditing => 'कार्य संपादन';

  @override
  String get shortcutCancelEditing => 'संपादन रद्द करें';

  @override
  String get shortcutCancelEditingDescription =>
      'कार्य संपादन या कार्य विवरण बंद करें';

  @override
  String get aboutBusyMax => 'BusyMax के बारे में';

  @override
  String get aboutBusyMaxDescription => 'कैलेंडर और कार्य';

  @override
  String get license => 'लाइसेंस';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'वेबसाइट';

  @override
  String get sourceCode => 'स्रोत कोड';

  @override
  String get reportAnIssue => 'समस्या की रिपोर्ट करें';

  @override
  String get sendFeedback => 'प्रतिक्रिया भेजें';

  @override
  String get feedbackSubmit => 'सबमिट करें';

  @override
  String get feedbackCategory => 'श्रेणी';

  @override
  String get feedbackSelectCategory => 'श्रेणी चुनें';

  @override
  String get feedbackCategoryProblem => 'समस्या या बग';

  @override
  String get feedbackCategoryFeature => 'सुविधा का अनुरोध';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'गोपनीयता या सुरक्षा संबंधी चिंता';

  @override
  String get feedbackCategoryUsability => 'उपयोगिता संबंधी चिंता';

  @override
  String get feedbackCategoryOther => 'अन्य';

  @override
  String get feedbackSubject => 'विषय';

  @override
  String get feedbackDetailedMessage => 'विस्तृत संदेश';

  @override
  String get feedbackReplyEmail => 'जवाब के लिए ईमेल (वैकल्पिक)';

  @override
  String get feedbackIncludeTechnicalDetails => 'तकनीकी विवरण शामिल करें';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'केवल आपके ऑपरेटिंग सिस्टम का नाम और संस्करण तथा ऐप की भाषा व क्षेत्रीय सेटिंग जोड़ी जाती है। लॉग, खाता डेटा, फ़ाइल नाम या अन्य निदान जानकारी शामिल नहीं की जाती।';

  @override
  String get feedbackCategoryRequired => 'श्रेणी चुनें।';

  @override
  String get feedbackSubjectLengthError =>
      'विषय 3 से 120 वर्णों के बीच होना चाहिए।';

  @override
  String get feedbackMessageLengthError =>
      'संदेश 10 से 5,000 वर्णों के बीच होना चाहिए।';

  @override
  String get feedbackInvalidEmail => 'मान्य ईमेल पता दर्ज करें।';

  @override
  String get feedbackConnectionError =>
      'BusyStack से कनेक्ट नहीं हो सका। अपना कनेक्शन जाँचें और फिर कोशिश करें।';

  @override
  String get feedbackTimeoutError =>
      'अनुरोध का समय समाप्त हो गया। आपकी प्रतिक्रिया हटाई नहीं गई है; फिर से कोशिश करें।';

  @override
  String get feedbackRateLimitedError =>
      'इस नेटवर्क से बहुत अधिक प्रतिक्रियाएँ भेजी गई हैं। प्रतीक्षा करें और फिर कोशिश करें।';

  @override
  String get feedbackRejectedError =>
      'सर्वर ने सबमिशन अस्वीकार कर दिया। फ़ील्ड की समीक्षा करें और फिर कोशिश करें।';

  @override
  String get feedbackServerError =>
      'BusyStack अभी आपकी प्रतिक्रिया स्वीकार नहीं कर सका। आपकी प्रतिक्रिया हटाई नहीं गई है; फिर से कोशिश करें।';

  @override
  String feedbackSuccess(String id) {
    return 'प्रतिक्रिया भेज दी गई। संदर्भ: $id';
  }

  @override
  String get toggleSidebar => 'साइडबार दिखाएँ या छिपाएँ';

  @override
  String get showSidebar => 'साइडबार पैनल दिखाएँ';

  @override
  String get hideSidebar => 'साइडबार पैनल छिपाएँ';

  @override
  String get accounts => 'खाते';

  @override
  String get currentAccount => 'मौजूदा खाता';

  @override
  String get switchAccount => 'खाता बदलें';

  @override
  String get addGoogleAccount => 'Google खाता जोड़ें';

  @override
  String get addMicrosoftAccount => 'Microsoft खाता जोड़ें';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'साइन इन है';

  @override
  String get removeAccount => 'खाता हटाएँ…';

  @override
  String get removingAccount => 'खाता हटाया जा रहा है…';

  @override
  String get removeAccountDescription =>
      'सिंक करना बंद करें और इस डिवाइस से इस खाते का डेटा हटाएँ।';

  @override
  String removeAccountTitle(String account) {
    return '$account को BusyMax से हटाएँ?';
  }

  @override
  String get removeAccountConfirmation =>
      'इससे इस डिवाइस से कैश किए गए कार्य, कैलेंडर, इवेंट, रिमाइंडर और लंबित ऑफ़लाइन बदलाव हट जाएँगे। सिंक न किए गए बदलाव खो जाएँगे। प्रदाता की कैलेंडर, इवेंट, कार्य सूची और कार्य प्रतियाँ हटाई नहीं जाएँगी।';

  @override
  String get revokeGoogleAccess =>
      'इस Google खाते से BusyMax की पहुँच भी रद्द करें';

  @override
  String get revokeGoogleAccessDescription =>
      'दोबारा कनेक्ट करने से पहले आपको फिर से पहुँच देनी होगी।';

  @override
  String get removeAccountAction => 'खाता हटाएँ';

  @override
  String get removeAccountFailed =>
      'खाता हटाना पूरा नहीं हो सका। फिर से कोशिश करें।';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'खाता इस डिवाइस से हटा दिया गया, लेकिन BusyMax की Google खाते तक पहुँच रद्द नहीं की जा सकी। आप यह पहुँच अपने Google खाते से रद्द कर सकते हैं।';

  @override
  String get newTaskList => 'नई कार्य सूची';

  @override
  String taskListCreateFailed(String error) {
    return 'कार्य सूची बनाई नहीं जा सकी: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'कार्य सूची का नाम बदला नहीं जा सका: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'कार्य सूची हटाई नहीं जा सकी: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'सूची को मिटाने या हटाने से पहले खाते को सिंक करें, या डायग्नोस्टिक्स में इस कार्य सूची के अवरुद्ध बदलावों का समाधान करें।';

  @override
  String get signInToViewTaskLists =>
      'कार्य सूचियाँ देखने के लिए साइन इन करें।';

  @override
  String get noTaskListsSynced => 'अभी तक कोई कार्य सूची सिंक नहीं हुई है।';

  @override
  String get listActions => 'सूची की कार्रवाइयाँ';

  @override
  String get rename => 'नाम बदलें';

  @override
  String get delete => 'मिटाएँ';

  @override
  String get renameList => 'सूची का नाम बदलें';

  @override
  String get deleteList => 'सूची मिटाएँ';

  @override
  String get unshare => 'साझा करना बंद करें';

  @override
  String get readOnlyTaskListCannotRename =>
      'यह कार्य सूची केवल-पठन है और इसका नाम नहीं बदला जा सकता।';

  @override
  String get taskListCannotDelete =>
      'आपकी मौजूदा अनुमतियों से यह कार्य सूची हटाई नहीं जा सकती।';

  @override
  String get builtInMicrosoftList => 'अंतर्निहित';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Microsoft To Do की अंतर्निहित सूचियों का नाम बदला या उन्हें मिटाया नहीं जा सकता।';

  @override
  String deleteListConfirmation(String title) {
    return 'Google Tasks से “$title” हटाएँ?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '“$title” और इसके सभी कार्य हटाएँ?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'इस खाते से “$title” साझा करना बंद करें?';
  }

  @override
  String get deleteEvent => 'इवेंट मिटाएँ';

  @override
  String get title => 'शीर्षक';

  @override
  String get create => 'बनाएँ';

  @override
  String get newTask => 'नया कार्य';

  @override
  String get clearCompleted => 'पूरे हुए कार्य हटाएँ';

  @override
  String get refreshList => 'सूची रीफ़्रेश करें';

  @override
  String get refreshAll => 'सभी रीफ़्रेश करें';

  @override
  String get listRefreshed => 'सूची रीफ़्रेश हो गई।';

  @override
  String get allTasksRefreshed => 'सभी खाते रीफ़्रेश हो गए।';

  @override
  String exportedFile(String path) {
    return '$path में निर्यात किया गया';
  }

  @override
  String exportFailed(String error) {
    return 'निर्यात विफल: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'रीफ़्रेश विफल: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'शुरू करने के लिए कार्य सूची चुनें या बनाएँ।';

  @override
  String get signInToViewTasks => 'कार्य देखने के लिए साइन इन करें।';

  @override
  String get noTasks => 'कोई कार्य नहीं।';

  @override
  String get noTasksYet => 'अभी तक कोई कार्य नहीं';

  @override
  String get noTasksYetMessage =>
      'शुरू करने के लिए कार्य बनाएँ या अपने खाते रीफ़्रेश करें।';

  @override
  String get noTasksInList => 'इस सूची में कोई कार्य नहीं है।';

  @override
  String get overdue => 'समय सीमा बीत चुकी';

  @override
  String get today => 'आज';

  @override
  String get tomorrow => 'कल';

  @override
  String get upcoming => 'आगामी';

  @override
  String get noDate => 'कोई तारीख नहीं';

  @override
  String get completed => 'पूर्ण';

  @override
  String duePrefix(String date) {
    return '$date को देय';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => 'कार्य का विवरण';

  @override
  String get editTask => 'कार्य संपादित करें';

  @override
  String get noTaskSelected => 'कोई कार्य नहीं चुना गया।';

  @override
  String get noTaskSelectedHelper =>
      'विवरण देखने और संपादित करने के लिए कोई कार्य चुनें।';

  @override
  String get taskUnavailable => 'कार्य उपलब्ध नहीं है।';

  @override
  String get signInToEditTasks => 'कार्य संपादित करने के लिए साइन इन करें।';

  @override
  String get refreshTask => 'कार्य रीफ़्रेश करें';

  @override
  String get primarySection => 'मुख्य';

  @override
  String get statusSection => 'स्थिति';

  @override
  String get openStatus => 'खुला';

  @override
  String get doneStatus => 'पूर्ण';

  @override
  String get taskStatus => 'स्थिति';

  @override
  String get taskStatusNone => 'कोई स्थिति नहीं';

  @override
  String get taskStatusNeedsAction => 'कार्रवाई आवश्यक';

  @override
  String get taskStatusInProcess => 'प्रगति में';

  @override
  String get taskStatusCompleted => 'पूर्ण';

  @override
  String get taskStatusCancelled => 'रद्द';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% पूर्ण';
  }

  @override
  String get completionDate => 'पूर्ण होने की तारीख';

  @override
  String get priority => 'प्राथमिकता';

  @override
  String get priorityNone => 'कोई प्राथमिकता नहीं';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'प्राथमिकता $priorityString · उच्च';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'प्राथमिकता $priorityString · मध्यम';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'प्राथमिकता $priorityString · निम्न';
  }

  @override
  String get taskUrl => 'कार्य URL';

  @override
  String get invalidTaskUrl => 'स्कीम सहित पूर्ण URL दर्ज करें।';

  @override
  String get classification => 'वर्गीकरण';

  @override
  String get classificationPublic => 'साझा होने पर पूरा कार्य दिखाएँ';

  @override
  String get classificationConfidential => 'साझा होने पर केवल व्यस्तता दिखाएँ';

  @override
  String get classificationPrivate => 'साझा होने पर यह कार्य छिपाएँ';

  @override
  String get pinTask => 'कार्य पिन करें';

  @override
  String get notes => 'नोट्स';

  @override
  String get dueDate => 'देय तारीख';

  @override
  String get clearDueDate => 'देय तारीख हटाएँ';

  @override
  String get dueTime => 'देय समय';

  @override
  String get startDate => 'शुरू होने की तारीख';

  @override
  String get startTime => 'शुरू होने का समय';

  @override
  String get endDate => 'समाप्ति तारीख';

  @override
  String get endTime => 'समाप्ति समय';

  @override
  String get reminderDate => 'रिमाइंडर की तारीख';

  @override
  String get reminderTime => 'रिमाइंडर का समय';

  @override
  String get reminder => 'रिमाइंडर';

  @override
  String get addReminder => 'रिमाइंडर जोड़ें';

  @override
  String get reminders => 'रिमाइंडर';

  @override
  String get noReminders => 'कोई रिमाइंडर नहीं';

  @override
  String get editReminder => 'रिमाइंडर संपादित करें';

  @override
  String get beforeTaskStarts => 'कार्य शुरू होने से पहले';

  @override
  String get beforeTaskDue => 'कार्य की नियत तारीख से पहले';

  @override
  String get afterTaskStarts => 'कार्य शुरू होने के बाद';

  @override
  String get afterTaskDue => 'कार्य की नियत तारीख के बाद';

  @override
  String get relativeToTaskStart => 'कार्य शुरू होने की तारीख के सापेक्ष';

  @override
  String get relativeToTaskDue => 'कार्य की नियत तारीख के सापेक्ष';

  @override
  String get reminderTimeOfDay => 'दिन का समय';

  @override
  String get absoluteReminder => 'तारीख और समय पर';

  @override
  String get reminderAmount => 'मात्रा';

  @override
  String get reminderUnit => 'इकाई';

  @override
  String get reminderUnitSeconds => 'सेकंड';

  @override
  String get reminderUnitMinutes => 'मिनट';

  @override
  String get reminderUnitHours => 'घंटे';

  @override
  String get reminderUnitDays => 'दिन';

  @override
  String get reminderUnitWeeks => 'सप्ताह';

  @override
  String get reminderAtTaskStart => 'कार्य शुरू होने पर';

  @override
  String get reminderAtTaskDue => 'कार्य की नियत तारीख पर';

  @override
  String get unsupportedReminder =>
      'यह रिमाइंडर प्रकार सुरक्षित है, लेकिन इसका समय संपादित नहीं किया जा सकता।';

  @override
  String get relatedRemindersTitle => 'संबंधित रिमाइंडर रखें?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'इस तारीख पर $countString संबंधित रिमाइंडर हैं। इन्हें उनकी मौजूदा तारीख और समय पर रखें?';
  }

  @override
  String get discardRelatedReminders => 'रिमाइंडर हटाएँ';

  @override
  String get keepRelatedReminders => 'रिमाइंडर रखें';

  @override
  String get addGuest => 'अतिथि जोड़ें';

  @override
  String get addGuestEmail => 'अतिथि का ईमेल जोड़ें';

  @override
  String get removeReminder => 'रिमाइंडर हटाएँ';

  @override
  String get off => 'बंद';

  @override
  String get repeat => 'दोहराएँ';

  @override
  String get repeatNone => 'कभी नहीं';

  @override
  String get noneValue => 'कोई नहीं';

  @override
  String get repeatDaily => 'प्रतिदिन';

  @override
  String get repeatWeekly => 'हर सप्ताह';

  @override
  String get repeatMonthly => 'हर महीने';

  @override
  String get repeatYearly => 'हर वर्ष';

  @override
  String get repeatEvery => 'दोहराव अंतराल';

  @override
  String get repeatOn => 'दोहराएँ';

  @override
  String get repeatEnd => 'दोहराव समाप्त करें';

  @override
  String get repeatNever => 'कभी नहीं';

  @override
  String get repeatUntil => 'तारीख तक';

  @override
  String get repeatAfter => 'कई बार दोहराने के बाद';

  @override
  String get repeatCount => 'दोहराव की संख्या';

  @override
  String get repeatDayOfMonth => 'महीने के दिन';

  @override
  String get repeatMonths => 'महीने';

  @override
  String get repeatOrdinal => 'सप्ताह के दिन की स्थिति';

  @override
  String get repeatSpecificDays => 'विशिष्ट दिन';

  @override
  String get repeatFirst => 'पहला';

  @override
  String get repeatSecond => 'दूसरा';

  @override
  String get repeatThird => 'तीसरा';

  @override
  String get repeatFourth => 'चौथा';

  @override
  String get repeatFifth => 'पाँचवाँ';

  @override
  String get repeatSecondToLast => 'अंतिम से दूसरा';

  @override
  String get repeatLast => 'अंतिम';

  @override
  String get repeatAnyDay => 'दिन';

  @override
  String get repeatWeekday => 'सप्ताह का दिन';

  @override
  String get repeatWeekendDay => 'सप्ताहांत का दिन';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'सोमवार',
      'TU': 'मंगलवार',
      'WE': 'बुधवार',
      'TH': 'गुरुवार',
      'FR': 'शुक्रवार',
      'SA': 'शनिवार',
      'SU': 'रविवार',
      'day': 'दिन',
      'weekday': 'सप्ताह का दिन',
      'weekend': 'सप्ताहांत का दिन',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'हर $countString दिन';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'हर $countString सप्ताह';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'हर $countString महीने';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'हर $countString साल';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days को';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'की $days तारीख को';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'के पहले $days को',
      'second': 'के दूसरे $days को',
      'third': 'के तीसरे $days को',
      'fourth': 'के चौथे $days को',
      'fifth': 'के पाँचवें $days को',
      'secondToLast': 'के अंतिम से दूसरे $days को',
      'last': 'के अंतिम $days को',
      'other': 'के $days को',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '$months में';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString बार',
      one: '$countString बार',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '$date तक';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'यह दोहराव नियम ऐसे विकल्पों का उपयोग करता है जिन्हें यह संपादक नहीं बदलता।';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'यह सूची इस दोहराव पैटर्न का समर्थन नहीं करती। पैटर्न बदलें या दूसरी सूची चुनें।';

  @override
  String get taskRecurrenceRequiresDate =>
      'इस दोहराव पैटर्न का उपयोग करने के लिए शुरू होने या नियत तिथि जोड़ें, या दोहराव बंद करें।';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'इस पुनरावृत्ति का उपयोग $provider के साथ नहीं किया जा सकता।';
  }

  @override
  String get importance => 'महत्त्व';

  @override
  String get importanceLow => 'कम';

  @override
  String get importanceNormal => 'सामान्य';

  @override
  String get importanceHigh => 'उच्च';

  @override
  String get categories => 'श्रेणियाँ';

  @override
  String get scheduleSection => 'शेड्यूल';

  @override
  String get dueGroup => 'देय';

  @override
  String get startGroup => 'शुरुआत';

  @override
  String get reminderGroup => 'रिमाइंडर';

  @override
  String get organizationSection => 'व्यवस्था';

  @override
  String get actionsSection => 'कार्रवाइयाँ';

  @override
  String get advancedSection => 'उन्नत';

  @override
  String get addCategory => 'श्रेणी जोड़ें';

  @override
  String get list => 'सूची';

  @override
  String get microsoftMoveUnsupported =>
      'इस संस्करण में Microsoft To Do खातों के लिए सूचियों के बीच कार्य ले जाना समर्थित नहीं है।';

  @override
  String get createSubtask => 'उपकार्य बनाएँ';

  @override
  String get subtasks => 'उपकार्य';

  @override
  String get duplicateTask => 'कार्य की प्रतिलिपि बनाएँ';

  @override
  String get taskDuplicated => 'कार्य की प्रतिलिपि बन गई।';

  @override
  String taskDuplicateFailed(String error) {
    return 'कार्य की प्रतिलिपि नहीं बन सकी: $error';
  }

  @override
  String get hideSubtasks => 'उपकार्य छिपाएँ';

  @override
  String get hideClosedSubtasks => 'बंद उपकार्य छिपाएँ';

  @override
  String get moveToTop => 'सबसे ऊपर ले जाएँ';

  @override
  String get deleteTask => 'कार्य मिटाएँ';

  @override
  String get newSubtask => 'नया उपकार्य';

  @override
  String deleteTaskConfirmation(String title) {
    return '“$title” मिटाएँ?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'इससे Google Docs या Chat Spaces में मूल टास्क भी मिट जाएगा।';

  @override
  String get metadata => 'मेटाडेटा';

  @override
  String get id => 'आईडी';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'अपडेट किया गया';

  @override
  String get parent => 'मूल कार्य';

  @override
  String get position => 'स्थान';

  @override
  String get webLink => 'वेब लिंक';

  @override
  String get assignment => 'असाइनमेंट';

  @override
  String get localState => 'स्थानीय स्थिति';

  @override
  String get pendingSync => 'सिंक लंबित';

  @override
  String get synced => 'सिंक किया गया';

  @override
  String get account => 'खाता';

  @override
  String get sync => 'सिंक';

  @override
  String get forceFullResync => 'पूर्ण पुनः सिंक करें';

  @override
  String get forceFullResyncDescription =>
      'हर कनेक्ट किए गए खाते से सभी डेटा पूरी तरह फिर से लोड करता है। इसका उपयोग केवल सिंक संबंधी समस्याओं के निवारण के लिए करें।';

  @override
  String get runInBackgroundWhenClosed => 'विंडो बंद होने पर भी चलते रहें';

  @override
  String get showTrayIcon => 'ट्रे आइकन दिखाएँ';

  @override
  String get startMinimizedToTray => 'ट्रे में मिनिमाइज़ होकर शुरू करें';

  @override
  String get launchAtLogin => 'लॉगिन पर शुरू करें';

  @override
  String get launchAtLoginDescription =>
      'BusyMax को बैकग्राउंड में शुरू करें ताकि लॉगिन के बाद रिमाइंडर काम करें।';

  @override
  String get launchAtLoginFailed =>
      'लॉगिन पर शुरू करने की सेटिंग अपडेट नहीं की जा सकी।';

  @override
  String get requiresTrayIcon => 'ट्रे आइकन आवश्यक है।';

  @override
  String get syncComplete => 'सिंक पूरा हुआ।';

  @override
  String syncFailed(String error) {
    return 'सिंक विफल: $error';
  }

  @override
  String get notifySyncFailures => 'सिंक विफल होने की सूचनाएँ';

  @override
  String get notifyConflicts => 'टकराव की सूचनाएँ';

  @override
  String get notifyDueToday => 'आज देय कार्यों की सूचनाएँ';

  @override
  String get eventReminders => 'इवेंट रिमाइंडर';

  @override
  String get onState => 'चालू';

  @override
  String get taskReminders => 'कार्य रिमाइंडर';

  @override
  String get notificationDetailLevel => 'सूचनाओं के विवरण का स्तर';

  @override
  String get notificationDetailPrivate => 'निजी';

  @override
  String get notificationDetailNormal => 'सामान्य';

  @override
  String get quietHours => 'शांत समय';

  @override
  String get quietHoursDescription => 'इस अवधि के दौरान सूचनाएँ रोकें।';

  @override
  String get quietHoursStart => 'शांत समय की शुरुआत';

  @override
  String get quietHoursEnd => 'शांत समय की समाप्ति';

  @override
  String get notifications => 'सूचनाएँ';

  @override
  String get windowsNotificationsUnavailable =>
      'Windows सूचनाएँ उपलब्ध नहीं हैं';

  @override
  String get windowsNotificationsUnpackaged =>
      'यह बिना पैकेज वाला डेवलपमेंट रन Windows सूचनाओं का उपयोग नहीं कर सकता। रिमाइंडर जाँचने के लिए परीक्षण-हस्ताक्षरित MSIX इंस्टॉल करें।';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax Windows सूचनाएँ शुरू नहीं कर सका। यह इंस्टॉलेशन समस्या हल होने तक रिमाइंडर दिखाई नहीं देंगे।';

  @override
  String get appearance => 'दिखावट';

  @override
  String get theme => 'थीम';

  @override
  String get themeSystem => 'सिस्टम';

  @override
  String get settingsSystem => 'सिस्टम';

  @override
  String get themeLight => 'हल्की';

  @override
  String get themeDark => 'गहरी';

  @override
  String get themeFamily => 'थीम परिवार';

  @override
  String get themeFamilyYaru => 'Ubuntu की मूल थीम (Yaru)';

  @override
  String get localization => 'स्थानीयकरण';

  @override
  String get currentLocale => 'मौजूदा भाषा और क्षेत्रीय सेटिंग';

  @override
  String get privacy => 'गोपनीयता';

  @override
  String get redactTaskContentInDiagnostics => 'निदान में कार्य सामग्री छिपाएँ';

  @override
  String get developerDiagnostics => 'डेवलपर निदान';

  @override
  String get diagnostics => 'निदान';

  @override
  String get apiInspectorDisabled => 'API इंस्पेक्टर दिखाएँ';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'डिस्कवरी संशोधन: $revision';
  }

  @override
  String get implementedMethods => 'लागू की गई विधियाँ';

  @override
  String get supportsTasksScopes => 'tasks और tasks.readonly स्कोप समर्थित हैं';

  @override
  String get requiresTasksScope => 'tasks स्कोप आवश्यक है';

  @override
  String get blockedPendingOperations => 'अवरुद्ध लंबित कार्रवाइयाँ';

  @override
  String get signInToInspectPendingOperations =>
      'लंबित कार्रवाइयाँ देखने के लिए साइन इन करें।';

  @override
  String get noBlockedPendingOperations =>
      'कोई अवरुद्ध लंबित कार्रवाई नहीं है।';

  @override
  String get operationActions => 'कार्रवाई के विकल्प';

  @override
  String pendingOpListId(String id) {
    return 'सूची=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'कार्य=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'प्रयास=$countString';
  }

  @override
  String get retry => 'फिर से कोशिश करें';

  @override
  String get discard => 'खारिज करें';

  @override
  String get discardChangesAction => 'बदलाव छोड़ें';

  @override
  String get discardChanges => 'बदलाव खारिज करें?';

  @override
  String get discardChangesConfirmation =>
      'इससे इस कार्य में किए गए सहेजे न गए बदलाव खारिज हो जाएँगे।';

  @override
  String get retryCompleted => 'दोबारा प्रयास पूरा हुआ।';

  @override
  String get discardPendingOperation => 'लंबित कार्रवाई खारिज करें?';

  @override
  String get discardPendingOperationConfirmation =>
      'इससे अवरुद्ध स्थानीय कार्रवाई हट जाती है। अगला सिंक Google Tasks से डेटा रीफ़्रेश करेगा।';

  @override
  String get pendingOperationDiscarded => 'लंबित कार्रवाई खारिज कर दी गई।';

  @override
  String get syncFailureNotificationTitle => 'BusyMax सिंक विफल';

  @override
  String syncFailureNotificationBody(String message) {
    return 'बैकग्राउंड सिंक विफल हुआ। $message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax सिंक में टकराव';

  @override
  String conflictNotificationBody(String summary) {
    return 'लंबित स्थानीय बदलाव अवरुद्ध किया गया। $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'आज देय कार्य';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'आज $countString कार्य देय हैं।',
      one: 'आज एक कार्य देय है।',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'इवेंट रिमाइंडर';

  @override
  String get taskReminderNotificationTitle => 'कार्य रिमाइंडर';

  @override
  String get eventReminderNotificationBody => 'इवेंट जल्द शुरू होगा।';

  @override
  String get taskReminderNotificationBody => 'कार्य जल्द देय है।';

  @override
  String get notificationOpenAction => 'खोलें';

  @override
  String get notificationSnoozeAction => '10 मिनट के लिए स्नूज़ करें';

  @override
  String get notificationDismissAction => 'बंद करें';

  @override
  String get notificationDetailsHidden =>
      'गोपनीयता सेटिंग्स के कारण विवरण छिपे हुए हैं।';

  @override
  String get previousMonth => 'पिछला महीना';

  @override
  String get nextMonth => 'अगला महीना';

  @override
  String get openMonthView => 'महीने का दृश्य खोलें';

  @override
  String get previousYear => 'पिछला वर्ष';

  @override
  String get nextYear => 'अगला वर्ष';

  @override
  String get openYearView => 'वर्ष का दृश्य खोलें';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'सप्ताह $numberString';
  }

  @override
  String get resizeAllDayPanel => 'पूरे दिन वाले पैनल का आकार बदलें';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString आइटम',
      one: '1 आइटम',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'यह कैलेंडर केवल पढ़ने योग्य है।';

  @override
  String get selectTimeZone => 'समय क्षेत्र चुनें';

  @override
  String get searchLocations => 'स्थान खोजें';

  @override
  String get noLocationsFound => 'कोई स्थान नहीं मिला';

  @override
  String get requiredField => 'यह फ़ील्ड आवश्यक है।';

  @override
  String get providerConnectionDescription =>
      'इनमें से किसी प्रदाता से कैलेंडर और कार्य कनेक्ट करें।';

  @override
  String get appleICloudProvider => 'Apple iCloud कैलेंडर';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud कार्य';

  @override
  String get addAppleICloudAccount => 'Apple iCloud Calendar खाता जोड़ें';

  @override
  String get addNextcloudAccount => 'Nextcloud खाता जोड़ें';

  @override
  String get waitingForAppleICloud => 'Apple iCloud से कनेक्ट हो रहा है…';

  @override
  String get waitingForNextcloud => 'Nextcloud प्राधिकरण की प्रतीक्षा है…';

  @override
  String get connectAppleICloudTitle => 'Apple iCloud Calendar कनेक्ट करें';

  @override
  String get appleAccountEmail => 'Apple खाते का ईमेल';

  @override
  String get appleAppSpecificPassword => 'ऐप-विशिष्ट पासवर्ड';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Apple खाते के लिए दो-चरणीय प्रमाणीकरण चालू करने के बाद ऐप-विशिष्ट पासवर्ड बनाएँ।';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Apple खाते का पासवर्ड रीसेट करने से ऐप-विशिष्ट पासवर्ड रद्द हो जाते हैं।';

  @override
  String get connectNextcloudTitle => 'Nextcloud कनेक्ट करें';

  @override
  String get nextcloudServerUrl => 'Nextcloud सर्वर या CalDAV पता';

  @override
  String get nextcloudServerUrlHelp =>
      'Nextcloud सर्वर URL दर्ज करें या Nextcloud से कॉपी किया गया प्राथमिक CalDAV पता चिपकाएँ।';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax आपका ब्राउज़र खोलेगा। वहाँ पहुँच की अनुमति दें और फिर BusyMax पर लौटें।';

  @override
  String get connectAccountAction => 'कनेक्ट करें';

  @override
  String get cancelAccountConnection => 'कनेक्शन रद्द करें';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'खाता स्थानीय रूप से हटाया गया, लेकिन Nextcloud ऐप पासवर्ड रद्द नहीं किया जा सका।';

  @override
  String get davReauthenticationRequired =>
      'सिंक फिर से शुरू करने के लिए इस खाते को दोबारा कनेक्ट करें।';

  @override
  String get davTemporarilyUnavailable =>
      'यह खाता अस्थायी रूप से उपलब्ध नहीं है।';

  @override
  String get davPermissionChanged =>
      'सर्वर अनुमतियाँ बदल गई हैं। लंबित संपादन रोक दिए गए हैं।';

  @override
  String get davUnsupportedServer =>
      'यह सर्वर या प्रदाता प्रोफ़ाइल समर्थित नहीं है।';

  @override
  String get collectionSettings => 'कैलेंडर और कार्य सूचियाँ';

  @override
  String get calendarContent => 'कैलेंडर इवेंट';

  @override
  String get taskContent => 'कार्य';

  @override
  String get readOnlySharedCollection => 'केवल-पठन';

  @override
  String get pendingLocally => 'स्थानीय रूप से लंबित';

  @override
  String get conflictBlocked => 'विरोध के कारण अवरुद्ध';

  @override
  String get authenticationBlocked => 'दोबारा कनेक्ट होने तक अवरुद्ध';

  @override
  String get operationFailed => 'कार्रवाई विफल';

  @override
  String get keepServerVersion => 'सर्वर संस्करण रखें';

  @override
  String get reapplyLocalChange => 'स्थानीय बदलाव की समीक्षा कर फिर लागू करें';

  @override
  String get duplicateLocalItem => 'नए आइटम के रूप में कॉपी बनाएँ';

  @override
  String get davConnectionState => 'कनेक्शन की स्थिति';

  @override
  String get davConnected => 'कनेक्टेड';

  @override
  String get davConnecting => 'कनेक्ट हो रहा है…';

  @override
  String get davSignedOut => 'साइन आउट किया गया';

  @override
  String davLastSuccessfulSync(String time) {
    return 'अंतिम सफल सिंक: $time';
  }

  @override
  String get davNeverSynced => 'अभी तक सिंक नहीं हुआ';

  @override
  String get refreshCollections => 'कैलेंडर और कार्य सूचियाँ रीफ़्रेश करें';

  @override
  String nextcloudServerHost(String host) {
    return 'सर्वर: $host';
  }

  @override
  String get collectionSupportsEvents => 'इवेंट कैलेंडर';

  @override
  String get collectionSupportsTasks => 'कार्य सूची';

  @override
  String get collectionSupportsEventsAndTasks => 'इवेंट और कार्य';

  @override
  String get writableCollection => 'लिखने योग्य';

  @override
  String get sharedCollection => 'साझा';

  @override
  String collectionLastSynced(String time) {
    return 'अंतिम सिंक: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'सिंक समस्या: $code';
  }

  @override
  String get syncConflicts => 'सिंक विरोध';

  @override
  String remoteChangedAt(String time) {
    return 'सर्वर में बदलाव: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'स्थानीय संपादन: $summary';
  }

  @override
  String get conflictResolutionFailed => 'विरोध का समाधान नहीं हो सका।';

  @override
  String get recurringEventScope => 'दोहराए जाने वाले इवेंट का दायरा';

  @override
  String get entireSeries => 'पूरी शृंखला';

  @override
  String get singleOccurrence => 'यह इवेंट';

  @override
  String get thisAndFollowingEvents => 'यह और इसके बाद के इवेंट';

  @override
  String get thisAndFutureUnavailable => 'यह प्रदाता इसका समर्थन नहीं करता।';

  @override
  String get thisAndFutureMoveUnavailable =>
      'इस और इसके बाद के इवेंट सुरक्षित रूप से नहीं ले जाए जा सकते। यह इवेंट या पूरी शृंखला चुनें।';

  @override
  String get entireSeriesMoveUnavailable =>
      'दोहराव का नियम स्थानीय रूप से उपलब्ध नहीं है। इसके बजाय केवल यह इवेंट ले जाएँ।';

  @override
  String get copyEventAndDeleteOriginal =>
      'इवेंट की कॉपी बनाकर मूल इवेंट मिटाएँ?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax इस इवेंट को $source से $destination में सीधे नहीं ले जा सकता। यह पहले कॉपी बनाएगा और कॉपी सफल होने के बाद ही मूल इवेंट मिटाएगा। इवेंट ID बदलेंगे; सहभागियों की प्रतिक्रिया स्थितियां रीसेट हो सकती हैं और आमंत्रण या रद्दीकरण भेजे जा सकते हैं; और कॉन्फ़्रेंस लिंक, अटैचमेंट, रिमाइंडर, प्रदाता-विशिष्ट फ़ील्ड तथा दोहराव अपवाद शायद स्थानांतरित न हों।';
  }

  @override
  String get copyAndDelete => 'कॉपी बनाएँ और मिटाएँ';

  @override
  String get chooseRecurringEventScope =>
      'चुनें कि यह बदलाव पूरी शृंखला, केवल इस इवेंट या इस और इसके बाद के इवेंट पर लागू हो।';

  @override
  String get taskDueBeforeStart => 'नियत समय प्रारंभ समय से पहले नहीं हो सकता।';

  @override
  String get taskStartDueTimeModeMismatch =>
      'प्रारंभ और नियत समय दोनों सेट करें, या कार्य को पूरे दिन का बनाएँ।';

  @override
  String deleteCalendarConfirmation(String title) {
    return '“$title” मिटाएँ?';
  }

  @override
  String get setCustomCalendarName => 'कस्टम नाम सेट करें';

  @override
  String get setAction => 'सेट करें';

  @override
  String get removeFromMyCalendars => 'मेरे कैलेंडर से हटाएँ';

  @override
  String get removeAction => 'हटाएँ';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'क्या \"$title\" को BusyMax से हटाएँ? मालिक का कैलेंडर और उसके इवेंट नहीं मिटाए जाएँगे।';
  }

  @override
  String get attachmentUploadUnresolved =>
      'अपलोड पूरा हो गया हो सकता है। दोबारा अपलोड करने से पहले परिणाम जाँचने के लिए अटैचमेंट रीफ़्रेश करें।';

  @override
  String removeCalendarConfirmation(String title) {
    return 'क्या \"$title\" को आपकी Google Calendar सूची से हटाएँ? साझा कैलेंडर और उसके इवेंट नहीं मिटाए जाएँगे।';
  }

  @override
  String get calendarCannotRemove =>
      'इस कैलेंडर को इस खाते से हटाया या मिटाया नहीं जा सकता।';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'कैलेंडर हटाने से पहले उसके लंबित बदलावों का सिंक पूरा होने की प्रतीक्षा करें।';

  @override
  String get calendarSubscriptions => 'कैलेंडर सदस्यताएँ';

  @override
  String get calendarSubscriptionsDescription =>
      'सुरक्षित WebCal URL से रीफ़्रेश होने वाले केवल-पठन कैलेंडर जोड़ें।';

  @override
  String get addCalendarSubscription => 'कैलेंडर सदस्यता जोड़ें';

  @override
  String get subscriptionName => 'स्थानीय नाम';

  @override
  String get subscriptionUrl => 'सदस्यता URL';

  @override
  String get subscriptionUrlHelp =>
      'HTTPS या webcal URL दर्ज करें। BusyMax पूरा URL सुरक्षित संग्रहण में रखता है।';

  @override
  String get subscriptionUrlInvalid =>
      'उपयोगकर्ता जानकारी या फ़्रैगमेंट के बिना मान्य HTTPS या webcal URL दर्ज करें।';

  @override
  String get subscriptionColor => 'स्थानीय रंग';

  @override
  String get subscriptionColorHelp =>
      '#3584E4 जैसे छह अंकों वाले रंग का उपयोग करें।';

  @override
  String get subscriptionColorInvalid =>
      'छह अंकों वाला हेक्साडेसिमल रंग दर्ज करें।';

  @override
  String get subscriptionRefreshMode => 'रीफ़्रेश आवृत्ति';

  @override
  String get subscriptionAutomatic => 'स्वचालित';

  @override
  String get subscriptionHourly => 'हर घंटे';

  @override
  String get subscriptionSixHours => 'हर छह घंटे';

  @override
  String get subscriptionDaily => 'हर दिन';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'स्रोत: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'सुरक्षित स्रोत का पूर्वावलोकन करने के लिए मान्य URL दर्ज करें।';

  @override
  String get subscriptionReadOnly => 'केवल-पठन सदस्यता';

  @override
  String get subscriptionNeverRefreshed => 'अभी तक रीफ़्रेश नहीं हुआ';

  @override
  String subscriptionLastRefresh(String time) {
    return 'अंतिम सफल रीफ़्रेश: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'अगला रीफ़्रेश: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'अप टू डेट';

  @override
  String subscriptionStatusIssue(String code) {
    return 'रीफ़्रेश समस्या: $code';
  }

  @override
  String get refreshNow => 'अभी रीफ़्रेश करें';

  @override
  String get unsubscribe => 'सदस्यता रद्द करें';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '“$name” की सदस्यता रद्द करें?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'इससे स्थानीय सदस्यता और कैश किए गए इवेंट हट जाएँगे। प्रकाशित कैलेंडर नहीं बदलेगा।';

  @override
  String get addSubscriptionAction => 'सदस्यता जोड़ें';

  @override
  String subscriptionOperationFailed(String error) {
    return 'कैलेंडर सदस्यता विफल: $error';
  }

  @override
  String get subscriptions => 'सदस्यताएँ';

  @override
  String get calendarImport => 'कैलेंडर आयात';

  @override
  String get calendarImportDescription =>
      'फ़ाइल चुनें, उसके इवेंट की समीक्षा करें और फिर वह लिखने योग्य कैलेंडर चुनें जिसे उन्हें प्राप्त करना चाहिए।';

  @override
  String get importIcsFile => '.ics फ़ाइल आयात करें';

  @override
  String get importIcsPreview => 'कैलेंडर इवेंट आयात करें';

  @override
  String importEventsFound(int count) {
    return 'आयात योग्य इवेंट सेट: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'अमान्य इवेंट: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'जानबूझकर छोड़े गए: $fields';
  }

  @override
  String get noWritableCalendars =>
      'कोई लिखने योग्य गंतव्य कैलेंडर उपलब्ध नहीं है।';

  @override
  String get importDestinationCalendar => 'गंतव्य कैलेंडर';

  @override
  String get importIcsConfirm => 'इवेंट आयात करें';

  @override
  String get importIcsComplete => 'आयात पूरा हुआ';

  @override
  String importQueued(int count) {
    return 'आयातित या कतार में: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'डुप्लिकेट छोड़े गए: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'असमर्थित दोहराव सेट: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'कैलेंडर फ़ाइल आयात नहीं की जा सकी: $error';
  }

  @override
  String get networkOffline => 'ऑफ़लाइन';

  @override
  String get networkOfflineDescription =>
      'कनेक्शन वापस आने पर बदलाव सिंक हो जाएंगे।';

  @override
  String get networkOfflineTryAgain =>
      'आप ऑफ़लाइन हैं। इंटरनेट से कनेक्ट करें और फिर से कोशिश करें।';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'की $days तारीखों को';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first और $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first और $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first और $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first और $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency $month की $day तारीख को';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency $month की $days तारीखों को';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency $months की $day तारीख को';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency $months की $days तारीखों को';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'पहले',
      'second': 'दूसरे',
      'third': 'तीसरे',
      'fourth': 'चौथे',
      'fifth': 'पाँचवें',
      'secondToLast': 'अंतिम से दूसरे',
      'last': 'अंतिम',
      'other': '',
    });
    return '$frequency $month के $_temp0 $days को';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'पहले',
      'second': 'दूसरे',
      'third': 'तीसरे',
      'fourth': 'चौथे',
      'fifth': 'पाँचवें',
      'secondToLast': 'अंतिम से दूसरे',
      'last': 'अंतिम',
      'other': '',
    });
    return '$frequency $months के $_temp0 $days को';
  }

  @override
  String get searchFilters => 'खोज फ़िल्टर';

  @override
  String get searchType => 'प्रकार';

  @override
  String get searchDate => 'तारीख';

  @override
  String get searchAnyDate => 'कोई भी तारीख (डाउनलोड किया गया डेटा)';

  @override
  String get eventLink => 'इवेंट लिंक';

  @override
  String get eventLinkOpenFailed => 'लिंक नहीं खोला जा सका।';

  @override
  String get scheduleRangeIncomplete =>
      'कुछ इवेंट की जाँच नहीं हो सकी। डाउनलोड किया गया डेटा दिखाया जा रहा है।';

  @override
  String get searchThisWeek => 'इस सप्ताह';

  @override
  String get searchCustomRange => 'कस्टम अवधि';

  @override
  String get searchTaskStatus => 'कार्य स्थिति';

  @override
  String get searchTaskDue => 'कार्य की नियत तारीख';

  @override
  String get searchAnyDueState => 'कोई भी नियत स्थिति';

  @override
  String get searchNoDueDate => 'बिना नियत तारीख';

  @override
  String get searchPerson => 'व्यक्ति';

  @override
  String get searchSources => 'स्रोत';

  @override
  String get searchClearFilters => 'फ़िल्टर रीसेट करें';

  @override
  String get searchFiltersAction => 'फ़िल्टर';

  @override
  String get searchNoSources => 'कोई खोज स्रोत नहीं चुना गया';

  @override
  String get searchClearText => 'पाठ साफ़ करें';

  @override
  String get openSharedCalendar => 'साझा कैलेंडर खोलें';

  @override
  String get manageCalendarSharing => 'कैलेंडर साझाकरण प्रबंधित करें';

  @override
  String get shareRecipientEmail => 'प्राप्तकर्ता का ईमेल';

  @override
  String get shareRole => 'पहुँच की भूमिका';

  @override
  String get addCalendarShare => 'पहुँच जोड़ें';

  @override
  String get sharingRefreshFailed =>
      'साझाकरण बदल गया, लेकिन अनुमतियों की सूची ताज़ा नहीं हो सकी। अगला बदलाव करने से पहले सूची फिर लोड करें।';

  @override
  String get sharingRateLimited =>
      'साझाकरण अस्थायी रूप से सीमित है। प्रतीक्षा अवधि समाप्त होने पर फिर प्रयास करें।';

  @override
  String get attachmentUploadRateLimited =>
      'अटैचमेंट अपलोड अस्थायी रूप से सीमित है। प्रतीक्षा अवधि समाप्त होने पर फिर प्रयास करें।';

  @override
  String get sharingPermissionUnavailable =>
      'इस कैलेंडर के लिए साझाकरण अनुमतियाँ उपलब्ध नहीं हैं।';

  @override
  String get calendarShareFreeBusy => 'केवल खाली/व्यस्त';

  @override
  String get calendarShareLimitedRead => 'सीमित विवरण पढ़ें';

  @override
  String get calendarShareRead => 'सभी विवरण पढ़ें';

  @override
  String get calendarShareWrite => 'कार्यक्रम संपादित करें';

  @override
  String get calendarShareWriteWithoutPrivate =>
      'निजी विवरण के बिना संपादित करें';

  @override
  String get calendarShareOwner => 'स्वामी';

  @override
  String get eventLabel => 'कार्यक्रम लेबल';

  @override
  String get loadOutlookCategories => 'Outlook श्रेणियाँ लोड करें';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlook श्रेणियाँ उपलब्ध नहीं हैं; मौजूदा श्रेणियाँ बनी रहेंगी।';

  @override
  String get googleEventType => 'कार्यक्रम का प्रकार';

  @override
  String get googleRegularEvent => 'सामान्य कार्यक्रम';

  @override
  String get googleFocusTime => 'एकाग्रता का समय';

  @override
  String get googleOutOfOffice => 'कार्यालय से बाहर';

  @override
  String get googleWorkingLocation => 'कार्य स्थान';

  @override
  String get googleDeclineInvitations => 'साथ आने वाले आमंत्रण अस्वीकार करें';

  @override
  String get googleDeclineNone => 'अस्वीकार न करें';

  @override
  String get googleDeclineNew => 'नए आमंत्रण अस्वीकार करें';

  @override
  String get googleDeclineAll => 'सभी टकराने वाले आमंत्रण अस्वीकार करें';

  @override
  String get googleDeclineMessage => 'अस्वीकृति संदेश';

  @override
  String get googleChatStatus => 'चैट स्थिति';

  @override
  String get googleChatAvailable => 'उपलब्ध';

  @override
  String get googleChatDoNotDisturb => 'परेशान न करें';

  @override
  String get googleWorkAtHome => 'घर';

  @override
  String get googleWorkAtOffice => 'कार्यालय';

  @override
  String get googleWorkAtCustomLocation => 'कस्टम स्थान';

  @override
  String get googleWorkLocationLabel => 'स्थान का नाम';

  @override
  String get googleStatusPrimaryOnly =>
      'Google स्थिति कार्यक्रम के लिए आपका मुख्य Google कैलेंडर आवश्यक है।';

  @override
  String unknownEventLabel(String id) {
    return 'अज्ञात लेबल ($id)';
  }

  @override
  String get calendarOwnerEmail => 'कैलेंडर स्वामी का ईमेल';

  @override
  String registrationSetupTitle(String provider) {
    return '$provider सेट अप करें';
  }

  @override
  String get registrationSetupGuide => 'सेटअप मार्गदर्शिका';

  @override
  String get registrationGoogleInstructions =>
      'अपना Google Cloud प्रोजेक्ट बनाएँ, Calendar और Tasks API चालू करें और Desktop OAuth क्लाइंट का JSON आयात करें। इच्छित खाते को अनुमति दें।';

  @override
  String get registrationMicrosoftInstructions =>
      'ऐसे Entra टेनेंट में सार्वजनिक ऐप पंजीकरण इस्तेमाल करें जो पंजीकरण की अनुमति देता हो। क्लाइंट ID और खाते के प्रकार दर्ज करें। क्लाइंट सीक्रेट की आवश्यकता नहीं है।';

  @override
  String get registrationImportGoogle => 'Desktop OAuth JSON चुनें';

  @override
  String get registrationValidate => 'पंजीकरण जाँचें';

  @override
  String get registrationAuthorize => 'ब्राउज़र में अनुमति दें';

  @override
  String get registrationClientId => 'एप्लिकेशन/क्लाइंट ID';

  @override
  String get registrationTenantId => 'टेनेंट ID';

  @override
  String get registrationAudience => 'समर्थित खाते';

  @override
  String get registrationBothAudience => 'व्यक्तिगत और संगठन के खाते';

  @override
  String get registrationOrganizationAudience => 'संगठन के खाते';

  @override
  String get registrationPersonalAudience => 'व्यक्तिगत खाते';

  @override
  String get registrationTenantAudience => 'एक संगठन का टेनेंट';

  @override
  String registrationSummary(String clientId) {
    return 'पंजीकरण: $clientId';
  }

  @override
  String get registrationMigrate => 'अभी माइग्रेट करें';

  @override
  String get registrationReplace => 'पंजीकरण बदलें';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'यह खाता मौजूदा खातों के लिए सुरक्षित मूल $provider पंजीकरण इस्तेमाल करता है। बदलने के लिए $setup सेट अप करके इस खाते को दोबारा कनेक्ट करें। मौजूदा कैलेंडर, कार्य और स्थानीय बदलाव सुरक्षित रहेंगे।';
  }

  @override
  String get registrationContinue => 'इस खाते का उपयोग जारी रखें';

  @override
  String get registrationGoogleProject => 'Google Cloud प्रोजेक्ट';

  @override
  String get registrationMicrosoftApp => 'Microsoft ऐप पंजीकरण';

  @override
  String get registrationUserOwned => 'उपयोगकर्ता द्वारा दिया गया पंजीकरण';

  @override
  String get registrationNativeGoogle => 'मूल Google Android पंजीकरण';

  @override
  String get registrationShared => 'साझा पंजीकरण (संक्रमण)';

  @override
  String get registrationUnresolved =>
      'पंजीकरण का स्रोत स्पष्ट नहीं है। खाते का डेटा सुरक्षित है।';

  @override
  String get registrationOfficialDocumentation => 'आधिकारिक दस्तावेज़';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'पैकेज: $packageName\nहस्ताक्षर हैश: $signatureHash\nरीडायरेक्ट URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'पंजीकरण में क्लाइंट प्रकार, समर्थित खाते, अनुमतियाँ और रीडायरेक्ट जाँचें। आयातित कॉन्फ़िगरेशन दोबारा चुनें।';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'यह प्राधिकरण पूरा नहीं हुआ। फिर से शुरू करें; मौजूदा कनेक्शन सुरक्षित है।';

  @override
  String get oauthPermissionRefused =>
      'प्राधिकरण अस्वीकार किया गया या आवश्यक अनुमतियाँ नहीं मिलीं। फिर प्रयास करें और आवश्यक अनुमतियाँ दें।';

  @override
  String get oauthProviderThrottled =>
      'प्रदाता अनुरोध सीमित कर रहा है। दोबारा प्रयास करने से पहले प्रतीक्षा करें; मौजूदा कनेक्शन सुरक्षित है।';

  @override
  String get oauthProviderTemporaryFailure =>
      'प्रदाता की अस्थायी समस्या के कारण प्राधिकरण पूरा नहीं हुआ। फिर प्रयास करें; मौजूदा कनेक्शन सुरक्षित है।';

  @override
  String get oauthAuthorizationTimedOut =>
      'प्राधिकरण का समय समाप्त हो गया। फिर प्रयास करें और आयातित कॉन्फ़िगरेशन दोबारा चुनें।';

  @override
  String get oauthWrongAccount =>
      'दोबारा जोड़ने के लिए चुने गए खाते को अधिकृत करें। मौजूदा कनेक्शन सुरक्षित है।';

  @override
  String get oauthSecureStorageUnavailable =>
      'सुरक्षित संग्रह उपलब्ध नहीं है। उसकी पहुँच बहाल करके फिर प्रयास करें।';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'दूरस्थ प्राधिकरण रद्द हुआ, लेकिन खाते की सफ़ाई पूरी नहीं हो सकी। स्थानीय पुनर्प्राप्ति दोबारा आज़माने के लिए BusyMax पुनः शुरू करें।';

  @override
  String get addAccount => 'खाता जोड़ें';

  @override
  String get registrationConnect => 'कनेक्ट करें';

  @override
  String get registrationBack => 'वापस';

  @override
  String get registrationReplaceGoogle => 'डेस्कटॉप OAuth JSON बदलें';

  @override
  String get registrationSelectedConfiguration => 'चुना गया कॉन्फ़िगरेशन';

  @override
  String get registrationDirectoryId => 'डायरेक्टरी/टेनेंट ID';

  @override
  String get registrationInvalidId => 'मान्य UUID दर्ज करें।';

  @override
  String get registrationExpired =>
      'यह कॉन्फ़िगरेशन समाप्त हो गया है। कनेक्ट करने से पहले फिर से आयात करें या पंजीकरण फ़ील्ड बदलें।';

  @override
  String get registrationOwnProjectRequired =>
      'अपने प्रोजेक्ट या टेनेंट का पंजीकरण चुनें।';

  @override
  String get registrationSetupFailed =>
      'सेटअप पूरा नहीं हो सका। फिर से कोशिश करें।';

  @override
  String get registrationLinkFailed =>
      'लिंक नहीं खुल सका। ब्राउज़र जाँचें और फिर से कोशिश करें।';

  @override
  String get registrationPermissions => 'अनुमतियाँ';

  @override
  String get registrationDesktopClient => 'डेस्कटॉप ऐप्लिकेशन';

  @override
  String get registrationOpenGoogleConsole => 'Google Cloud Console खोलें';

  @override
  String get registrationGoogleAudienceHelp =>
      'Google प्रकाशन और परीक्षण उपयोगकर्ता की ज़रूरतें';

  @override
  String get registrationDesktopHelp => 'डेस्कटॉप ऐप पंजीकरण के निर्देश';

  @override
  String get registrationOpenEntra => 'Microsoft Entra व्यवस्थापन केंद्र खोलें';

  @override
  String get registrationGuideGoogleProject =>
      'Google Cloud Console खोलें। ऊपर के प्रोजेक्ट चयन से अपना प्रोजेक्ट चुनें, या New project चुनकर नाम दर्ज करें और Create चुनें। अगले चरणों में इसी प्रोजेक्ट को चुना रहने दें।';

  @override
  String get registrationGuideGoogleAudience =>
      'Google Auth Platform → Branding में जाएँ। सेटअप शुरू नहीं हुआ है तो Get started चुनें। App name में BusyMax दर्ज करें, अपना User support email चुनें और Next चुनें। Audience में External चुनें। Next चुनें, Contact Information में अपना ईमेल दर्ज करें और Next चुनें। User Data Policy स्वीकार करें और Continue तथा Create चुनें। पहले से सेट है तो Branding और Audience जाँचें।';

  @override
  String get registrationGuideGooglePermissions =>
      'Google Auth Platform → Data Access → Add or remove scopes खोलें। नीचे के पाँच दायरे चुनें; आवश्यक हो तो Manually add scopes इस्तेमाल करें। मैन्युअल प्रविष्टि के लिए छूटे हुए मान पेस्ट करें और Add to table चुनें। Update और फिर Save चुनें। BusyMax को कैलेंडर और कार्यों, दोनों का ऐक्सेस चाहिए।';

  @override
  String get registrationGuideGoogleClient =>
      'Google Auth Platform → Clients → Create client खोलें। Application type को Desktop app रखें, Name में BusyMax दर्ज करें और Create चुनें। बनाने वाले संवाद में Download JSON चुनें और फ़ाइल सेव करें। वापस चुनकर फ़ॉर्म पर लौटें, फ़ाइल चुनें और प्रोजेक्ट तथा क्लाइंट ID जाँचें। कनेक्ट चुनें और ब्राउज़र में कैलेंडर तथा कार्यों का ऐक्सेस स्वीकार करें।';

  @override
  String get registrationGuideMicrosoftApp =>
      'Microsoft Entra व्यवस्थापन केंद्र में साइन इन करें। Settings से ऐसा टेनेंट चुनें जहाँ आप ऐप पंजीकृत कर सकते हैं। Entra ID → App registrations → New registration खोलें। Name में BusyMax दर्ज करें और अगले चरण में समर्थित खाता प्रकार चुनें। पंजीकरण बंद हो तो टेनेंट व्यवस्थापक से ऐक्सेस माँगें।';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'अपने पंजीकरण में Authentication → Add a platform → Mobile and desktop applications खोलें। नीचे का रीडायरेक्ट URI चुनें या दर्ज करें, फिर Configure से सेव करें। BusyMax सिस्टम ब्राउज़र इस्तेमाल करता है। क्लाइंट सीक्रेट आवश्यक नहीं है।';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'API permissions → Add a permission → Microsoft Graph → Delegated permissions खोलें। नीचे का प्रत्येक दायरा खोजकर चुनें, फिर Add permissions चुनें। User.Read पहले से है तो रहने दें। संगठन व्यवस्थापक की सहमति माँगता है तो व्यवस्थापक से टेनेंट के लिए Grant admin consent इस्तेमाल करने को कहें।';

  @override
  String get registrationGuideMicrosoftConnect =>
      'वापस चुनकर फ़ॉर्म पर लौटें। Application (client) ID पेस्ट करें और पंजीकरण जैसे समर्थित खाते चुनें। एक संगठन टेनेंट के लिए Directory (tenant) ID भी पेस्ट करें। कनेक्ट चुनें और ब्राउज़र में इच्छित खाते से साइन इन करें। BusyMax फ़ील्ड की जाँच स्थानीय रूप से करता है; Microsoft ब्राउज़र में साइन इन के दौरान आपकी सहमति माँगता है।';

  @override
  String get registrationGoogleImportFailed =>
      'यह फ़ाइल आयात नहीं हो सकी। मान्य डेस्कटॉप OAuth JSON चुनें। पिछला मान्य चयन सुरक्षित रखा जाता है।';

  @override
  String get registrationGoogleSetupInstructions => 'Google सेटअप निर्देश';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Microsoft सेटअप निर्देश';

  @override
  String get registrationDesktopConfiguration => 'डेस्कटॉप OAuth कॉन्फ़िगरेशन';

  @override
  String get registrationNoFileSelected => 'कोई फ़ाइल नहीं चुनी गई';

  @override
  String get registrationChooseFile => 'फ़ाइल चुनें…';

  @override
  String get registrationReplaceFile => 'बदलें…';

  @override
  String get registrationGoogleIntroduction =>
      'अपने Google Cloud प्रोजेक्ट की डेस्कटॉप OAuth JSON फ़ाइल चुनें।';

  @override
  String get registrationMicrosoftIntroduction =>
      'अपने Microsoft ऐप पंजीकरण की जानकारी दर्ज करें।';

  @override
  String get registrationSetupInstructions => 'सेटअप निर्देश';

  @override
  String get registrationInstructionsDescription =>
      'खाता जोड़ने के लिए आवश्यक कॉन्फ़िगरेशन बनाएँ।';

  @override
  String get registrationEnableApis => 'Calendar और Tasks चालू करें';

  @override
  String get registrationConsentScreen => 'सहमति स्क्रीन सेट करें';

  @override
  String get registrationAppName => 'ऐप का नाम';

  @override
  String get registrationScopes => 'अनुमति दायरे';

  @override
  String get registrationRedirectUri => 'रीडायरेक्ट URI';

  @override
  String get registrationOpenApiLibrary => 'Google API लाइब्रेरी खोलें';

  @override
  String get registrationOpenBranding =>
      'Google Auth Platform में Branding खोलें';

  @override
  String get registrationOpenDataAccess =>
      'Google Auth Platform में Data Access खोलें';

  @override
  String get registrationOpenClients =>
      'Google Auth Platform में Clients खोलें';

  @override
  String get registrationOpenEntraAuthentication =>
      'Authentication सेट करने के लिए Entra ऐप पंजीकरण खोलें';

  @override
  String get registrationOpenEntraPermissions =>
      'API permissions सेट करने के लिए Entra ऐप पंजीकरण खोलें';

  @override
  String get registrationCopy => 'कॉपी करें';

  @override
  String get registrationCopyAll => 'सभी कॉपी करें';

  @override
  String get registrationGuideGoogleApis =>
      'APIs & Services → Library में जाएँ। Google Calendar API खोजें, उसका पृष्ठ खोलें और Enable चुनें। Library पर लौटें और Google Tasks API के लिए यही करें।';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Supported account types में निजी खाते के लिए Personal accounts only, संगठन खातों के लिए Multiple Entra ID tenants, दोनों के लिए Any Entra ID Tenant + Personal Microsoft accounts, या इसी निर्देशिका के लिए Single tenant only चुनें। Register चुनें। Overview से Application (client) ID कॉपी करें; एक टेनेंट के लिए Directory (tenant) ID भी कॉपी करें। BusyMax में समान समर्थित खाते विकल्प चुनें।';

  @override
  String get registrationConnectBusyMax => 'BusyMax से कनेक्ट करें';

  @override
  String get registrationRecommended => 'अनुशंसित';

  @override
  String get registrationOtherMethods => 'कनेक्शन के अन्य तरीके';

  @override
  String get registrationWorkspace => 'Google Workspace संगठन';

  @override
  String get registrationGoogleCustom => 'कस्टम OAuth क्लाइंट';

  @override
  String get registrationMicrosoftCustom => 'कस्टम ऐप पंजीकरण';

  @override
  String get registrationMethodsIntroduction =>
      'अपना खाता कनेक्ट करने का तरीका चुनें।';

  @override
  String get registrationWorkspaceDescription =>
      'अपने संगठन द्वारा प्रबंधित कॉन्फ़िगरेशन इस्तेमाल करें।';

  @override
  String get registrationCustomDescription =>
      'अपने द्वारा प्रबंधित पंजीकरण इस्तेमाल करें।';

  @override
  String get registrationSharedUnavailable =>
      'इस बिल्ड में BusyMax कनेक्शन उपलब्ध नहीं है। नीचे कनेक्शन का कोई दूसरा तरीका इस्तेमाल कर सकते हैं।';

  @override
  String get registrationWorkspaceIntroduction =>
      'अपने संगठन द्वारा दिए या प्रबंधित Desktop OAuth JSON को चुनें। फ़ाइल संगठन का स्वामित्व, ऑडियंस या सत्यापन स्थिति साबित नहीं करती।';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Google Workspace सेटअप निर्देश';

  @override
  String get registrationBusyMaxManaged => 'BusyMax द्वारा प्रबंधित पंजीकरण';

  @override
  String get registrationBranding => 'ब्रैंडिंग और डोमेन कॉन्फ़िगर करें';

  @override
  String get registrationPublishing => 'सामान्य इस्तेमाल के लिए प्रकाशित करें';

  @override
  String get registrationOpenAudience => 'Google Auth Platform Audience खोलें';

  @override
  String get registrationGuideWorkspaceProject =>
      'व्यवस्थापक से Desktop OAuth JSON माँगें, या Google Cloud Console खोलकर अपने Google Workspace संगठन का प्रोजेक्ट चुनें। नया प्रोजेक्ट बनाने के लिए संसाधन प्रबंधित करें → प्रोजेक्ट बनाएँ खोलें, प्रोजेक्ट का नाम दर्ज करें, पैरेंट संसाधन में अपना संगठन या उसका फ़ोल्डर चुनें और बनाएँ चुनें। अगले चरणों के लिए वही प्रोजेक्ट चुनें। बनाने के लिए Project Creator, OAuth कॉन्फ़िगरेशन के लिए OAuth Config Editor और API चालू करने के लिए Service Usage Admin या समान अनुमतियाँ चाहिए। कार्रवाई अवरुद्ध हो तो व्यवस्थापक से मदद माँगें।';

  @override
  String get registrationGuideGoogleBranding =>
      'Branding → App domain में होमपेज, निजता नीति और सेवा शर्तों के URL से पहले प्रोजेक्ट के अधिकृत डोमेन जोड़ें, फिर Save चुनें। External प्रोडक्शन ऐप को ये लिंक चाहिए। अपने स्वामित्व वाले डोमेन इस्तेमाल करें और Google के ब्रैंड सत्यापन माँगने पर Search Console में स्वामित्व सत्यापित करें। नीचे BusyMax का निजता लिंक आपके प्रोजेक्ट का busystack.org पर स्वामित्व साबित नहीं करता।';

  @override
  String get registrationGuideGooglePublishing =>
      'Audience में Publish app चुनकर In production की पुष्टि करें। सामान्य इस्तेमाल को Testing में न छोड़ें: ये Calendar/Tasks प्राधिकरण और रीफ़्रेश टोकन सात दिन में समाप्त होते हैं। प्रकाशन और सत्यापन अलग हैं। 100 से कम उपयोगकर्ताओं वाला निजी इस्तेमाल चेतावनी और उपयोगकर्ता सीमा के साथ सत्यापन से मुक्त हो सकता है; बड़े वितरण में ब्रैंड और स्कोप स्वीकृति चाहिए हो सकती है। प्रोडक्शन प्राधिकरण भी समाप्त या रद्द हो सकते हैं।';

  @override
  String get registrationGuideWorkspacePermissions =>
      'व्यवस्थापक के साथ ये स्कोप देखें। Internal ऐप को सहमति स्क्रीन पर स्कोप सूची नहीं चाहिए। माँगे जाने पर Data Access → Add or remove scopes खोलें, मान जोड़ें, फिर Update और Save चुनें। व्यवस्थापक के नियंत्रण प्राधिकरण सीमित कर सकते हैं।';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'साझा कैलेंडर और श्रेणी अनुमतियाँ इन वैकल्पिक सुविधाओं को चालू करते समय अलग से माँगी जाती हैं; इन्हें ऊपर के अनिवार्य सेटअप में न जोड़ें।';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Google Auth Platform → Branding में जाएँ। सेटअप शुरू नहीं हुआ है तो Get started चुनें। App name में BusyMax दर्ज करें, अपना User support email चुनें और Next चुनें। Audience में Internal चुनें। Next चुनें, Contact Information में अपना ईमेल दर्ज करें और Next चुनें। User Data Policy स्वीकार करें और Continue तथा Create चुनें। पहले से सेट है तो Branding और Audience जाँचें।\n\nInternal सिर्फ़ प्रोजेक्ट के मूल संगठन के खातों को अनुमति देता है और व्यवस्थापक के नियंत्रण लागू रहते हैं। परीक्षण उपयोगकर्ताओं की सूची नहीं चाहिए। BusyMax डाउनलोड किए JSON से ये कंसोल सेटिंग सत्यापित नहीं कर सकता।';

  @override
  String get contactsTitle => 'संपर्क';

  @override
  String get contactsLinkedDescription =>
      'इवेंट में अतिथि जोड़ते समय इस खाते के कैश किए गए संपर्कों का उपयोग करें।';

  @override
  String get contactsEnableSuggestions => 'संपर्क सुझाव चालू करें';

  @override
  String get contactsReadPermissionDescription =>
      'संपर्कों के लिए केवल पढ़ने की अनुमति माँगता है';

  @override
  String get contactsEnableEditing => 'संपर्क संपादन चालू करें';

  @override
  String get contactsWritePermissionDescription =>
      'संपर्कों को पढ़ने और लिखने की अनुमति माँगता है';

  @override
  String get contactsSuggestionsEnabled => 'संपर्क सुझाव चालू हैं';

  @override
  String get contactsNeedsAttention => 'संपर्कों पर ध्यान देना आवश्यक है';

  @override
  String get contactsReadWriteAccess => 'पढ़ने और लिखने की पहुँच';

  @override
  String get contactsDisableForAccount => 'इस खाते के संपर्क बंद करें';

  @override
  String get contactsOnlyDescription =>
      'ये स्रोत कैलेंडर और कार्य खातों से स्वतंत्र हैं।';

  @override
  String get contactsAddCardDav => 'CardDAV संपर्क जोड़ें';

  @override
  String get contactsAddNextcloud => 'Nextcloud संपर्क जोड़ें';

  @override
  String get contactsUseForAttendees =>
      'उपस्थित व्यक्ति के सुझावों के लिए उपयोग करें';

  @override
  String get contactsServerUrlLabel => 'HTTPS सर्वर URL';

  @override
  String get contactsUsernameLabel => 'उपयोगकर्ता नाम';

  @override
  String get contactsPasswordLabel => 'पासवर्ड';
}
