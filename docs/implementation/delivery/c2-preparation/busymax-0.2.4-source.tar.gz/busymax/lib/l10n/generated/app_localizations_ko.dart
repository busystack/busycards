// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Korean (`ko`).
class AppLocalizationsKo extends AppLocalizations {
  AppLocalizationsKo([String locale = 'ko']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      '데스크톱의 시작 프로그램 설정에 의해 BusyMax가 실행되었습니다. 이 스위치를 사용하려면 해당 설정에서 BusyMax 항목을 제거한 다음 BusyMax를 완전히 종료하고 다시 여세요.';

  @override
  String get timeFormat => '시간 형식';

  @override
  String get firstDayOfWeek => '한 주의 시작 요일';

  @override
  String get systemDefault => '시스템 기본값';

  @override
  String systemDefaultResolved(String weekday) {
    return '시스템 기본값($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12시간';

  @override
  String get timeFormatTwentyFourHour => '24시간';

  @override
  String get timeEndOfDay => '하루의 끝';

  @override
  String get timePeriod => '오전/오후';

  @override
  String get launchAtLoginReadFailed => '로그인 시 실행 상태를 확인할 수 없습니다.';

  @override
  String get launchAtLoginUnavailable => '이 시스템에서는 로그인 시 실행을 사용할 수 없습니다.';

  @override
  String get windowsStartupEnabledByPolicy =>
      '관리자가 자동 시작을 활성화했으며 여기서는 변경할 수 없습니다.';

  @override
  String get settingsSaveFailed =>
      '설정을 저장할 수 없습니다. BusyMax를 다시 시작하면 변경 사항이 사라질 수 있습니다.';

  @override
  String get nextcloudExportCollection => '컬렉션 리소스 내보내기';

  @override
  String nextcloudImportItems(int count) {
    return '일정/작업 리소스 $count개 발견';
  }

  @override
  String get nextcloudSchedulingInbox => '일정 초대 수신함';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud가 이 메시지를 캘린더에 반영합니다. 확인하면 메시지만 삭제되고 일정은 유지됩니다.';

  @override
  String get nextcloudInboxEmpty => '일정 메시지가 없습니다.';

  @override
  String get nextcloudAcknowledge => '메시지 확인';

  @override
  String get nextcloudAcknowledgeConfirm =>
      '수신함에서 이 메시지를 삭제할까요? 캘린더 일정은 유지됩니다.';

  @override
  String get nextcloudGuestAvailability => '참석자의 가능한 시간 확인';

  @override
  String nextcloudTrashRetention(int days) {
    return '서버 휴지통 보관 기간: $days일';
  }

  @override
  String get nextcloudCancelMeeting => '회의 취소';

  @override
  String get nextcloudDeclineAndRemove => '초대 거절 및 삭제';

  @override
  String get nextcloudDeclineRemovalWarning =>
      '동기화할 때 거절 응답을 보냅니다. 주최자의 회의는 취소되지 않습니다.';

  @override
  String get nextcloudAvailabilityUnknown => '가능한 시간 알 수 없음';

  @override
  String get nextcloudAvailabilityFree => '이 시간대에 보고된 바쁜 시간이 없습니다';

  @override
  String get nextcloudAvailabilityBusy => '바쁜 시간대';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud는 동기화할 때 회의 변경 내용을 보냅니다. 로컬 저장은 전달 완료를 의미하지 않습니다.';

  @override
  String get nextcloudAttendeeRestrictions =>
      '주최자나 권한 있는 대리인만 회의 세부 정보를 변경할 수 있습니다. 초대 세부 정보에서 응답할 수 있습니다.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      '복사 후 삭제하는 방식으로는 이 회의를 이동할 수 없습니다. 동일한 일정 관리 주체의 캘린더를 사용하세요.';

  @override
  String get nextcloudSchedulingStatus => '서버 일정 처리 상태';

  @override
  String get nextcloudImportFollowUp =>
      '가져온 리소스를 로컬에 저장했습니다. 알림 새로 고침이 대기 중이므로 다시 가져오지 마세요.';

  @override
  String get nextcloudNativeImport =>
      '초대를 보내지 않고 완전한 일정과 작업 리소스를 가져옵니다. 새 사본을 선택하지 않으면 기존 UID를 건너뜁니다. 지원하지 않는 리소스는 개별 보고합니다.';

  @override
  String get nextcloudImportMethod =>
      '이 파일에는 일정 메시지가 있습니다. 가져오기는 내용을 저장하고 METHOD를 제거하며 초대나 응답을 처리하지 않습니다.';

  @override
  String get nextcloudImportCopies => '새 식별자로 새 사본 가져오기';

  @override
  String get nextcloudCollectionSettings => '컬렉션 설정';

  @override
  String get nextcloudSharing => '공유 설정';

  @override
  String get nextcloudOwned => '소유함';

  @override
  String get nextcloudShared => '공유됨';

  @override
  String get nextcloudDelegated => '위임됨';

  @override
  String get nextcloudSubscription => '구독';

  @override
  String get nextcloudDeleted => '삭제됨';

  @override
  String get nextcloudMetadataEditable =>
      '캘린더 내용은 읽기 전용이지만 컬렉션 속성은 변경할 수 있습니다.';

  @override
  String get nextcloudServerOrder => '서버 순서(사이드바 순서와 별개)';

  @override
  String get nextcloudCalendarEnabled => '서버에서 활성화';

  @override
  String get nextcloudAvailability => '가능한 시간 계산에 이 컬렉션 포함';

  @override
  String get nextcloudCalendarTimezone => '캘린더 시간대(VTIMEZONE 문서)';

  @override
  String get nextcloudRefreshPending =>
      '변경 내용을 Nextcloud에 저장했습니다. 새로 고침이 대기 중이므로 변경을 반복하지 마세요.';

  @override
  String get nextcloudOutcomeUnknown => '서버 결과를 확인하지 못했습니다. 새로 고친 후 다시 시도하세요.';

  @override
  String get nextcloudRemoveShared => '공유 캘린더/목록 제거';

  @override
  String get nextcloudRemoveMixed => '이 컬렉션에는 일정과 작업이 있습니다. 삭제하면 둘 다 삭제됩니다.';

  @override
  String get nextcloudReadAccess => '읽기 전용';

  @override
  String get nextcloudWriteAccess => '읽기 및 쓰기';

  @override
  String get nextcloudRecipientSearch => '사용자 또는 그룹 찾기';

  @override
  String get nextcloudNoRecipients => '일치하는 사용자나 그룹이 없습니다.';

  @override
  String get nextcloudRevokeShare => '접근 권한 취소';

  @override
  String get nextcloudPublish => '링크 공개';

  @override
  String get nextcloudUnpublish => '공개 중단';

  @override
  String get nextcloudPublishWarning =>
      '공개 링크가 있는 사람은 이 캘린더를 읽을 수 있습니다. 공개할까요?';

  @override
  String get nextcloudTrash => '삭제된 캘린더와 작업';

  @override
  String get nextcloudTrashEmpty => '삭제된 캘린더 항목이 없습니다.';

  @override
  String get nextcloudRestore => '복원';

  @override
  String get nextcloudPermanentDelete => '영구 삭제';

  @override
  String get nextcloudPermanentDeleteWarning =>
      '이 항목을 영구 삭제할까요? Nextcloud 캘린더 휴지통에서 복원할 수 없게 됩니다.';

  @override
  String get nextcloudOperationDenied => 'Nextcloud가 이 작업을 허용하지 않았습니다.';

  @override
  String get nextcloudUnsupported => '서버가 이 작업을 지원하지 않습니다.';

  @override
  String get nextcloudPendingChanges => '닫기 전에 컬렉션 변경 내용을 저장하거나 버리세요.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud에 연결하지 못했습니다. 캐시와 대기 중인 변경 내용은 유지됩니다.';

  @override
  String get mapsShow => '지도에서 보기';

  @override
  String get openLink => '링크 열기';

  @override
  String get externalLocationOpenFailed => '외부 앱에서 위치를 열 수 없습니다.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      '일정 시간을 변경하지 못했습니다. 저장된 시간은 변경되지 않았습니다.';

  @override
  String get scheduleRescheduleStale => '드래그하는 동안 이 일정이 변경되었습니다. 다시 시도해 주세요.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      '새 시간은 저장되었지만 알림을 갱신하지 못했습니다.';

  @override
  String get moveUp => '위로 이동';

  @override
  String get moveDown => '아래로 이동';

  @override
  String get windowsSupport => '지원';

  @override
  String get windowsThirdPartyLicenses => '타사 라이선스';

  @override
  String get windowsSearch => '검색';

  @override
  String get windowsStartupDisabledByUser =>
      'Windows 설정에서 사용자가 사용하지 않도록 설정했습니다.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Windows 정책에 의해 사용하지 않도록 설정되었습니다.';

  @override
  String get windowsStartupUnavailable => 'BusyMax를 MSIX 패키지로 설치하면 사용할 수 있습니다.';

  @override
  String get windowsReminderExitNotice =>
      'BusyMax를 완전히 종료하면 미리 알림이 중지됩니다. 받으려면 백그라운드에서 계속 실행하세요.';

  @override
  String get windowsProductVersionLabel => '제품 버전';

  @override
  String get windowsPackageVersionLabel => 'Windows 패키지 버전';

  @override
  String get windowsUnpackaged => '패키지되지 않음';

  @override
  String get windowsAgendaLoadMore => '일정 항목 더 불러오기';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '월요일',
      'TU': '화요일',
      'WE': '수요일',
      'TH': '목요일',
      'FR': '금요일',
      'SA': '토요일',
      'SU': '일요일',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first과 $second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $month의 $firstDay과 $secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency $firstMonth과 $secondMonth의 $day';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $firstMonth과 $secondMonth의 $firstDay과 $secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency $firstMonth과 $secondMonth의 $days';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Google, Microsoft, Apple iCloud Calendar 또는 Nextcloud 계정을 연결하세요.';

  @override
  String get googlePermissionsConsentNotice =>
      'Google 권한 화면에서 캘린더와 할 일 권한을 모두 선택하세요.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google Calendar 및 Google Tasks 권한이 필요합니다. 다시 시도하여 두 체크박스를 모두 선택하세요.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => '이 서비스는 설정되어 있지 않습니다.';

  @override
  String get waitingForGoogleSignIn => 'Google 로그인을 기다리는 중...';

  @override
  String get waitingForMicrosoftSignIn => 'Microsoft 로그인을 기다리는 중...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsoft 로그인이 구성되지 않았습니다. MICROSOFT_OAUTH_CLIENT_ID를 설정하세요.';

  @override
  String get cancel => '취소';

  @override
  String get close => '닫기';

  @override
  String get windowMinimize => '최소화';

  @override
  String get windowMaximize => '최대화';

  @override
  String get windowRestore => '복원';

  @override
  String get exit => '종료';

  @override
  String get options => '옵션';

  @override
  String get hide => '숨기기';

  @override
  String get show => '표시';

  @override
  String get export => '내보내기';

  @override
  String get save => '저장';

  @override
  String get settings => '설정';

  @override
  String get all => '모두';

  @override
  String get calendarEvents => '일정';

  @override
  String get calendarTasks => '할 일';

  @override
  String get calendar => '캘린더';

  @override
  String get calendars => '캘린더';

  @override
  String get newCalendar => '새 캘린더';

  @override
  String get calendarColor => '캘린더 색상';

  @override
  String calendarColorOption(int number) {
    return '색상 $number';
  }

  @override
  String get calendarManagementUnsupported =>
      '이 공급자는 BusyMax에서 캘린더 관리를 지원하지 않습니다.';

  @override
  String get primaryCalendarCannotDelete => '기본 캘린더는 삭제할 수 없습니다.';

  @override
  String calendarCreateFailed(String error) {
    return '캘린더를 만들 수 없습니다: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      '캘린더가 생성되었지만 BusyMax에서 계정을 새로 고치지 못했습니다. 다음 동기화 후에 표시됩니다.';

  @override
  String calendarUpdateFailed(String error) {
    return '캘린더를 업데이트할 수 없습니다: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return '캘린더를 삭제할 수 없습니다: $error';
  }

  @override
  String get newEvent => '새 일정';

  @override
  String get refreshCalendar => '캘린더 새로 고침';

  @override
  String get openInProvider => '서비스에서 열기';

  @override
  String get linkedResources => '연결된 리소스';

  @override
  String get noLinkedResources => '연결된 리소스가 없습니다';

  @override
  String get attachments => '첨부 파일';

  @override
  String get attachmentsNotLoaded => '첨부 파일을 불러오지 못했습니다';

  @override
  String get hideFromSchedule => '일정에서 숨기기';

  @override
  String get showInSchedule => '일정에 표시';

  @override
  String get noCalendarsSynced => '아직 동기화된 캘린더가 없습니다.';

  @override
  String get allDay => '하루 종일';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString개 더 보기';
  }

  @override
  String get noEventsOrTasks => '일정 또는 할 일이 없습니다';

  @override
  String get scheduleLoading => '일정을 불러오는 중...';

  @override
  String get scheduleUnavailable => '일정을 사용할 수 없습니다';

  @override
  String get scheduleNoSources => '표시할 캘린더 또는 할 일 목록이 없습니다';

  @override
  String get scheduleNoSourcesDescription => '설정에서 표시할 항목을 선택한 다음 새로 고침하세요.';

  @override
  String get scheduleNoSearchResults => '일치하는 일정 또는 할 일이 없습니다';

  @override
  String get scheduleNoSearchResultsDescription => '다른 검색어를 사용하거나 현재 필터를 지우세요.';

  @override
  String get refresh => '새로 고침';

  @override
  String get trayOpenBusyMax => 'BusyMax 열기';

  @override
  String get trayShowBusyMax => 'BusyMax 표시';

  @override
  String get trayNewEvent => '새 일정…';

  @override
  String get trayNewTask => '새 할 일…';

  @override
  String get trayToday => '오늘';

  @override
  String get trayAllDay => '종일';

  @override
  String get trayNow => '지금';

  @override
  String get trayCalendarEvent => '캘린더 일정';

  @override
  String get trayUntitledEvent => '제목 없는 일정';

  @override
  String get trayNothingElseToday => '오늘은 더 이상 없음';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '오늘 마감인 할 일 $count개',
      one: '오늘 마감인 할 일 1개',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => '오늘 일정 열기';

  @override
  String get traySyncNow => '지금 동기화';

  @override
  String get traySyncing => '동기화 중…';

  @override
  String get trayNotConnected => '연결되지 않음';

  @override
  String get trayNotYetSynced => '아직 동기화되지 않음';

  @override
  String get trayLastSyncedJustNow => '방금 동기화됨';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count분 전에 동기화됨',
      one: '1분 전에 동기화됨',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count시간 전에 동기화됨',
      one: '1시간 전에 동기화됨',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count일 전에 동기화됨',
      one: '1일 전에 동기화됨',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => '설정';

  @override
  String get trayQuitBusyMax => 'BusyMax 종료';

  @override
  String get agendaLoadMoreOverdue => '기한이 지난 할 일 더 불러오기';

  @override
  String get agendaLoadMoreNoDate => '날짜 없는 할 일 더 불러오기';

  @override
  String get viewDay => '일';

  @override
  String get viewWeek => '주';

  @override
  String get viewMonth => '월';

  @override
  String get viewYear => '년';

  @override
  String get viewAgenda => '일정 목록';

  @override
  String get scheduleSettings => '일정';

  @override
  String get scheduleDisplaySettings => '일정 표시';

  @override
  String get newEventsAndTasks => '새 일정 및 작업';

  @override
  String get defaultCalendar => '기본 캘린더';

  @override
  String get defaultTaskList => '기본 작업 목록';

  @override
  String get lastUsed => '마지막으로 사용';

  @override
  String get scheduleDisplayHoursDescription =>
      '일간 및 주간 보기는 처음에 이 시간 범위를 표시합니다. 필요한 경우 더 이르거나 늦은 항목에 맞춰 범위가 확장됩니다.';

  @override
  String get scheduleDayStartsAt => '하루 시작 시간';

  @override
  String get scheduleDayEndsAt => '하루 종료 시간';

  @override
  String get sourceCalendar => '캘린더';

  @override
  String get sourceTaskList => '할 일 목록';

  @override
  String get createChoiceTitle => '만들기';

  @override
  String get createEventAtTime => '일정';

  @override
  String get createTaskAtDate => '할 일';

  @override
  String get editEvent => '일정 편집';

  @override
  String get eventTitle => '일정 제목';

  @override
  String get location => '위치';

  @override
  String get timeSlot => '시간대';

  @override
  String get startDateTime => '시작 날짜/시간';

  @override
  String get endDateTime => '종료 날짜/시간';

  @override
  String get doesNotRepeat => '반복 안 함';

  @override
  String get defaultReminder => '기본 미리 알림';

  @override
  String get guests => '참석자';

  @override
  String get noGuests => '참석자 없음';

  @override
  String get attendeeRequired => '필수';

  @override
  String get attendeeOptional => '선택사항';

  @override
  String get meetingSection => '회의';

  @override
  String get addGoogleMeet => 'Google Meet 추가';

  @override
  String get addTeamsMeeting => 'Microsoft Teams 회의 추가';

  @override
  String get onlineMeetingAdded => '온라인 회의가 추가됨';

  @override
  String get requestResponses => '응답 요청';

  @override
  String get requestResponsesDescription => '참석자에게 초대에 응답하도록 요청합니다.';

  @override
  String get hideGuestList => '참석자 목록 숨기기';

  @override
  String get hideGuestListDescription => '참석자는 다른 초대 대상자를 볼 수 없습니다.';

  @override
  String get allowNewTimeProposals => '새 시간 제안 허용';

  @override
  String get allowNewTimeProposalsDescription => '참석자가 다른 회의 시간을 제안할 수 있습니다.';

  @override
  String get notifyGuestsTitle => '참석자에게 알릴까요?';

  @override
  String get notifyGuestsSaveMessage =>
      '이 회의에는 참석자가 있습니다. 저장할 때 초대 또는 일정 업데이트를 보낼까요?';

  @override
  String get notifyGuestsDeleteMessage => '이 회의에는 참석자가 있습니다. 삭제할 때 취소를 보낼까요?';

  @override
  String get sendUpdates => '업데이트 보내기';

  @override
  String get sendCancellation => '취소 보내기';

  @override
  String get doNotSend => '보내지 않음';

  @override
  String get microsoftNotifyGuestsSaveTitle => '회의를 저장할까요?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft에서 참석자에게 초대 또는 일정 업데이트를 보냅니다.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '회의를 삭제할까요?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft에서 참석자에게 취소를 보냅니다.';

  @override
  String get organizer => '주최자';

  @override
  String get yourResponse => '내 응답';

  @override
  String get guestResponses => '참석자 응답';

  @override
  String get respond => '응답';

  @override
  String get acceptInvitation => '수락';

  @override
  String get tentativeInvitation => '미정';

  @override
  String get declineInvitation => '거절';

  @override
  String get joinMeeting => '회의 참가';

  @override
  String get responseAccepted => '수락됨';

  @override
  String get responseTentative => '미정';

  @override
  String get responseDeclined => '거절됨';

  @override
  String get responseNeedsAction => '응답 대기 중';

  @override
  String get responseNotResponded => '응답하지 않음';

  @override
  String get responseOrganizer => '주최자';

  @override
  String invitationResponseFailed(String error) {
    return '응답을 보낼 수 없습니다: $error';
  }

  @override
  String get joinMeetingFailed => '회의 링크를 열 수 없습니다.';

  @override
  String get description => '설명';

  @override
  String get availabilityShowAs => '일정 상태 / 표시 방식';

  @override
  String get busy => '바쁨';

  @override
  String get visibility => '공개 범위';

  @override
  String get defaultVisibility => '기본 공개 범위';

  @override
  String get conference => '회의';

  @override
  String get noConference => '회의 없음';

  @override
  String get providerCalendar => '서비스 캘린더';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => '굵게';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => '기울임꼴';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => '밑줄';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString분 전',
      one: '1분 전',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => '시작 시';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString시간 전',
      one: '1시간 전',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString일 전',
      one: '1일 전',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => '한가함';

  @override
  String get availabilityTentative => '미정';

  @override
  String get availabilityOutOfOffice => '부재중';

  @override
  String get availabilityWorkingElsewhere => '다른 장소에서 근무';

  @override
  String get visibilityDefault => '기본값';

  @override
  String get visibilityPublic => '공개';

  @override
  String get visibilityPrivate => '비공개';

  @override
  String get visibilityConfidential => '기밀';

  @override
  String get sensitivityNormal => '일반';

  @override
  String get sensitivityPersonal => '개인';

  @override
  String get tasks => '할 일';

  @override
  String get allTasks => '모든 할 일';

  @override
  String tasksInList(String title) {
    return '$title의 할 일';
  }

  @override
  String get taskLists => '할 일 목록';

  @override
  String get navigation => '탐색';

  @override
  String get mainMenu => '주 메뉴';

  @override
  String get keyboardShortcuts => '키보드 단축키';

  @override
  String get shortcutGroupGeneral => '일반';

  @override
  String get shortcutKeyboardShortcutsDescription => '이 단축키 도움말 표시';

  @override
  String get shortcutGroupNavigation => '탐색';

  @override
  String get shortcutNextPeriod => '다음 기간';

  @override
  String get shortcutNextPeriodDescription =>
      '주간 보기에서는 다음 주, 월간 보기에서는 다음 달로 이동하는 식입니다';

  @override
  String get shortcutPreviousPeriod => '이전 기간';

  @override
  String get shortcutPreviousPeriodDescription =>
      '주간 보기에서는 이전 주, 월간 보기에서는 이전 달로 이동하는 식입니다';

  @override
  String get shortcutJumpToToday => '오늘로 이동';

  @override
  String get shortcutGroupView => '보기';

  @override
  String get viewSelector => '보기';

  @override
  String get shortcutDayView => '일간 보기';

  @override
  String get shortcutWeekView => '주간 보기';

  @override
  String get shortcutMonthView => '월간 보기';

  @override
  String get shortcutYearView => '연간 보기';

  @override
  String get shortcutAgendaView => '일정 목록 보기';

  @override
  String get shortcutGroupCreateAndEdit => '만들기 및 편집';

  @override
  String get shortcutSaveItem => '일정 또는 할 일 저장';

  @override
  String get shortcutDeleteItem => '일정 또는 할 일 삭제';

  @override
  String get shortcutGroupTaskEditing => '할 일 편집';

  @override
  String get shortcutCancelEditing => '편집 취소';

  @override
  String get shortcutCancelEditingDescription => '할 일 편집 또는 할 일 세부 정보 닫기';

  @override
  String get aboutBusyMax => 'BusyMax 정보';

  @override
  String get aboutBusyMaxDescription => '캘린더와 할 일';

  @override
  String get license => '라이선스';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => '웹사이트';

  @override
  String get sourceCode => '소스 코드';

  @override
  String get reportAnIssue => '문제 신고';

  @override
  String get sendFeedback => '의견 보내기';

  @override
  String get feedbackSubmit => '제출';

  @override
  String get feedbackCategory => '범주';

  @override
  String get feedbackSelectCategory => '범주 선택';

  @override
  String get feedbackCategoryProblem => '문제 또는 버그';

  @override
  String get feedbackCategoryFeature => '기능 요청';

  @override
  String get feedbackCategoryPrivacySecurity => '개인정보 보호 또는 보안 우려';

  @override
  String get feedbackCategoryUsability => '사용 편의성 문제';

  @override
  String get feedbackCategoryOther => '기타';

  @override
  String get feedbackSubject => '제목';

  @override
  String get feedbackDetailedMessage => '자세한 내용';

  @override
  String get feedbackReplyEmail => '답변 받을 이메일 주소(선택 사항)';

  @override
  String get feedbackIncludeTechnicalDetails => '기술 세부 정보 포함';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      '운영 체제 이름과 버전 및 앱 로캘만 추가됩니다. 로그, 계정 데이터, 파일 이름 또는 기타 진단 정보는 포함되지 않습니다.';

  @override
  String get feedbackCategoryRequired => '범주를 선택하세요.';

  @override
  String get feedbackSubjectLengthError => '제목은 3~120자여야 합니다.';

  @override
  String get feedbackMessageLengthError => '메시지는 10~5,000자여야 합니다.';

  @override
  String get feedbackInvalidEmail => '올바른 이메일 주소를 입력하세요.';

  @override
  String get feedbackConnectionError =>
      'BusyStack에 연결할 수 없습니다. 연결을 확인하고 다시 시도하세요.';

  @override
  String get feedbackTimeoutError =>
      '요청 시간이 초과되었습니다. 의견은 지워지지 않았습니다. 다시 시도하세요.';

  @override
  String get feedbackRateLimitedError =>
      '이 네트워크에서 너무 많은 의견이 제출되었습니다. 잠시 기다린 후 다시 시도하세요.';

  @override
  String get feedbackRejectedError => '서버가 제출을 거부했습니다. 입력란을 검토하고 다시 시도하세요.';

  @override
  String get feedbackServerError =>
      '현재 BusyStack에서 의견을 받을 수 없습니다. 의견은 지워지지 않았습니다. 다시 시도하세요.';

  @override
  String feedbackSuccess(String id) {
    return '의견을 보냈습니다. 참조: $id';
  }

  @override
  String get toggleSidebar => '사이드바 표시 전환';

  @override
  String get showSidebar => '사이드바 패널 표시';

  @override
  String get hideSidebar => '사이드바 패널 숨기기';

  @override
  String get accounts => '계정';

  @override
  String get currentAccount => '현재 계정';

  @override
  String get switchAccount => '계정 전환';

  @override
  String get addGoogleAccount => 'Google 계정 추가';

  @override
  String get addMicrosoftAccount => 'Microsoft 계정 추가';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => '로그인됨';

  @override
  String get removeAccount => '계정 삭제…';

  @override
  String get removingAccount => '계정 삭제 중…';

  @override
  String get removeAccountDescription => '동기화를 중지하고 이 기기에서 이 계정의 데이터를 삭제합니다.';

  @override
  String removeAccountTitle(String account) {
    return '$account을(를) BusyMax에서 삭제할까요?';
  }

  @override
  String get removeAccountConfirmation =>
      '이 작업은 이 기기에서 캐시된 할 일, 캘린더, 일정, 알림 및 보류 중인 오프라인 변경사항을 삭제합니다. 동기화되지 않은 변경사항은 손실됩니다. 제공업체의 캘린더, 일정, 할 일 목록 및 할 일 사본은 삭제되지 않습니다.';

  @override
  String get revokeGoogleAccess => '이 Google 계정에 대한 BusyMax의 액세스 권한도 취소';

  @override
  String get revokeGoogleAccessDescription => '다시 연결하기 전에 액세스 권한을 다시 부여해야 합니다.';

  @override
  String get removeAccountAction => '계정 삭제';

  @override
  String get removeAccountFailed => '계정 삭제를 완료할 수 없습니다. 다시 시도하세요.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      '계정은 이 기기에서 삭제되었지만 BusyMax가 Google 계정 액세스 권한을 취소하지 못했습니다. Google 계정에서 직접 취소할 수 있습니다.';

  @override
  String get newTaskList => '새 할 일 목록';

  @override
  String taskListCreateFailed(String error) {
    return '할 일 목록을 만들 수 없습니다: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return '할 일 목록 이름을 바꿀 수 없습니다: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return '할 일 목록을 삭제할 수 없습니다: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      '목록을 삭제하거나 제거하기 전에 계정을 동기화하거나 진단에서 이 작업 목록의 차단된 변경 사항을 해결하세요.';

  @override
  String get signInToViewTaskLists => '할 일 목록을 보려면 로그인하세요.';

  @override
  String get noTaskListsSynced => '아직 동기화된 할 일 목록이 없습니다.';

  @override
  String get listActions => '목록 작업';

  @override
  String get rename => '이름 바꾸기';

  @override
  String get delete => '삭제';

  @override
  String get renameList => '목록 이름 바꾸기';

  @override
  String get deleteList => '목록 삭제';

  @override
  String get unshare => '공유 해제';

  @override
  String get readOnlyTaskListCannotRename =>
      '이 할 일 목록은 읽기 전용이므로 이름을 바꿀 수 없습니다.';

  @override
  String get taskListCannotDelete => '현재 권한으로는 이 할 일 목록을 삭제할 수 없습니다.';

  @override
  String get builtInMicrosoftList => '기본 제공';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Microsoft To Do의 기본 제공 목록은 이름을 바꾸거나 삭제할 수 없습니다.';

  @override
  String deleteListConfirmation(String title) {
    return 'Google Tasks에서 “$title”을(를) 삭제할까요?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '“$title” 및 모든 할 일을 삭제할까요?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return '이 계정에서 “$title” 공유를 해제할까요?';
  }

  @override
  String get deleteEvent => '일정 삭제';

  @override
  String get title => '제목';

  @override
  String get create => '만들기';

  @override
  String get newTask => '새 할 일';

  @override
  String get clearCompleted => '완료된 항목 지우기';

  @override
  String get refreshList => '목록 새로 고침';

  @override
  String get refreshAll => '모두 새로 고침';

  @override
  String get listRefreshed => '목록을 새로 고쳤습니다.';

  @override
  String get allTasksRefreshed => '모든 계정을 새로 고쳤습니다.';

  @override
  String exportedFile(String path) {
    return '$path에 내보냈습니다';
  }

  @override
  String exportFailed(String error) {
    return '내보내기 실패: $error';
  }

  @override
  String refreshFailed(String error) {
    return '새로 고침 실패: $error';
  }

  @override
  String get selectOrCreateTaskList => '시작하려면 할 일 목록을 선택하거나 만드세요.';

  @override
  String get signInToViewTasks => '할 일을 보려면 로그인하세요.';

  @override
  String get noTasks => '할 일이 없습니다.';

  @override
  String get noTasksYet => '아직 할 일이 없습니다';

  @override
  String get noTasksYetMessage => '할 일을 만들거나 계정을 새로 고쳐 시작하세요.';

  @override
  String get noTasksInList => '이 목록에 할 일이 없습니다.';

  @override
  String get overdue => '기한 지남';

  @override
  String get today => '오늘';

  @override
  String get tomorrow => '내일';

  @override
  String get upcoming => '예정';

  @override
  String get noDate => '날짜 없음';

  @override
  String get completed => '완료';

  @override
  String duePrefix(String date) {
    return '$date 마감';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => '할 일 세부 정보';

  @override
  String get editTask => '할 일 편집';

  @override
  String get noTaskSelected => '선택된 할 일이 없습니다.';

  @override
  String get noTaskSelectedHelper => '세부 정보를 보고 편집할 할 일을 선택하세요.';

  @override
  String get taskUnavailable => '할 일을 사용할 수 없습니다.';

  @override
  String get signInToEditTasks => '할 일을 편집하려면 로그인하세요.';

  @override
  String get refreshTask => '할 일 새로 고침';

  @override
  String get primarySection => '기본';

  @override
  String get statusSection => '상태';

  @override
  String get openStatus => '미완료';

  @override
  String get doneStatus => '완료';

  @override
  String get taskStatus => '상태';

  @override
  String get taskStatusNone => '상태 없음';

  @override
  String get taskStatusNeedsAction => '조치 필요';

  @override
  String get taskStatusInProcess => '진행 중';

  @override
  String get taskStatusCompleted => '완료';

  @override
  String get taskStatusCancelled => '취소됨';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% 완료';
  }

  @override
  String get completionDate => '완료 날짜';

  @override
  String get priority => '우선순위';

  @override
  String get priorityNone => '우선순위 없음';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '우선순위 $priorityString · 높음';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '우선순위 $priorityString · 중간';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '우선순위 $priorityString · 낮음';
  }

  @override
  String get taskUrl => '할 일 URL';

  @override
  String get invalidTaskUrl => '스킴을 포함한 절대 URL을 입력하세요.';

  @override
  String get classification => '분류';

  @override
  String get classificationPublic => '공유할 때 전체 할 일 표시';

  @override
  String get classificationConfidential => '공유할 때 바쁨 상태만 표시';

  @override
  String get classificationPrivate => '공유할 때 이 할 일 숨기기';

  @override
  String get pinTask => '할 일 고정';

  @override
  String get notes => '메모';

  @override
  String get dueDate => '마감일';

  @override
  String get clearDueDate => '마감일 지우기';

  @override
  String get dueTime => '마감 시간';

  @override
  String get startDate => '시작일';

  @override
  String get startTime => '시작 시간';

  @override
  String get endDate => '종료일';

  @override
  String get endTime => '종료 시간';

  @override
  String get reminderDate => '미리 알림 날짜';

  @override
  String get reminderTime => '미리 알림 시간';

  @override
  String get reminder => '미리 알림';

  @override
  String get addReminder => '알림 추가';

  @override
  String get reminders => '알림';

  @override
  String get noReminders => '알림 없음';

  @override
  String get editReminder => '알림 수정';

  @override
  String get beforeTaskStarts => '할 일 시작 전';

  @override
  String get beforeTaskDue => '할 일 마감 전';

  @override
  String get afterTaskStarts => '할 일 시작 후';

  @override
  String get afterTaskDue => '할 일 마감 후';

  @override
  String get relativeToTaskStart => '할 일 시작일 기준';

  @override
  String get relativeToTaskDue => '할 일 마감일 기준';

  @override
  String get reminderTimeOfDay => '시간';

  @override
  String get absoluteReminder => '날짜 및 시간에';

  @override
  String get reminderAmount => '수량';

  @override
  String get reminderUnit => '단위';

  @override
  String get reminderUnitSeconds => '초';

  @override
  String get reminderUnitMinutes => '분';

  @override
  String get reminderUnitHours => '시간';

  @override
  String get reminderUnitDays => '일';

  @override
  String get reminderUnitWeeks => '주';

  @override
  String get reminderAtTaskStart => '할 일 시작 시';

  @override
  String get reminderAtTaskDue => '할 일 마감 시';

  @override
  String get unsupportedReminder => '이 알림 유형은 유지되지만 시간을 수정할 수 없습니다.';

  @override
  String get relatedRemindersTitle => '관련 알림을 유지할까요?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '이 날짜에 관련 알림이 $countString개 있습니다. 현재 날짜와 시간에 유지할까요?';
  }

  @override
  String get discardRelatedReminders => '알림 삭제';

  @override
  String get keepRelatedReminders => '알림 유지';

  @override
  String get addGuest => '참석자 추가';

  @override
  String get addGuestEmail => '참석자 이메일 추가';

  @override
  String get removeReminder => '미리 알림 삭제';

  @override
  String get off => '끔';

  @override
  String get repeat => '반복';

  @override
  String get repeatNone => '없음';

  @override
  String get noneValue => '없음';

  @override
  String get repeatDaily => '매일';

  @override
  String get repeatWeekly => '매주';

  @override
  String get repeatMonthly => '매월';

  @override
  String get repeatYearly => '매년';

  @override
  String get repeatEvery => '반복 간격';

  @override
  String get repeatOn => '반복 요일';

  @override
  String get repeatEnd => '반복 종료';

  @override
  String get repeatNever => '안 함';

  @override
  String get repeatUntil => '날짜까지';

  @override
  String get repeatAfter => '지정한 횟수 후';

  @override
  String get repeatCount => '반복 횟수';

  @override
  String get repeatDayOfMonth => '월의 날짜';

  @override
  String get repeatMonths => '월';

  @override
  String get repeatOrdinal => '요일 순서';

  @override
  String get repeatSpecificDays => '특정 요일';

  @override
  String get repeatFirst => '첫 번째';

  @override
  String get repeatSecond => '두 번째';

  @override
  String get repeatThird => '세 번째';

  @override
  String get repeatFourth => '네 번째';

  @override
  String get repeatFifth => '다섯 번째';

  @override
  String get repeatSecondToLast => '끝에서 두 번째';

  @override
  String get repeatLast => '마지막';

  @override
  String get repeatAnyDay => '요일';

  @override
  String get repeatWeekday => '평일';

  @override
  String get repeatWeekendDay => '주말';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '월요일',
      'TU': '화요일',
      'WE': '수요일',
      'TH': '목요일',
      'FR': '금요일',
      'SA': '토요일',
      'SU': '일요일',
      'day': '날',
      'weekday': '평일',
      'weekend': '주말',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString일마다';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString주마다';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString개월마다';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString년마다';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days에';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '첫 번째 $days',
      'second': '두 번째 $days',
      'third': '세 번째 $days',
      'fourth': '네 번째 $days',
      'fifth': '다섯 번째 $days',
      'secondToLast': '끝에서 두 번째 $days',
      'last': '마지막 $days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '$months에';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString회',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '$date까지';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      '이 반복 규칙에는 이 편집기에서 변경하지 않는 옵션이 사용됩니다.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      '이 목록은 이 반복 패턴을 지원하지 않습니다. 패턴을 변경하거나 다른 목록을 선택하세요.';

  @override
  String get taskRecurrenceRequiresDate =>
      '이 반복 패턴을 사용하려면 시작일 또는 마감일을 추가하거나 반복을 끄세요.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return '이 반복은 $provider에서 사용할 수 없습니다.';
  }

  @override
  String get importance => '중요도';

  @override
  String get importanceLow => '낮음';

  @override
  String get importanceNormal => '보통';

  @override
  String get importanceHigh => '높음';

  @override
  String get categories => '범주';

  @override
  String get scheduleSection => '일정';

  @override
  String get dueGroup => '마감';

  @override
  String get startGroup => '시작';

  @override
  String get reminderGroup => '미리 알림';

  @override
  String get organizationSection => '구성';

  @override
  String get actionsSection => '작업';

  @override
  String get advancedSection => '고급';

  @override
  String get addCategory => '범주 추가';

  @override
  String get list => '목록';

  @override
  String get microsoftMoveUnsupported =>
      '이 버전에서는 Microsoft To Do 계정의 목록 간에 할 일을 이동할 수 없습니다.';

  @override
  String get createSubtask => '하위 할 일 만들기';

  @override
  String get subtasks => '하위 할 일';

  @override
  String get duplicateTask => '할 일 복제';

  @override
  String get taskDuplicated => '할 일이 복제되었습니다.';

  @override
  String taskDuplicateFailed(String error) {
    return '할 일을 복제할 수 없습니다: $error';
  }

  @override
  String get hideSubtasks => '하위 할 일 숨기기';

  @override
  String get hideClosedSubtasks => '완료된 하위 할 일 숨기기';

  @override
  String get moveToTop => '맨 위로 이동';

  @override
  String get deleteTask => '할 일 삭제';

  @override
  String get newSubtask => '새 하위 할 일';

  @override
  String deleteTaskConfirmation(String title) {
    return '“$title” 항목을 삭제할까요?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Google Docs 또는 Chat 스페이스의 원본 할 일도 삭제됩니다.';

  @override
  String get metadata => '메타데이터';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => '업데이트됨';

  @override
  String get parent => '상위 할 일';

  @override
  String get position => '위치';

  @override
  String get webLink => '웹 링크';

  @override
  String get assignment => '할당';

  @override
  String get localState => '로컬 상태';

  @override
  String get pendingSync => '동기화 보류 중';

  @override
  String get synced => '동기화됨';

  @override
  String get account => '계정';

  @override
  String get sync => '동기화';

  @override
  String get forceFullResync => '전체 재동기화 강제 실행';

  @override
  String get forceFullResyncDescription =>
      '연결된 모든 계정의 데이터를 완전히 다시 불러옵니다. 동기화 문제를 해결할 때만 사용하세요.';

  @override
  String get runInBackgroundWhenClosed => '창을 닫아도 계속 실행';

  @override
  String get showTrayIcon => '트레이 아이콘 표시';

  @override
  String get startMinimizedToTray => '트레이에 최소화하여 시작';

  @override
  String get launchAtLogin => '로그인할 때 실행';

  @override
  String get launchAtLoginDescription =>
      '로그인 후에도 미리 알림이 작동하도록 BusyMax를 백그라운드에서 실행합니다.';

  @override
  String get launchAtLoginFailed => '로그인 시 실행 설정을 업데이트할 수 없습니다.';

  @override
  String get requiresTrayIcon => '트레이 아이콘이 필요합니다.';

  @override
  String get syncComplete => '동기화가 완료되었습니다.';

  @override
  String syncFailed(String error) {
    return '동기화 실패: $error';
  }

  @override
  String get notifySyncFailures => '동기화 실패 알림';

  @override
  String get notifyConflicts => '충돌 알림';

  @override
  String get notifyDueToday => '오늘 마감인 할 일 알림';

  @override
  String get eventReminders => '일정 미리 알림';

  @override
  String get onState => '켬';

  @override
  String get taskReminders => '할 일 미리 알림';

  @override
  String get notificationDetailLevel => '알림 세부 수준';

  @override
  String get notificationDetailPrivate => '비공개';

  @override
  String get notificationDetailNormal => '일반';

  @override
  String get quietHours => '방해 금지 시간';

  @override
  String get quietHoursDescription => '이 시간 동안 알림을 일시 중지합니다.';

  @override
  String get quietHoursStart => '방해 금지 시작 시간';

  @override
  String get quietHoursEnd => '방해 금지 종료 시간';

  @override
  String get notifications => '알림';

  @override
  String get windowsNotificationsUnavailable => 'Windows 알림을 사용할 수 없음';

  @override
  String get windowsNotificationsUnpackaged =>
      '패키징되지 않은 이 개발 실행에서는 Windows 알림을 사용할 수 없습니다. 미리 알림을 테스트하려면 테스트 서명된 MSIX를 설치하세요.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax에서 Windows 알림을 초기화하지 못했습니다. 이 설치 문제가 해결될 때까지 미리 알림이 표시되지 않습니다.';

  @override
  String get appearance => '화면 모양';

  @override
  String get theme => '테마';

  @override
  String get themeSystem => '시스템';

  @override
  String get settingsSystem => '시스템';

  @override
  String get themeLight => '라이트';

  @override
  String get themeDark => '다크';

  @override
  String get themeFamily => '테마 계열';

  @override
  String get themeFamilyYaru => 'Ubuntu 기본 테마(Yaru)';

  @override
  String get localization => '언어 및 지역';

  @override
  String get currentLocale => '현재 로캘';

  @override
  String get privacy => '개인정보 보호';

  @override
  String get redactTaskContentInDiagnostics => '진단 정보에서 할 일 내용 숨기기';

  @override
  String get developerDiagnostics => '개발자 진단';

  @override
  String get diagnostics => '진단';

  @override
  String get apiInspectorDisabled => 'API 검사기 표시';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery 리비전: $revision';
  }

  @override
  String get implementedMethods => '구현된 메서드';

  @override
  String get supportsTasksScopes => 'tasks 및 tasks.readonly 범위 지원';

  @override
  String get requiresTasksScope => 'tasks 범위 필요';

  @override
  String get blockedPendingOperations => '차단된 보류 작업';

  @override
  String get signInToInspectPendingOperations => '보류 작업을 확인하려면 로그인하세요.';

  @override
  String get noBlockedPendingOperations => '차단된 보류 작업이 없습니다.';

  @override
  String get operationActions => '작업별 조치';

  @override
  String pendingOpListId(String id) {
    return '목록=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return '할 일=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '시도=$countString';
  }

  @override
  String get retry => '다시 시도';

  @override
  String get discard => '버리기';

  @override
  String get discardChangesAction => '변경 사항 버리기';

  @override
  String get discardChanges => '변경 사항을 버릴까요?';

  @override
  String get discardChangesConfirmation => '이 할 일에서 저장하지 않은 편집 내용을 버립니다.';

  @override
  String get retryCompleted => '다시 시도했습니다.';

  @override
  String get discardPendingOperation => '보류 작업을 버릴까요?';

  @override
  String get discardPendingOperationConfirmation =>
      '차단된 로컬 작업을 삭제합니다. 다음 동기화에서 Google Tasks의 데이터를 새로 불러옵니다.';

  @override
  String get pendingOperationDiscarded => '보류 작업을 버렸습니다.';

  @override
  String get syncFailureNotificationTitle => 'BusyMax 동기화 실패';

  @override
  String syncFailureNotificationBody(String message) {
    return '백그라운드 동기화에 실패했습니다. $message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax 동기화 충돌';

  @override
  String conflictNotificationBody(String summary) {
    return '보류 중인 로컬 변경사항이 차단되었습니다. $summary';
  }

  @override
  String get dueTodayNotificationTitle => '오늘 마감인 할 일';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '오늘 마감인 할 일이 $countString개 있습니다.',
      one: '오늘 마감인 할 일이 1개 있습니다.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => '일정 미리 알림';

  @override
  String get taskReminderNotificationTitle => '할 일 미리 알림';

  @override
  String get eventReminderNotificationBody => '일정이 곧 시작됩니다.';

  @override
  String get taskReminderNotificationBody => '할 일 마감이 얼마 남지 않았습니다.';

  @override
  String get notificationOpenAction => '열기';

  @override
  String get notificationSnoozeAction => '10분 후 다시 알림';

  @override
  String get notificationDismissAction => '닫기';

  @override
  String get notificationDetailsHidden => '개인정보 보호 설정에 따라 세부 정보가 숨겨졌습니다.';

  @override
  String get previousMonth => '이전 달';

  @override
  String get nextMonth => '다음 달';

  @override
  String get openMonthView => '월간 보기 열기';

  @override
  String get previousYear => '이전 해';

  @override
  String get nextYear => '다음 해';

  @override
  String get openYearView => '연간 보기 열기';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return '$numberString주차';
  }

  @override
  String get resizeAllDayPanel => '종일 패널 크기 조절';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '항목 $countString개',
      one: '항목 1개',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => '이 캘린더는 읽기 전용입니다.';

  @override
  String get selectTimeZone => '시간대 선택';

  @override
  String get searchLocations => '위치 검색';

  @override
  String get noLocationsFound => '위치를 찾을 수 없음';

  @override
  String get requiredField => '이 필드는 필수입니다.';

  @override
  String get providerConnectionDescription => '다음 제공업체 중 하나에서 캘린더와 할 일을 연결하세요.';

  @override
  String get appleICloudProvider => 'Apple iCloud 캘린더';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud 할 일';

  @override
  String get addAppleICloudAccount => 'Apple iCloud 캘린더 계정 추가';

  @override
  String get addNextcloudAccount => 'Nextcloud 계정 추가';

  @override
  String get waitingForAppleICloud => 'Apple iCloud에 연결 중…';

  @override
  String get waitingForNextcloud => 'Nextcloud 인증 대기 중…';

  @override
  String get connectAppleICloudTitle => 'Apple iCloud 캘린더 연결';

  @override
  String get appleAccountEmail => 'Apple 계정 이메일';

  @override
  String get appleAppSpecificPassword => '앱 전용 암호';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Apple 계정에서 이중 인증을 활성화한 후 앱 전용 암호를 생성하세요.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Apple 계정 암호를 재설정하면 앱 전용 암호가 취소됩니다.';

  @override
  String get connectNextcloudTitle => 'Nextcloud 연결';

  @override
  String get nextcloudServerUrl => 'Nextcloud 서버 또는 CalDAV 주소';

  @override
  String get nextcloudServerUrlHelp =>
      'Nextcloud 서버 URL을 입력하거나 Nextcloud에서 복사한 기본 CalDAV 주소를 붙여넣으세요.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax가 브라우저를 엽니다. 그곳에서 액세스를 승인한 다음 BusyMax로 돌아오세요.';

  @override
  String get connectAccountAction => '연결';

  @override
  String get cancelAccountConnection => '연결 취소';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      '계정은 로컬에서 삭제되었지만 Nextcloud 앱 암호를 취소할 수 없습니다.';

  @override
  String get davReauthenticationRequired => '동기화를 재개하려면 이 계정을 다시 연결하세요.';

  @override
  String get davTemporarilyUnavailable => '이 계정은 일시적으로 사용할 수 없습니다.';

  @override
  String get davPermissionChanged => '서버 권한이 변경되었습니다. 보류 중인 편집이 일시 중지되었습니다.';

  @override
  String get davUnsupportedServer => '이 서버 또는 제공업체 프로필은 지원되지 않습니다.';

  @override
  String get collectionSettings => '캘린더 및 할 일 목록';

  @override
  String get calendarContent => '캘린더 일정';

  @override
  String get taskContent => '할 일';

  @override
  String get readOnlySharedCollection => '읽기 전용';

  @override
  String get pendingLocally => '로컬에서 보류 중';

  @override
  String get conflictBlocked => '충돌로 차단됨';

  @override
  String get authenticationBlocked => '다시 연결할 때까지 차단됨';

  @override
  String get operationFailed => '작업 실패';

  @override
  String get keepServerVersion => '서버 버전 유지';

  @override
  String get reapplyLocalChange => '로컬 변경사항 검토 후 다시 적용';

  @override
  String get duplicateLocalItem => '새 항목으로 복제';

  @override
  String get davConnectionState => '연결 상태';

  @override
  String get davConnected => '연결됨';

  @override
  String get davConnecting => '연결 중…';

  @override
  String get davSignedOut => '로그아웃됨';

  @override
  String davLastSuccessfulSync(String time) {
    return '마지막으로 성공한 동기화: $time';
  }

  @override
  String get davNeverSynced => '아직 동기화되지 않음';

  @override
  String get refreshCollections => '캘린더 및 할 일 목록 새로 고침';

  @override
  String nextcloudServerHost(String host) {
    return '서버: $host';
  }

  @override
  String get collectionSupportsEvents => '일정 캘린더';

  @override
  String get collectionSupportsTasks => '할 일 목록';

  @override
  String get collectionSupportsEventsAndTasks => '일정 및 할 일';

  @override
  String get writableCollection => '쓰기 가능';

  @override
  String get sharedCollection => '공유됨';

  @override
  String collectionLastSynced(String time) {
    return '마지막 동기화: $time';
  }

  @override
  String collectionSyncError(String code) {
    return '동기화 문제: $code';
  }

  @override
  String get syncConflicts => '동기화 충돌';

  @override
  String remoteChangedAt(String time) {
    return '서버 변경: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return '로컬 편집: $summary';
  }

  @override
  String get conflictResolutionFailed => '충돌을 해결할 수 없습니다.';

  @override
  String get recurringEventScope => '반복 일정 범위';

  @override
  String get entireSeries => '전체 시리즈';

  @override
  String get singleOccurrence => '이 일정';

  @override
  String get thisAndFollowingEvents => '이 일정 및 향후 일정';

  @override
  String get thisAndFutureUnavailable => '이 제공업체에서는 지원되지 않습니다.';

  @override
  String get thisAndFutureMoveUnavailable =>
      '이 일정과 이후 일정을 안전하게 이동할 수 없습니다. 이 일정 또는 전체 반복 일정을 선택하세요.';

  @override
  String get entireSeriesMoveUnavailable =>
      '반복 규칙을 로컬에서 사용할 수 없습니다. 이 일정만 이동하세요.';

  @override
  String get copyEventAndDeleteOriginal => '일정을 복사하고 원본을 삭제할까요?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax는 이 일정을 $source에서 $destination(으)로 직접 이동할 수 없습니다. 먼저 복사본을 만들고 복사가 성공한 뒤에만 원본을 삭제합니다. 일정 ID가 변경되고 참석자 응답 상태가 초기화되며 초대 또는 취소가 전송될 수 있습니다. 회의 링크, 첨부 파일, 미리 알림, 제공업체별 필드 및 반복 예외는 이전되지 않을 수 있습니다.';
  }

  @override
  String get copyAndDelete => '복사 후 삭제';

  @override
  String get chooseRecurringEventScope =>
      '이 변경을 전체 시리즈, 이 일정만 또는 이 일정과 이후 일정에 적용할지 선택하세요.';

  @override
  String get taskDueBeforeStart => '마감은 시작보다 빠를 수 없습니다.';

  @override
  String get taskStartDueTimeModeMismatch =>
      '시작과 마감에 모두 시간을 설정하거나 작업을 종일로 설정하세요.';

  @override
  String deleteCalendarConfirmation(String title) {
    return '“$title” 캘린더를 삭제할까요?';
  }

  @override
  String get setCustomCalendarName => '맞춤 이름 설정';

  @override
  String get setAction => '설정';

  @override
  String get removeFromMyCalendars => '내 캘린더에서 삭제';

  @override
  String get removeAction => '삭제';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'BusyMax에서 \"$title\"을(를) 제거할까요? 소유자의 캘린더와 일정은 삭제되지 않습니다.';
  }

  @override
  String get attachmentUploadUnresolved =>
      '업로드가 완료되었을 수 있습니다. 다시 업로드하기 전에 첨부 파일을 새로 고쳐 결과를 확인하세요.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Google Calendar 목록에서 \"$title\"을(를) 삭제할까요? 공유 캘린더와 일정은 삭제되지 않습니다.';
  }

  @override
  String get calendarCannotRemove => '이 캘린더는 이 계정에서 삭제하거나 제거할 수 없습니다.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      '삭제하거나 제거하기 전에 이 캘린더의 보류 중인 변경사항이 동기화될 때까지 기다리세요.';

  @override
  String get calendarSubscriptions => '캘린더 구독';

  @override
  String get calendarSubscriptionsDescription =>
      '보안 WebCal URL에서 새로 고침되는 읽기 전용 캘린더를 추가하세요.';

  @override
  String get addCalendarSubscription => '캘린더 구독 추가';

  @override
  String get subscriptionName => '로컬 이름';

  @override
  String get subscriptionUrl => '구독 URL';

  @override
  String get subscriptionUrlHelp =>
      'HTTPS 또는 webcal URL을 입력하세요. BusyMax는 전체 URL을 안전한 저장소에 보관합니다.';

  @override
  String get subscriptionUrlInvalid =>
      '사용자 정보나 프래그먼트가 없는 올바른 HTTPS 또는 webcal URL을 입력하세요.';

  @override
  String get subscriptionColor => '로컬 색상';

  @override
  String get subscriptionColorHelp => '#3584E4와 같은 6자리 색상을 사용하세요.';

  @override
  String get subscriptionColorInvalid => '6자리 16진수 색상을 입력하세요.';

  @override
  String get subscriptionRefreshMode => '새로 고침 빈도';

  @override
  String get subscriptionAutomatic => '자동';

  @override
  String get subscriptionHourly => '매시간';

  @override
  String get subscriptionSixHours => '6시간마다';

  @override
  String get subscriptionDaily => '매일';

  @override
  String subscriptionSafeOrigin(String origin) {
    return '소스: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      '안전한 원본을 미리 보려면 올바른 URL을 입력하세요.';

  @override
  String get subscriptionReadOnly => '읽기 전용 구독';

  @override
  String get subscriptionNeverRefreshed => '아직 새로 고치지 않음';

  @override
  String subscriptionLastRefresh(String time) {
    return '마지막으로 성공한 새로 고침: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return '다음 새로 고침: $time';
  }

  @override
  String get subscriptionStatusHealthy => '최신 상태';

  @override
  String subscriptionStatusIssue(String code) {
    return '새로 고침 문제: $code';
  }

  @override
  String get refreshNow => '지금 새로 고침';

  @override
  String get unsubscribe => '구독 취소';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '“$name” 구독을 취소할까요?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      '로컬 구독과 캐시된 일정을 제거합니다. 게시된 캘린더는 변경되지 않습니다.';

  @override
  String get addSubscriptionAction => '구독 추가';

  @override
  String subscriptionOperationFailed(String error) {
    return '캘린더 구독 실패: $error';
  }

  @override
  String get subscriptions => '구독';

  @override
  String get calendarImport => '캘린더 가져오기';

  @override
  String get calendarImportDescription =>
      '파일을 선택하고 일정을 검토한 다음 이를 받을 쓰기 가능한 캘린더를 선택하세요.';

  @override
  String get importIcsFile => '.ics 파일 가져오기';

  @override
  String get importIcsPreview => '캘린더 일정 가져오기';

  @override
  String importEventsFound(int count) {
    return '가져올 수 있는 일정 세트: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return '잘못된 일정: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return '의도적으로 생략됨: $fields';
  }

  @override
  String get noWritableCalendars => '쓰기 가능한 대상 캘린더가 없습니다.';

  @override
  String get importDestinationCalendar => '대상 캘린더';

  @override
  String get importIcsConfirm => '일정 가져오기';

  @override
  String get importIcsComplete => '가져오기 완료';

  @override
  String importQueued(int count) {
    return '가져왔거나 대기열에 추가됨: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return '중복 건너뜀: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return '지원되지 않는 반복 세트: $count';
  }

  @override
  String importIcsFailed(String error) {
    return '캘린더 파일을 가져올 수 없습니다: $error';
  }

  @override
  String get networkOffline => '오프라인';

  @override
  String get networkOfflineDescription => '연결이 복구되면 변경 사항이 동기화됩니다.';

  @override
  String get networkOfflineTryAgain => '오프라인 상태입니다. 인터넷에 연결한 후 다시 시도하세요.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day일';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first과 $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first과 $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first과 $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first과 $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency $month $day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency $month의 $days';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency $months의 $day';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency $months의 $days';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '첫 번째 $days',
      'second': '두 번째 $days',
      'third': '세 번째 $days',
      'fourth': '네 번째 $days',
      'fifth': '다섯 번째 $days',
      'secondToLast': '끝에서 두 번째 $days',
      'last': '마지막 $days',
      'other': '$days',
    });
    return '$frequency $month의 $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '첫 번째 $days',
      'second': '두 번째 $days',
      'third': '세 번째 $days',
      'fourth': '네 번째 $days',
      'fifth': '다섯 번째 $days',
      'secondToLast': '끝에서 두 번째 $days',
      'last': '마지막 $days',
      'other': '$days',
    });
    return '$frequency $months의 $_temp0';
  }

  @override
  String get searchFilters => '검색 필터';

  @override
  String get searchType => '유형';

  @override
  String get searchDate => '날짜';

  @override
  String get searchAnyDate => '모든 날짜(다운로드한 데이터)';

  @override
  String get eventLink => '일정 링크';

  @override
  String get eventLinkOpenFailed => '링크를 열 수 없습니다.';

  @override
  String get scheduleRangeIncomplete => '일부 일정을 확인할 수 없습니다. 다운로드한 데이터를 표시합니다.';

  @override
  String get searchThisWeek => '이번 주';

  @override
  String get searchCustomRange => '사용자 지정 기간';

  @override
  String get searchTaskStatus => '작업 상태';

  @override
  String get searchTaskDue => '작업 기한';

  @override
  String get searchAnyDueState => '모든 기한 상태';

  @override
  String get searchNoDueDate => '기한 없음';

  @override
  String get searchPerson => '사람';

  @override
  String get searchSources => '검색 소스';

  @override
  String get searchClearFilters => '필터 초기화';

  @override
  String get searchFiltersAction => '필터';

  @override
  String get searchNoSources => '선택한 검색 소스가 없습니다';

  @override
  String get searchClearText => '텍스트 지우기';

  @override
  String get openSharedCalendar => '공유 캘린더 열기';

  @override
  String get manageCalendarSharing => '캘린더 공유 관리';

  @override
  String get shareRecipientEmail => '받는 사람 이메일';

  @override
  String get shareRole => '액세스 역할';

  @override
  String get addCalendarShare => '액세스 추가';

  @override
  String get sharingRefreshFailed =>
      '공유 변경은 완료되었지만 권한 목록을 새로 고치지 못했습니다. 다음 변경 전에 다시 불러오세요.';

  @override
  String get sharingRateLimited => '공유가 일시적으로 제한되었습니다. 대기 시간이 끝나면 다시 시도하세요.';

  @override
  String get attachmentUploadRateLimited =>
      '첨부 파일 업로드가 일시적으로 제한되었습니다. 대기 시간이 끝나면 다시 시도하세요.';

  @override
  String get sharingPermissionUnavailable => '이 캘린더의 공유 권한을 사용할 수 없습니다.';

  @override
  String get calendarShareFreeBusy => '한가함/바쁨만 보기';

  @override
  String get calendarShareLimitedRead => '제한된 세부정보 읽기';

  @override
  String get calendarShareRead => '모든 세부정보 읽기';

  @override
  String get calendarShareWrite => '일정 수정';

  @override
  String get calendarShareWriteWithoutPrivate => '비공개 정보 제외하고 수정';

  @override
  String get calendarShareOwner => '소유자';

  @override
  String get eventLabel => '일정 라벨';

  @override
  String get loadOutlookCategories => 'Outlook 범주 불러오기';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlook 범주를 사용할 수 없습니다. 기존 지정은 유지됩니다.';

  @override
  String get googleEventType => '일정 유형';

  @override
  String get googleRegularEvent => '일반 일정';

  @override
  String get googleFocusTime => '집중 시간';

  @override
  String get googleOutOfOffice => '부재중';

  @override
  String get googleWorkingLocation => '근무 위치';

  @override
  String get googleDeclineInvitations => '겹치는 초대 거절';

  @override
  String get googleDeclineNone => '거절하지 않음';

  @override
  String get googleDeclineNew => '새 초대 거절';

  @override
  String get googleDeclineAll => '충돌하는 초대 모두 거절';

  @override
  String get googleDeclineMessage => '거절 메시지';

  @override
  String get googleChatStatus => '채팅 상태';

  @override
  String get googleChatAvailable => '사용 가능';

  @override
  String get googleChatDoNotDisturb => '방해 금지';

  @override
  String get googleWorkAtHome => '집';

  @override
  String get googleWorkAtOffice => '사무실';

  @override
  String get googleWorkAtCustomLocation => '사용자 지정 위치';

  @override
  String get googleWorkLocationLabel => '위치 이름';

  @override
  String get googleStatusPrimaryOnly => 'Google 상태 일정에는 기본 Google 캘린더가 필요합니다.';

  @override
  String unknownEventLabel(String id) {
    return '알 수 없는 라벨 ($id)';
  }

  @override
  String get calendarOwnerEmail => '캘린더 소유자 이메일';

  @override
  String registrationSetupTitle(String provider) {
    return '$provider 설정';
  }

  @override
  String get registrationSetupGuide => '설정 안내';

  @override
  String get registrationGoogleInstructions =>
      '자신의 Google Cloud 프로젝트를 만들고 Calendar 및 Tasks API를 사용 설정한 후 Desktop OAuth 클라이언트 JSON을 가져오세요. 원하는 계정에 권한을 부여하세요.';

  @override
  String get registrationMicrosoftInstructions =>
      '앱 등록을 허용하는 Entra 테넌트에서 공용 앱 등록을 사용하세요. 클라이언트 ID와 지원 계정 유형을 입력하세요. 클라이언트 암호는 필요 없습니다.';

  @override
  String get registrationImportGoogle => 'Desktop OAuth JSON 선택';

  @override
  String get registrationValidate => '등록 확인';

  @override
  String get registrationAuthorize => '브라우저에서 권한 부여';

  @override
  String get registrationClientId => '애플리케이션/클라이언트 ID';

  @override
  String get registrationTenantId => '테넌트 ID';

  @override
  String get registrationAudience => '지원 계정';

  @override
  String get registrationBothAudience => '개인 및 조직 계정';

  @override
  String get registrationOrganizationAudience => '조직 계정';

  @override
  String get registrationPersonalAudience => '개인 계정';

  @override
  String get registrationTenantAudience => '하나의 조직 테넌트';

  @override
  String registrationSummary(String clientId) {
    return '등록: $clientId';
  }

  @override
  String get registrationMigrate => '지금 이전';

  @override
  String get registrationReplace => '등록 교체';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return '이 계정은 기존 계정용 원래 $provider 등록을 사용합니다. 바꾸려면 $setup을 설정하고 이 계정을 다시 연결하세요. 기존 캘린더, 작업 및 로컬 변경 사항은 유지됩니다.';
  }

  @override
  String get registrationContinue => '이 계정 계속 사용';

  @override
  String get registrationGoogleProject => 'Google Cloud 프로젝트';

  @override
  String get registrationMicrosoftApp => 'Microsoft 앱 등록';

  @override
  String get registrationUserOwned => '사용자가 제공한 등록';

  @override
  String get registrationNativeGoogle => 'Google Android 기본 등록';

  @override
  String get registrationShared => '공유 등록(전환 기간)';

  @override
  String get registrationUnresolved => '등록 출처를 확인할 수 없습니다. 계정 데이터는 보존됩니다.';

  @override
  String get registrationOfficialDocumentation => '공식 문서';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return '패키지: $packageName\n서명 해시: $signatureHash\n리디렉션 URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      '등록의 클라이언트 유형, 지원 계정, 권한 및 리디렉션을 확인하세요. 가져온 설정이라면 다시 선택하세요.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      '이 인증을 완료하지 못했습니다. 인증을 다시 시작하세요. 기존 연결은 유지됩니다.';

  @override
  String get oauthPermissionRefused =>
      '인증이 거부되었거나 필요한 권한이 부여되지 않았습니다. 다시 시도하여 필요한 권한을 부여하세요.';

  @override
  String get oauthProviderThrottled =>
      '제공자가 요청을 제한하고 있습니다. 잠시 기다린 후 다시 시도하세요. 기존 연결은 유지됩니다.';

  @override
  String get oauthProviderTemporaryFailure =>
      '제공자의 일시적인 문제로 인증을 완료하지 못했습니다. 다시 시도하세요. 기존 연결은 유지됩니다.';

  @override
  String get oauthAuthorizationTimedOut =>
      '인증 시간이 초과되었습니다. 다시 시도하고 가져온 설정이라면 다시 선택하세요.';

  @override
  String get oauthWrongAccount => '다시 연결하도록 선택한 계정을 인증하세요. 기존 연결은 유지됩니다.';

  @override
  String get oauthSecureStorageUnavailable =>
      '보안 저장소를 사용할 수 없습니다. 접근을 복구한 후 다시 시도하세요.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      '원격 인증은 취소되었지만 계정 정리를 완료하지 못했습니다. BusyMax를 다시 시작하여 로컬 복구를 재시도하세요.';

  @override
  String get addAccount => '계정 추가';

  @override
  String get registrationConnect => '연결';

  @override
  String get registrationBack => '뒤로';

  @override
  String get registrationReplaceGoogle => '데스크톱 OAuth JSON 교체';

  @override
  String get registrationSelectedConfiguration => '선택한 구성';

  @override
  String get registrationDirectoryId => '디렉터리/테넌트 ID';

  @override
  String get registrationInvalidId => '올바른 UUID를 입력하세요.';

  @override
  String get registrationExpired =>
      '이 구성이 만료되었습니다. 연결하기 전에 다시 가져오거나 등록 필드를 수정하세요.';

  @override
  String get registrationOwnProjectRequired => '본인 프로젝트 또는 테넌트의 등록을 선택하세요.';

  @override
  String get registrationSetupFailed => '설정을 완료하지 못했습니다. 다시 시도하세요.';

  @override
  String get registrationLinkFailed => '링크를 열지 못했습니다. 브라우저를 확인하고 다시 시도하세요.';

  @override
  String get registrationPermissions => '권한';

  @override
  String get registrationDesktopClient => '데스크톱 앱';

  @override
  String get registrationOpenGoogleConsole => 'Google Cloud Console 열기';

  @override
  String get registrationGoogleAudienceHelp => 'Google 게시 및 테스트 사용자 요구사항';

  @override
  String get registrationDesktopHelp => '데스크톱 앱 등록 안내';

  @override
  String get registrationOpenEntra => 'Microsoft Entra 관리 센터 열기';

  @override
  String get registrationGuideGoogleProject =>
      'Google Cloud Console을 여세요. 위쪽 프로젝트 선택기에서 본인 프로젝트를 선택하거나 New project를 선택하고 이름을 입력한 뒤 Create를 선택하세요. 나머지 단계에서도 같은 프로젝트를 유지하세요.';

  @override
  String get registrationGuideGoogleAudience =>
      'Google Auth Platform → Branding으로 이동하세요. 아직 설정하지 않았다면 Get started를 선택하세요. App name에 BusyMax를 입력하고 본인 User support email을 선택한 뒤 Next를 선택하세요. Audience에서 External을 선택하세요. Next를 선택하고 Contact Information에 이메일을 입력한 뒤 Next를 선택하세요. User Data Policy에 동의하고 Continue와 Create를 선택하세요. 이미 설정했다면 Branding과 Audience를 확인하세요.';

  @override
  String get registrationGuideGooglePermissions =>
      'Google Auth Platform → Data Access → Add or remove scopes를 여세요. 아래 다섯 범위를 선택하고 필요하면 Manually add scopes를 사용하세요. 수동 입력 시 누락된 값을 붙여넣고 Add to table을 선택하세요. Update를 선택한 뒤 Save를 선택하세요. BusyMax에는 캘린더와 작업 모두의 접근 권한이 필요합니다.';

  @override
  String get registrationGuideGoogleClient =>
      'Google Auth Platform → Clients → Create client를 여세요. Application type을 Desktop app으로 설정하고 Name에 BusyMax를 입력한 뒤 Create를 선택하세요. 생성 대화상자에서 Download JSON을 선택하고 파일을 저장하세요. 뒤로를 선택하고 양식으로 돌아와 파일을 선택하고 프로젝트 및 클라이언트 ID를 확인하세요. 연결을 선택하고 브라우저에서 캘린더와 작업 접근을 승인하세요.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Microsoft Entra 관리 센터에 로그인하세요. Settings에서 앱을 등록할 수 있는 테넌트를 선택하세요. Entra ID → App registrations → New registration을 여세요. Name에 BusyMax를 입력하고 다음 단계에서 지원하는 계정 유형을 선택하세요. 등록이 차단되면 테넌트 관리자에게 권한을 요청하세요.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      '앱 등록에서 Authentication → Add a platform → Mobile and desktop applications를 여세요. 아래 리디렉션 URI를 선택하거나 입력하고 Configure로 저장하세요. BusyMax는 시스템 브라우저를 사용합니다. 클라이언트 암호는 필요하지 않습니다.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'API permissions → Add a permission → Microsoft Graph → Delegated permissions를 여세요. 아래 범위를 각각 검색하여 선택한 뒤 Add permissions를 선택하세요. User.Read가 이미 있다면 유지하세요. 조직에서 관리자 동의를 요구하면 관리자에게 테넌트의 Grant admin consent 사용을 요청하세요.';

  @override
  String get registrationGuideMicrosoftConnect =>
      '뒤로를 선택하고 양식으로 돌아오세요. Application (client) ID를 붙여넣고 등록과 같은 지원 계정을 선택하세요. 단일 조직 테넌트라면 Directory (tenant) ID도 붙여넣으세요. 연결을 선택하고 브라우저에서 원하는 계정으로 로그인하세요. BusyMax는 필드를 로컬에서 검사하며 Microsoft는 브라우저 로그인 중 동의를 요청합니다.';

  @override
  String get registrationGoogleImportFailed =>
      '이 파일을 가져오지 못했습니다. 올바른 데스크톱 OAuth JSON을 선택하세요. 이전의 유효한 선택은 유지됩니다.';

  @override
  String get registrationGoogleSetupInstructions => 'Google 설정 안내';

  @override
  String get registrationMicrosoftSetupInstructions => 'Microsoft 설정 안내';

  @override
  String get registrationDesktopConfiguration => '데스크톱 OAuth 구성';

  @override
  String get registrationNoFileSelected => '선택한 파일 없음';

  @override
  String get registrationChooseFile => '파일 선택…';

  @override
  String get registrationReplaceFile => '바꾸기…';

  @override
  String get registrationGoogleIntroduction =>
      '본인 Google Cloud 프로젝트의 데스크톱 OAuth JSON을 선택하세요.';

  @override
  String get registrationMicrosoftIntroduction =>
      '본인 Microsoft 앱 등록 정보를 입력하세요.';

  @override
  String get registrationSetupInstructions => '설정 안내';

  @override
  String get registrationInstructionsDescription => '계정 연결에 필요한 구성을 만드세요.';

  @override
  String get registrationEnableApis => 'Calendar 및 Tasks 사용 설정';

  @override
  String get registrationConsentScreen => '동의 화면 설정';

  @override
  String get registrationAppName => '앱 이름';

  @override
  String get registrationScopes => '범위';

  @override
  String get registrationRedirectUri => '리디렉션 URI';

  @override
  String get registrationOpenApiLibrary => 'Google API 라이브러리 열기';

  @override
  String get registrationOpenBranding => 'Google Auth Platform의 Branding 열기';

  @override
  String get registrationOpenDataAccess =>
      'Google Auth Platform의 Data Access 열기';

  @override
  String get registrationOpenClients => 'Google Auth Platform의 Clients 열기';

  @override
  String get registrationOpenEntraAuthentication =>
      'Authentication 설정을 위해 Entra 앱 등록 열기';

  @override
  String get registrationOpenEntraPermissions =>
      'API permissions 설정을 위해 Entra 앱 등록 열기';

  @override
  String get registrationCopy => '복사';

  @override
  String get registrationCopyAll => '모두 복사';

  @override
  String get registrationGuideGoogleApis =>
      'APIs & Services → Library로 이동하세요. Google Calendar API를 검색하여 페이지를 열고 Enable을 선택하세요. Library로 돌아가 Google Tasks API에도 같은 작업을 하세요.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Supported account types에서 개인 계정은 Personal accounts only, 조직 계정은 Multiple Entra ID tenants, 둘 다는 Any Entra ID Tenant + Personal Microsoft accounts, 이 디렉터리만은 Single tenant only를 선택하세요. Register를 선택하세요. Overview에서 Application (client) ID를 복사하고 단일 테넌트라면 Directory (tenant) ID도 복사하세요. BusyMax에서 같은 지원 계정 선택을 사용하세요.';

  @override
  String get registrationConnectBusyMax => 'BusyMax로 연결';

  @override
  String get registrationRecommended => '권장';

  @override
  String get registrationOtherMethods => '다른 연결 방법';

  @override
  String get registrationWorkspace => 'Google Workspace 조직';

  @override
  String get registrationGoogleCustom => '사용자 지정 OAuth 클라이언트';

  @override
  String get registrationMicrosoftCustom => '사용자 지정 앱 등록';

  @override
  String get registrationMethodsIntroduction => '계정을 연결할 방법을 선택하세요.';

  @override
  String get registrationWorkspaceDescription => '조직이 관리하는 구성을 사용하세요.';

  @override
  String get registrationCustomDescription => '직접 관리하는 등록을 사용하세요.';

  @override
  String get registrationSharedUnavailable =>
      '이 빌드에서는 BusyMax 연결을 사용할 수 없습니다. 아래에서 다른 연결 방법을 사용할 수 있습니다.';

  @override
  String get registrationWorkspaceIntroduction =>
      '조직에서 제공하거나 관리하는 데스크톱 OAuth JSON을 선택하세요. 파일은 조직 소유권, 대상 계정 또는 인증 상태를 증명하지 않습니다.';

  @override
  String get registrationWorkspaceSetupInstructions => 'Google Workspace 설정 안내';

  @override
  String get registrationBusyMaxManaged => 'BusyMax에서 관리하는 등록';

  @override
  String get registrationBranding => '브랜딩 및 도메인 구성';

  @override
  String get registrationPublishing => '일반 사용을 위해 게시';

  @override
  String get registrationOpenAudience => 'Google Auth Platform Audience 열기';

  @override
  String get registrationGuideWorkspaceProject =>
      '관리자에게 Desktop OAuth JSON을 받거나 Google Cloud Console에서 Google Workspace 조직이 소유한 프로젝트를 선택하세요. 새로 만들려면 리소스 관리 → 프로젝트 만들기를 열고 프로젝트 이름을 입력한 뒤 상위 리소스에서 조직 또는 조직의 폴더를 선택하고 만들기를 누르세요. 다음 단계에서도 해당 프로젝트를 선택하세요. 생성에는 Project Creator, OAuth 설정에는 OAuth Config Editor, API 사용 설정에는 Service Usage Admin 또는 동등한 권한이 필요합니다. 작업이 차단되면 관리자에게 문의하세요.';

  @override
  String get registrationGuideGoogleBranding =>
      'Branding → App domain에서 프로젝트의 승인된 도메인을 먼저 추가한 뒤 홈페이지, 개인정보 처리방침, 서비스 약관 URL을 입력하고 Save를 선택하세요. External 프로덕션 앱에는 이 링크가 필요합니다. 소유한 도메인을 사용하고 Google이 브랜드 인증을 요구하면 Search Console에서 소유권을 확인하세요. 아래 BusyMax 개인정보 링크는 프로젝트의 busystack.org 소유권을 증명하지 않습니다.';

  @override
  String get registrationGuideGooglePublishing =>
      'Audience에서 Publish app을 선택하고 In production을 확인하세요. 일반 사용을 Testing으로 두지 마세요. 이 Calendar/Tasks 승인과 갱신 토큰은 7일 후 만료됩니다. 게시와 인증은 별개입니다. 100명 미만의 개인 사용은 경고와 사용자 제한을 적용하여 인증 면제가 가능하며, 광범위 배포는 브랜드와 범위 승인이 필요할 수 있습니다. 프로덕션 승인도 만료되거나 취소될 수 있습니다.';

  @override
  String get registrationGuideWorkspacePermissions =>
      '이 범위를 관리자와 검토하세요. Internal 앱은 동의 화면에 범위를 나열할 필요가 없습니다. 요청받으면 Data Access → Add or remove scopes에서 값을 추가하고 Update와 Save를 선택하세요. 관리자 제어로 승인이 제한될 수 있습니다.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      '공유 캘린더와 범주 권한은 선택 기능을 활성화할 때 별도로 요청됩니다. 위의 필수 설정에 추가하지 마세요.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Google Auth Platform → Branding으로 이동하세요. 아직 설정하지 않았다면 Get started를 선택하세요. App name에 BusyMax를 입력하고 본인 User support email을 선택한 뒤 Next를 선택하세요. Audience에서 Internal을 선택하세요. Next를 선택하고 Contact Information에 이메일을 입력한 뒤 Next를 선택하세요. User Data Policy에 동의하고 Continue와 Create를 선택하세요. 이미 설정했다면 Branding과 Audience를 확인하세요.\n\nInternal은 프로젝트의 상위 조직 계정만 허용하며 관리자 제어도 적용됩니다. 테스트 사용자 목록은 필요 없습니다. BusyMax는 다운로드한 JSON으로 이러한 콘솔 설정을 확인할 수 없습니다.';

  @override
  String get contactsTitle => '연락처';

  @override
  String get contactsLinkedDescription =>
      '이벤트 참석자를 추가할 때 이 계정에 캐시된 연락처를 사용합니다.';

  @override
  String get contactsEnableSuggestions => '연락처 추천 사용';

  @override
  String get contactsReadPermissionDescription => '연락처 읽기 전용 권한을 요청합니다';

  @override
  String get contactsEnableEditing => '연락처 편집 사용';

  @override
  String get contactsWritePermissionDescription => '연락처 읽기 및 쓰기 권한을 요청합니다';

  @override
  String get contactsSuggestionsEnabled => '연락처 추천을 사용 중입니다';

  @override
  String get contactsNeedsAttention => '연락처를 확인해야 합니다';

  @override
  String get contactsReadWriteAccess => '읽기 및 쓰기 권한';

  @override
  String get contactsDisableForAccount => '이 계정의 연락처 사용 중지';

  @override
  String get contactsOnlyDescription => '이 원본은 캘린더 및 작업 계정과 별개입니다.';

  @override
  String get contactsAddCardDav => 'CardDAV 연락처 추가';

  @override
  String get contactsAddNextcloud => 'Nextcloud 연락처 추가';

  @override
  String get contactsUseForAttendees => '참석자 추천에 사용';

  @override
  String get contactsServerUrlLabel => 'HTTPS 서버 URL';

  @override
  String get contactsUsernameLabel => '사용자 이름';

  @override
  String get contactsPasswordLabel => '비밀번호';
}
