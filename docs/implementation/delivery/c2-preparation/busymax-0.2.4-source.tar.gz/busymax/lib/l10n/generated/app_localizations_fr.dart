// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax a été lancé par les paramètres de démarrage de votre bureau. Supprimez son entrée à cet endroit, puis quittez et rouvrez BusyMax pour utiliser cet interrupteur.';

  @override
  String get timeFormat => 'Format de l’heure';

  @override
  String get firstDayOfWeek => 'Premier jour de la semaine';

  @override
  String get systemDefault => 'Valeur par défaut du système';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Valeur par défaut du système ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 heures';

  @override
  String get timeFormatTwentyFourHour => '24 heures';

  @override
  String get timeEndOfDay => 'fin de journée';

  @override
  String get timePeriod => 'Période de la journée';

  @override
  String get launchAtLoginReadFailed =>
      'Impossible de déterminer l’état du lancement à la connexion.';

  @override
  String get launchAtLoginUnavailable =>
      'Le lancement à la connexion n’est pas disponible sur ce système.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'Le démarrage automatique est activé par votre administrateur et ne peut pas être modifié ici.';

  @override
  String get settingsSaveFailed =>
      'Impossible d’enregistrer les paramètres. Vos modifications risquent d’être perdues au redémarrage de BusyMax.';

  @override
  String get nextcloudExportCollection =>
      'Exporter les ressources de la collection';

  @override
  String nextcloudImportItems(int count) {
    return '$count ressources d’événements/tâches trouvées';
  }

  @override
  String get nextcloudSchedulingInbox => 'Boîte de réception des invitations';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud traite ces messages dans vos calendriers. Accuser réception supprime uniquement le message, pas l’événement.';

  @override
  String get nextcloudInboxEmpty => 'Aucun message d’invitation.';

  @override
  String get nextcloudAcknowledge => 'Accuser réception';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Supprimer ce message de la boîte de réception ? L’événement sera conservé.';

  @override
  String get nextcloudGuestAvailability =>
      'Vérifier la disponibilité des invités';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Conservation dans la corbeille du serveur : $days jours';
  }

  @override
  String get nextcloudCancelMeeting => 'Annuler la réunion';

  @override
  String get nextcloudDeclineAndRemove => 'Refuser et retirer l’invitation';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Le retrait enverra un refus à la synchronisation. Il n’annule pas la réunion de l’organisateur.';

  @override
  String get nextcloudAvailabilityUnknown => 'Disponibilité inconnue';

  @override
  String get nextcloudAvailabilityFree =>
      'Aucune période occupée signalée pour cet intervalle';

  @override
  String get nextcloudAvailabilityBusy => 'Périodes occupées';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud enverra les mises à jour lors de la synchronisation. L’enregistrement local ne confirme pas leur remise.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Seul l’organisateur ou un délégué autorisé peut modifier la réunion. Répondez à l’invitation depuis ses détails.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'Cette réunion ne peut pas être déplacée par copie et suppression. Utilisez un calendrier relevant de la même identité de planification.';

  @override
  String get nextcloudSchedulingStatus => 'État de planification du serveur';

  @override
  String get nextcloudImportFollowUp =>
      'Les ressources importées sont enregistrées localement. L’actualisation des rappels est en attente ; ne les importez pas à nouveau.';

  @override
  String get nextcloudNativeImport =>
      'Importer les événements et tâches complets sans envoyer d’invitations. Les UID existants sont ignorés sauf si vous choisissez de nouvelles copies. Les ressources non prises en charge sont signalées individuellement.';

  @override
  String get nextcloudImportMethod =>
      'Ce fichier contient des messages de planification. L’importation conserve leur contenu et retire METHOD ; elle ne traite ni invitation ni réponse.';

  @override
  String get nextcloudImportCopies =>
      'Importer de nouvelles copies avec de nouvelles identités';

  @override
  String get nextcloudCollectionSettings => 'Paramètres de la collection';

  @override
  String get nextcloudSharing => 'Partage';

  @override
  String get nextcloudOwned => 'Propriétaire';

  @override
  String get nextcloudShared => 'Partagée';

  @override
  String get nextcloudDelegated => 'Déléguée';

  @override
  String get nextcloudSubscription => 'Abonnement';

  @override
  String get nextcloudDeleted => 'Supprimée';

  @override
  String get nextcloudMetadataEditable =>
      'Le contenu est en lecture seule ; les propriétés de la collection restent modifiables.';

  @override
  String get nextcloudServerOrder =>
      'Ordre sur le serveur (distinct de celui de la barre latérale)';

  @override
  String get nextcloudCalendarEnabled => 'Activée sur le serveur';

  @override
  String get nextcloudAvailability =>
      'Inclure cette collection dans la disponibilité';

  @override
  String get nextcloudCalendarTimezone =>
      'Fuseau horaire du calendrier (document VTIMEZONE)';

  @override
  String get nextcloudRefreshPending =>
      'La modification est enregistrée sur Nextcloud. L’actualisation est en attente ; ne répétez pas la modification.';

  @override
  String get nextcloudOutcomeUnknown =>
      'Le résultat sur le serveur n’a pas pu être confirmé. Actualisez avant de réessayer.';

  @override
  String get nextcloudRemoveShared =>
      'Retirer le calendrier ou la liste partagée';

  @override
  String get nextcloudRemoveMixed =>
      'Cette collection contient des événements et des tâches. Sa suppression retire les deux.';

  @override
  String get nextcloudReadAccess => 'Lecture seule';

  @override
  String get nextcloudWriteAccess => 'Lecture et écriture';

  @override
  String get nextcloudRecipientSearch =>
      'Rechercher des personnes ou des groupes';

  @override
  String get nextcloudNoRecipients =>
      'Aucune personne ni aucun groupe correspondant.';

  @override
  String get nextcloudRevokeShare => 'Révoquer l’accès';

  @override
  String get nextcloudPublish => 'Publier un lien';

  @override
  String get nextcloudUnpublish => 'Arrêter la publication';

  @override
  String get nextcloudPublishWarning =>
      'Toute personne disposant du lien publié pourra peut-être lire ce calendrier. Le publier ?';

  @override
  String get nextcloudTrash => 'Calendriers et tâches supprimés';

  @override
  String get nextcloudTrashEmpty => 'Aucun élément de calendrier supprimé.';

  @override
  String get nextcloudRestore => 'Restaurer';

  @override
  String get nextcloudPermanentDelete => 'Supprimer définitivement';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Supprimer définitivement cet élément ? Il ne pourra pas être restauré depuis la corbeille de calendriers Nextcloud.';

  @override
  String get nextcloudOperationDenied => 'Nextcloud a refusé cette opération.';

  @override
  String get nextcloudUnsupported =>
      'Le serveur ne prend pas en charge cette opération.';

  @override
  String get nextcloudPendingChanges =>
      'Enregistrez ou abandonnez les modifications de la collection avant de fermer.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud est inaccessible. Les éléments en cache et les modifications en attente restent inchangés.';

  @override
  String get mapsShow => 'Afficher sur la carte';

  @override
  String get openLink => 'Ouvrir le lien';

  @override
  String get externalLocationOpenFailed =>
      'Impossible d’ouvrir le lieu dans une application externe.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'Impossible de replanifier l’événement. Son horaire enregistré n’a pas été modifié.';

  @override
  String get scheduleRescheduleStale =>
      'Cet événement a été modifié pendant le déplacement. Veuillez réessayer.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'Le nouvel horaire a été enregistré, mais les rappels n’ont pas pu être actualisés.';

  @override
  String get moveUp => 'Monter';

  @override
  String get moveDown => 'Descendre';

  @override
  String get windowsSupport => 'Assistance';

  @override
  String get windowsThirdPartyLicenses => 'Licences tierces';

  @override
  String get windowsSearch => 'Rechercher';

  @override
  String get windowsStartupDisabledByUser =>
      'Désactivé par l’utilisateur dans les paramètres Windows.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Désactivé par une stratégie Windows.';

  @override
  String get windowsStartupUnavailable =>
      'Disponible après l’installation de BusyMax à partir d’un package MSIX.';

  @override
  String get windowsReminderExitNotice =>
      'Les rappels s’arrêtent lorsque BusyMax est complètement fermé. Laissez-le s’exécuter en arrière-plan pour les recevoir.';

  @override
  String get windowsProductVersionLabel => 'Version du produit';

  @override
  String get windowsPackageVersionLabel => 'Version du package Windows';

  @override
  String get windowsUnpackaged => 'Non empaqueté';

  @override
  String get windowsAgendaLoadMore => 'Charger plus d’éléments de l’agenda';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'le lundi',
      'TU': 'le mardi',
      'WE': 'le mercredi',
      'TH': 'le jeudi',
      'FR': 'le vendredi',
      'SA': 'le samedi',
      'SU': 'le dimanche',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'les jours $first et $second du mois';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency les jours $firstDay et $secondDay de $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency le $day de $firstMonth et $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency les jours $firstDay et $secondDay de $firstMonth et $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency les jours $days de $firstMonth et $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Connectez les comptes Google, Microsoft, Calendrier Apple iCloud ou Nextcloud.';

  @override
  String get googlePermissionsConsentNotice =>
      'Sur l’écran d’autorisations Google, sélectionnez les autorisations Calendrier et Tâches.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Les autorisations Google Calendar et Google Tasks sont requises. Réessayez et sélectionnez les deux cases.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'Ce fournisseur n’est pas configuré.';

  @override
  String get waitingForGoogleSignIn => 'En attente de la connexion Google...';

  @override
  String get waitingForMicrosoftSignIn =>
      'En attente de la connexion Microsoft...';

  @override
  String get microsoftSignInNotConfigured =>
      'La connexion Microsoft n’est pas configurée. Définissez MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Annuler';

  @override
  String get close => 'Fermer';

  @override
  String get windowMinimize => 'Réduire';

  @override
  String get windowMaximize => 'Agrandir';

  @override
  String get windowRestore => 'Restaurer';

  @override
  String get exit => 'Quitter';

  @override
  String get options => 'Choix';

  @override
  String get hide => 'Masquer';

  @override
  String get show => 'Afficher';

  @override
  String get export => 'Exporter';

  @override
  String get save => 'Enregistrer';

  @override
  String get settings => 'Paramètres';

  @override
  String get all => 'Tout';

  @override
  String get calendarEvents => 'Événements';

  @override
  String get calendarTasks => 'Tâches';

  @override
  String get calendar => 'Calendrier';

  @override
  String get calendars => 'Calendriers';

  @override
  String get newCalendar => 'Nouveau calendrier';

  @override
  String get calendarColor => 'Couleur du calendrier';

  @override
  String calendarColorOption(int number) {
    return 'Couleur $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'Ce fournisseur ne prend pas en charge la gestion des calendriers dans BusyMax.';

  @override
  String get primaryCalendarCannotDelete =>
      'Le calendrier principal ne peut pas être supprimé.';

  @override
  String calendarCreateFailed(String error) {
    return 'Impossible de créer le calendrier : $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'Le calendrier a été créé, mais BusyMax n’a pas pu actualiser le compte. Il apparaîtra après la prochaine synchronisation.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Impossible de mettre à jour le calendrier : $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Impossible de supprimer le calendrier : $error';
  }

  @override
  String get newEvent => 'Nouvel événement';

  @override
  String get refreshCalendar => 'Actualiser le calendrier';

  @override
  String get openInProvider => 'Ouvrir dans le service';

  @override
  String get linkedResources => 'Ressources liées';

  @override
  String get noLinkedResources => 'Aucune ressource liée';

  @override
  String get attachments => 'Pièces jointes';

  @override
  String get attachmentsNotLoaded => 'Pièces jointes non chargées';

  @override
  String get hideFromSchedule => 'Masquer du planning';

  @override
  String get showInSchedule => 'Afficher dans le planning';

  @override
  String get noCalendarsSynced => 'Aucun calendrier synchronisé.';

  @override
  String get allDay => 'Toute la journée';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString de plus';
  }

  @override
  String get noEventsOrTasks => 'Aucun événement ni tâche';

  @override
  String get scheduleLoading => 'Chargement du planning...';

  @override
  String get scheduleUnavailable => 'Planning indisponible';

  @override
  String get scheduleNoSources => 'Aucun calendrier ni liste de tâches visible';

  @override
  String get scheduleNoSourcesDescription =>
      'Choisissez les éléments à afficher dans les paramètres, puis actualisez.';

  @override
  String get scheduleNoSearchResults =>
      'Aucun événement ni aucune tâche ne correspond';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Essayez une autre recherche ou effacez les filtres actuels.';

  @override
  String get refresh => 'Actualiser';

  @override
  String get trayOpenBusyMax => 'Ouvrir BusyMax';

  @override
  String get trayShowBusyMax => 'Afficher BusyMax';

  @override
  String get trayNewEvent => 'Nouvel événement…';

  @override
  String get trayNewTask => 'Nouvelle tâche…';

  @override
  String get trayToday => 'Aujourd’hui';

  @override
  String get trayAllDay => 'Toute la journée';

  @override
  String get trayNow => 'Maintenant';

  @override
  String get trayCalendarEvent => 'Événement du calendrier';

  @override
  String get trayUntitledEvent => 'Événement sans titre';

  @override
  String get trayNothingElseToday => 'Rien d’autre aujourd’hui';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count tâches arrivent à échéance aujourd’hui',
      one: '1 tâche arrive à échéance aujourd’hui',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Ouvrir l’agenda du jour';

  @override
  String get traySyncNow => 'Synchroniser maintenant';

  @override
  String get traySyncing => 'Synchronisation…';

  @override
  String get trayNotConnected => 'Non connecté';

  @override
  String get trayNotYetSynced => 'Pas encore synchronisé';

  @override
  String get trayLastSyncedJustNow => 'Synchronisé à l’instant';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synchronisé il y a $count minutes',
      one: 'Synchronisé il y a 1 minute',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synchronisé il y a $count heures',
      one: 'Synchronisé il y a 1 heure',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synchronisé il y a $count jours',
      one: 'Synchronisé il y a 1 jour',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Paramètres';

  @override
  String get trayQuitBusyMax => 'Quitter BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Charger plus de tâches en retard';

  @override
  String get agendaLoadMoreNoDate => 'Charger plus de tâches sans date';

  @override
  String get viewDay => 'Jour';

  @override
  String get viewWeek => 'Semaine';

  @override
  String get viewMonth => 'Mois';

  @override
  String get viewYear => 'Année';

  @override
  String get viewAgenda => 'Vue agenda';

  @override
  String get scheduleSettings => 'Planning';

  @override
  String get scheduleDisplaySettings => 'Affichage du planning';

  @override
  String get newEventsAndTasks => 'Nouveaux événements et tâches';

  @override
  String get defaultCalendar => 'Calendrier par défaut';

  @override
  String get defaultTaskList => 'Liste de tâches par défaut';

  @override
  String get lastUsed => 'Dernier utilisé';

  @override
  String get scheduleDisplayHoursDescription =>
      'Les vues Jour et Semaine s’ouvrent dans cette plage horaire. Les éléments situés avant ou après cette plage l’étendent si nécessaire.';

  @override
  String get scheduleDayStartsAt => 'La journée commence à';

  @override
  String get scheduleDayEndsAt => 'La journée se termine à';

  @override
  String get sourceCalendar => 'Calendrier';

  @override
  String get sourceTaskList => 'Liste de tâches';

  @override
  String get createChoiceTitle => 'Créer';

  @override
  String get createEventAtTime => 'Événement';

  @override
  String get createTaskAtDate => 'Tâche';

  @override
  String get editEvent => 'Modifier l’événement';

  @override
  String get eventTitle => 'Titre de l’événement';

  @override
  String get location => 'Lieu';

  @override
  String get timeSlot => 'Créneau';

  @override
  String get startDateTime => 'Date/heure de début';

  @override
  String get endDateTime => 'Date/heure de fin';

  @override
  String get doesNotRepeat => 'Ne se répète pas';

  @override
  String get defaultReminder => 'Rappel par défaut';

  @override
  String get guests => 'Invités';

  @override
  String get noGuests => 'Aucun invité';

  @override
  String get attendeeRequired => 'Obligatoire';

  @override
  String get attendeeOptional => 'Facultatif';

  @override
  String get meetingSection => 'Réunion';

  @override
  String get addGoogleMeet => 'Ajouter Google Meet';

  @override
  String get addTeamsMeeting => 'Ajouter une réunion Microsoft Teams';

  @override
  String get onlineMeetingAdded => 'Réunion en ligne ajoutée';

  @override
  String get requestResponses => 'Demander des réponses';

  @override
  String get requestResponsesDescription =>
      'Demandez aux invités de répondre à l’invitation.';

  @override
  String get hideGuestList => 'Masquer la liste des invités';

  @override
  String get hideGuestListDescription =>
      'Les invités ne peuvent pas voir qui d’autre a été invité.';

  @override
  String get allowNewTimeProposals =>
      'Autoriser les nouvelles propositions d’horaire';

  @override
  String get allowNewTimeProposalsDescription =>
      'Les invités peuvent proposer une autre heure de réunion.';

  @override
  String get notifyGuestsTitle => 'Notifier les invités ?';

  @override
  String get notifyGuestsSaveMessage =>
      'Cette réunion comporte des invités. Envoyer les invitations ou les mises à jour de l’événement lors de l’enregistrement ?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Cette réunion comporte des invités. Envoyer une annulation lors de sa suppression ?';

  @override
  String get sendUpdates => 'Envoyer les mises à jour';

  @override
  String get sendCancellation => 'Envoyer l’annulation';

  @override
  String get doNotSend => 'Ne pas envoyer';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Enregistrer la réunion ?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft enverra les invitations ou les mises à jour de l’événement aux invités.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Supprimer la réunion ?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft enverra une annulation aux invités.';

  @override
  String get organizer => 'Organisateur';

  @override
  String get yourResponse => 'Votre réponse';

  @override
  String get guestResponses => 'Réponses des invités';

  @override
  String get respond => 'Répondre';

  @override
  String get acceptInvitation => 'Accepter';

  @override
  String get tentativeInvitation => 'Provisoire';

  @override
  String get declineInvitation => 'Refuser';

  @override
  String get joinMeeting => 'Rejoindre la réunion';

  @override
  String get responseAccepted => 'Acceptée';

  @override
  String get responseTentative => 'Provisoire';

  @override
  String get responseDeclined => 'Refusée';

  @override
  String get responseNeedsAction => 'Réponse attendue';

  @override
  String get responseNotResponded => 'Sans réponse';

  @override
  String get responseOrganizer => 'Organisateur';

  @override
  String invitationResponseFailed(String error) {
    return 'Impossible d’envoyer votre réponse : $error';
  }

  @override
  String get joinMeetingFailed => 'Impossible d’ouvrir le lien de la réunion.';

  @override
  String get description => 'Détails';

  @override
  String get availabilityShowAs => 'Disponibilité / Afficher comme';

  @override
  String get busy => 'Occupé';

  @override
  String get visibility => 'Visibilité';

  @override
  String get defaultVisibility => 'Visibilité par défaut';

  @override
  String get conference => 'Conférence';

  @override
  String get noConference => 'Aucune conférence';

  @override
  String get providerCalendar => 'Calendrier du fournisseur';

  @override
  String get formatBoldShortLabel => 'G';

  @override
  String get formatBoldTooltip => 'Gras';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => 'Italique';

  @override
  String get formatUnderlineShortLabel => 'S';

  @override
  String get formatUnderlineTooltip => 'Souligné';

  @override
  String reminderMinutesBefore(int minutes) {
    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutes minutes avant',
      one: '1 minute avant',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'À l’heure de début';

  @override
  String reminderHoursBefore(int hours) {
    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hours heures avant',
      one: '1 heure avant',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$days jours avant',
      one: '1 jour avant',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Disponible';

  @override
  String get availabilityTentative => 'Provisoire';

  @override
  String get availabilityOutOfOffice => 'Absent du bureau';

  @override
  String get availabilityWorkingElsewhere => 'Travail ailleurs';

  @override
  String get visibilityDefault => 'Par défaut';

  @override
  String get visibilityPublic => 'Publique';

  @override
  String get visibilityPrivate => 'Privée';

  @override
  String get visibilityConfidential => 'Confidentielle';

  @override
  String get sensitivityNormal => 'Normale';

  @override
  String get sensitivityPersonal => 'Personnelle';

  @override
  String get tasks => 'Tâches';

  @override
  String get allTasks => 'Toutes les tâches';

  @override
  String tasksInList(String title) {
    return 'Tâches dans $title';
  }

  @override
  String get taskLists => 'Listes de tâches';

  @override
  String get navigation => 'Déplacement';

  @override
  String get mainMenu => 'Menu principal';

  @override
  String get keyboardShortcuts => 'Raccourcis clavier';

  @override
  String get shortcutGroupGeneral => 'Général';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Afficher cette liste de raccourcis';

  @override
  String get shortcutGroupNavigation => 'Déplacement';

  @override
  String get shortcutNextPeriod => 'Période suivante';

  @override
  String get shortcutNextPeriodDescription =>
      'Semaine suivante en vue semaine, mois suivant en vue mois, etc.';

  @override
  String get shortcutPreviousPeriod => 'Période précédente';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Semaine précédente en vue semaine, mois précédent en vue mois, etc.';

  @override
  String get shortcutJumpToToday => 'Aller à la date du jour';

  @override
  String get shortcutGroupView => 'Affichage';

  @override
  String get viewSelector => 'Affichage';

  @override
  String get shortcutDayView => 'Vue jour';

  @override
  String get shortcutWeekView => 'Vue semaine';

  @override
  String get shortcutMonthView => 'Vue mois';

  @override
  String get shortcutYearView => 'Vue année';

  @override
  String get shortcutAgendaView => 'Vue agenda';

  @override
  String get shortcutGroupCreateAndEdit => 'Créer et modifier';

  @override
  String get shortcutSaveItem => 'Enregistrer l\'événement ou la tâche';

  @override
  String get shortcutDeleteItem => 'Supprimer l\'événement ou la tâche';

  @override
  String get shortcutGroupTaskEditing => 'Modification des tâches';

  @override
  String get shortcutCancelEditing => 'Annuler la modification';

  @override
  String get shortcutCancelEditingDescription =>
      'Fermer la modification ou les détails de la tâche';

  @override
  String get aboutBusyMax => 'À propos de BusyMax';

  @override
  String get aboutBusyMaxDescription => 'Calendrier et tâches';

  @override
  String get license => 'Licence';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Site web';

  @override
  String get sourceCode => 'Code source';

  @override
  String get reportAnIssue => 'Signaler un problème';

  @override
  String get sendFeedback => 'Envoyer des commentaires';

  @override
  String get feedbackSubmit => 'Envoyer';

  @override
  String get feedbackCategory => 'Catégorie';

  @override
  String get feedbackSelectCategory => 'Sélectionnez une catégorie';

  @override
  String get feedbackCategoryProblem => 'Problème ou bug';

  @override
  String get feedbackCategoryFeature => 'Demande de fonctionnalité';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'Problème de confidentialité ou de sécurité';

  @override
  String get feedbackCategoryUsability => 'Problème d’ergonomie';

  @override
  String get feedbackCategoryOther => 'Autre';

  @override
  String get feedbackSubject => 'Objet';

  @override
  String get feedbackDetailedMessage => 'Message détaillé';

  @override
  String get feedbackReplyEmail => 'Adresse e-mail de réponse (facultatif)';

  @override
  String get feedbackIncludeTechnicalDetails =>
      'Inclure les détails techniques';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Ajoute uniquement le nom et la version de votre système d’exploitation et la langue de l’application. Aucun journal, aucune donnée de compte, aucun nom de fichier ni autre diagnostic n’est inclus.';

  @override
  String get feedbackCategoryRequired => 'Sélectionnez une catégorie.';

  @override
  String get feedbackSubjectLengthError =>
      'L’objet doit comporter entre 3 et 120 caractères.';

  @override
  String get feedbackMessageLengthError =>
      'Le message doit comporter entre 10 et 5 000 caractères.';

  @override
  String get feedbackInvalidEmail => 'Saisissez une adresse e-mail valide.';

  @override
  String get feedbackConnectionError =>
      'Impossible de se connecter à BusyStack. Vérifiez votre connexion et réessayez.';

  @override
  String get feedbackTimeoutError =>
      'La demande a expiré. Vos commentaires n’ont pas été effacés ; réessayez.';

  @override
  String get feedbackRateLimitedError =>
      'Trop de commentaires ont été envoyés depuis ce réseau. Patientez, puis réessayez.';

  @override
  String get feedbackRejectedError =>
      'Le serveur a rejeté l’envoi. Vérifiez les champs, puis réessayez.';

  @override
  String get feedbackServerError =>
      'BusyStack ne peut pas accepter vos commentaires pour le moment. Vos commentaires n’ont pas été effacés ; réessayez.';

  @override
  String feedbackSuccess(String id) {
    return 'Commentaires envoyés. Référence : $id';
  }

  @override
  String get toggleSidebar => 'Afficher/masquer la barre latérale';

  @override
  String get showSidebar => 'Afficher le panneau latéral';

  @override
  String get hideSidebar => 'Masquer le panneau latéral';

  @override
  String get accounts => 'Comptes';

  @override
  String get currentAccount => 'Compte actuel';

  @override
  String get switchAccount => 'Changer de compte';

  @override
  String get addGoogleAccount => 'Ajouter un compte Google';

  @override
  String get addMicrosoftAccount => 'Ajouter un compte Microsoft';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Connecté';

  @override
  String get removeAccount => 'Supprimer le compte…';

  @override
  String get removingAccount => 'Suppression du compte…';

  @override
  String get removeAccountDescription =>
      'Arrêter la synchronisation et supprimer les données de ce compte de cet appareil.';

  @override
  String removeAccountTitle(String account) {
    return 'Supprimer $account de BusyMax ?';
  }

  @override
  String get removeAccountConfirmation =>
      'Cette action supprime de cet appareil les tâches, calendriers, événements, rappels et modifications hors ligne en attente mis en cache. Les modifications non synchronisées seront perdues. Les copies des calendriers, événements, listes de tâches et tâches conservées chez le fournisseur ne sont pas supprimées.';

  @override
  String get revokeGoogleAccess =>
      'Révoquer également l’accès de BusyMax à ce compte Google';

  @override
  String get revokeGoogleAccessDescription =>
      'Vous devrez accorder à nouveau l’accès avant de reconnecter le compte.';

  @override
  String get removeAccountAction => 'Supprimer le compte';

  @override
  String get removeAccountFailed =>
      'Impossible de terminer la suppression du compte. Réessayez.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'Le compte a été supprimé de cet appareil, mais BusyMax n’a pas pu révoquer son accès à votre compte Google. Vous pouvez révoquer cet accès depuis votre compte Google.';

  @override
  String get newTaskList => 'Nouvelle liste de tâches';

  @override
  String taskListCreateFailed(String error) {
    return 'Impossible de créer la liste de tâches : $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Impossible de renommer la liste de tâches : $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Impossible de supprimer la liste de tâches : $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Synchronisez le compte ou résolvez les modifications bloquées de cette liste de tâches dans Diagnostics avant de supprimer ou de retirer la liste.';

  @override
  String get signInToViewTaskLists =>
      'Connectez-vous pour voir les listes de tâches.';

  @override
  String get noTaskListsSynced => 'Aucune liste de tâches synchronisée.';

  @override
  String get listActions => 'Actions de liste';

  @override
  String get rename => 'Renommer';

  @override
  String get delete => 'Supprimer';

  @override
  String get renameList => 'Renommer la liste';

  @override
  String get deleteList => 'Supprimer la liste';

  @override
  String get unshare => 'Ne plus partager';

  @override
  String get readOnlyTaskListCannotRename =>
      'Cette liste de tâches est en lecture seule et ne peut pas être renommée.';

  @override
  String get taskListCannotDelete =>
      'Cette liste de tâches ne peut pas être supprimée avec vos autorisations actuelles.';

  @override
  String get builtInMicrosoftList => 'Intégrée';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Les listes Microsoft To Do intégrées ne peuvent pas être renommées ni supprimées.';

  @override
  String deleteListConfirmation(String title) {
    return 'Supprimer « $title » de Google Tasks ?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Supprimer « $title » et toutes ses tâches ?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Ne plus partager « $title » avec ce compte ?';
  }

  @override
  String get deleteEvent => 'Supprimer l’événement';

  @override
  String get title => 'Titre';

  @override
  String get create => 'Créer';

  @override
  String get newTask => 'Nouvelle tâche';

  @override
  String get clearCompleted => 'Effacer les tâches terminées';

  @override
  String get refreshList => 'Actualiser la liste';

  @override
  String get refreshAll => 'Tout actualiser';

  @override
  String get listRefreshed => 'Liste actualisée.';

  @override
  String get allTasksRefreshed => 'Tous les comptes ont été actualisés.';

  @override
  String exportedFile(String path) {
    return 'Exporté vers $path';
  }

  @override
  String exportFailed(String error) {
    return 'Échec de l’export : $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Échec de l’actualisation : $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Sélectionnez ou créez une liste de tâches pour commencer.';

  @override
  String get signInToViewTasks => 'Connectez-vous pour voir les tâches.';

  @override
  String get noTasks => 'Aucune tâche.';

  @override
  String get noTasksYet => 'Aucune tâche pour le moment';

  @override
  String get noTasksYetMessage =>
      'Créez une tâche ou actualisez vos comptes pour commencer.';

  @override
  String get noTasksInList => 'Aucune tâche dans cette liste.';

  @override
  String get overdue => 'En retard';

  @override
  String get today => 'Aujourd’hui';

  @override
  String get tomorrow => 'Demain';

  @override
  String get upcoming => 'À venir';

  @override
  String get noDate => 'Sans date';

  @override
  String get completed => 'Terminées';

  @override
  String duePrefix(String date) {
    return 'Échéance $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date à $time';
  }

  @override
  String get taskDetails => 'Détails de la tâche';

  @override
  String get editTask => 'Modifier la tâche';

  @override
  String get noTaskSelected => 'Aucune tâche sélectionnée.';

  @override
  String get noTaskSelectedHelper =>
      'Sélectionnez une tâche pour afficher et modifier ses détails.';

  @override
  String get taskUnavailable => 'Tâche indisponible.';

  @override
  String get signInToEditTasks => 'Connectez-vous pour modifier les tâches.';

  @override
  String get refreshTask => 'Actualiser la tâche';

  @override
  String get primarySection => 'Principal';

  @override
  String get statusSection => 'État';

  @override
  String get openStatus => 'Ouverte';

  @override
  String get doneStatus => 'Terminée';

  @override
  String get taskStatus => 'État';

  @override
  String get taskStatusNone => 'Aucun état';

  @override
  String get taskStatusNeedsAction => 'Action requise';

  @override
  String get taskStatusInProcess => 'En cours';

  @override
  String get taskStatusCompleted => 'Terminée';

  @override
  String get taskStatusCancelled => 'Annulée';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString % terminée';
  }

  @override
  String get completionDate => 'Date d’achèvement';

  @override
  String get priority => 'Priorité';

  @override
  String get priorityNone => 'Aucune priorité';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorité $priorityString · élevée';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorité $priorityString · moyenne';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorité $priorityString · faible';
  }

  @override
  String get taskUrl => 'URL de la tâche';

  @override
  String get invalidTaskUrl => 'Saisissez une URL absolue, avec son schéma.';

  @override
  String get classification => 'Catégorisation';

  @override
  String get classificationPublic =>
      'Lorsqu’elle est partagée, afficher la tâche complète';

  @override
  String get classificationConfidential =>
      'Lorsqu’elle est partagée, afficher uniquement l’état occupé';

  @override
  String get classificationPrivate =>
      'Lorsqu’elle est partagée, masquer cette tâche';

  @override
  String get pinTask => 'Épingler la tâche';

  @override
  String get notes => 'Remarques';

  @override
  String get dueDate => 'Date d’échéance';

  @override
  String get clearDueDate => 'Effacer la date d’échéance';

  @override
  String get dueTime => 'Heure d’échéance';

  @override
  String get startDate => 'Date de début';

  @override
  String get startTime => 'Heure de début';

  @override
  String get endDate => 'Date de fin';

  @override
  String get endTime => 'Heure de fin';

  @override
  String get reminderDate => 'Date de rappel';

  @override
  String get reminderTime => 'Heure de rappel';

  @override
  String get reminder => 'Rappel';

  @override
  String get addReminder => 'Ajouter un rappel';

  @override
  String get reminders => 'Rappels';

  @override
  String get noReminders => 'Aucun rappel';

  @override
  String get editReminder => 'Modifier le rappel';

  @override
  String get beforeTaskStarts => 'Avant le début de la tâche';

  @override
  String get beforeTaskDue => 'Avant l’échéance de la tâche';

  @override
  String get afterTaskStarts => 'Après le début de la tâche';

  @override
  String get afterTaskDue => 'Après l’échéance de la tâche';

  @override
  String get relativeToTaskStart =>
      'Par rapport à la date de début de la tâche';

  @override
  String get relativeToTaskDue =>
      'Par rapport à la date d’échéance de la tâche';

  @override
  String get reminderTimeOfDay => 'Heure de la journée';

  @override
  String get absoluteReminder => 'À une date et une heure';

  @override
  String get reminderAmount => 'Quantité';

  @override
  String get reminderUnit => 'Unité';

  @override
  String get reminderUnitSeconds => 'Secondes';

  @override
  String get reminderUnitMinutes => 'min';

  @override
  String get reminderUnitHours => 'Heures';

  @override
  String get reminderUnitDays => 'Jours';

  @override
  String get reminderUnitWeeks => 'Semaines';

  @override
  String get reminderAtTaskStart => 'Au début de la tâche';

  @override
  String get reminderAtTaskDue => 'À l’échéance de la tâche';

  @override
  String get unsupportedReminder =>
      'Ce type de rappel est conservé, mais son heure ne peut pas être modifiée.';

  @override
  String get relatedRemindersTitle => 'Conserver les rappels associés ?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Cette date comporte $countString rappels associés. Les conserver à leur date et heure actuelles ?';
  }

  @override
  String get discardRelatedReminders => 'Supprimer les rappels';

  @override
  String get keepRelatedReminders => 'Conserver les rappels';

  @override
  String get addGuest => 'Ajouter un invité';

  @override
  String get addGuestEmail => 'Ajouter l’e-mail de l’invité';

  @override
  String get removeReminder => 'Supprimer le rappel';

  @override
  String get off => 'Désactivé';

  @override
  String get repeat => 'Répéter';

  @override
  String get repeatNone => 'Aucun';

  @override
  String get noneValue => 'Aucun';

  @override
  String get repeatDaily => 'Quotidien';

  @override
  String get repeatWeekly => 'Hebdomadaire';

  @override
  String get repeatMonthly => 'Mensuel';

  @override
  String get repeatYearly => 'Annuel';

  @override
  String get repeatEvery => 'Intervalle';

  @override
  String get repeatOn => 'Répéter le';

  @override
  String get repeatEnd => 'Terminer la répétition';

  @override
  String get repeatNever => 'Jamais';

  @override
  String get repeatUntil => 'À une date';

  @override
  String get repeatAfter => 'Après un certain nombre de répétitions';

  @override
  String get repeatCount => 'Nombre d’occurrences';

  @override
  String get repeatDayOfMonth => 'Jours du mois';

  @override
  String get repeatMonths => 'Mois';

  @override
  String get repeatOrdinal => 'Position du jour de la semaine';

  @override
  String get repeatSpecificDays => 'Jours précis';

  @override
  String get repeatFirst => 'Premier';

  @override
  String get repeatSecond => 'Deuxième';

  @override
  String get repeatThird => 'Troisième';

  @override
  String get repeatFourth => 'Quatrième';

  @override
  String get repeatFifth => 'Cinquième';

  @override
  String get repeatSecondToLast => 'Avant-dernier';

  @override
  String get repeatLast => 'Dernier';

  @override
  String get repeatAnyDay => 'Jour';

  @override
  String get repeatWeekday => 'Jour de semaine';

  @override
  String get repeatWeekendDay => 'Jour du week-end';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'lundi',
      'TU': 'mardi',
      'WE': 'mercredi',
      'TH': 'jeudi',
      'FR': 'vendredi',
      'SA': 'samedi',
      'SU': 'dimanche',
      'day': 'jour',
      'weekday': 'jour de semaine',
      'weekend': 'jour du week-end',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Tous les $countString jours';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Toutes les $countString semaines';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Tous les $countString mois';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Toutes les $countString années';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'le $days du mois';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'le premier $days',
      'second': 'le deuxième $days',
      'third': 'le troisième $days',
      'fourth': 'le quatrième $days',
      'fifth': 'le cinquième $days',
      'secondToLast': 'l’avant-dernier $days',
      'last': 'le dernier $days',
      'other': 'les $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'en $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString fois',
      one: '$countString fois',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'jusqu’au $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'Cette règle de récurrence utilise des options que cet éditeur ne modifie pas.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'Cette liste ne prend pas en charge ce modèle de répétition. Modifiez le modèle ou choisissez une autre liste.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Ajoutez une date de début ou d’échéance pour utiliser ce modèle de répétition, ou désactivez la répétition.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Cette récurrence ne peut pas être utilisée avec $provider.';
  }

  @override
  String get importance => 'Niveau d’importance';

  @override
  String get importanceLow => 'Faible';

  @override
  String get importanceNormal => 'Normale';

  @override
  String get importanceHigh => 'Élevée';

  @override
  String get categories => 'Catégories';

  @override
  String get scheduleSection => 'Planification';

  @override
  String get dueGroup => 'Échéance';

  @override
  String get startGroup => 'Début';

  @override
  String get reminderGroup => 'Rappel';

  @override
  String get organizationSection => 'Organisation';

  @override
  String get actionsSection => 'Opérations';

  @override
  String get advancedSection => 'Avancé';

  @override
  String get addCategory => 'Ajouter une catégorie';

  @override
  String get list => 'Liste';

  @override
  String get microsoftMoveUnsupported =>
      'Le déplacement entre listes n’est pas pris en charge pour les comptes Microsoft To Do dans cette version.';

  @override
  String get createSubtask => 'Créer une sous-tâche';

  @override
  String get subtasks => 'Sous-tâches';

  @override
  String get duplicateTask => 'Dupliquer la tâche';

  @override
  String get taskDuplicated => 'Tâche dupliquée.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Impossible de dupliquer la tâche : $error';
  }

  @override
  String get hideSubtasks => 'Masquer les sous-tâches';

  @override
  String get hideClosedSubtasks => 'Masquer les sous-tâches terminées';

  @override
  String get moveToTop => 'Déplacer tout en haut';

  @override
  String get deleteTask => 'Supprimer la tâche';

  @override
  String get newSubtask => 'Nouvelle sous-tâche';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Supprimer « $title » ?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Cela supprime aussi la tâche d’origine dans Google Docs ou les espaces Chat.';

  @override
  String get metadata => 'Métadonnées';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Mis à jour';

  @override
  String get parent => 'Tâche parente';

  @override
  String get position => 'Ordre';

  @override
  String get webLink => 'Lien web';

  @override
  String get assignment => 'Attribution';

  @override
  String get localState => 'État local';

  @override
  String get pendingSync => 'Synchronisation en attente';

  @override
  String get synced => 'Synchronisé';

  @override
  String get account => 'Compte';

  @override
  String get sync => 'Synchronisation';

  @override
  String get forceFullResync => 'Forcer une resynchronisation complète';

  @override
  String get forceFullResyncDescription =>
      'Recharge entièrement les données de chaque compte connecté. N’utilisez cette option que pour résoudre des problèmes de synchronisation.';

  @override
  String get runInBackgroundWhenClosed =>
      'Continuer à s’exécuter après la fermeture de la fenêtre';

  @override
  String get showTrayIcon => 'Afficher l’icône dans la zone de notification';

  @override
  String get startMinimizedToTray =>
      'Démarrer réduit dans la zone de notification';

  @override
  String get launchAtLogin => 'Lancer à la connexion';

  @override
  String get launchAtLoginDescription =>
      'Démarrer BusyMax en arrière-plan afin que les rappels fonctionnent après la connexion.';

  @override
  String get launchAtLoginFailed =>
      'Impossible de modifier le lancement à la connexion.';

  @override
  String get requiresTrayIcon =>
      'Nécessite l’icône de la zone de notification.';

  @override
  String get syncComplete => 'Synchronisation terminée.';

  @override
  String syncFailed(String error) {
    return 'Échec de la synchronisation : $error';
  }

  @override
  String get notifySyncFailures => 'Notifications d’échec de synchronisation';

  @override
  String get notifyConflicts => 'Notifications de conflits';

  @override
  String get notifyDueToday => 'Notifications des tâches dues aujourd’hui';

  @override
  String get eventReminders => 'Rappels d’événements';

  @override
  String get onState => 'Activé';

  @override
  String get taskReminders => 'Rappels de tâches';

  @override
  String get notificationDetailLevel => 'Niveau de détail des notifications';

  @override
  String get notificationDetailPrivate => 'Privé';

  @override
  String get notificationDetailNormal => 'Standard';

  @override
  String get quietHours => 'Période de silence';

  @override
  String get quietHoursDescription =>
      'Mettre les notifications en pause pendant cette période.';

  @override
  String get quietHoursStart => 'Début de la période de silence';

  @override
  String get quietHoursEnd => 'Fin de la période de silence';

  @override
  String get notifications => 'Alertes';

  @override
  String get windowsNotificationsUnavailable =>
      'Les notifications Windows sont indisponibles';

  @override
  String get windowsNotificationsUnpackaged =>
      'Cette exécution de développement non empaquetée ne peut pas utiliser les notifications Windows. Installez le MSIX signé pour les tests afin de vérifier les rappels.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax n’a pas pu initialiser les notifications Windows. Les rappels ne s’afficheront pas tant que ce problème d’installation ne sera pas résolu.';

  @override
  String get appearance => 'Apparence';

  @override
  String get theme => 'Thème';

  @override
  String get themeSystem => 'Système';

  @override
  String get settingsSystem => 'Système';

  @override
  String get themeLight => 'Clair';

  @override
  String get themeDark => 'Sombre';

  @override
  String get themeFamily => 'Famille de thèmes';

  @override
  String get themeFamilyYaru => 'Thème natif d’Ubuntu (Yaru)';

  @override
  String get localization => 'Localisation';

  @override
  String get currentLocale => 'Paramètres régionaux actuels';

  @override
  String get privacy => 'Confidentialité';

  @override
  String get redactTaskContentInDiagnostics =>
      'Masquer le contenu des tâches dans les diagnostics';

  @override
  String get developerDiagnostics => 'Diagnostics développeur';

  @override
  String get diagnostics => 'Informations de diagnostic';

  @override
  String get apiInspectorDisabled => 'Afficher l’inspecteur API';

  @override
  String get googleTasksApi => 'API Google Tasks';

  @override
  String discoveryRevision(String revision) {
    return 'Révision Discovery : $revision';
  }

  @override
  String get implementedMethods => 'Méthodes implémentées';

  @override
  String get supportsTasksScopes =>
      'Prend en charge les champs d’application tasks et tasks.readonly';

  @override
  String get requiresTasksScope => 'Nécessite le champ d’application tasks';

  @override
  String get blockedPendingOperations => 'Opérations en attente bloquées';

  @override
  String get signInToInspectPendingOperations =>
      'Connectez-vous pour inspecter les opérations en attente.';

  @override
  String get noBlockedPendingOperations =>
      'Aucune opération en attente bloquée.';

  @override
  String get operationActions => 'Actions de l’opération';

  @override
  String pendingOpListId(String id) {
    return 'liste=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'tâche=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'tentatives=$countString';
  }

  @override
  String get retry => 'Réessayer';

  @override
  String get discard => 'Abandonner';

  @override
  String get discardChangesAction => 'Abandonner';

  @override
  String get discardChanges => 'Abandonner les modifications ?';

  @override
  String get discardChangesConfirmation =>
      'Les modifications non enregistrées apportées à cette tâche seront perdues.';

  @override
  String get retryCompleted => 'Nouvelle tentative terminée.';

  @override
  String get discardPendingOperation => 'Abandonner l’opération en attente ?';

  @override
  String get discardPendingOperationConfirmation =>
      'Cette action supprime l’opération locale bloquée. Lors de la prochaine synchronisation, les données seront rechargées depuis Google Tasks.';

  @override
  String get pendingOperationDiscarded => 'Opération en attente abandonnée.';

  @override
  String get syncFailureNotificationTitle =>
      'Échec de la synchronisation BusyMax';

  @override
  String syncFailureNotificationBody(String message) {
    return 'La synchronisation en arrière-plan a échoué. $message';
  }

  @override
  String get conflictNotificationTitle => 'Conflit de synchronisation BusyMax';

  @override
  String conflictNotificationBody(String summary) {
    return 'Une modification locale en attente a été bloquée. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Tâches dues aujourd’hui';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString tâches sont dues aujourd’hui.',
      one: 'Une tâche est due aujourd’hui.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Rappel d’événement';

  @override
  String get taskReminderNotificationTitle => 'Rappel de tâche';

  @override
  String get eventReminderNotificationBody => 'L’événement commence bientôt.';

  @override
  String get taskReminderNotificationBody =>
      'La tâche arrive bientôt à échéance.';

  @override
  String get notificationOpenAction => 'Ouvrir';

  @override
  String get notificationSnoozeAction => 'Rappeler dans 10 minutes';

  @override
  String get notificationDismissAction => 'Fermer';

  @override
  String get notificationDetailsHidden =>
      'Les détails sont masqués par les paramètres de confidentialité.';

  @override
  String get previousMonth => 'Mois précédent';

  @override
  String get nextMonth => 'Mois suivant';

  @override
  String get openMonthView => 'Ouvrir la vue mensuelle';

  @override
  String get previousYear => 'Année précédente';

  @override
  String get nextYear => 'Année suivante';

  @override
  String get openYearView => 'Ouvrir la vue annuelle';

  @override
  String weekNumberTooltip(int number) {
    return 'Semaine $number';
  }

  @override
  String get resizeAllDayPanel =>
      'Redimensionner le volet des événements sur toute la journée';

  @override
  String scheduleItemCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count éléments',
      one: '1 élément',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'Ce calendrier est en lecture seule.';

  @override
  String get selectTimeZone => 'Sélectionner le fuseau horaire';

  @override
  String get searchLocations => 'Rechercher des lieux';

  @override
  String get noLocationsFound => 'Aucun lieu trouvé';

  @override
  String get requiredField => 'Ce champ est obligatoire.';

  @override
  String get providerConnectionDescription =>
      'Connectez les calendriers et les tâches à l’un de ces fournisseurs.';

  @override
  String get appleICloudProvider => 'Calendrier Apple iCloud';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Tâches Nextcloud';

  @override
  String get addAppleICloudAccount =>
      'Ajouter un compte Calendrier Apple iCloud';

  @override
  String get addNextcloudAccount => 'Ajouter un compte Nextcloud';

  @override
  String get waitingForAppleICloud => 'Connexion à Apple iCloud…';

  @override
  String get waitingForNextcloud => 'En attente de l’autorisation Nextcloud…';

  @override
  String get connectAppleICloudTitle => 'Connecter le Calendrier Apple iCloud';

  @override
  String get appleAccountEmail => 'E-mail du compte Apple';

  @override
  String get appleAppSpecificPassword => 'Mot de passe spécifique à l’app';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Créez un mot de passe spécifique à l’app après avoir activé l’authentification à deux facteurs de votre compte Apple.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'La réinitialisation du mot de passe de votre compte Apple révoque les mots de passe spécifiques aux apps.';

  @override
  String get connectNextcloudTitle => 'Connecter Nextcloud';

  @override
  String get nextcloudServerUrl => 'Serveur Nextcloud ou adresse CalDAV';

  @override
  String get nextcloudServerUrlHelp =>
      'Saisissez l’URL de votre serveur Nextcloud ou collez l’adresse CalDAV principale copiée depuis Nextcloud.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax va ouvrir votre navigateur. Autorisez-y l’accès, puis revenez dans BusyMax.';

  @override
  String get connectAccountAction => 'Connecter';

  @override
  String get cancelAccountConnection => 'Annuler la connexion';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'Le compte a été supprimé localement, mais le mot de passe d’app Nextcloud n’a pas pu être révoqué.';

  @override
  String get davReauthenticationRequired =>
      'Reconnectez ce compte pour reprendre la synchronisation.';

  @override
  String get davTemporarilyUnavailable =>
      'Ce compte est temporairement indisponible.';

  @override
  String get davPermissionChanged =>
      'Les autorisations du serveur ont changé. Les modifications en attente sont suspendues.';

  @override
  String get davUnsupportedServer =>
      'Ce serveur ou profil de fournisseur n’est pas pris en charge.';

  @override
  String get collectionSettings => 'Calendriers et listes de tâches';

  @override
  String get calendarContent => 'Événements du calendrier';

  @override
  String get taskContent => 'Tâches';

  @override
  String get readOnlySharedCollection => 'Lecture seule';

  @override
  String get pendingLocally => 'En attente localement';

  @override
  String get conflictBlocked => 'Bloqué par un conflit';

  @override
  String get authenticationBlocked => 'Bloqué jusqu’à la reconnexion';

  @override
  String get operationFailed => 'Échec de l’opération';

  @override
  String get keepServerVersion => 'Conserver la version du serveur';

  @override
  String get reapplyLocalChange =>
      'Examiner et réappliquer la modification locale';

  @override
  String get duplicateLocalItem => 'Dupliquer comme nouvel élément';

  @override
  String get davConnectionState => 'État de la connexion';

  @override
  String get davConnected => 'Connecté';

  @override
  String get davConnecting => 'Connexion…';

  @override
  String get davSignedOut => 'Déconnecté';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Dernière synchronisation réussie : $time';
  }

  @override
  String get davNeverSynced => 'Pas encore synchronisé';

  @override
  String get refreshCollections =>
      'Actualiser les calendriers et les listes de tâches';

  @override
  String nextcloudServerHost(String host) {
    return 'Serveur : $host';
  }

  @override
  String get collectionSupportsEvents => 'Calendrier d’événements';

  @override
  String get collectionSupportsTasks => 'Liste de tâches';

  @override
  String get collectionSupportsEventsAndTasks => 'Événements et tâches';

  @override
  String get writableCollection => 'Modifiable';

  @override
  String get sharedCollection => 'Partagé';

  @override
  String collectionLastSynced(String time) {
    return 'Dernière synchronisation : $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Problème de synchronisation : $code';
  }

  @override
  String get syncConflicts => 'Conflits de synchronisation';

  @override
  String remoteChangedAt(String time) {
    return 'Modification du serveur : $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Modification locale : $summary';
  }

  @override
  String get conflictResolutionFailed => 'Impossible de résoudre le conflit.';

  @override
  String get recurringEventScope => 'Portée de l’événement récurrent';

  @override
  String get entireSeries => 'Série entière';

  @override
  String get singleOccurrence => 'Cet événement';

  @override
  String get thisAndFollowingEvents => 'Cet événement et les suivants';

  @override
  String get thisAndFutureUnavailable =>
      'Non pris en charge par ce fournisseur.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'Cet événement et les suivants ne peuvent pas être déplacés de manière fiable. Choisissez cet événement ou toute la série.';

  @override
  String get entireSeriesMoveUnavailable =>
      'La règle de récurrence n’est pas disponible localement. Déplacez uniquement cet événement.';

  @override
  String get copyEventAndDeleteOriginal =>
      'Copier l’événement et supprimer l’original ?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax ne peut pas déplacer directement cet événement de $source vers $destination. La copie sera créée en premier et l’original ne sera supprimé qu’après la réussite de la copie. Les identifiants changeront ; les statuts de réponse des participants pourront être réinitialisés et des invitations ou annulations envoyées ; les liens de conférence, pièces jointes, rappels, champs propres au fournisseur et exceptions de récurrence pourront ne pas être conservés.';
  }

  @override
  String get copyAndDelete => 'Copier et supprimer';

  @override
  String get chooseRecurringEventScope =>
      'Choisissez si cette modification s’applique à toute la série, à cet événement uniquement ou à cet événement et aux suivants.';

  @override
  String get taskDueBeforeStart => 'L’échéance ne peut pas précéder le début.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Définissez une heure pour le début et l’échéance, ou passez la tâche en journée entière.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Supprimer « $title » ?';
  }

  @override
  String get setCustomCalendarName => 'Définir un nom personnalisé';

  @override
  String get setAction => 'Définir';

  @override
  String get removeFromMyCalendars => 'Retirer de mes agendas';

  @override
  String get removeAction => 'Retirer';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Retirer « $title » de BusyMax ? L’agenda et les événements du propriétaire ne seront pas supprimés.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'L’envoi a peut-être réussi. Actualisez les pièces jointes pour vérifier le résultat avant de réessayer.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Retirer « $title » de votre liste Google Agenda ? L’agenda partagé et ses événements ne seront pas supprimés.';
  }

  @override
  String get calendarCannotRemove =>
      'Ce calendrier ne peut pas être supprimé ou retiré de ce compte.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Attendez que les modifications en attente de ce calendrier aient fini de se synchroniser avant de le supprimer ou de le retirer.';

  @override
  String get calendarSubscriptions => 'Abonnements aux calendriers';

  @override
  String get calendarSubscriptionsDescription =>
      'Ajoutez des calendriers en lecture seule qui se mettent à jour depuis une URL WebCal sécurisée.';

  @override
  String get addCalendarSubscription => 'Ajouter un abonnement de calendrier';

  @override
  String get subscriptionName => 'Nom local';

  @override
  String get subscriptionUrl => 'URL de l’abonnement';

  @override
  String get subscriptionUrlHelp =>
      'Saisissez une URL HTTPS ou webcal. BusyMax conserve l’URL complète dans un stockage sécurisé.';

  @override
  String get subscriptionUrlInvalid =>
      'Saisissez une URL HTTPS ou webcal valide, sans informations utilisateur ni fragment.';

  @override
  String get subscriptionColor => 'Couleur locale';

  @override
  String get subscriptionColorHelp =>
      'Utilisez une couleur à six chiffres, comme #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Saisissez une couleur hexadécimale à six chiffres.';

  @override
  String get subscriptionRefreshMode => 'Fréquence d’actualisation';

  @override
  String get subscriptionAutomatic => 'Automatique';

  @override
  String get subscriptionHourly => 'Toutes les heures';

  @override
  String get subscriptionSixHours => 'Toutes les six heures';

  @override
  String get subscriptionDaily => 'Tous les jours';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Source : $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Saisissez une URL valide pour prévisualiser son origine sécurisée.';

  @override
  String get subscriptionReadOnly => 'Abonnement en lecture seule';

  @override
  String get subscriptionNeverRefreshed => 'Pas encore actualisé';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Dernière actualisation réussie : $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Prochaine actualisation : $time';
  }

  @override
  String get subscriptionStatusHealthy => 'À jour';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Problème d’actualisation : $code';
  }

  @override
  String get refreshNow => 'Actualiser maintenant';

  @override
  String get unsubscribe => 'Se désabonner';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Se désabonner de « $name » ?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'Cette action supprime l’abonnement local et ses événements mis en cache. Le calendrier publié n’est pas modifié.';

  @override
  String get addSubscriptionAction => 'Ajouter un abonnement';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Échec de l’abonnement au calendrier : $error';
  }

  @override
  String get subscriptions => 'Abonnements';

  @override
  String get calendarImport => 'Importation de calendrier';

  @override
  String get calendarImportDescription =>
      'Sélectionnez un fichier, vérifiez ses événements, puis choisissez le calendrier modifiable qui doit les recevoir.';

  @override
  String get importIcsFile => 'Importer un fichier .ics';

  @override
  String get importIcsPreview => 'Importer des événements du calendrier';

  @override
  String importEventsFound(int count) {
    return 'Ensembles d’événements importables : $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Événements non valides : $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Exclus intentionnellement : $fields';
  }

  @override
  String get noWritableCalendars =>
      'Aucun calendrier de destination modifiable n’est disponible.';

  @override
  String get importDestinationCalendar => 'Calendrier de destination';

  @override
  String get importIcsConfirm => 'Importer les événements';

  @override
  String get importIcsComplete => 'Importation terminée';

  @override
  String importQueued(int count) {
    return 'Importés ou mis en file d’attente : $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Doublons ignorés : $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Ensembles de récurrence non pris en charge : $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'Impossible d’importer le fichier de calendrier : $error';
  }

  @override
  String get networkOffline => 'Hors ligne';

  @override
  String get networkOfflineDescription =>
      'Les modifications seront synchronisées au rétablissement de la connexion.';

  @override
  String get networkOfflineTryAgain =>
      'Vous êtes hors ligne. Connectez-vous à Internet et réessayez.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'les $days du mois';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first et $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first et $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first et $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first et $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency le $day $month';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency les jours $days de $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency le $day de $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency les jours $days de $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'le premier $days de $month',
      'second': 'le deuxième $days de $month',
      'third': 'le troisième $days de $month',
      'fourth': 'le quatrième $days de $month',
      'fifth': 'le cinquième $days de $month',
      'secondToLast': 'l’avant-dernier $days de $month',
      'last': 'le dernier $days de $month',
      'other': 'les $days de $month',
    });
    return '$frequency $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'le premier $days de $months',
      'second': 'le deuxième $days de $months',
      'third': 'le troisième $days de $months',
      'fourth': 'le quatrième $days de $months',
      'fifth': 'le cinquième $days de $months',
      'secondToLast': 'l’avant-dernier $days de $months',
      'last': 'le dernier $days de $months',
      'other': 'les $days de $months',
    });
    return '$frequency $_temp0';
  }

  @override
  String get searchFilters => 'Filtres de recherche';

  @override
  String get searchType => 'Type d’élément';

  @override
  String get searchDate => 'Date de recherche';

  @override
  String get searchAnyDate => 'Toutes les dates (données téléchargées)';

  @override
  String get eventLink => 'Lien de l’événement';

  @override
  String get eventLinkOpenFailed => 'Impossible d’ouvrir le lien.';

  @override
  String get scheduleRangeIncomplete =>
      'Certains événements n’ont pas pu être vérifiés. Les données téléchargées sont affichées.';

  @override
  String get searchThisWeek => 'Cette semaine';

  @override
  String get searchCustomRange => 'Période personnalisée';

  @override
  String get searchTaskStatus => 'État des tâches';

  @override
  String get searchTaskDue => 'Échéance des tâches';

  @override
  String get searchAnyDueState => 'Toute échéance';

  @override
  String get searchNoDueDate => 'Sans échéance';

  @override
  String get searchPerson => 'Personne';

  @override
  String get searchSources => 'Sources de recherche';

  @override
  String get searchClearFilters => 'Réinitialiser les filtres';

  @override
  String get searchFiltersAction => 'Filtres';

  @override
  String get searchNoSources => 'Aucune source de recherche sélectionnée';

  @override
  String get searchClearText => 'Effacer le texte';

  @override
  String get openSharedCalendar => 'Ouvrir un calendrier partagé';

  @override
  String get manageCalendarSharing => 'Gérer le partage de l’agenda';

  @override
  String get shareRecipientEmail => 'Adresse e-mail du destinataire';

  @override
  String get shareRole => 'Rôle d’accès';

  @override
  String get addCalendarShare => 'Ajouter un accès';

  @override
  String get sharingRefreshFailed =>
      'Le partage a été modifié, mais la liste des autorisations n’a pas pu être actualisée. Rechargez-la avant une autre modification.';

  @override
  String get sharingRateLimited =>
      'Le partage est temporairement limité. Réessayez après le délai d’attente.';

  @override
  String get attachmentUploadRateLimited =>
      'L’envoi de pièces jointes est temporairement limité. Réessayez après le délai d’attente.';

  @override
  String get sharingPermissionUnavailable =>
      'Les autorisations de partage sont indisponibles pour cet agenda.';

  @override
  String get calendarShareFreeBusy => 'Disponibilité uniquement';

  @override
  String get calendarShareLimitedRead => 'Lire les détails limités';

  @override
  String get calendarShareRead => 'Lire tous les détails';

  @override
  String get calendarShareWrite => 'Modifier les événements';

  @override
  String get calendarShareWriteWithoutPrivate => 'Modifier sans détails privés';

  @override
  String get calendarShareOwner => 'Propriétaire';

  @override
  String get eventLabel => 'Étiquette de l’événement';

  @override
  String get loadOutlookCategories => 'Charger les catégories Outlook';

  @override
  String get outlookCategoriesUnavailable =>
      'Les catégories Outlook sont indisponibles; les affectations existantes sont conservées.';

  @override
  String get googleEventType => 'Type d’événement';

  @override
  String get googleRegularEvent => 'Événement ordinaire';

  @override
  String get googleFocusTime => 'Temps de concentration';

  @override
  String get googleOutOfOffice => 'Absent du bureau';

  @override
  String get googleWorkingLocation => 'Lieu de travail';

  @override
  String get googleDeclineInvitations =>
      'Refuser les invitations qui se chevauchent';

  @override
  String get googleDeclineNone => 'Ne pas refuser';

  @override
  String get googleDeclineNew => 'Refuser les nouvelles invitations';

  @override
  String get googleDeclineAll =>
      'Refuser toutes les invitations conflictuelles';

  @override
  String get googleDeclineMessage => 'Message de refus';

  @override
  String get googleChatStatus => 'Statut de discussion';

  @override
  String get googleChatAvailable => 'Disponible';

  @override
  String get googleChatDoNotDisturb => 'Ne pas déranger';

  @override
  String get googleWorkAtHome => 'Domicile';

  @override
  String get googleWorkAtOffice => 'Bureau';

  @override
  String get googleWorkAtCustomLocation => 'Lieu personnalisé';

  @override
  String get googleWorkLocationLabel => 'Nom du lieu';

  @override
  String get googleStatusPrimaryOnly =>
      'Les événements de statut Google nécessitent votre agenda Google principal.';

  @override
  String unknownEventLabel(String id) {
    return 'Étiquette inconnue ($id)';
  }

  @override
  String get calendarOwnerEmail =>
      'Adresse e-mail du propriétaire du calendrier';

  @override
  String registrationSetupTitle(String provider) {
    return 'Configurer $provider';
  }

  @override
  String get registrationSetupGuide => 'Guide de configuration';

  @override
  String get registrationGoogleInstructions =>
      'Créez votre propre projet Google Cloud, activez Calendar et Tasks et importez le JSON d’un client OAuth de bureau. Autorisez le compte souhaité.';

  @override
  String get registrationMicrosoftInstructions =>
      'Utilisez une inscription d’application publique dans un locataire Entra qui autorise les inscriptions. Saisissez l’ID client et les types de comptes. Aucun secret client n’est nécessaire.';

  @override
  String get registrationImportGoogle => 'Choisir le JSON OAuth de bureau';

  @override
  String get registrationValidate => 'Valider l’inscription';

  @override
  String get registrationAuthorize => 'Autoriser dans le navigateur';

  @override
  String get registrationClientId => 'ID d’application/client';

  @override
  String get registrationTenantId => 'ID du locataire';

  @override
  String get registrationAudience => 'Comptes pris en charge';

  @override
  String get registrationBothAudience => 'Comptes personnels et professionnels';

  @override
  String get registrationOrganizationAudience => 'Comptes professionnels';

  @override
  String get registrationPersonalAudience => 'Comptes personnels';

  @override
  String get registrationTenantAudience => 'Un locataire professionnel';

  @override
  String registrationSummary(String clientId) {
    return 'Inscription : $clientId';
  }

  @override
  String get registrationMigrate => 'Migrer maintenant';

  @override
  String get registrationReplace => 'Remplacer l’inscription';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'Ce compte utilise une inscription $provider d’origine réservée aux comptes existants. Pour la remplacer, configurez $setup et reconnectez ce compte. Vos calendriers, tâches et modifications locales seront conservés.';
  }

  @override
  String get registrationContinue => 'Continuer à utiliser ce compte';

  @override
  String get registrationGoogleProject => 'Projet Google Cloud';

  @override
  String get registrationMicrosoftApp => 'Inscription d’application Microsoft';

  @override
  String get registrationUserOwned => 'Inscription fournie par l’utilisateur';

  @override
  String get registrationNativeGoogle =>
      'Inscription native Google pour Android';

  @override
  String get registrationShared => 'Inscription partagée (transition)';

  @override
  String get registrationUnresolved =>
      'L’origine de l’inscription est inconnue. Les données du compte sont conservées.';

  @override
  String get registrationOfficialDocumentation => 'Documentation officielle';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Paquet : $packageName\nEmpreinte de signature : $signatureHash\nURI de redirection : $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Vérifiez le type de client, les comptes pris en charge, les autorisations et la redirection de votre inscription. Sélectionnez à nouveau la configuration importée.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'Cette tentative d’autorisation n’a pas abouti. Recommencez ; votre connexion existante est préservée.';

  @override
  String get oauthPermissionRefused =>
      'L’autorisation a été refusée ou des permissions requises manquent. Réessayez et accordez les permissions nécessaires.';

  @override
  String get oauthProviderThrottled =>
      'Le fournisseur limite les requêtes. Patientez avant de réessayer ; votre connexion existante est préservée.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Un problème temporaire du fournisseur empêche l’autorisation. Réessayez ; votre connexion existante est préservée.';

  @override
  String get oauthAuthorizationTimedOut =>
      'Le délai d’autorisation est dépassé. Réessayez et sélectionnez à nouveau la configuration importée.';

  @override
  String get oauthWrongAccount =>
      'Autorisez le compte sélectionné pour la reconnexion. Votre connexion existante est préservée.';

  @override
  String get oauthSecureStorageUnavailable =>
      'Le stockage sécurisé est indisponible. Rétablissez son accès et réessayez.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'L’autorisation distante a été révoquée, mais le nettoyage du compte n’a pas pu être terminé. Redémarrez BusyMax pour réessayer la récupération locale.';

  @override
  String get addAccount => 'Ajouter un compte';

  @override
  String get registrationConnect => 'Connecter';

  @override
  String get registrationBack => 'Retour';

  @override
  String get registrationReplaceGoogle => 'Remplacer le JSON OAuth de bureau';

  @override
  String get registrationSelectedConfiguration => 'Configuration sélectionnée';

  @override
  String get registrationDirectoryId => 'ID du répertoire/locataire';

  @override
  String get registrationInvalidId => 'Saisissez un UUID valide.';

  @override
  String get registrationExpired =>
      'Cette configuration a expiré. Importez-la à nouveau ou modifiez les champs avant de vous connecter.';

  @override
  String get registrationOwnProjectRequired =>
      'Choisissez une inscription de votre propre projet ou locataire.';

  @override
  String get registrationSetupFailed =>
      'La configuration n’a pas pu être terminée. Réessayez.';

  @override
  String get registrationLinkFailed =>
      'Impossible d’ouvrir le lien. Vérifiez votre navigateur et réessayez.';

  @override
  String get registrationPermissions => 'Autorisations';

  @override
  String get registrationDesktopClient => 'Application de bureau';

  @override
  String get registrationOpenGoogleConsole => 'Ouvrir Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Conditions de publication et utilisateurs de test Google';

  @override
  String get registrationDesktopHelp =>
      'Instructions d’inscription des applications de bureau';

  @override
  String get registrationOpenEntra =>
      'Ouvrir le centre d’administration Microsoft Entra';

  @override
  String get registrationGuideGoogleProject =>
      'Ouvrez Google Cloud Console. Utilisez le sélecteur de projet en haut pour choisir votre propre projet, ou choisissez New project, saisissez un nom et sélectionnez Create. Gardez ce projet sélectionné pour les étapes suivantes.';

  @override
  String get registrationGuideGoogleAudience =>
      'Allez dans Google Auth Platform → Branding. Pour une nouvelle configuration, sélectionnez Get started. Saisissez BusyMax dans App name, choisissez votre propre User support email et sélectionnez Next. Dans Audience, choisissez External. Sélectionnez Next, saisissez votre adresse e-mail dans Contact Information et sélectionnez Next. Acceptez User Data Policy, puis sélectionnez Continue et Create. Si la configuration existe, vérifiez Branding et Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Ouvrez Google Auth Platform → Data Access → Add or remove scopes. Sélectionnez les cinq champs d’accès ci-dessous ; utilisez Manually add scopes si nécessaire. Pour la saisie manuelle, collez les valeurs manquantes et sélectionnez Add to table. Sélectionnez Update, puis Save. BusyMax a besoin de l’accès au calendrier et aux tâches.';

  @override
  String get registrationGuideGoogleClient =>
      'Ouvrez Google Auth Platform → Clients → Create client. Choisissez Desktop app dans Application type, saisissez BusyMax dans Name et sélectionnez Create. Dans la boîte de création, sélectionnez Download JSON et enregistrez le fichier. Sélectionnez Retour pour revenir au formulaire, choisissez ce fichier et vérifiez le projet et l’ID client. Sélectionnez Connecter et autorisez l’accès au calendrier et aux tâches dans le navigateur.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Connectez-vous au centre d’administration Microsoft Entra. Utilisez Settings pour choisir un locataire où vous pouvez inscrire des applications. Ouvrez Entra ID → App registrations → New registration. Saisissez BusyMax dans Name, puis choisissez les types de comptes à l’étape suivante. Si l’inscription est bloquée, demandez l’accès à l’administrateur du locataire.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'Dans votre inscription, ouvrez Authentication → Add a platform → Mobile and desktop applications. Sélectionnez ou saisissez l’URI de redirection ci-dessous, puis sélectionnez Configure pour l’enregistrer. BusyMax utilise votre navigateur système. Aucun secret client n’est nécessaire.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Ouvrez API permissions → Add a permission → Microsoft Graph → Delegated permissions. Recherchez et sélectionnez chaque champ d’accès ci-dessous, puis sélectionnez Add permissions. Conservez User.Read s’il est déjà présent. Si votre organisation exige un consentement administrateur, demandez à un administrateur d’utiliser Grant admin consent pour le locataire.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Sélectionnez Retour pour revenir au formulaire. Collez Application (client) ID et choisissez les mêmes Comptes pris en charge que dans l’inscription. Pour Un locataire organisationnel, collez aussi Directory (tenant) ID. Sélectionnez Connecter et connectez-vous au compte souhaité dans le navigateur. BusyMax vérifie les champs localement ; Microsoft demande votre consentement lors de la connexion dans le navigateur.';

  @override
  String get registrationGoogleImportFailed =>
      'Impossible d’importer ce fichier. Sélectionnez un JSON OAuth de bureau valide. Toute sélection valide précédente est conservée.';

  @override
  String get registrationGoogleSetupInstructions =>
      'Instructions de configuration Google';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Instructions de configuration Microsoft';

  @override
  String get registrationDesktopConfiguration =>
      'Configuration OAuth pour ordinateur';

  @override
  String get registrationNoFileSelected => 'Aucun fichier sélectionné';

  @override
  String get registrationChooseFile => 'Choisir un fichier…';

  @override
  String get registrationReplaceFile => 'Remplacer…';

  @override
  String get registrationGoogleIntroduction =>
      'Choisissez le fichier JSON OAuth pour ordinateur de votre propre projet Google Cloud.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Saisissez les informations de votre propre inscription d’application Microsoft.';

  @override
  String get registrationSetupInstructions => 'Instructions de configuration';

  @override
  String get registrationInstructionsDescription =>
      'Créez la configuration nécessaire pour connecter votre compte.';

  @override
  String get registrationEnableApis => 'Activer Calendar et Tasks';

  @override
  String get registrationConsentScreen => 'Configurer l’écran de consentement';

  @override
  String get registrationAppName => 'Nom de l’application';

  @override
  String get registrationScopes => 'Champs d’accès';

  @override
  String get registrationRedirectUri => 'URI de redirection';

  @override
  String get registrationOpenApiLibrary =>
      'Ouvrir la bibliothèque d’API Google';

  @override
  String get registrationOpenBranding =>
      'Ouvrir Branding dans Google Auth Platform';

  @override
  String get registrationOpenDataAccess =>
      'Ouvrir Data Access dans Google Auth Platform';

  @override
  String get registrationOpenClients =>
      'Ouvrir Clients dans Google Auth Platform';

  @override
  String get registrationOpenEntraAuthentication =>
      'Ouvrir les inscriptions Entra pour Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'Ouvrir les inscriptions Entra pour API permissions';

  @override
  String get registrationCopy => 'Copier';

  @override
  String get registrationCopyAll => 'Tout copier';

  @override
  String get registrationGuideGoogleApis =>
      'Allez dans APIs & Services → Library. Recherchez Google Calendar API, ouvrez sa page et sélectionnez Enable. Revenez à Library et répétez l’opération pour Google Tasks API.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Dans Supported account types, choisissez Personal accounts only pour un compte personnel, Multiple Entra ID tenants pour des comptes professionnels, Any Entra ID Tenant + Personal Microsoft accounts pour les deux, ou Single tenant only pour cet annuaire. Sélectionnez Register. Dans Overview, copiez Application (client) ID ; pour un seul locataire, copiez aussi Directory (tenant) ID. Choisissez l’option correspondante dans Comptes pris en charge de BusyMax.';

  @override
  String get registrationConnectBusyMax => 'Connecter avec BusyMax';

  @override
  String get registrationRecommended => 'Recommandé';

  @override
  String get registrationOtherMethods => 'Autres méthodes de connexion';

  @override
  String get registrationWorkspace => 'Organisation Google Workspace';

  @override
  String get registrationGoogleCustom => 'Client OAuth personnalisé';

  @override
  String get registrationMicrosoftCustom =>
      'Inscription d’application personnalisée';

  @override
  String get registrationMethodsIntroduction =>
      'Choisissez comment connecter votre compte.';

  @override
  String get registrationWorkspaceDescription =>
      'Utilisez une configuration gérée par votre organisation.';

  @override
  String get registrationCustomDescription =>
      'Utilisez une inscription que vous gérez.';

  @override
  String get registrationSharedUnavailable =>
      'La connexion avec BusyMax est indisponible dans cette version. Vous pouvez utiliser une autre méthode ci-dessous.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Choisissez le JSON OAuth de bureau fourni ou géré par votre organisation. Le fichier ne prouve ni la propriété de l’organisation, ni l’audience, ni l’état de validation.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Instructions de configuration de Google Workspace';

  @override
  String get registrationBusyMaxManaged => 'Inscription gérée par BusyMax';

  @override
  String get registrationBranding => 'Configurer la marque et les domaines';

  @override
  String get registrationPublishing => 'Publier pour un usage normal';

  @override
  String get registrationOpenAudience =>
      'Ouvrir Audience dans Google Auth Platform';

  @override
  String get registrationGuideWorkspaceProject =>
      'Demandez le JSON OAuth de bureau à votre administrateur ou ouvrez Google Cloud Console et sélectionnez un projet de votre organisation Google Workspace. Pour en créer un, ouvrez Gérer les ressources → Créer un projet, saisissez le Nom du projet, choisissez votre organisation ou un de ses dossiers dans Ressource parente, puis Créer. Sélectionnez ce projet pour la suite. La création nécessite Project Creator, la configuration OAuth nécessite OAuth Config Editor et l’activation des API nécessite Service Usage Admin ou des autorisations équivalentes. Contactez l’administrateur en cas de blocage.';

  @override
  String get registrationGuideGoogleBranding =>
      'Dans Branding → App domain, ajoutez les domaines autorisés de votre projet avant ses URL de page d’accueil, confidentialité et conditions d’utilisation, puis sélectionnez Save. Les applications External en production nécessitent ces liens. Utilisez vos propres domaines et vérifiez leur propriété dans Search Console si Google exige la validation de marque. Le lien de confidentialité BusyMax ci-dessous ne prouve pas que votre projet possède busystack.org.';

  @override
  String get registrationGuideGooglePublishing =>
      'Dans Audience, sélectionnez Publish app et confirmez In production. Ne laissez pas l’usage normal en Testing : ces autorisations Calendar/Tasks et jetons d’actualisation expirent après sept jours. Publication et validation sont distinctes. Un usage personnel avec moins de 100 utilisateurs peut être exempté de validation, avec avertissements et plafond d’utilisateurs ; une diffusion plus large peut nécessiter la validation de marque et des portées. Les autorisations de production peuvent toujours expirer ou être révoquées.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Examinez ces portées avec votre administrateur. Les applications Internal n’ont pas à les lister sur l’écran de consentement. Si demandé, ouvrez Data Access → Add or remove scopes, ajoutez ces valeurs, puis Update et Save. Les contrôles administratifs peuvent encore limiter l’autorisation.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'Les autorisations de calendriers partagés et de catégories sont demandées séparément lors de l’activation de ces fonctions facultatives ; ne les ajoutez pas à la configuration obligatoire ci-dessus.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Allez dans Google Auth Platform → Branding. Pour une nouvelle configuration, sélectionnez Get started. Saisissez BusyMax dans App name, choisissez votre propre User support email et sélectionnez Next. Dans Audience, choisissez Internal. Sélectionnez Next, saisissez votre adresse e-mail dans Contact Information et sélectionnez Next. Acceptez User Data Policy, puis sélectionnez Continue et Create. Si la configuration existe, vérifiez Branding et Audience.\n\nInternal autorise uniquement les comptes de l’organisation parente du projet, sous réserve des contrôles administratifs. Aucune liste de testeurs n’est nécessaire. BusyMax ne peut pas vérifier ces réglages à partir du JSON.';

  @override
  String get contactsTitle => 'Carnet d’adresses';

  @override
  String get contactsLinkedDescription =>
      'Utiliser les contacts en cache de ce compte lors de l’ajout d’invités aux événements.';

  @override
  String get contactsEnableSuggestions => 'Activer les suggestions de contacts';

  @override
  String get contactsReadPermissionDescription =>
      'Demande un accès en lecture seule aux contacts';

  @override
  String get contactsEnableEditing => 'Activer la modification des contacts';

  @override
  String get contactsWritePermissionDescription =>
      'Demande un accès en lecture et en écriture aux contacts';

  @override
  String get contactsSuggestionsEnabled => 'Suggestions de contacts activées';

  @override
  String get contactsNeedsAttention =>
      'Les contacts nécessitent votre attention';

  @override
  String get contactsReadWriteAccess => 'Accès en lecture et en écriture';

  @override
  String get contactsDisableForAccount =>
      'Désactiver les contacts pour ce compte';

  @override
  String get contactsOnlyDescription =>
      'Ces sources sont indépendantes des comptes de calendrier et de tâches.';

  @override
  String get contactsAddCardDav => 'Ajouter des contacts CardDAV';

  @override
  String get contactsAddNextcloud => 'Ajouter des contacts Nextcloud';

  @override
  String get contactsUseForAttendees =>
      'Utiliser pour les suggestions de participants';

  @override
  String get contactsServerUrlLabel => 'URL du serveur HTTPS';

  @override
  String get contactsUsernameLabel => 'Nom d’utilisateur';

  @override
  String get contactsPasswordLabel => 'Mot de passe';
}
