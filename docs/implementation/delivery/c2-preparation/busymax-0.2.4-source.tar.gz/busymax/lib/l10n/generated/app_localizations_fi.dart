// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Finnish (`fi`).
class AppLocalizationsFi extends AppLocalizations {
  AppLocalizationsFi([String locale = 'fi']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax käynnistettiin työpöydän automaattisen käynnistyksen asetuksista. Poista sen merkintä sieltä, lopeta BusyMax ja avaa se uudelleen, jotta voit käyttää tätä kytkintä.';

  @override
  String get timeFormat => 'Aikamuoto';

  @override
  String get firstDayOfWeek => 'Viikon ensimmäinen päivä';

  @override
  String get systemDefault => 'Järjestelmän oletus';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Järjestelmän oletus ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 tuntia';

  @override
  String get timeFormatTwentyFourHour => '24 tuntia';

  @override
  String get timeEndOfDay => 'vuorokauden loppu';

  @override
  String get timePeriod => 'Vuorokaudenaika';

  @override
  String get launchAtLoginReadFailed =>
      'Kirjautumisen yhteydessä käynnistymisen tilaa ei voitu selvittää.';

  @override
  String get launchAtLoginUnavailable =>
      'Käynnistys kirjautumisen yhteydessä ei ole käytettävissä tässä järjestelmässä.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'Ylläpitäjä on ottanut automaattisen käynnistyksen käyttöön, eikä sitä voi muuttaa täällä.';

  @override
  String get settingsSaveFailed =>
      'Asetuksia ei voitu tallentaa. Muutokset saattavat kadota, kun BusyMax käynnistetään uudelleen.';

  @override
  String get nextcloudExportCollection => 'Vie kokoelman resurssit';

  @override
  String nextcloudImportItems(int count) {
    return 'Löytyi $count tapahtuma-/tehtäväresurssia';
  }

  @override
  String get nextcloudSchedulingInbox => 'Kutsujen saapuneet';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud käsittelee nämä viestit kalentereihisi. Kuittaus poistaa vain viestin, ei tapahtumaa.';

  @override
  String get nextcloudInboxEmpty => 'Ei ajoitusviestejä.';

  @override
  String get nextcloudAcknowledge => 'Kuittaa viesti';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Poistetaanko tämä viesti saapuneista? Kalenteritapahtuma säilytetään.';

  @override
  String get nextcloudGuestAvailability => 'Tarkista vieraiden saatavuus';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Palvelimen roskakorin säilytysaika: $days päivää';
  }

  @override
  String get nextcloudCancelMeeting => 'Peru kokous';

  @override
  String get nextcloudDeclineAndRemove => 'Hylkää ja poista kutsu';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Poisto lähettää hylkäyksen synkronoinnissa. Se ei peru järjestäjän kokousta.';

  @override
  String get nextcloudAvailabilityUnknown => 'Saatavuus tuntematon';

  @override
  String get nextcloudAvailabilityFree =>
      'Tälle aikavälille ei ilmoitettu varattuja aikoja';

  @override
  String get nextcloudAvailabilityBusy => 'Varatut ajat';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud lähettää kokouspäivitykset synkronoinnissa. Paikallinen tallennus ei vahvista toimitusta.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Vain järjestäjä tai valtuutettu edustaja voi muuttaa kokouksen tietoja. Voit vastata kutsuun sen tiedoista.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'Kokousta ei voi siirtää kopioimalla ja poistamalla. Käytä saman ajoitusidentiteetin kalenteria.';

  @override
  String get nextcloudSchedulingStatus => 'Palvelimen ajoitustila';

  @override
  String get nextcloudImportFollowUp =>
      'Tuodut resurssit tallennettiin paikallisesti. Muistutusten päivitys odottaa; älä tuo niitä uudelleen.';

  @override
  String get nextcloudNativeImport =>
      'Tuo täydelliset tapahtumat ja tehtävät lähettämättä kutsuja. Olemassa olevat UID:t ohitetaan, ellet valitse uusia kopioita. Tukemattomat resurssit ilmoitetaan erikseen.';

  @override
  String get nextcloudImportMethod =>
      'Tiedosto sisältää ajoitusviestejä. Tuonti tallentaa sisällön ja poistaa METHOD-kentän; se ei käsittele kutsua tai vastausta.';

  @override
  String get nextcloudImportCopies =>
      'Tuo uusina kopioina uusilla tunnisteilla';

  @override
  String get nextcloudCollectionSettings => 'Kokoelman asetukset';

  @override
  String get nextcloudSharing => 'Jakaminen';

  @override
  String get nextcloudOwned => 'Oma';

  @override
  String get nextcloudShared => 'Jaettu';

  @override
  String get nextcloudDelegated => 'Valtuutettu';

  @override
  String get nextcloudSubscription => 'Tilaus';

  @override
  String get nextcloudDeleted => 'Poistettu';

  @override
  String get nextcloudMetadataEditable =>
      'Kalenterin sisältö on vain luettavissa; kokoelman ominaisuuksia voi muuttaa.';

  @override
  String get nextcloudServerOrder =>
      'Palvelinjärjestys (erillinen sivupalkin järjestyksestä)';

  @override
  String get nextcloudCalendarEnabled => 'Käytössä palvelimella';

  @override
  String get nextcloudAvailability => 'Huomioi kokoelma saatavuudessa';

  @override
  String get nextcloudCalendarTimezone =>
      'Kalenterin aikavyöhyke (VTIMEZONE-asiakirja)';

  @override
  String get nextcloudRefreshPending =>
      'Muutos tallennettiin Nextcloudiin. Päivitys odottaa; älä toista muutosta.';

  @override
  String get nextcloudOutcomeUnknown =>
      'Palvelimen tulosta ei voitu vahvistaa. Päivitä ennen uutta yritystä.';

  @override
  String get nextcloudRemoveShared => 'Poista jaettu kalenteri/luettelo';

  @override
  String get nextcloudRemoveMixed =>
      'Kokoelma sisältää tapahtumia ja tehtäviä. Poistaminen poistaa molemmat.';

  @override
  String get nextcloudReadAccess => 'Vain luku';

  @override
  String get nextcloudWriteAccess => 'Luku ja kirjoitus';

  @override
  String get nextcloudRecipientSearch => 'Etsi henkilöitä tai ryhmiä';

  @override
  String get nextcloudNoRecipients =>
      'Vastaavia henkilöitä tai ryhmiä ei löytynyt.';

  @override
  String get nextcloudRevokeShare => 'Peru käyttöoikeus';

  @override
  String get nextcloudPublish => 'Julkaise linkki';

  @override
  String get nextcloudUnpublish => 'Lopeta julkaiseminen';

  @override
  String get nextcloudPublishWarning =>
      'Julkaistun linkin saaneet saattavat voida lukea kalenteria. Julkaistaanko?';

  @override
  String get nextcloudTrash => 'Poistetut kalenterit ja tehtävät';

  @override
  String get nextcloudTrashEmpty => 'Ei poistettuja kalenterikohteita.';

  @override
  String get nextcloudRestore => 'Palauta';

  @override
  String get nextcloudPermanentDelete => 'Poista pysyvästi';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Poistetaanko kohde pysyvästi? Sitä ei voi palauttaa Nextcloudin kalenteriroskakorista.';

  @override
  String get nextcloudOperationDenied => 'Nextcloud ei sallinut toimintoa.';

  @override
  String get nextcloudUnsupported => 'Palvelin ei tue toimintoa.';

  @override
  String get nextcloudPendingChanges =>
      'Tallenna tai hylkää kokoelman muutokset ennen sulkemista.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloudiin ei saada yhteyttä. Välimuistin kohteet ja odottavat muutokset säilyvät ennallaan.';

  @override
  String get mapsShow => 'Näytä kartalla';

  @override
  String get openLink => 'Avaa linkki';

  @override
  String get externalLocationOpenFailed =>
      'Sijaintia ei voitu avata ulkoisessa sovelluksessa.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'Tapahtumaa ei voitu siirtää. Sen tallennettu aika ei muuttunut.';

  @override
  String get scheduleRescheduleStale =>
      'Tapahtuma muuttui vetämisen aikana. Yritä uudelleen.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'Uusi aika tallennettiin, mutta muistutuksia ei voitu päivittää.';

  @override
  String get moveUp => 'Siirrä ylös';

  @override
  String get moveDown => 'Siirrä alas';

  @override
  String get windowsSupport => 'Tuki';

  @override
  String get windowsThirdPartyLicenses => 'Kolmannen osapuolen lisenssit';

  @override
  String get windowsSearch => 'Haku';

  @override
  String get windowsStartupDisabledByUser =>
      'Käyttäjä on poistanut toiminnon käytöstä Windowsin asetuksissa.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Windows-käytäntö on poistanut toiminnon käytöstä.';

  @override
  String get windowsStartupUnavailable =>
      'Käytettävissä, kun BusyMax on asennettu MSIX-paketista.';

  @override
  String get windowsReminderExitNotice =>
      'Muistutukset lakkaavat, kun BusyMax suljetaan kokonaan. Jätä se toimimaan taustalle saadaksesi muistutukset.';

  @override
  String get windowsProductVersionLabel => 'Tuoteversio';

  @override
  String get windowsPackageVersionLabel => 'Windows-paketin versio';

  @override
  String get windowsUnpackaged => 'Pakkaamaton';

  @override
  String get windowsAgendaLoadMore => 'Lataa lisää esityslistan kohteita';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'maanantaisin',
      'TU': 'tiistaisin',
      'WE': 'keskiviikkoisin',
      'TH': 'torstaisin',
      'FR': 'perjantaisin',
      'SA': 'lauantaisin',
      'SU': 'sunnuntaisin',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'kuukauden $first ja $second päivänä';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $month $firstDay ja $secondDay päivänä';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency $firstMonth ja $secondMonth $day päivänä';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $firstMonth ja $secondMonth $firstDay ja $secondDay päivänä';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency $firstMonth ja $secondMonth $days päivänä';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Yhdistä Google-, Microsoft-, Apple iCloud Calendar- tai Nextcloud-tilit.';

  @override
  String get googlePermissionsConsentNotice =>
      'Valitse Googlen käyttöoikeusnäkymässä sekä Kalenteri- että Tehtävät-käyttöoikeudet.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google Kalenterin ja Google Tasksin käyttöoikeudet vaaditaan. Yritä uudelleen ja valitse molemmat valintaruudut.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured =>
      'Tätä palveluntarjoajaa ei ole määritetty.';

  @override
  String get waitingForGoogleSignIn => 'Odotetaan Google-kirjautumista...';

  @override
  String get waitingForMicrosoftSignIn =>
      'Odotetaan Microsoft-kirjautumista...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsoft-kirjautumista ei ole määritetty. Aseta MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Peruuta';

  @override
  String get close => 'Sulje';

  @override
  String get windowMinimize => 'Pienennä';

  @override
  String get windowMaximize => 'Suurenna';

  @override
  String get windowRestore => 'Palauta';

  @override
  String get exit => 'Lopeta';

  @override
  String get options => 'Valinnat';

  @override
  String get hide => 'Piilota';

  @override
  String get show => 'Näytä';

  @override
  String get export => 'Vie';

  @override
  String get save => 'Tallenna';

  @override
  String get settings => 'Asetukset';

  @override
  String get all => 'Kaikki';

  @override
  String get calendarEvents => 'Tapahtumat';

  @override
  String get calendarTasks => 'Tehtävät';

  @override
  String get calendar => 'Kalenteri';

  @override
  String get calendars => 'Kalenterit';

  @override
  String get newCalendar => 'Uusi kalenteri';

  @override
  String get calendarColor => 'Kalenterin väri';

  @override
  String calendarColorOption(int number) {
    return 'Väri $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'Tämä palveluntarjoaja ei tue kalenterien hallintaa BusyMaxissa.';

  @override
  String get primaryCalendarCannotDelete =>
      'Ensisijaista kalenteria ei voi poistaa.';

  @override
  String calendarCreateFailed(String error) {
    return 'Kalenteria ei voitu luoda: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'Kalenteri luotiin, mutta BusyMax ei voinut päivittää tiliä. Se tulee näkyviin seuraavan synkronoinnin jälkeen.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Kalenteria ei voitu päivittää: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Kalenteria ei voitu poistaa: $error';
  }

  @override
  String get newEvent => 'Uusi tapahtuma';

  @override
  String get refreshCalendar => 'Päivitä kalenteri';

  @override
  String get openInProvider => 'Avaa palvelussa';

  @override
  String get linkedResources => 'Linkitetyt resurssit';

  @override
  String get noLinkedResources => 'Ei linkitettyjä resursseja';

  @override
  String get attachments => 'Liitteet';

  @override
  String get attachmentsNotLoaded => 'Liitteitä ei ladattu';

  @override
  String get hideFromSchedule => 'Piilota aikataulusta';

  @override
  String get showInSchedule => 'Näytä aikataulussa';

  @override
  String get noCalendarsSynced => 'Kalentereita ei ole vielä synkronoitu.';

  @override
  String get allDay => 'Koko päivä';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '+$countString muuta',
      one: '+1 muu',
    );
    return '$_temp0';
  }

  @override
  String get noEventsOrTasks => 'Ei tapahtumia tai tehtäviä';

  @override
  String get scheduleLoading => 'Ladataan aikataulua...';

  @override
  String get scheduleUnavailable => 'Aikataulu ei ole käytettävissä';

  @override
  String get scheduleNoSources =>
      'Ei näkyviä kalentereita tai tehtäväluetteloita';

  @override
  String get scheduleNoSourcesDescription =>
      'Valitse asetuksissa, mitä näytetään, ja päivitä sitten näkymä.';

  @override
  String get scheduleNoSearchResults => 'Ei vastaavia tapahtumia tai tehtäviä';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Kokeile toista hakua tai tyhjennä nykyiset suodattimet.';

  @override
  String get refresh => 'Päivitä';

  @override
  String get trayOpenBusyMax => 'Avaa BusyMax';

  @override
  String get trayShowBusyMax => 'Näytä BusyMax';

  @override
  String get trayNewEvent => 'Uusi tapahtuma…';

  @override
  String get trayNewTask => 'Uusi tehtävä…';

  @override
  String get trayToday => 'Tänään';

  @override
  String get trayAllDay => 'Koko päivä';

  @override
  String get trayNow => 'Nyt';

  @override
  String get trayCalendarEvent => 'Kalenteritapahtuma';

  @override
  String get trayUntitledEvent => 'Nimetön tapahtuma';

  @override
  String get trayNothingElseToday => 'Ei muuta tänään';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count tehtävää erääntyy tänään',
      one: '1 tehtävä erääntyy tänään',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Avaa tämän päivän agenda';

  @override
  String get traySyncNow => 'Synkronoi nyt';

  @override
  String get traySyncing => 'Synkronoidaan…';

  @override
  String get trayNotConnected => 'Ei yhteyttä';

  @override
  String get trayNotYetSynced => 'Ei vielä synkronoitu';

  @override
  String get trayLastSyncedJustNow => 'Synkronoitu juuri nyt';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synkronoitu $count minuuttia sitten',
      one: 'Synkronoitu minuutti sitten',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synkronoitu $count tuntia sitten',
      one: 'Synkronoitu tunti sitten',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Synkronoitu $count päivää sitten',
      one: 'Synkronoitu päivä sitten',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Asetukset';

  @override
  String get trayQuitBusyMax => 'Lopeta BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Lataa lisää myöhässä olevia tehtäviä';

  @override
  String get agendaLoadMoreNoDate => 'Lataa lisää päiväämättömiä tehtäviä';

  @override
  String get viewDay => 'Päivä';

  @override
  String get viewWeek => 'Viikko';

  @override
  String get viewMonth => 'Kuukausi';

  @override
  String get viewYear => 'Vuosi';

  @override
  String get viewAgenda => 'Agendanäkymä';

  @override
  String get scheduleSettings => 'Aikataulu';

  @override
  String get scheduleDisplaySettings => 'Aikataulun näyttö';

  @override
  String get newEventsAndTasks => 'Uudet tapahtumat ja tehtävät';

  @override
  String get defaultCalendar => 'Oletuskalenteri';

  @override
  String get defaultTaskList => 'Oletustehtävälista';

  @override
  String get lastUsed => 'Viimeksi käytetty';

  @override
  String get scheduleDisplayHoursDescription =>
      'Päivä- ja viikkonäkymät näyttävät aluksi tämän aikavälin. Aikaisemmat ja myöhemmät kohteet laajentavat sitä tarvittaessa.';

  @override
  String get scheduleDayStartsAt => 'Päivä alkaa';

  @override
  String get scheduleDayEndsAt => 'Päivä päättyy';

  @override
  String get sourceCalendar => 'Kalenteri';

  @override
  String get sourceTaskList => 'Tehtäväluettelo';

  @override
  String get createChoiceTitle => 'Luo';

  @override
  String get createEventAtTime => 'Tapahtuma';

  @override
  String get createTaskAtDate => 'Tehtävä';

  @override
  String get editEvent => 'Muokkaa tapahtumaa';

  @override
  String get eventTitle => 'Tapahtuman nimi';

  @override
  String get location => 'Sijainti';

  @override
  String get timeSlot => 'Ajankohta';

  @override
  String get startDateTime => 'Alkamispäivä ja -aika';

  @override
  String get endDateTime => 'Päättymispäivä ja -aika';

  @override
  String get doesNotRepeat => 'Ei toistu';

  @override
  String get defaultReminder => 'Oletusmuistutus';

  @override
  String get guests => 'Vieraat';

  @override
  String get noGuests => 'Ei vieraita';

  @override
  String get attendeeRequired => 'Pakollinen';

  @override
  String get attendeeOptional => 'Valinnainen';

  @override
  String get meetingSection => 'Kokous';

  @override
  String get addGoogleMeet => 'Lisää Google Meet';

  @override
  String get addTeamsMeeting => 'Lisää Microsoft Teams -kokous';

  @override
  String get onlineMeetingAdded => 'Verkkokokous lisätty';

  @override
  String get requestResponses => 'Pyydä vastauksia';

  @override
  String get requestResponsesDescription =>
      'Pyydä vieraita vastaamaan kutsuun.';

  @override
  String get hideGuestList => 'Piilota vierasluettelo';

  @override
  String get hideGuestListDescription =>
      'Vieraat eivät näe, keitä muita on kutsuttu.';

  @override
  String get allowNewTimeProposals => 'Salli uudet aikaehdotukset';

  @override
  String get allowNewTimeProposalsDescription =>
      'Vieraat voivat ehdottaa toista kokousaikaa.';

  @override
  String get notifyGuestsTitle => 'Ilmoitetaanko vieraille?';

  @override
  String get notifyGuestsSaveMessage =>
      'Tässä kokouksessa on vieraita. Lähetetäänkö kutsut tai tapahtumapäivitykset tallennettaessa?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Tässä kokouksessa on vieraita. Lähetetäänkö peruutus, kun kokous poistetaan?';

  @override
  String get sendUpdates => 'Lähetä päivitykset';

  @override
  String get sendCancellation => 'Lähetä peruutus';

  @override
  String get doNotSend => 'Älä lähetä';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Tallennetaanko kokous?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft lähettää vieraille kutsut tai tapahtumapäivitykset.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Poistetaanko kokous?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft lähettää vieraille peruutuksen.';

  @override
  String get organizer => 'Järjestäjä';

  @override
  String get yourResponse => 'Vastauksesi';

  @override
  String get guestResponses => 'Vieraiden vastaukset';

  @override
  String get respond => 'Vastaa';

  @override
  String get acceptInvitation => 'Hyväksy';

  @override
  String get tentativeInvitation => 'Alustava';

  @override
  String get declineInvitation => 'Hylkää';

  @override
  String get joinMeeting => 'Liity kokoukseen';

  @override
  String get responseAccepted => 'Hyväksytty';

  @override
  String get responseTentative => 'Alustava';

  @override
  String get responseDeclined => 'Hylätty';

  @override
  String get responseNeedsAction => 'Vastausta odotetaan';

  @override
  String get responseNotResponded => 'Ei vastausta';

  @override
  String get responseOrganizer => 'Järjestäjä';

  @override
  String invitationResponseFailed(String error) {
    return 'Vastauksesi lähetys epäonnistui: $error';
  }

  @override
  String get joinMeetingFailed => 'Kokouslinkkiä ei voitu avata.';

  @override
  String get description => 'Kuvaus';

  @override
  String get availabilityShowAs => 'Saatavuus / Näytä tilana';

  @override
  String get busy => 'Varattu';

  @override
  String get visibility => 'Näkyvyys';

  @override
  String get defaultVisibility => 'Oletusnäkyvyys';

  @override
  String get conference => 'Verkkokokous';

  @override
  String get noConference => 'Ei verkkokokousta';

  @override
  String get providerCalendar => 'Palveluntarjoajan kalenteri';

  @override
  String get formatBoldShortLabel => 'L';

  @override
  String get formatBoldTooltip => 'Lihavointi';

  @override
  String get formatItalicShortLabel => 'K';

  @override
  String get formatItalicTooltip => 'Kursivointi';

  @override
  String get formatUnderlineShortLabel => 'A';

  @override
  String get formatUnderlineTooltip => 'Alleviivaus';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString minuuttia ennen',
      one: '1 minuutti ennen',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'Alkamishetkellä';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString tuntia ennen',
      one: '1 tunti ennen',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString päivää ennen',
      one: '1 päivä ennen',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Vapaa';

  @override
  String get availabilityTentative => 'Alustava';

  @override
  String get availabilityOutOfOffice => 'Poissa toimistolta';

  @override
  String get availabilityWorkingElsewhere => 'Työskentelee muualla';

  @override
  String get visibilityDefault => 'Oletus';

  @override
  String get visibilityPublic => 'Julkinen';

  @override
  String get visibilityPrivate => 'Yksityinen';

  @override
  String get visibilityConfidential => 'Luottamuksellinen';

  @override
  String get sensitivityNormal => 'Normaali';

  @override
  String get sensitivityPersonal => 'Henkilökohtainen';

  @override
  String get tasks => 'Tehtävät';

  @override
  String get allTasks => 'Kaikki tehtävät';

  @override
  String tasksInList(String title) {
    return 'Luettelon $title tehtävät';
  }

  @override
  String get taskLists => 'Tehtäväluettelot';

  @override
  String get navigation => 'Siirtyminen';

  @override
  String get mainMenu => 'Päävalikko';

  @override
  String get keyboardShortcuts => 'Pikanäppäimet';

  @override
  String get shortcutGroupGeneral => 'Yleiset';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Näytä tämä pikanäppäinluettelo';

  @override
  String get shortcutGroupNavigation => 'Siirtyminen';

  @override
  String get shortcutNextPeriod => 'Seuraava ajanjakso';

  @override
  String get shortcutNextPeriodDescription =>
      'Seuraava viikko viikkonäkymässä, seuraava kuukausi kuukausinäkymässä ja niin edelleen';

  @override
  String get shortcutPreviousPeriod => 'Edellinen ajanjakso';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Edellinen viikko viikkonäkymässä, edellinen kuukausi kuukausinäkymässä ja niin edelleen';

  @override
  String get shortcutJumpToToday => 'Siirry tähän päivään';

  @override
  String get shortcutGroupView => 'Näkymä';

  @override
  String get viewSelector => 'Näkymä';

  @override
  String get shortcutDayView => 'Päivänäkymä';

  @override
  String get shortcutWeekView => 'Viikkonäkymä';

  @override
  String get shortcutMonthView => 'Kuukausinäkymä';

  @override
  String get shortcutYearView => 'Vuosinäkymä';

  @override
  String get shortcutAgendaView => 'Agendanäkymä';

  @override
  String get shortcutGroupCreateAndEdit => 'Luominen ja muokkaaminen';

  @override
  String get shortcutSaveItem => 'Tallenna tapahtuma tai tehtävä';

  @override
  String get shortcutDeleteItem => 'Poista tapahtuma tai tehtävä';

  @override
  String get shortcutGroupTaskEditing => 'Tehtävien muokkaaminen';

  @override
  String get shortcutCancelEditing => 'Peruuta muokkaaminen';

  @override
  String get shortcutCancelEditingDescription =>
      'Sulje tehtävän muokkaus tai tehtävän tiedot';

  @override
  String get aboutBusyMax => 'Tietoja BusyMaxista';

  @override
  String get aboutBusyMaxDescription => 'Kalenteri ja tehtävät';

  @override
  String get license => 'Lisenssi';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Verkkosivusto';

  @override
  String get sourceCode => 'Lähdekoodi';

  @override
  String get reportAnIssue => 'Ilmoita ongelmasta';

  @override
  String get sendFeedback => 'Lähetä palautetta';

  @override
  String get feedbackSubmit => 'Lähetä';

  @override
  String get feedbackCategory => 'Luokka';

  @override
  String get feedbackSelectCategory => 'Valitse luokka';

  @override
  String get feedbackCategoryProblem => 'Ongelma tai virhe';

  @override
  String get feedbackCategoryFeature => 'Ominaisuuspyyntö';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'Tietosuojaan tai tietoturvaan liittyvä huoli';

  @override
  String get feedbackCategoryUsability => 'Käytettävyyshuoli';

  @override
  String get feedbackCategoryOther => 'Muu';

  @override
  String get feedbackSubject => 'Aihe';

  @override
  String get feedbackDetailedMessage => 'Yksityiskohtainen viesti';

  @override
  String get feedbackReplyEmail =>
      'Sähköpostiosoite vastausta varten (valinnainen)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Sisällytä tekniset tiedot';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Lisää vain käyttöjärjestelmäsi nimen ja version sekä sovelluksen alueasetuksen. Lokeja, tilitietoja, tiedostonimiä tai muita diagnostiikkatietoja ei lisätä.';

  @override
  String get feedbackCategoryRequired => 'Valitse luokka.';

  @override
  String get feedbackSubjectLengthError =>
      'Aiheen pituuden on oltava 3–120 merkkiä.';

  @override
  String get feedbackMessageLengthError =>
      'Viestin pituuden on oltava 10–5 000 merkkiä.';

  @override
  String get feedbackInvalidEmail => 'Anna kelvollinen sähköpostiosoite.';

  @override
  String get feedbackConnectionError =>
      'BusyStackiin ei saatu yhteyttä. Tarkista yhteys ja yritä uudelleen.';

  @override
  String get feedbackTimeoutError =>
      'Pyyntö aikakatkaistiin. Palautettasi ei ole tyhjennetty. Yritä uudelleen.';

  @override
  String get feedbackRateLimitedError =>
      'Tästä verkosta on lähetetty liian monta palautetta. Odota ja yritä uudelleen.';

  @override
  String get feedbackRejectedError =>
      'Palvelin hylkäsi lähetyksen. Tarkista kentät ja yritä uudelleen.';

  @override
  String get feedbackServerError =>
      'BusyStack ei voi vastaanottaa palautettasi juuri nyt. Palautettasi ei ole tyhjennetty. Yritä uudelleen.';

  @override
  String feedbackSuccess(String id) {
    return 'Palaute lähetetty. Viite: $id';
  }

  @override
  String get toggleSidebar => 'Näytä tai piilota sivupalkki';

  @override
  String get showSidebar => 'Näytä sivupaneeli';

  @override
  String get hideSidebar => 'Piilota sivupaneeli';

  @override
  String get accounts => 'Tilit';

  @override
  String get currentAccount => 'Nykyinen tili';

  @override
  String get switchAccount => 'Vaihda tiliä';

  @override
  String get addGoogleAccount => 'Lisää Google-tili';

  @override
  String get addMicrosoftAccount => 'Lisää Microsoft-tili';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Kirjautunut';

  @override
  String get removeAccount => 'Poista tili…';

  @override
  String get removingAccount => 'Poistetaan tiliä…';

  @override
  String get removeAccountDescription =>
      'Lopeta synkronointi ja poista tämän tilin tiedot tältä laitteelta.';

  @override
  String removeAccountTitle(String account) {
    return 'Poistetaanko $account BusyMaxista?';
  }

  @override
  String get removeAccountConfirmation =>
      'Tämä poistaa laitteelta välimuistiin tallennetut tehtävät, kalenterit, tapahtumat, muistutukset ja odottavat offline-muutokset. Synkronoimattomat muutokset menetetään. Palveluntarjoajan kalenteri-, tapahtuma-, tehtäväluettelo- ja tehtäväkopioita ei poisteta.';

  @override
  String get revokeGoogleAccess =>
      'Peruuta myös BusyMaxin käyttöoikeus tähän Google-tiliin';

  @override
  String get revokeGoogleAccessDescription =>
      'Käyttöoikeus on myönnettävä uudelleen ennen tilin yhdistämistä.';

  @override
  String get removeAccountAction => 'Poista tili';

  @override
  String get removeAccountFailed =>
      'Tilin poistamista ei voitu viimeistellä. Yritä uudelleen.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'Tili poistettiin tältä laitteelta, mutta BusyMax ei voinut peruuttaa Google-käyttöoikeutta. Voit peruuttaa sen Google-tililtäsi.';

  @override
  String get newTaskList => 'Uusi tehtäväluettelo';

  @override
  String taskListCreateFailed(String error) {
    return 'Tehtäväluettelon luominen epäonnistui: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Tehtäväluettelon uudelleennimeäminen epäonnistui: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Tehtäväluettelon poistaminen epäonnistui: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Synkronoi tili tai ratkaise tämän tehtäväluettelon estetyt muutokset Diagnostiikassa ennen luettelon poistamista.';

  @override
  String get signInToViewTaskLists =>
      'Kirjaudu sisään nähdäksesi tehtäväluettelot.';

  @override
  String get noTaskListsSynced =>
      'Tehtäväluetteloita ei ole vielä synkronoitu.';

  @override
  String get listActions => 'Luettelon toiminnot';

  @override
  String get rename => 'Nimeä uudelleen';

  @override
  String get delete => 'Poista';

  @override
  String get renameList => 'Nimeä luettelo uudelleen';

  @override
  String get deleteList => 'Poista luettelo';

  @override
  String get unshare => 'Lopeta jakaminen';

  @override
  String get readOnlyTaskListCannotRename =>
      'Tämä tehtäväluettelo on vain luku -tilassa, eikä sitä voi nimetä uudelleen.';

  @override
  String get taskListCannotDelete =>
      'Tätä tehtäväluetteloa ei voi poistaa nykyisillä käyttöoikeuksillasi.';

  @override
  String get builtInMicrosoftList => 'Sisäänrakennettu';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Microsoft To Do -sovelluksen sisäänrakennettuja luetteloita ei voi nimetä uudelleen tai poistaa.';

  @override
  String deleteListConfirmation(String title) {
    return 'Poistetaanko ”$title” Google Tasksista?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Poistetaanko ”$title” ja kaikki sen tehtävät?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Lopetetaanko kohteen ”$title” jakaminen tämän tilin kanssa?';
  }

  @override
  String get deleteEvent => 'Poista tapahtuma';

  @override
  String get title => 'Nimi';

  @override
  String get create => 'Luo';

  @override
  String get newTask => 'Uusi tehtävä';

  @override
  String get clearCompleted => 'Tyhjennä valmiit';

  @override
  String get refreshList => 'Päivitä luettelo';

  @override
  String get refreshAll => 'Päivitä kaikki';

  @override
  String get listRefreshed => 'Luettelo päivitetty.';

  @override
  String get allTasksRefreshed => 'Kaikki tilit päivitetty.';

  @override
  String exportedFile(String path) {
    return 'Viety kohteeseen $path';
  }

  @override
  String exportFailed(String error) {
    return 'Vienti epäonnistui: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Päivitys epäonnistui: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Valitse tai luo tehtäväluettelo aloittaaksesi.';

  @override
  String get signInToViewTasks => 'Kirjaudu sisään nähdäksesi tehtävät.';

  @override
  String get noTasks => 'Ei tehtäviä.';

  @override
  String get noTasksYet => 'Ei vielä tehtäviä';

  @override
  String get noTasksYetMessage =>
      'Luo tehtävä tai päivitä tilisi aloittaaksesi.';

  @override
  String get noTasksInList => 'Tässä luettelossa ei ole tehtäviä.';

  @override
  String get overdue => 'Myöhässä';

  @override
  String get today => 'Tänään';

  @override
  String get tomorrow => 'Huomenna';

  @override
  String get upcoming => 'Tulossa';

  @override
  String get noDate => 'Ei päivämäärää';

  @override
  String get completed => 'Valmiit';

  @override
  String duePrefix(String date) {
    return 'Eräpäivä $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date klo $time';
  }

  @override
  String get taskDetails => 'Tehtävän tiedot';

  @override
  String get editTask => 'Muokkaa tehtävää';

  @override
  String get noTaskSelected => 'Tehtävää ei ole valittu.';

  @override
  String get noTaskSelectedHelper =>
      'Valitse tehtävä nähdäksesi ja muokataksesi sen tietoja.';

  @override
  String get taskUnavailable => 'Tehtävä ei ole käytettävissä.';

  @override
  String get signInToEditTasks => 'Kirjaudu sisään muokataksesi tehtäviä.';

  @override
  String get refreshTask => 'Päivitä tehtävä';

  @override
  String get primarySection => 'Ensisijaiset tiedot';

  @override
  String get statusSection => 'Tila';

  @override
  String get openStatus => 'Avoin';

  @override
  String get doneStatus => 'Valmis';

  @override
  String get taskStatus => 'Tila';

  @override
  String get taskStatusNone => 'Ei tilaa';

  @override
  String get taskStatusNeedsAction => 'Vaatii toimenpiteitä';

  @override
  String get taskStatusInProcess => 'Käsittelyssä';

  @override
  String get taskStatusCompleted => 'Valmis';

  @override
  String get taskStatusCancelled => 'Peruutettu';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return 'Valmis $percentString %';
  }

  @override
  String get completionDate => 'Valmistumispäivä';

  @override
  String get priority => 'Tärkeys';

  @override
  String get priorityNone => 'Ei tärkeyttä';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Tärkeys $priorityString · korkea';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Tärkeys $priorityString · keskitaso';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Tärkeys $priorityString · matala';
  }

  @override
  String get taskUrl => 'Tehtävän URL';

  @override
  String get invalidTaskUrl => 'Anna absoluuttinen URL-osoite skeemoineen.';

  @override
  String get classification => 'Luokittelu';

  @override
  String get classificationPublic => 'Näytä koko tehtävä jaettaessa';

  @override
  String get classificationConfidential => 'Näytä jaettaessa vain varattu-aika';

  @override
  String get classificationPrivate => 'Piilota tämä tehtävä jaettaessa';

  @override
  String get pinTask => 'Kiinnitä tehtävä';

  @override
  String get notes => 'Muistiinpanot';

  @override
  String get dueDate => 'Eräpäivä';

  @override
  String get clearDueDate => 'Tyhjennä eräpäivä';

  @override
  String get dueTime => 'Erääntymisaika';

  @override
  String get startDate => 'Alkamispäivä';

  @override
  String get startTime => 'Alkamisaika';

  @override
  String get endDate => 'Päättymispäivä';

  @override
  String get endTime => 'Päättymisaika';

  @override
  String get reminderDate => 'Muistutuspäivä';

  @override
  String get reminderTime => 'Muistutusaika';

  @override
  String get reminder => 'Muistutus';

  @override
  String get addReminder => 'Lisää muistutus';

  @override
  String get reminders => 'Muistutukset';

  @override
  String get noReminders => 'Ei muistutuksia';

  @override
  String get editReminder => 'Muokkaa muistutusta';

  @override
  String get beforeTaskStarts => 'Ennen tehtävän alkamista';

  @override
  String get beforeTaskDue => 'Ennen tehtävän määräaikaa';

  @override
  String get afterTaskStarts => 'Tehtävän alkamisen jälkeen';

  @override
  String get afterTaskDue => 'Tehtävän määräajan jälkeen';

  @override
  String get relativeToTaskStart => 'Suhteessa tehtävän aloituspäivään';

  @override
  String get relativeToTaskDue => 'Suhteessa tehtävän määräpäivään';

  @override
  String get reminderTimeOfDay => 'Kellonaika';

  @override
  String get absoluteReminder => 'Tiettynä päivänä ja kellonaikana';

  @override
  String get reminderAmount => 'Määrä';

  @override
  String get reminderUnit => 'Yksikkö';

  @override
  String get reminderUnitSeconds => 'Sekunnit';

  @override
  String get reminderUnitMinutes => 'Minuutit';

  @override
  String get reminderUnitHours => 'Tunnit';

  @override
  String get reminderUnitDays => 'Päivät';

  @override
  String get reminderUnitWeeks => 'Viikot';

  @override
  String get reminderAtTaskStart => 'Tehtävän alkaessa';

  @override
  String get reminderAtTaskDue => 'Tehtävän määräaikana';

  @override
  String get unsupportedReminder =>
      'Tämä muistutustyyppi säilytetään, mutta sen aikaa ei voi muokata.';

  @override
  String get relatedRemindersTitle => 'Säilytetäänkö liittyvät muistutukset?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Tällä päivämäärällä on $countString liittyvää muistutusta. Säilytetäänkö ne nykyisessä päivämäärässä ja kellonajassa?';
  }

  @override
  String get discardRelatedReminders => 'Hylkää muistutukset';

  @override
  String get keepRelatedReminders => 'Säilytä muistutukset';

  @override
  String get addGuest => 'Lisää vieras';

  @override
  String get addGuestEmail => 'Lisää vieraan sähköpostiosoite';

  @override
  String get removeReminder => 'Poista muistutus';

  @override
  String get off => 'Ei käytössä';

  @override
  String get repeat => 'Toisto';

  @override
  String get repeatNone => 'Ei toistoa';

  @override
  String get noneValue => 'Ei mitään';

  @override
  String get repeatDaily => 'Päivittäin';

  @override
  String get repeatWeekly => 'Viikoittain';

  @override
  String get repeatMonthly => 'Kuukausittain';

  @override
  String get repeatYearly => 'Vuosittain';

  @override
  String get repeatEvery => 'Toistoväli';

  @override
  String get repeatOn => 'Toistopäivät';

  @override
  String get repeatEnd => 'Lopeta toisto';

  @override
  String get repeatNever => 'Ei koskaan';

  @override
  String get repeatUntil => 'Päivämääränä';

  @override
  String get repeatAfter => 'Toistokertojen jälkeen';

  @override
  String get repeatCount => 'Toistokerrat';

  @override
  String get repeatDayOfMonth => 'Kuukauden päivät';

  @override
  String get repeatMonths => 'Kuukaudet';

  @override
  String get repeatOrdinal => 'Viikonpäivän järjestys';

  @override
  String get repeatSpecificDays => 'Tietyt päivät';

  @override
  String get repeatFirst => 'Ensimmäinen';

  @override
  String get repeatSecond => 'Toinen';

  @override
  String get repeatThird => 'Kolmas';

  @override
  String get repeatFourth => 'Neljäs';

  @override
  String get repeatFifth => 'Viides';

  @override
  String get repeatSecondToLast => 'Toiseksi viimeinen';

  @override
  String get repeatLast => 'Viimeinen';

  @override
  String get repeatAnyDay => 'Päivä';

  @override
  String get repeatWeekday => 'Arkipäivä';

  @override
  String get repeatWeekendDay => 'Viikonlopun päivä';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'maanantaina',
      'TU': 'tiistaina',
      'WE': 'keskiviikkona',
      'TH': 'torstaina',
      'FR': 'perjantaina',
      'SA': 'lauantaina',
      'SU': 'sunnuntaina',
      'day': 'päivänä',
      'weekday': 'arkipäivänä',
      'weekend': 'viikonlopun päivänä',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Joka $countString. päivä';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Joka $countString. viikko';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Joka $countString. kuukausi';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Joka $countString. vuosi';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'kuukauden $days päivänä';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'ensimmäisenä $days',
      'second': 'toisena $days',
      'third': 'kolmantena $days',
      'fourth': 'neljäntenä $days',
      'fifth': 'viidentenä $days',
      'secondToLast': 'toiseksi viimeisenä $days',
      'last': 'viimeisenä $days',
      'other': 'päivinä $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '$months aikana';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString kertaa',
      one: '$countString kerran',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '$date asti';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'Tämä toistosääntö käyttää asetuksia, joita tämä muokkain ei muuta.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'Tämä lista ei tue tätä toistomallia. Muuta mallia tai valitse toinen lista.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Lisää alkamis- tai määräpäivä käyttääksesi tätä toistomallia tai poista toisto käytöstä.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Tätä toistoa ei voi käyttää palvelussa $provider.';
  }

  @override
  String get importance => 'Tärkeys';

  @override
  String get importanceLow => 'Pieni';

  @override
  String get importanceNormal => 'Normaali';

  @override
  String get importanceHigh => 'Suuri';

  @override
  String get categories => 'Luokat';

  @override
  String get scheduleSection => 'Aikataulu';

  @override
  String get dueGroup => 'Eräpäivä';

  @override
  String get startGroup => 'Alku';

  @override
  String get reminderGroup => 'Muistutus';

  @override
  String get organizationSection => 'Järjestely';

  @override
  String get actionsSection => 'Toiminnot';

  @override
  String get advancedSection => 'Lisäasetukset';

  @override
  String get addCategory => 'Lisää luokka';

  @override
  String get list => 'Luettelo';

  @override
  String get microsoftMoveUnsupported =>
      'Luettelosta toiseen siirtämistä ei tueta Microsoft To Do -tileillä tässä versiossa.';

  @override
  String get createSubtask => 'Luo alitehtävä';

  @override
  String get subtasks => 'Alitehtävät';

  @override
  String get duplicateTask => 'Monista tehtävä';

  @override
  String get taskDuplicated => 'Tehtävä monistettiin.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Tehtävän monistaminen epäonnistui: $error';
  }

  @override
  String get hideSubtasks => 'Piilota alitehtävät';

  @override
  String get hideClosedSubtasks => 'Piilota suljetut alitehtävät';

  @override
  String get moveToTop => 'Siirrä ylimmäksi';

  @override
  String get deleteTask => 'Poista tehtävä';

  @override
  String get newSubtask => 'Uusi alitehtävä';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Poistetaanko \"$title\"?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Tämä poistaa myös alkuperäisen tehtävän Google Docsista tai Chat-tiloista.';

  @override
  String get metadata => 'Metatiedot';

  @override
  String get id => 'Tunnus';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Päivitetty';

  @override
  String get parent => 'Ylätehtävä';

  @override
  String get position => 'Sijainti';

  @override
  String get webLink => 'Verkkolinkki';

  @override
  String get assignment => 'Määritys';

  @override
  String get localState => 'Paikallinen tila';

  @override
  String get pendingSync => 'Odottaa synkronointia';

  @override
  String get synced => 'Synkronoitu';

  @override
  String get account => 'Tili';

  @override
  String get sync => 'Synkronointi';

  @override
  String get forceFullResync => 'Pakota täydellinen uudelleensynkronointi';

  @override
  String get forceFullResyncDescription =>
      'Lataa kaikkien yhdistettyjen tilien tiedot kokonaan uudelleen. Käytä tätä vain synkronointiongelmien vianmääritykseen.';

  @override
  String get runInBackgroundWhenClosed =>
      'Jatka toimintaa, kun ikkuna suljetaan';

  @override
  String get showTrayIcon => 'Näytä ilmoitusalueen kuvake';

  @override
  String get startMinimizedToTray => 'Käynnistä pienennettynä ilmoitusalueelle';

  @override
  String get launchAtLogin => 'Käynnistä kirjautumisen yhteydessä';

  @override
  String get launchAtLoginDescription =>
      'Käynnistä BusyMax taustalla, jotta muistutukset toimivat kirjautumisen jälkeen.';

  @override
  String get launchAtLoginFailed =>
      'Kirjautumisen yhteydessä käynnistämistä ei voitu päivittää.';

  @override
  String get requiresTrayIcon => 'Vaatii ilmoitusalueen kuvakkeen.';

  @override
  String get syncComplete => 'Synkronointi valmis.';

  @override
  String syncFailed(String error) {
    return 'Synkronointi epäonnistui: $error';
  }

  @override
  String get notifySyncFailures => 'Ilmoita synkronointivirheistä';

  @override
  String get notifyConflicts => 'Ilmoita ristiriidoista';

  @override
  String get notifyDueToday => 'Ilmoita tänään erääntyvistä';

  @override
  String get eventReminders => 'Tapahtumamuistutukset';

  @override
  String get onState => 'Käytössä';

  @override
  String get taskReminders => 'Tehtävämuistutukset';

  @override
  String get notificationDetailLevel => 'Ilmoitusten yksityiskohtaisuus';

  @override
  String get notificationDetailPrivate => 'Yksityinen';

  @override
  String get notificationDetailNormal => 'Normaali';

  @override
  String get quietHours => 'Hiljainen aika';

  @override
  String get quietHoursDescription =>
      'Keskeytä ilmoitukset tällä ajanjaksolla.';

  @override
  String get quietHoursStart => 'Hiljaisen ajan alku';

  @override
  String get quietHoursEnd => 'Hiljaisen ajan loppu';

  @override
  String get notifications => 'Ilmoitukset';

  @override
  String get windowsNotificationsUnavailable =>
      'Windows-ilmoitukset eivät ole käytettävissä';

  @override
  String get windowsNotificationsUnpackaged =>
      'Tämä paketoimaton kehitysajo ei voi käyttää Windows-ilmoituksia. Testaa muistutukset asentamalla testivarmenteella allekirjoitettu MSIX.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax ei voinut alustaa Windows-ilmoituksia. Muistutuksia ei näytetä, ennen kuin tämä asennusongelma on ratkaistu.';

  @override
  String get appearance => 'Ulkoasu';

  @override
  String get theme => 'Teema';

  @override
  String get themeSystem => 'Järjestelmä';

  @override
  String get settingsSystem => 'Järjestelmä';

  @override
  String get themeLight => 'Vaalea';

  @override
  String get themeDark => 'Tumma';

  @override
  String get themeFamily => 'Teemaperhe';

  @override
  String get themeFamilyYaru => 'Ubuntun oma (Yaru)';

  @override
  String get localization => 'Lokalisointi';

  @override
  String get currentLocale => 'Nykyinen alueasetus';

  @override
  String get privacy => 'Tietosuoja';

  @override
  String get redactTaskContentInDiagnostics =>
      'Peitä tehtävien sisältö diagnostiikassa';

  @override
  String get developerDiagnostics => 'Kehittäjän diagnostiikka';

  @override
  String get diagnostics => 'Diagnostiikka';

  @override
  String get apiInspectorDisabled => 'Näytä API-tarkastaja';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery-versio: $revision';
  }

  @override
  String get implementedMethods => 'Toteutetut metodit';

  @override
  String get supportsTasksScopes =>
      'Tukee tasks- ja tasks.readonly-käyttöoikeusalueita';

  @override
  String get requiresTasksScope => 'Vaatii tasks-käyttöoikeusalueen';

  @override
  String get blockedPendingOperations => 'Estetyt odottavat toiminnot';

  @override
  String get signInToInspectPendingOperations =>
      'Kirjaudu sisään tarkastellaksesi odottavia toimintoja.';

  @override
  String get noBlockedPendingOperations => 'Ei estettyjä odottavia toimintoja.';

  @override
  String get operationActions => 'Toiminnot';

  @override
  String pendingOpListId(String id) {
    return 'luettelo=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'tehtävä=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'yritykset=$countString';
  }

  @override
  String get retry => 'Yritä uudelleen';

  @override
  String get discard => 'Hylkää';

  @override
  String get discardChangesAction => 'Hylkää';

  @override
  String get discardChanges => 'Hylätäänkö muutokset?';

  @override
  String get discardChangesConfirmation =>
      'Tämä hylkää tehtävän tallentamattomat muutokset.';

  @override
  String get retryCompleted => 'Uudelleenyritys suoritettu.';

  @override
  String get discardPendingOperation => 'Hylätäänkö odottava toiminto?';

  @override
  String get discardPendingOperationConfirmation =>
      'Tämä poistaa estetyn paikallisen toiminnon. Seuraava synkronointi päivittää tiedot Google Tasksista.';

  @override
  String get pendingOperationDiscarded => 'Odottava toiminto hylätty.';

  @override
  String get syncFailureNotificationTitle =>
      'BusyMaxin synkronointi epäonnistui';

  @override
  String syncFailureNotificationBody(String message) {
    return 'Taustasynkronointi epäonnistui. $message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMaxin synkronointiristiriita';

  @override
  String conflictNotificationBody(String summary) {
    return 'Odottava paikallinen muutos estettiin. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Tänään erääntyvät tehtävät';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString tehtävää erääntyy tänään.',
      one: 'Yksi tehtävä erääntyy tänään.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Tapahtumamuistutus';

  @override
  String get taskReminderNotificationTitle => 'Tehtävämuistutus';

  @override
  String get eventReminderNotificationBody => 'Tapahtuma alkaa pian.';

  @override
  String get taskReminderNotificationBody => 'Tehtävän määräaika lähestyy.';

  @override
  String get notificationOpenAction => 'Avaa';

  @override
  String get notificationSnoozeAction => 'Torkuta 10 minuuttia';

  @override
  String get notificationDismissAction => 'Sulje';

  @override
  String get notificationDetailsHidden =>
      'Yksityiskohdat on piilotettu tietosuoja-asetusten vuoksi.';

  @override
  String get previousMonth => 'Edellinen kuukausi';

  @override
  String get nextMonth => 'Seuraava kuukausi';

  @override
  String get openMonthView => 'Avaa kuukausinäkymä';

  @override
  String get previousYear => 'Edellinen vuosi';

  @override
  String get nextYear => 'Seuraava vuosi';

  @override
  String get openYearView => 'Avaa vuosinäkymä';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'Viikko $numberString';
  }

  @override
  String get resizeAllDayPanel => 'Muuta koko päivän paneelin kokoa';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString kohdetta',
      one: '1 kohde',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'Tämä kalenteri on kirjoitussuojattu.';

  @override
  String get selectTimeZone => 'Valitse aikavyöhyke';

  @override
  String get searchLocations => 'Hae sijainteja';

  @override
  String get noLocationsFound => 'Sijainteja ei löytynyt';

  @override
  String get requiredField => 'Tämä kenttä on pakollinen.';

  @override
  String get providerConnectionDescription =>
      'Yhdistä kalenterit ja tehtävät johonkin näistä palveluntarjoajista.';

  @override
  String get appleICloudProvider => 'Apple iCloud -kalenteri';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud-tehtävät';

  @override
  String get addAppleICloudAccount => 'Lisää Apple iCloud -kalenteritili';

  @override
  String get addNextcloudAccount => 'Lisää Nextcloud-tili';

  @override
  String get waitingForAppleICloud => 'Yhdistetään Apple iCloudiin…';

  @override
  String get waitingForNextcloud => 'Odotetaan Nextcloud-valtuutusta…';

  @override
  String get connectAppleICloudTitle => 'Yhdistä Apple iCloud -kalenteri';

  @override
  String get appleAccountEmail => 'Apple-tilin sähköposti';

  @override
  String get appleAppSpecificPassword => 'Sovelluskohtainen salasana';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Luo sovelluskohtainen salasana, kun olet ottanut kaksivaiheisen todennuksen käyttöön Apple-tililläsi.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Apple-tilin salasanan vaihtaminen mitätöi sovelluskohtaiset salasanat.';

  @override
  String get connectNextcloudTitle => 'Yhdistä Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloud-palvelin tai CalDAV-osoite';

  @override
  String get nextcloudServerUrlHelp =>
      'Anna Nextcloud-palvelimesi URL-osoite tai liitä Nextcloudista kopioitu ensisijainen CalDAV-osoite.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax avaa selaimesi. Hyväksy käyttö siellä ja palaa sitten BusyMaxiin.';

  @override
  String get connectAccountAction => 'Yhdistä';

  @override
  String get cancelAccountConnection => 'Peruuta yhteys';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'Tili poistettiin paikallisesti, mutta Nextcloudin sovellussalasanaa ei voitu kumota.';

  @override
  String get davReauthenticationRequired =>
      'Yhdistä tämä tili uudelleen jatkaaksesi synkronointia.';

  @override
  String get davTemporarilyUnavailable =>
      'Tämä tili ei ole tilapäisesti käytettävissä.';

  @override
  String get davPermissionChanged =>
      'Palvelimen käyttöoikeudet muuttuivat. Odottavat muokkaukset on keskeytetty.';

  @override
  String get davUnsupportedServer =>
      'Tätä palvelinta tai palveluntarjoajan profiilia ei tueta.';

  @override
  String get collectionSettings => 'Kalenterit ja tehtäväluettelot';

  @override
  String get calendarContent => 'Kalenteritapahtumat';

  @override
  String get taskContent => 'Tehtävät';

  @override
  String get readOnlySharedCollection => 'Vain luku';

  @override
  String get pendingLocally => 'Paikallisesti odottava';

  @override
  String get conflictBlocked => 'Ristiriidan estämä';

  @override
  String get authenticationBlocked =>
      'Estetty, kunnes yhteys muodostetaan uudelleen';

  @override
  String get operationFailed => 'Toiminto epäonnistui';

  @override
  String get keepServerVersion => 'Säilytä palvelinversio';

  @override
  String get reapplyLocalChange =>
      'Tarkista ja ota paikallinen muutos uudelleen käyttöön';

  @override
  String get duplicateLocalItem => 'Monista uudeksi kohteeksi';

  @override
  String get davConnectionState => 'Yhteyden tila';

  @override
  String get davConnected => 'Yhdistetty';

  @override
  String get davConnecting => 'Yhdistetään…';

  @override
  String get davSignedOut => 'Kirjautunut ulos';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Viimeisin onnistunut synkronointi: $time';
  }

  @override
  String get davNeverSynced => 'Ei vielä synkronoitu';

  @override
  String get refreshCollections => 'Päivitä kalenterit ja tehtäväluettelot';

  @override
  String nextcloudServerHost(String host) {
    return 'Palvelin: $host';
  }

  @override
  String get collectionSupportsEvents => 'Tapahtumakalenteri';

  @override
  String get collectionSupportsTasks => 'Tehtäväluettelo';

  @override
  String get collectionSupportsEventsAndTasks => 'Tapahtumat ja tehtävät';

  @override
  String get writableCollection => 'Muokattava';

  @override
  String get sharedCollection => 'Jaettu';

  @override
  String collectionLastSynced(String time) {
    return 'Viimeksi synkronoitu: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Synkronointiongelma: $code';
  }

  @override
  String get syncConflicts => 'Synkronointiristiriidat';

  @override
  String remoteChangedAt(String time) {
    return 'Palvelin muuttui: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Paikallinen muokkaus: $summary';
  }

  @override
  String get conflictResolutionFailed => 'Ristiriitaa ei voitu ratkaista.';

  @override
  String get recurringEventScope => 'Toistuvan tapahtuman laajuus';

  @override
  String get entireSeries => 'Koko sarja';

  @override
  String get singleOccurrence => 'Tämä tapahtuma';

  @override
  String get thisAndFollowingEvents => 'Tämä ja seuraavat tapahtumat';

  @override
  String get thisAndFutureUnavailable => 'Tämä palveluntarjoaja ei tue tätä.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'Tätä ja seuraavia tapahtumia ei voi siirtää turvallisesti. Valitse tämä tapahtuma tai koko sarja.';

  @override
  String get entireSeriesMoveUnavailable =>
      'Toistumissääntö ei ole saatavilla paikallisesti. Siirrä sen sijaan vain tämä tapahtuma.';

  @override
  String get copyEventAndDeleteOriginal =>
      'Kopioidaanko tapahtuma ja poistetaanko alkuperäinen?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax ei voi siirtää tätä tapahtumaa suoraan kalenterista $source kalenteriin $destination. Kopio luodaan ensin, ja alkuperäinen poistetaan vasta onnistuneen kopioinnin jälkeen. Tapahtuman tunnisteet muuttuvat; osallistujien vastaustilat voivat nollautua ja kutsuja tai peruutuksia voidaan lähettää; kokouslinkit, liitteet, muistutukset, palveluntarjoajakohtaiset kentät ja toistumisen poikkeukset eivät välttämättä siirry.';
  }

  @override
  String get copyAndDelete => 'Kopioi ja poista';

  @override
  String get chooseRecurringEventScope =>
      'Valitse, koskeeko tämä muutos koko sarjaa, vain tätä tapahtumaa vai tätä ja seuraavia tapahtumia.';

  @override
  String get taskDueBeforeStart => 'Määräaika ei saa olla ennen alkamisaikaa.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Aseta kellonaika sekä alkamiselle että määräajalle tai tee tehtävästä koko päivän tehtävä.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Poistetaanko \"$title\"?';
  }

  @override
  String get setCustomCalendarName => 'Aseta mukautettu nimi';

  @override
  String get setAction => 'Aseta';

  @override
  String get removeFromMyCalendars => 'Poista omista kalentereistani';

  @override
  String get removeAction => 'Poista';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Poistetaanko ”$title” BusyMaxista? Omistajan kalenteria tai tapahtumia ei poisteta.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'Lataus saattoi onnistua. Päivitä liitteet ja tarkista tulos ennen uutta latausta.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Poistetaanko ”$title” Google Kalenterin luettelostasi? Jaettua kalenteria tai sen tapahtumia ei poisteta.';
  }

  @override
  String get calendarCannotRemove =>
      'Tätä kalenteria ei voi poistaa tai irrottaa tästä tilistä.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Odota tämän kalenterin odottavien muutosten synkronointia ennen poistamista tai irrottamista.';

  @override
  String get calendarSubscriptions => 'Kalenteritilaukset';

  @override
  String get calendarSubscriptionsDescription =>
      'Lisää vain luku -kalentereita, jotka päivittyvät suojatusta WebCal-URL-osoitteesta.';

  @override
  String get addCalendarSubscription => 'Lisää kalenteritilaus';

  @override
  String get subscriptionName => 'Paikallinen nimi';

  @override
  String get subscriptionUrl => 'Tilauksen URL';

  @override
  String get subscriptionUrlHelp =>
      'Anna HTTPS- tai webcal-URL. BusyMax säilyttää täydellisen URL-osoitteen suojatussa tallennustilassa.';

  @override
  String get subscriptionUrlInvalid =>
      'Anna kelvollinen HTTPS- tai webcal-URL ilman käyttäjätietoja tai fragmenttia.';

  @override
  String get subscriptionColor => 'Paikallinen väri';

  @override
  String get subscriptionColorHelp =>
      'Käytä kuusinumeroista väriä, kuten #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Anna kuusinumeroinen heksadesimaaliväri.';

  @override
  String get subscriptionRefreshMode => 'Päivitystiheys';

  @override
  String get subscriptionAutomatic => 'Automaattinen';

  @override
  String get subscriptionHourly => 'Tunneittain';

  @override
  String get subscriptionSixHours => 'Kuuden tunnin välein';

  @override
  String get subscriptionDaily => 'Päivittäin';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Lähde: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Anna kelvollinen URL esikatsellaksesi sen suojattua alkuperää.';

  @override
  String get subscriptionReadOnly => 'Vain luku -tilaus';

  @override
  String get subscriptionNeverRefreshed => 'Ei vielä päivitetty';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Viimeisin onnistunut päivitys: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Seuraava päivitys: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Ajan tasalla';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Päivitysongelma: $code';
  }

  @override
  String get refreshNow => 'Päivitä nyt';

  @override
  String get unsubscribe => 'Peruuta tilaus';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Perutaanko tilaus kalenterista ”$name”?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'Tämä poistaa paikallisen tilauksen ja sen välimuistissa olevat tapahtumat. Julkaistua kalenteria ei muuteta.';

  @override
  String get addSubscriptionAction => 'Lisää tilaus';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Kalenteritilaus epäonnistui: $error';
  }

  @override
  String get subscriptions => 'Tilaukset';

  @override
  String get calendarImport => 'Kalenterin tuonti';

  @override
  String get calendarImportDescription =>
      'Valitse tiedosto, tarkista sen tapahtumat ja valitse sitten muokattava kalenteri, joka vastaanottaa ne.';

  @override
  String get importIcsFile => 'Tuo .ics-tiedosto';

  @override
  String get importIcsPreview => 'Tuo kalenteritapahtumat';

  @override
  String importEventsFound(int count) {
    return 'Tuotavat tapahtumajoukot: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Virheelliset tapahtumat: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Jätetty tarkoituksella pois: $fields';
  }

  @override
  String get noWritableCalendars =>
      'Muokattavaa kohdekalenteria ei ole saatavilla.';

  @override
  String get importDestinationCalendar => 'Kohdekalenteri';

  @override
  String get importIcsConfirm => 'Tuo tapahtumat';

  @override
  String get importIcsComplete => 'Tuonti valmis';

  @override
  String importQueued(int count) {
    return 'Tuotu tai jonossa: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Ohitetut kaksoiskappaleet: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Tukemattomat toistojoukot: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'Kalenteritiedostoa ei voitu tuoda: $error';
  }

  @override
  String get networkOffline => 'Ei verkkoyhteyttä';

  @override
  String get networkOfflineDescription =>
      'Muutokset synkronoidaan, kun yhteys palautuu.';

  @override
  String get networkOfflineTryAgain =>
      'Verkkoyhteyttä ei ole. Yhdistä internetiin ja yritä uudelleen.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'kuukauden $days päivänä';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day.';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {
      'jan': 'tammikuun',
      'feb': 'helmikuun',
      'mar': 'maaliskuun',
      'apr': 'huhtikuun',
      'may': 'toukokuun',
      'jun': 'kesäkuun',
      'jul': 'heinäkuun',
      'aug': 'elokuun',
      'sep': 'syyskuun',
      'oct': 'lokakuun',
      'nov': 'marraskuun',
      'dec': 'joulukuun',
      'other': '$month',
    });
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency $month $day päivänä';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency $month $days päivänä';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency $months $day päivänä';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency $months $days päivänä';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'ensimmäisenä',
      'second': 'toisena',
      'third': 'kolmantena',
      'fourth': 'neljäntenä',
      'fifth': 'viidentenä',
      'secondToLast': 'toiseksi viimeisenä',
      'last': 'viimeisenä',
      'other': '',
    });
    return '$frequency $month $_temp0 $days';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'ensimmäisenä',
      'second': 'toisena',
      'third': 'kolmantena',
      'fourth': 'neljäntenä',
      'fifth': 'viidentenä',
      'secondToLast': 'toiseksi viimeisenä',
      'last': 'viimeisenä',
      'other': '',
    });
    return '$frequency $months $_temp0 $days';
  }

  @override
  String get searchFilters => 'Hakusuodattimet';

  @override
  String get searchType => 'Tyyppi';

  @override
  String get searchDate => 'Päivämäärä';

  @override
  String get searchAnyDate => 'Kaikki päivämäärät (ladatut tiedot)';

  @override
  String get eventLink => 'Tapahtuman linkki';

  @override
  String get eventLinkOpenFailed => 'Linkkiä ei voitu avata.';

  @override
  String get scheduleRangeIncomplete =>
      'Kaikkia tapahtumia ei voitu tarkistaa. Näytetään ladatut tiedot.';

  @override
  String get searchThisWeek => 'Tämä viikko';

  @override
  String get searchCustomRange => 'Mukautettu aikaväli';

  @override
  String get searchTaskStatus => 'Tehtävän tila';

  @override
  String get searchTaskDue => 'Tehtävän erääntyminen';

  @override
  String get searchAnyDueState => 'Kaikki erääntymistilat';

  @override
  String get searchNoDueDate => 'Ei eräpäivää';

  @override
  String get searchPerson => 'Henkilö';

  @override
  String get searchSources => 'Lähteet';

  @override
  String get searchClearFilters => 'Nollaa suodattimet';

  @override
  String get searchFiltersAction => 'Suodattimet';

  @override
  String get searchNoSources => 'Hakulähteitä ei ole valittu';

  @override
  String get searchClearText => 'Tyhjennä teksti';

  @override
  String get openSharedCalendar => 'Avaa jaettu kalenteri';

  @override
  String get manageCalendarSharing => 'Hallitse kalenterin jakamista';

  @override
  String get shareRecipientEmail => 'Vastaanottajan sähköposti';

  @override
  String get shareRole => 'Käyttöoikeusrooli';

  @override
  String get addCalendarShare => 'Lisää käyttöoikeus';

  @override
  String get sharingRefreshFailed =>
      'Jako muutettiin, mutta oikeusluetteloa ei voitu päivittää. Lataa luettelo uudelleen ennen seuraavaa muutosta.';

  @override
  String get sharingRateLimited =>
      'Jakamista on rajoitettu tilapäisesti. Yritä uudelleen odotusajan päätyttyä.';

  @override
  String get attachmentUploadRateLimited =>
      'Liitteiden lataamista on rajoitettu tilapäisesti. Yritä uudelleen odotusajan päätyttyä.';

  @override
  String get sharingPermissionUnavailable =>
      'Tämän kalenterin jako-oikeudet eivät ole saatavilla.';

  @override
  String get calendarShareFreeBusy => 'Vain vapaa/varattu';

  @override
  String get calendarShareLimitedRead => 'Lue rajatut tiedot';

  @override
  String get calendarShareRead => 'Lue kaikki tiedot';

  @override
  String get calendarShareWrite => 'Muokkaa tapahtumia';

  @override
  String get calendarShareWriteWithoutPrivate =>
      'Muokkaa ilman yksityisiä tietoja';

  @override
  String get calendarShareOwner => 'Omistaja';

  @override
  String get eventLabel => 'Tapahtuman tunniste';

  @override
  String get loadOutlookCategories => 'Lataa Outlook-luokat';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlook-luokat eivät ole saatavilla; aiemmat luokitukset säilyvät.';

  @override
  String get googleEventType => 'Tapahtuman tyyppi';

  @override
  String get googleRegularEvent => 'Tavallinen tapahtuma';

  @override
  String get googleFocusTime => 'Keskittymisaika';

  @override
  String get googleOutOfOffice => 'Poissa toimistolta';

  @override
  String get googleWorkingLocation => 'Työskentelypaikka';

  @override
  String get googleDeclineInvitations => 'Hylkää päällekkäiset kutsut';

  @override
  String get googleDeclineNone => 'Älä hylkää';

  @override
  String get googleDeclineNew => 'Hylkää uudet kutsut';

  @override
  String get googleDeclineAll => 'Hylkää kaikki päällekkäiset kutsut';

  @override
  String get googleDeclineMessage => 'Hylkäysviesti';

  @override
  String get googleChatStatus => 'Keskustelun tila';

  @override
  String get googleChatAvailable => 'Saatavilla';

  @override
  String get googleChatDoNotDisturb => 'Älä häiritse';

  @override
  String get googleWorkAtHome => 'Kotona';

  @override
  String get googleWorkAtOffice => 'Toimistolla';

  @override
  String get googleWorkAtCustomLocation => 'Mukautettu sijainti';

  @override
  String get googleWorkLocationLabel => 'Sijainnin nimi';

  @override
  String get googleStatusPrimaryOnly =>
      'Googlen tilatapahtumat vaativat ensisijaisen Google-kalenterin.';

  @override
  String unknownEventLabel(String id) {
    return 'Tuntematon tunniste ($id)';
  }

  @override
  String get calendarOwnerEmail => 'Kalenterin omistajan sähköpostiosoite';

  @override
  String registrationSetupTitle(String provider) {
    return 'Määritä $provider';
  }

  @override
  String get registrationSetupGuide => 'Määritysohje';

  @override
  String get registrationGoogleInstructions =>
      'Luo oma Google Cloud -projekti, ota Calendar ja Tasks käyttöön ja tuo työpöydän OAuth-asiakkaan JSON-tiedosto. Valtuuta haluamasi tili.';

  @override
  String get registrationMicrosoftInstructions =>
      'Käytä julkisen sovelluksen rekisteröintiä Entra-vuokraajassa, joka sallii rekisteröinnit. Anna asiakastunnus ja tilityypit. Asiakassalaisuutta ei tarvita.';

  @override
  String get registrationImportGoogle => 'Valitse työpöydän OAuth-JSON';

  @override
  String get registrationValidate => 'Tarkista rekisteröinti';

  @override
  String get registrationAuthorize => 'Valtuuta selaimessa';

  @override
  String get registrationClientId => 'Sovellus-/asiakastunnus';

  @override
  String get registrationTenantId => 'Vuokraajan tunnus';

  @override
  String get registrationAudience => 'Tuetut tilit';

  @override
  String get registrationBothAudience =>
      'Henkilökohtaiset ja organisaation tilit';

  @override
  String get registrationOrganizationAudience => 'Organisaation tilit';

  @override
  String get registrationPersonalAudience => 'Henkilökohtaiset tilit';

  @override
  String get registrationTenantAudience => 'Yksi organisaation vuokraaja';

  @override
  String registrationSummary(String clientId) {
    return 'Rekisteröinti: $clientId';
  }

  @override
  String get registrationMigrate => 'Siirry nyt';

  @override
  String get registrationReplace => 'Vaihda rekisteröinti';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'Tämä tili käyttää alkuperäistä $provider-rekisteröintiä, joka on varattu olemassa oleville tileille. Korvaa se määrittämällä $setup ja yhdistämällä tili uudelleen. Kalenterit, tehtävät ja paikalliset muutokset säilyvät.';
  }

  @override
  String get registrationContinue => 'Jatka tämän tilin käyttöä';

  @override
  String get registrationGoogleProject => 'Google Cloud -projekti';

  @override
  String get registrationMicrosoftApp => 'Microsoft-sovellusrekisteröinti';

  @override
  String get registrationUserOwned => 'Käyttäjän antama rekisteröinti';

  @override
  String get registrationNativeGoogle =>
      'Natiivi Google Android -rekisteröinti';

  @override
  String get registrationShared => 'Yhteinen rekisteröinti (siirtymä)';

  @override
  String get registrationUnresolved =>
      'Rekisteröinnin alkuperä on selvittämättä. Tilin tiedot säilytetään.';

  @override
  String get registrationOfficialDocumentation => 'Virallinen dokumentaatio';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Paketti: $packageName\nAllekirjoituksen tiiviste: $signatureHash\nUudelleenohjaus-URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Tarkista rekisteröinnin asiakastyyppi, tuetut tilit, käyttöoikeudet ja uudelleenohjaus. Valitse tuotu määritystiedosto uudelleen.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'Tätä valtuutusta ei voitu viimeistellä. Aloita uudelleen; nykyinen yhteys säilyy.';

  @override
  String get oauthPermissionRefused =>
      'Valtuutus hylättiin tai vaadittuja käyttöoikeuksia puuttuu. Yritä uudelleen ja myönnä tarvittavat oikeudet.';

  @override
  String get oauthProviderThrottled =>
      'Palveluntarjoaja rajoittaa pyyntöjä. Odota ennen uutta yritystä; nykyinen yhteys säilyy.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Palveluntarjoajan tilapäinen ongelma esti valtuutuksen. Yritä uudelleen; nykyinen yhteys säilyy.';

  @override
  String get oauthAuthorizationTimedOut =>
      'Valtuutus aikakatkaistiin. Yritä uudelleen ja valitse tuotu määritystiedosto uudelleen.';

  @override
  String get oauthWrongAccount =>
      'Valtuuta uudelleenyhdistämistä varten valittu tili. Nykyinen yhteys säilyy.';

  @override
  String get oauthSecureStorageUnavailable =>
      'Suojattu tallennustila ei ole käytettävissä. Palauta sen käyttö ja yritä uudelleen.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'Etävaltuutus peruttiin, mutta tilin siivousta ei voitu viimeistellä. Käynnistä BusyMax uudelleen ja yritä paikallista palautusta uudelleen.';

  @override
  String get addAccount => 'Lisää tili';

  @override
  String get registrationConnect => 'Yhdistä';

  @override
  String get registrationBack => 'Takaisin';

  @override
  String get registrationReplaceGoogle => 'Vaihda työpöydän OAuth-JSON';

  @override
  String get registrationSelectedConfiguration => 'Valittu määritys';

  @override
  String get registrationDirectoryId => 'Hakemiston/vuokraajan tunnus';

  @override
  String get registrationInvalidId => 'Anna kelvollinen UUID.';

  @override
  String get registrationExpired =>
      'Tämä määritys on vanhentunut. Tuo se uudelleen tai muokkaa rekisteröintikenttiä ennen yhdistämistä.';

  @override
  String get registrationOwnProjectRequired =>
      'Valitse oman projektisi tai vuokraajasi rekisteröinti.';

  @override
  String get registrationSetupFailed =>
      'Määritystä ei voitu viimeistellä. Yritä uudelleen.';

  @override
  String get registrationLinkFailed =>
      'Linkkiä ei voitu avata. Tarkista selain ja yritä uudelleen.';

  @override
  String get registrationPermissions => 'Käyttöoikeudet';

  @override
  String get registrationDesktopClient => 'Työpöytäsovellus';

  @override
  String get registrationOpenGoogleConsole => 'Avaa Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Googlen julkaisu- ja testikäyttäjävaatimukset';

  @override
  String get registrationDesktopHelp =>
      'Työpöytäsovelluksen rekisteröintiohjeet';

  @override
  String get registrationOpenEntra => 'Avaa Microsoft Entra -hallintakeskus';

  @override
  String get registrationGuideGoogleProject =>
      'Avaa Google Cloud Console. Valitse yläreunan projektivalitsimesta oma projektisi tai valitse New project, anna nimi ja valitse Create. Pidä tämä projekti valittuna seuraavissa vaiheissa.';

  @override
  String get registrationGuideGoogleAudience =>
      'Avaa Google Auth Platform → Branding. Aloita uusi määritys valitsemalla Get started. Anna App name -kenttään BusyMax, valitse oma User support email ja valitse Next. Valitse Audience-kohdassa External. Valitse Next, anna sähköpostiosoitteesi Contact Information -kohdassa ja valitse Next. Hyväksy User Data Policy ja valitse Continue ja Create. Tarkista aiemmassa määrityksessä Branding ja Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Avaa Google Auth Platform → Data Access → Add or remove scopes. Valitse alla olevat viisi käyttöoikeusaluetta; käytä tarvittaessa Manually add scopes -toimintoa. Liitä puuttuvat arvot käsin lisättäessä ja valitse Add to table. Valitse Update ja sitten Save. BusyMax tarvitsee kalenterin ja tehtävien käyttöoikeudet.';

  @override
  String get registrationGuideGoogleClient =>
      'Avaa Google Auth Platform → Clients → Create client. Valitse Application type -arvoksi Desktop app, anna Name-kenttään BusyMax ja valitse Create. Valitse luonti-ikkunassa Download JSON ja tallenna tiedosto. Valitse Takaisin palataksesi lomakkeeseen, valitse tiedosto ja tarkista projekti ja asiakastunnus. Valitse Yhdistä ja hyväksy kalenterin ja tehtävien käyttö selaimessa.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Kirjaudu Microsoft Entra -hallintakeskukseen. Valitse Settings-kohdassa vuokraaja, jossa voit rekisteröidä sovelluksia. Avaa Entra ID → App registrations → New registration. Anna Name-kenttään BusyMax ja valitse seuraavassa vaiheessa tuetut tilityypit. Jos rekisteröinti on estetty, pyydä oikeutta vuokraajan ylläpitäjältä.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'Avaa rekisteröinnissä Authentication → Add a platform → Mobile and desktop applications. Valitse tai anna alla oleva uudelleenohjaus-URI ja tallenna valitsemalla Configure. BusyMax käyttää järjestelmän selainta. Asiakkaan salaisuutta ei tarvita.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Avaa API permissions → Add a permission → Microsoft Graph → Delegated permissions. Etsi ja valitse jokainen alla oleva käyttöoikeusalue ja valitse Add permissions. Säilytä User.Read, jos se on jo lisätty. Jos organisaatiosi vaatii ylläpitäjän suostumuksen, pyydä ylläpitäjää käyttämään vuokraajan Grant admin consent -toimintoa.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Valitse Takaisin palataksesi lomakkeeseen. Liitä Application (client) ID ja valitse rekisteröintiä vastaavat Tuetut tilit. Yhdelle organisaation vuokraajalle liitä myös Directory (tenant) ID. Valitse Yhdistä ja kirjaudu haluamallesi tilille selaimessa. BusyMax tarkistaa kentät paikallisesti; Microsoft pyytää suostumuksesi selaimessa kirjautuessa.';

  @override
  String get registrationGoogleImportFailed =>
      'Tätä tiedostoa ei voitu tuoda. Valitse kelvollinen työpöydän OAuth-JSON. Aiempi kelvollinen valinta säilyy.';

  @override
  String get registrationGoogleSetupInstructions => 'Googlen määritysohjeet';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Microsoftin määritysohjeet';

  @override
  String get registrationDesktopConfiguration => 'Työpöydän OAuth-määritys';

  @override
  String get registrationNoFileSelected => 'Tiedostoa ei ole valittu';

  @override
  String get registrationChooseFile => 'Valitse tiedosto…';

  @override
  String get registrationReplaceFile => 'Korvaa…';

  @override
  String get registrationGoogleIntroduction =>
      'Valitse oman Google Cloud -projektisi työpöydän OAuth-JSON-tiedosto.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Anna oman Microsoft-sovellusrekisteröintisi tiedot.';

  @override
  String get registrationSetupInstructions => 'Määritysohjeet';

  @override
  String get registrationInstructionsDescription =>
      'Luo tilin yhdistämiseen tarvittava määritys.';

  @override
  String get registrationEnableApis => 'Ota Calendar ja Tasks käyttöön';

  @override
  String get registrationConsentScreen => 'Määritä suostumusnäyttö';

  @override
  String get registrationAppName => 'Sovelluksen nimi';

  @override
  String get registrationScopes => 'Käyttöoikeusalueet';

  @override
  String get registrationRedirectUri => 'Uudelleenohjaus-URI';

  @override
  String get registrationOpenApiLibrary => 'Avaa Googlen API-kirjasto';

  @override
  String get registrationOpenBranding => 'Avaa Google Auth Platformin Branding';

  @override
  String get registrationOpenDataAccess =>
      'Avaa Google Auth Platformin Data Access';

  @override
  String get registrationOpenClients => 'Avaa Google Auth Platformin Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      'Avaa Entran sovellusrekisteröinnit Authentication-määritystä varten';

  @override
  String get registrationOpenEntraPermissions =>
      'Avaa Entran sovellusrekisteröinnit API permissions -määritystä varten';

  @override
  String get registrationCopy => 'Kopioi';

  @override
  String get registrationCopyAll => 'Kopioi kaikki';

  @override
  String get registrationGuideGoogleApis =>
      'Avaa APIs & Services → Library. Etsi Google Calendar API, avaa sen sivu ja valitse Enable. Palaa Library-sivulle ja toista Google Tasks API:lle.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Valitse Supported account types -kohdassa Personal accounts only henkilökohtaiselle tilille, Multiple Entra ID tenants organisaatioiden tileille, Any Entra ID Tenant + Personal Microsoft accounts molemmille tai Single tenant only tälle hakemistolle. Valitse Register. Kopioi Overview-kohdasta Application (client) ID; yhdelle vuokraajalle myös Directory (tenant) ID. Valitse vastaava Tuetut tilit -vaihtoehto BusyMaxissa.';

  @override
  String get registrationConnectBusyMax => 'Yhdistä BusyMaxilla';

  @override
  String get registrationRecommended => 'Suositeltu';

  @override
  String get registrationOtherMethods => 'Muut yhdistämistavat';

  @override
  String get registrationWorkspace => 'Google Workspace -organisaatio';

  @override
  String get registrationGoogleCustom => 'Oma OAuth-asiakas';

  @override
  String get registrationMicrosoftCustom => 'Oma sovellusrekisteröinti';

  @override
  String get registrationMethodsIntroduction =>
      'Valitse, miten yhdistät tilisi.';

  @override
  String get registrationWorkspaceDescription =>
      'Käytä organisaatiosi hallitsemaa määritystä.';

  @override
  String get registrationCustomDescription =>
      'Käytä itse hallitsemaasi rekisteröintiä.';

  @override
  String get registrationSharedUnavailable =>
      'BusyMax-yhteys ei ole käytettävissä tässä koontiversiossa. Voit käyttää alla toista yhdistämistapaa.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Valitse organisaatiosi toimittama tai hallitsema työpöydän OAuth-JSON. Tiedosto ei todista organisaation omistajuutta, kohderyhmää tai vahvistustilaa.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Google Workspacen asennusohjeet';

  @override
  String get registrationBusyMaxManaged => 'BusyMaxin hallitsema rekisteröinti';

  @override
  String get registrationBranding => 'Määritä brändi ja verkkotunnukset';

  @override
  String get registrationPublishing => 'Julkaise normaalia käyttöä varten';

  @override
  String get registrationOpenAudience => 'Avaa Google Auth Platformin Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      'Pyydä ylläpitäjältä Desktop OAuth JSON tai avaa Google Cloud Console ja valitse Google Workspace -organisaatiosi omistama projekti. Luo projekti kohdassa Resurssien hallinta → Luo projekti: anna Projektin nimi, valitse organisaatiosi tai sen kansio Yläresurssi-kohdassa ja valitse Luo. Valitse tämä projekti seuraavia vaiheita varten. Luominen edellyttää Project Creator -oikeutta, OAuth-määritys OAuth Config Editor -oikeutta ja APIen käyttöönotto Service Usage Admin -oikeutta tai vastaavia oikeuksia. Pyydä ylläpitäjältä apua, jos toiminto on estetty.';

  @override
  String get registrationGuideGoogleBranding =>
      'Lisää kohdassa Branding → App domain projektin valtuutetut verkkotunnukset ennen etusivun, tietosuojan ja käyttöehtojen URL-osoitteita ja valitse Save. External-tuotantosovellukset tarvitsevat nämä linkit. Käytä omia verkkotunnuksia ja vahvista omistajuus Search Consolessa, jos Google vaatii brändin vahvistamista. BusyMaxin tietosuojalinkki ei todista projektisi omistavan busystack.org-verkkotunnusta.';

  @override
  String get registrationGuideGooglePublishing =>
      'Valitse Audience-kohdassa Publish app ja vahvista In production. Älä jätä normaalia käyttöä Testing-tilaan: nämä Calendar/Tasks-valtuutukset ja päivitystunnukset vanhenevat seitsemässä päivässä. Julkaiseminen ja vahvistaminen ovat eri asioita. Alle 100 käyttäjän henkilökohtainen käyttö voi olla vapautettu vahvistuksesta varoituksin ja käyttäjärajoin; laajempi jakelu voi edellyttää brändin ja käyttöoikeuksien hyväksyntää. Tuotantovaltuutukset voivat silti vanhentua tai tulla perutuiksi.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Tarkista nämä käyttöoikeudet ylläpitäjän kanssa. Internal-sovellusten ei tarvitse luetella niitä suostumusnäytössä. Jos luetteloa pyydetään, avaa Data Access → Add or remove scopes, lisää arvot ja valitse Update ja Save. Ylläpitäjän rajoitukset voivat estää valtuutuksen.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'Jaettujen kalenterien ja luokkien käyttöoikeuksia pyydetään erikseen valinnaisten toimintojen käyttöönotossa; älä lisää niitä yllä olevaan pakolliseen määritykseen.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Avaa Google Auth Platform → Branding. Aloita uusi määritys valitsemalla Get started. Anna App name -kenttään BusyMax, valitse oma User support email ja valitse Next. Valitse Audience-kohdassa Internal. Valitse Next, anna sähköpostiosoitteesi Contact Information -kohdassa ja valitse Next. Hyväksy User Data Policy ja valitse Continue ja Create. Tarkista aiemmassa määrityksessä Branding ja Audience.\n\nInternal sallii vain projektin emo-organisaation tilit ylläpitäjän rajoitusten mukaisesti. Testikäyttäjäluetteloa ei tarvita. BusyMax ei voi vahvistaa näitä konsoliasetuksia JSON-tiedostosta.';

  @override
  String get contactsTitle => 'Yhteystiedot';

  @override
  String get contactsLinkedDescription =>
      'Käytä tämän tilin välimuistissa olevia yhteystietoja tapahtuman vieraita lisättäessä.';

  @override
  String get contactsEnableSuggestions => 'Ota yhteystietoehdotukset käyttöön';

  @override
  String get contactsReadPermissionDescription =>
      'Pyytää yhteystietoihin vain luku -oikeuden';

  @override
  String get contactsEnableEditing => 'Ota yhteystietojen muokkaus käyttöön';

  @override
  String get contactsWritePermissionDescription =>
      'Pyytää yhteystietoihin luku- ja kirjoitusoikeuden';

  @override
  String get contactsSuggestionsEnabled => 'Yhteystietoehdotukset käytössä';

  @override
  String get contactsNeedsAttention => 'Yhteystiedot vaativat huomiota';

  @override
  String get contactsReadWriteAccess => 'Luku- ja kirjoitusoikeus';

  @override
  String get contactsDisableForAccount =>
      'Poista tämän tilin yhteystiedot käytöstä';

  @override
  String get contactsOnlyDescription =>
      'Nämä lähteet ovat erillisiä kalenteri- ja tehtävätileistä.';

  @override
  String get contactsAddCardDav => 'Lisää CardDAV-yhteystiedot';

  @override
  String get contactsAddNextcloud => 'Lisää Nextcloud-yhteystiedot';

  @override
  String get contactsUseForAttendees => 'Käytä osallistujaehdotuksiin';

  @override
  String get contactsServerUrlLabel => 'HTTPS-palvelimen URL';

  @override
  String get contactsUsernameLabel => 'Käyttäjänimi';

  @override
  String get contactsPasswordLabel => 'Salasana';
}
