// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Japanese (`ja`).
class AppLocalizationsJa extends AppLocalizations {
  AppLocalizationsJa([String locale = 'ja']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax はデスクトップの自動起動設定によって起動されました。このスイッチを使うには、そこで BusyMax の項目を削除してから、BusyMax を終了して開き直してください。';

  @override
  String get timeFormat => '時刻の表示形式';

  @override
  String get firstDayOfWeek => '週の最初の曜日';

  @override
  String get systemDefault => 'システムの既定値';

  @override
  String systemDefaultResolved(String weekday) {
    return 'システムの既定値（$weekday）';
  }

  @override
  String get timeFormatTwelveHour => '12時間表示';

  @override
  String get timeFormatTwentyFourHour => '24時間表示';

  @override
  String get timeEndOfDay => '一日の終わり';

  @override
  String get timePeriod => '午前・午後';

  @override
  String get launchAtLoginReadFailed => 'ログイン時の起動状態を確認できませんでした。';

  @override
  String get launchAtLoginUnavailable => 'このシステムではログイン時の起動を利用できません。';

  @override
  String get windowsStartupEnabledByPolicy =>
      '管理者によって自動起動が有効になっているため、ここでは変更できません。';

  @override
  String get settingsSaveFailed =>
      '設定を保存できませんでした。BusyMax を再起動すると変更が失われる可能性があります。';

  @override
  String get nextcloudExportCollection => 'コレクションのリソースをエクスポート';

  @override
  String nextcloudImportItems(int count) {
    return '予定／タスクのリソースが $count 件見つかりました';
  }

  @override
  String get nextcloudSchedulingInbox => '招待の受信トレイ';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud はこれらのメッセージをカレンダーに反映します。確認するとメッセージだけが削除され、予定は残ります。';

  @override
  String get nextcloudInboxEmpty => '日程調整メッセージはありません。';

  @override
  String get nextcloudAcknowledge => 'メッセージを確認';

  @override
  String get nextcloudAcknowledgeConfirm => 'このメッセージを受信トレイから削除しますか？予定は保持されます。';

  @override
  String get nextcloudGuestAvailability => '参加者の空き時間を確認';

  @override
  String nextcloudTrashRetention(int days) {
    return 'サーバーのごみ箱の保存期間：$days 日';
  }

  @override
  String get nextcloudCancelMeeting => '会議をキャンセル';

  @override
  String get nextcloudDeclineAndRemove => '招待を辞退して削除';

  @override
  String get nextcloudDeclineRemovalWarning =>
      '同期時に辞退の返信を送信します。主催者の会議はキャンセルされません。';

  @override
  String get nextcloudAvailabilityUnknown => '空き状況は不明';

  @override
  String get nextcloudAvailabilityFree => 'この時間帯の予定ありの期間は報告されていません';

  @override
  String get nextcloudAvailabilityBusy => '予定ありの時間帯';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud は同期時に会議の更新を送信します。ローカル保存は配信の確認ではありません。';

  @override
  String get nextcloudAttendeeRestrictions =>
      '会議の詳細を変更できるのは主催者または権限のある代理人だけです。招待の詳細から返信できます。';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'コピーして削除する方法ではこの会議を移動できません。同じ日程調整の主体に属するカレンダーを使用してください。';

  @override
  String get nextcloudSchedulingStatus => 'サーバーの日程調整状態';

  @override
  String get nextcloudImportFollowUp =>
      'インポートしたリソースはローカルに保存されました。リマインダーの更新待ちです。再インポートしないでください。';

  @override
  String get nextcloudNativeImport =>
      '招待を送信せずに予定とタスクを完全なリソースとしてインポートします。新しいコピーを選ばない限り既存の UID はスキップされます。非対応のリソースは個別に報告されます。';

  @override
  String get nextcloudImportMethod =>
      'このファイルには日程調整メッセージが含まれます。インポートは内容を保存して METHOD を削除しますが、招待や返信を処理しません。';

  @override
  String get nextcloudImportCopies => '新しい識別子を持つ新規コピーとしてインポート';

  @override
  String get nextcloudCollectionSettings => 'コレクション設定';

  @override
  String get nextcloudSharing => '共有設定';

  @override
  String get nextcloudOwned => '所有';

  @override
  String get nextcloudShared => '共有済み';

  @override
  String get nextcloudDelegated => '委任';

  @override
  String get nextcloudSubscription => '購読';

  @override
  String get nextcloudDeleted => '削除済み';

  @override
  String get nextcloudMetadataEditable =>
      'カレンダーの内容は読み取り専用ですが、コレクションのプロパティは変更できます。';

  @override
  String get nextcloudServerOrder => 'サーバー上の順序（サイドバーの順序とは別）';

  @override
  String get nextcloudCalendarEnabled => 'サーバーで有効';

  @override
  String get nextcloudAvailability => 'このコレクションを空き状況に含める';

  @override
  String get nextcloudCalendarTimezone => 'カレンダーのタイムゾーン（VTIMEZONE 文書）';

  @override
  String get nextcloudRefreshPending =>
      '変更は Nextcloud に保存されました。再読み込み待ちです。同じ変更を繰り返さないでください。';

  @override
  String get nextcloudOutcomeUnknown =>
      'サーバーの結果を確認できませんでした。再読み込みしてから再試行してください。';

  @override
  String get nextcloudRemoveShared => '共有カレンダー／リストを削除';

  @override
  String get nextcloudRemoveMixed => 'このコレクションには予定とタスクが含まれます。削除すると両方が削除されます。';

  @override
  String get nextcloudReadAccess => '読み取り専用';

  @override
  String get nextcloudWriteAccess => '読み取りと書き込み';

  @override
  String get nextcloudRecipientSearch => 'ユーザーまたはグループを検索';

  @override
  String get nextcloudNoRecipients => '一致するユーザーやグループはありません。';

  @override
  String get nextcloudRevokeShare => 'アクセスを取り消す';

  @override
  String get nextcloudPublish => 'リンクを公開';

  @override
  String get nextcloudUnpublish => '公開を停止';

  @override
  String get nextcloudPublishWarning =>
      '公開リンクを知る人がこのカレンダーを閲覧できる可能性があります。公開しますか？';

  @override
  String get nextcloudTrash => '削除したカレンダーとタスク';

  @override
  String get nextcloudTrashEmpty => '削除したカレンダー項目はありません。';

  @override
  String get nextcloudRestore => '復元';

  @override
  String get nextcloudPermanentDelete => '完全に削除';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'この項目を完全に削除しますか？Nextcloud のカレンダーのごみ箱からは復元できなくなります。';

  @override
  String get nextcloudOperationDenied => 'Nextcloud はこの操作を許可しませんでした。';

  @override
  String get nextcloudUnsupported => 'サーバーはこの操作に対応していません。';

  @override
  String get nextcloudPendingChanges => '閉じる前にコレクションの変更を保存または破棄してください。';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud に接続できません。キャッシュと保留中の変更はそのまま保持されます。';

  @override
  String get mapsShow => '地図で表示';

  @override
  String get openLink => 'リンクを開く';

  @override
  String get externalLocationOpenFailed => '外部アプリで場所を開けませんでした。';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed => '予定の日時を変更できませんでした。保存済みの日時は変更されていません。';

  @override
  String get scheduleRescheduleStale => 'ドラッグ中にこの予定が変更されました。もう一度お試しください。';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      '新しい日時は保存されましたが、リマインダーを更新できませんでした。';

  @override
  String get moveUp => '上に移動';

  @override
  String get moveDown => '下に移動';

  @override
  String get windowsSupport => 'サポート';

  @override
  String get windowsThirdPartyLicenses => 'サードパーティ ライセンス';

  @override
  String get windowsSearch => '検索';

  @override
  String get windowsStartupDisabledByUser => 'Windows の設定でユーザーにより無効にされています。';

  @override
  String get windowsStartupDisabledByPolicy => 'Windows ポリシーにより無効にされています。';

  @override
  String get windowsStartupUnavailable =>
      'BusyMax を MSIX パッケージからインストールすると利用できます。';

  @override
  String get windowsReminderExitNotice =>
      'BusyMax を完全に終了するとリマインダーも停止します。受け取るにはバックグラウンドで実行したままにしてください。';

  @override
  String get windowsProductVersionLabel => '製品バージョン';

  @override
  String get windowsPackageVersionLabel => 'Windows パッケージ バージョン';

  @override
  String get windowsUnpackaged => 'パッケージ化されていません';

  @override
  String get windowsAgendaLoadMore => '予定をさらに読み込む';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '月曜日',
      'TU': '火曜日',
      'WE': '水曜日',
      'TH': '木曜日',
      'FR': '金曜日',
      'SA': '土曜日',
      'SU': '日曜日',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$monthの$firstDayと$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency$firstMonthと$secondMonthの$day';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$firstMonthと$secondMonthの$firstDayと$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency$firstMonthと$secondMonthの$days';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Google、Microsoft、Apple iCloud Calendar、または Nextcloud のアカウントを接続します。';

  @override
  String get googlePermissionsConsentNotice =>
      'Google の権限画面で、カレンダーとタスクの両方の権限を選択してください。';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google カレンダーと Google Tasks の権限が必要です。もう一度試して、両方のチェックボックスを選択してください。';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'このプロバイダーは設定されていません。';

  @override
  String get waitingForGoogleSignIn => 'Google のサインインを待機しています...';

  @override
  String get waitingForMicrosoftSignIn => 'Microsoft のサインインを待機しています...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsoft のサインインが設定されていません。MICROSOFT_OAUTH_CLIENT_ID を設定してください。';

  @override
  String get cancel => 'キャンセル';

  @override
  String get close => '閉じる';

  @override
  String get windowMinimize => '最小化';

  @override
  String get windowMaximize => '最大化';

  @override
  String get windowRestore => '元に戻す';

  @override
  String get exit => '終了';

  @override
  String get options => 'オプション';

  @override
  String get hide => '非表示';

  @override
  String get show => '表示';

  @override
  String get export => 'エクスポート';

  @override
  String get save => '保存';

  @override
  String get settings => '設定';

  @override
  String get all => 'すべて';

  @override
  String get calendarEvents => '予定';

  @override
  String get calendarTasks => 'タスク';

  @override
  String get calendar => 'カレンダー';

  @override
  String get calendars => 'カレンダー';

  @override
  String get newCalendar => '新しいカレンダー';

  @override
  String get calendarColor => 'カレンダーの色';

  @override
  String calendarColorOption(int number) {
    return '色 $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'このプロバイダーのカレンダー管理は BusyMax ではサポートされていません。';

  @override
  String get primaryCalendarCannotDelete => 'メインカレンダーは削除できません。';

  @override
  String calendarCreateFailed(String error) {
    return 'カレンダーを作成できませんでした: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'カレンダーは作成されましたが、BusyMax はアカウントを更新できませんでした。次回の同期後に表示されます。';

  @override
  String calendarUpdateFailed(String error) {
    return 'カレンダーを更新できませんでした: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'カレンダーを削除できませんでした: $error';
  }

  @override
  String get newEvent => '新しい予定';

  @override
  String get refreshCalendar => 'カレンダーを更新';

  @override
  String get openInProvider => 'サービスで開く';

  @override
  String get linkedResources => 'リンクされたリソース';

  @override
  String get noLinkedResources => 'リンクされたリソースはありません';

  @override
  String get attachments => '添付ファイル';

  @override
  String get attachmentsNotLoaded => '添付ファイルは読み込まれていません';

  @override
  String get hideFromSchedule => 'スケジュールから非表示';

  @override
  String get showInSchedule => 'スケジュールに表示';

  @override
  String get noCalendarsSynced => '同期済みのカレンダーはまだありません。';

  @override
  String get allDay => '終日';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '他 $countString 件';
  }

  @override
  String get noEventsOrTasks => '予定またはタスクはありません';

  @override
  String get scheduleLoading => 'スケジュールを読み込んでいます...';

  @override
  String get scheduleUnavailable => 'スケジュールを利用できません';

  @override
  String get scheduleNoSources => '表示できるカレンダーまたはタスクリストがありません';

  @override
  String get scheduleNoSourcesDescription => '設定で表示する項目を選択してから、更新してください。';

  @override
  String get scheduleNoSearchResults => '一致する予定またはタスクはありません';

  @override
  String get scheduleNoSearchResultsDescription =>
      '別の条件で検索するか、現在のフィルターを解除してください。';

  @override
  String get refresh => '更新';

  @override
  String get trayOpenBusyMax => 'BusyMax を開く';

  @override
  String get trayShowBusyMax => 'BusyMax を表示';

  @override
  String get trayNewEvent => '新しい予定…';

  @override
  String get trayNewTask => '新しいタスク…';

  @override
  String get trayToday => '今日';

  @override
  String get trayAllDay => '終日';

  @override
  String get trayNow => '今';

  @override
  String get trayCalendarEvent => 'カレンダーの予定';

  @override
  String get trayUntitledEvent => '無題の予定';

  @override
  String get trayNothingElseToday => '今日はこれ以上ありません';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今日が期限のタスクは $count 件',
      one: '今日が期限のタスクは 1 件',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => '今日の予定表を開く';

  @override
  String get traySyncNow => '今すぐ同期';

  @override
  String get traySyncing => '同期中…';

  @override
  String get trayNotConnected => '未接続';

  @override
  String get trayNotYetSynced => 'まだ同期されていません';

  @override
  String get trayLastSyncedJustNow => 'たった今同期';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 分前に同期',
      one: '1 分前に同期',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 時間前に同期',
      one: '1 時間前に同期',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 日前に同期',
      one: '1 日前に同期',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => '設定';

  @override
  String get trayQuitBusyMax => 'BusyMax を終了';

  @override
  String get agendaLoadMoreOverdue => '期限切れのタスクをさらに読み込む';

  @override
  String get agendaLoadMoreNoDate => '日付のないタスクをさらに読み込む';

  @override
  String get viewDay => '日';

  @override
  String get viewWeek => '週';

  @override
  String get viewMonth => '月';

  @override
  String get viewYear => '年';

  @override
  String get viewAgenda => '予定一覧';

  @override
  String get scheduleSettings => 'スケジュール';

  @override
  String get scheduleDisplaySettings => 'スケジュール表示';

  @override
  String get newEventsAndTasks => '新しい予定とタスク';

  @override
  String get defaultCalendar => '既定のカレンダー';

  @override
  String get defaultTaskList => '既定のタスクリスト';

  @override
  String get lastUsed => '前回使用';

  @override
  String get scheduleDisplayHoursDescription =>
      '日表示と週表示では、最初にこの時間範囲が表示されます。必要に応じて、この範囲より前または後の項目も表示されるように範囲が広がります。';

  @override
  String get scheduleDayStartsAt => '一日の開始時刻';

  @override
  String get scheduleDayEndsAt => '一日の終了時刻';

  @override
  String get sourceCalendar => 'カレンダー';

  @override
  String get sourceTaskList => 'タスクリスト';

  @override
  String get createChoiceTitle => '作成';

  @override
  String get createEventAtTime => '予定';

  @override
  String get createTaskAtDate => 'タスク';

  @override
  String get editEvent => '予定を編集';

  @override
  String get eventTitle => '予定のタイトル';

  @override
  String get location => '場所';

  @override
  String get timeSlot => '時間帯';

  @override
  String get startDateTime => '開始日時';

  @override
  String get endDateTime => '終了日時';

  @override
  String get doesNotRepeat => '繰り返さない';

  @override
  String get defaultReminder => 'デフォルトのリマインダー';

  @override
  String get guests => 'ゲスト';

  @override
  String get noGuests => 'ゲストなし';

  @override
  String get attendeeRequired => '必須';

  @override
  String get attendeeOptional => '任意';

  @override
  String get meetingSection => '会議';

  @override
  String get addGoogleMeet => 'Google Meet を追加';

  @override
  String get addTeamsMeeting => 'Microsoft Teams 会議を追加';

  @override
  String get onlineMeetingAdded => 'オンライン会議を追加しました';

  @override
  String get requestResponses => '返信をリクエスト';

  @override
  String get requestResponsesDescription => 'ゲストに招待への返信を依頼します。';

  @override
  String get hideGuestList => 'ゲストリストを非表示';

  @override
  String get hideGuestListDescription => 'ゲストには他の招待者が表示されません。';

  @override
  String get allowNewTimeProposals => '新しい日時の提案を許可';

  @override
  String get allowNewTimeProposalsDescription => 'ゲストは別の会議時間を提案できます。';

  @override
  String get notifyGuestsTitle => 'ゲストに通知しますか？';

  @override
  String get notifyGuestsSaveMessage => 'この会議にはゲストがいます。保存時に招待または予定の更新を送信しますか？';

  @override
  String get notifyGuestsDeleteMessage => 'この会議にはゲストがいます。削除時にキャンセルを送信しますか？';

  @override
  String get sendUpdates => '更新を送信';

  @override
  String get sendCancellation => 'キャンセルを送信';

  @override
  String get doNotSend => '送信しない';

  @override
  String get microsoftNotifyGuestsSaveTitle => '会議を保存しますか？';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft からゲストに招待または予定の更新が送信されます。';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '会議を削除しますか？';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft からゲストにキャンセルが送信されます。';

  @override
  String get organizer => '主催者';

  @override
  String get yourResponse => '自分の返信';

  @override
  String get guestResponses => 'ゲストの返信';

  @override
  String get respond => '返信';

  @override
  String get acceptInvitation => '承諾';

  @override
  String get tentativeInvitation => '仮承諾';

  @override
  String get declineInvitation => '辞退';

  @override
  String get joinMeeting => '会議に参加';

  @override
  String get responseAccepted => '承諾済み';

  @override
  String get responseTentative => '仮承諾';

  @override
  String get responseDeclined => '辞退済み';

  @override
  String get responseNeedsAction => '返信待ち';

  @override
  String get responseNotResponded => '未返信';

  @override
  String get responseOrganizer => '主催者';

  @override
  String invitationResponseFailed(String error) {
    return '返信を送信できませんでした: $error';
  }

  @override
  String get joinMeetingFailed => '会議リンクを開けませんでした。';

  @override
  String get description => '説明';

  @override
  String get availabilityShowAs => '空き時間情報 / 表示方法';

  @override
  String get busy => '予定あり';

  @override
  String get visibility => '公開設定';

  @override
  String get defaultVisibility => 'デフォルトの公開設定';

  @override
  String get conference => '会議';

  @override
  String get noConference => '会議なし';

  @override
  String get providerCalendar => 'プロバイダーのカレンダー';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => '太字';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => '斜体';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => '下線';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString分前',
      one: '1分前',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => '開始時';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString時間前',
      one: '1時間前',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString日前',
      one: '1日前',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => '空き時間';

  @override
  String get availabilityTentative => '仮の予定';

  @override
  String get availabilityOutOfOffice => '外出中';

  @override
  String get availabilityWorkingElsewhere => '別の場所で勤務';

  @override
  String get visibilityDefault => 'デフォルト';

  @override
  String get visibilityPublic => '一般公開';

  @override
  String get visibilityPrivate => '非公開';

  @override
  String get visibilityConfidential => '機密';

  @override
  String get sensitivityNormal => '標準';

  @override
  String get sensitivityPersonal => '個人用';

  @override
  String get tasks => 'タスク';

  @override
  String get allTasks => 'すべてのタスク';

  @override
  String tasksInList(String title) {
    return '$title のタスク';
  }

  @override
  String get taskLists => 'タスクリスト';

  @override
  String get navigation => 'ナビゲーション';

  @override
  String get mainMenu => 'メインメニュー';

  @override
  String get keyboardShortcuts => 'キーボードショートカット';

  @override
  String get shortcutGroupGeneral => '全般';

  @override
  String get shortcutKeyboardShortcutsDescription => 'このショートカット一覧を表示';

  @override
  String get shortcutGroupNavigation => 'ナビゲーション';

  @override
  String get shortcutNextPeriod => '次の期間';

  @override
  String get shortcutNextPeriodDescription => '週表示では次の週、月表示では次の月というように移動します';

  @override
  String get shortcutPreviousPeriod => '前の期間';

  @override
  String get shortcutPreviousPeriodDescription =>
      '週表示では前の週、月表示では前の月というように移動します';

  @override
  String get shortcutJumpToToday => '今日に移動';

  @override
  String get shortcutGroupView => '表示';

  @override
  String get viewSelector => '表示';

  @override
  String get shortcutDayView => '日表示';

  @override
  String get shortcutWeekView => '週表示';

  @override
  String get shortcutMonthView => '月表示';

  @override
  String get shortcutYearView => '年表示';

  @override
  String get shortcutAgendaView => '予定一覧表示';

  @override
  String get shortcutGroupCreateAndEdit => '作成と編集';

  @override
  String get shortcutSaveItem => '予定またはタスクを保存';

  @override
  String get shortcutDeleteItem => '予定またはタスクを削除';

  @override
  String get shortcutGroupTaskEditing => 'タスクの編集';

  @override
  String get shortcutCancelEditing => '編集をキャンセル';

  @override
  String get shortcutCancelEditingDescription => 'タスクの編集または詳細を閉じる';

  @override
  String get aboutBusyMax => 'BusyMax について';

  @override
  String get aboutBusyMaxDescription => 'カレンダーとタスク';

  @override
  String get license => 'ライセンス';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'ウェブサイト';

  @override
  String get sourceCode => 'ソースコード';

  @override
  String get reportAnIssue => '問題を報告';

  @override
  String get sendFeedback => 'フィードバックを送信';

  @override
  String get feedbackSubmit => '送信';

  @override
  String get feedbackCategory => 'カテゴリー';

  @override
  String get feedbackSelectCategory => 'カテゴリーを選択';

  @override
  String get feedbackCategoryProblem => '問題またはバグ';

  @override
  String get feedbackCategoryFeature => '機能のリクエスト';

  @override
  String get feedbackCategoryPrivacySecurity => 'プライバシーまたはセキュリティに関する懸念';

  @override
  String get feedbackCategoryUsability => '使いやすさに関する懸念';

  @override
  String get feedbackCategoryOther => 'その他';

  @override
  String get feedbackSubject => '件名';

  @override
  String get feedbackDetailedMessage => '詳しい内容';

  @override
  String get feedbackReplyEmail => '返信先メールアドレス（任意）';

  @override
  String get feedbackIncludeTechnicalDetails => '技術情報を含める';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'オペレーティングシステムの名前とバージョン、およびアプリのロケールのみが追加されます。ログ、アカウントデータ、ファイル名、その他の診断情報は含まれません。';

  @override
  String get feedbackCategoryRequired => 'カテゴリーを選択してください。';

  @override
  String get feedbackSubjectLengthError => '件名は3文字以上120文字以下にしてください。';

  @override
  String get feedbackMessageLengthError => 'メッセージは10文字以上5,000文字以下にしてください。';

  @override
  String get feedbackInvalidEmail => '有効なメールアドレスを入力してください。';

  @override
  String get feedbackConnectionError =>
      'BusyStack に接続できませんでした。接続を確認して、もう一度お試しください。';

  @override
  String get feedbackTimeoutError =>
      'リクエストがタイムアウトしました。フィードバックは消去されていません。もう一度お試しください。';

  @override
  String get feedbackRateLimitedError =>
      'このネットワークから送信されたフィードバックが多すぎます。しばらく待ってから、もう一度お試しください。';

  @override
  String get feedbackRejectedError => 'サーバーが送信を拒否しました。入力内容を確認して、もう一度お試しください。';

  @override
  String get feedbackServerError =>
      '現在、BusyStack はフィードバックを受け付けられません。フィードバックは消去されていません。もう一度お試しください。';

  @override
  String feedbackSuccess(String id) {
    return 'フィードバックを送信しました。参照番号: $id';
  }

  @override
  String get toggleSidebar => 'サイドバーの表示を切り替え';

  @override
  String get showSidebar => 'サイドバーパネルを表示';

  @override
  String get hideSidebar => 'サイドバーパネルを非表示';

  @override
  String get accounts => 'アカウント';

  @override
  String get currentAccount => '現在のアカウント';

  @override
  String get switchAccount => 'アカウントを切り替え';

  @override
  String get addGoogleAccount => 'Google アカウントを追加';

  @override
  String get addMicrosoftAccount => 'Microsoft アカウントを追加';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'サインイン済み';

  @override
  String get removeAccount => 'アカウントを削除…';

  @override
  String get removingAccount => 'アカウントを削除しています…';

  @override
  String get removeAccountDescription => '同期を停止し、このアカウントのデータをこのデバイスから削除します。';

  @override
  String removeAccountTitle(String account) {
    return '$account を BusyMax から削除しますか？';
  }

  @override
  String get removeAccountConfirmation =>
      'このデバイスから、キャッシュされたタスク、カレンダー、予定、リマインダー、保留中のオフライン変更を削除します。同期されていない変更は失われます。プロバイダー側のカレンダー、予定、タスクリスト、タスクのコピーは削除されません。';

  @override
  String get revokeGoogleAccess => 'この Google アカウントへの BusyMax のアクセス権も取り消す';

  @override
  String get revokeGoogleAccessDescription => '再接続する前に、もう一度アクセスを許可する必要があります。';

  @override
  String get removeAccountAction => 'アカウントを削除';

  @override
  String get removeAccountFailed => 'アカウントの削除を完了できませんでした。もう一度お試しください。';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'アカウントはこのデバイスから削除されましたが、BusyMax は Google アカウントへのアクセス権を取り消せませんでした。Google アカウントの設定から取り消すことができます。';

  @override
  String get newTaskList => '新しいタスクリスト';

  @override
  String taskListCreateFailed(String error) {
    return 'タスクリストを作成できませんでした: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'タスクリストの名前を変更できませんでした: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'タスクリストを削除できませんでした: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'このリストを削除する前に、アカウントを同期するか、［診断］でこのタスクリストのブロックされた変更を解決してください。';

  @override
  String get signInToViewTaskLists => 'タスクリストを表示するにはサインインしてください。';

  @override
  String get noTaskListsSynced => '同期済みのタスクリストはまだありません。';

  @override
  String get listActions => 'リストの操作';

  @override
  String get rename => '名前を変更';

  @override
  String get delete => '削除';

  @override
  String get renameList => 'リスト名を変更';

  @override
  String get deleteList => 'リストを削除';

  @override
  String get unshare => '共有を解除';

  @override
  String get readOnlyTaskListCannotRename => 'このタスクリストは読み取り専用のため、名前を変更できません。';

  @override
  String get taskListCannotDelete => '現在の権限ではこのタスクリストを削除できません。';

  @override
  String get builtInMicrosoftList => '組み込み';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Microsoft To Do の組み込みリストは、名前の変更や削除ができません。';

  @override
  String deleteListConfirmation(String title) {
    return 'Google Tasks から「$title」を削除しますか？';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '「$title」とそのすべてのタスクを削除しますか？';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'このアカウントとの「$title」の共有を解除しますか？';
  }

  @override
  String get deleteEvent => '予定を削除';

  @override
  String get title => 'タイトル';

  @override
  String get create => '作成';

  @override
  String get newTask => '新しいタスク';

  @override
  String get clearCompleted => '完了済みを消去';

  @override
  String get refreshList => 'リストを更新';

  @override
  String get refreshAll => 'すべて更新';

  @override
  String get listRefreshed => 'リストを更新しました。';

  @override
  String get allTasksRefreshed => 'すべてのアカウントを更新しました。';

  @override
  String exportedFile(String path) {
    return '$path にエクスポートしました';
  }

  @override
  String exportFailed(String error) {
    return 'エクスポートに失敗しました: $error';
  }

  @override
  String refreshFailed(String error) {
    return '更新に失敗しました: $error';
  }

  @override
  String get selectOrCreateTaskList => '開始するには、タスクリストを選択または作成してください。';

  @override
  String get signInToViewTasks => 'タスクを表示するにはサインインしてください。';

  @override
  String get noTasks => 'タスクはありません。';

  @override
  String get noTasksYet => 'タスクはまだありません';

  @override
  String get noTasksYetMessage => 'タスクを作成するか、アカウントを更新して始めましょう。';

  @override
  String get noTasksInList => 'このリストにタスクはありません。';

  @override
  String get overdue => '期限超過';

  @override
  String get today => '今日';

  @override
  String get tomorrow => '明日';

  @override
  String get upcoming => '今後';

  @override
  String get noDate => '日付なし';

  @override
  String get completed => '完了';

  @override
  String duePrefix(String date) {
    return '期限: $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => 'タスクの詳細';

  @override
  String get editTask => 'タスクを編集';

  @override
  String get noTaskSelected => 'タスクが選択されていません。';

  @override
  String get noTaskSelectedHelper => '詳細を表示して編集するタスクを選択してください。';

  @override
  String get taskUnavailable => 'タスクを利用できません。';

  @override
  String get signInToEditTasks => 'タスクを編集するにはサインインしてください。';

  @override
  String get refreshTask => 'タスクを更新';

  @override
  String get primarySection => '基本情報';

  @override
  String get statusSection => 'ステータス';

  @override
  String get openStatus => '未完了';

  @override
  String get doneStatus => '完了';

  @override
  String get taskStatus => 'ステータス';

  @override
  String get taskStatusNone => 'ステータスなし';

  @override
  String get taskStatusNeedsAction => '要対応';

  @override
  String get taskStatusInProcess => '進行中';

  @override
  String get taskStatusCompleted => '完了';

  @override
  String get taskStatusCancelled => 'キャンセル済み';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% 完了';
  }

  @override
  String get completionDate => '完了日';

  @override
  String get priority => '優先度';

  @override
  String get priorityNone => '優先度なし';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先度 $priorityString · 高';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先度 $priorityString · 中';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先度 $priorityString · 低';
  }

  @override
  String get taskUrl => 'タスク URL';

  @override
  String get invalidTaskUrl => 'スキームを含む絶対 URL を入力してください。';

  @override
  String get classification => '分類';

  @override
  String get classificationPublic => '共有時にタスク全体を表示';

  @override
  String get classificationConfidential => '共有時に空き状況のみ表示';

  @override
  String get classificationPrivate => '共有時にこのタスクを非表示';

  @override
  String get pinTask => 'タスクをピン留め';

  @override
  String get notes => 'メモ';

  @override
  String get dueDate => '期限日';

  @override
  String get clearDueDate => '期限日を消去';

  @override
  String get dueTime => '期限時刻';

  @override
  String get startDate => '開始日';

  @override
  String get startTime => '開始時刻';

  @override
  String get endDate => '終了日';

  @override
  String get endTime => '終了時刻';

  @override
  String get reminderDate => 'リマインダーの日付';

  @override
  String get reminderTime => 'リマインダーの時刻';

  @override
  String get reminder => 'リマインダー';

  @override
  String get addReminder => 'リマインダーを追加';

  @override
  String get reminders => 'リマインダー';

  @override
  String get noReminders => 'リマインダーなし';

  @override
  String get editReminder => 'リマインダーを編集';

  @override
  String get beforeTaskStarts => 'タスクの開始前';

  @override
  String get beforeTaskDue => 'タスクの期限前';

  @override
  String get afterTaskStarts => 'タスクの開始後';

  @override
  String get afterTaskDue => 'タスクの期限後';

  @override
  String get relativeToTaskStart => 'タスクの開始日に対して';

  @override
  String get relativeToTaskDue => 'タスクの期限日に対して';

  @override
  String get reminderTimeOfDay => '時刻';

  @override
  String get absoluteReminder => '日時を指定';

  @override
  String get reminderAmount => '数値';

  @override
  String get reminderUnit => '単位';

  @override
  String get reminderUnitSeconds => '秒';

  @override
  String get reminderUnitMinutes => '分';

  @override
  String get reminderUnitHours => '時間';

  @override
  String get reminderUnitDays => '日';

  @override
  String get reminderUnitWeeks => '週';

  @override
  String get reminderAtTaskStart => 'タスクの開始時';

  @override
  String get reminderAtTaskDue => 'タスクの期限時刻';

  @override
  String get unsupportedReminder => 'このリマインダーの種類は保持されますが、時刻は編集できません。';

  @override
  String get relatedRemindersTitle => '関連するリマインダーを保持しますか？';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'この日付には関連するリマインダーが $countString 件あります。現在の日付と時刻を保持しますか？';
  }

  @override
  String get discardRelatedReminders => 'リマインダーを破棄';

  @override
  String get keepRelatedReminders => 'リマインダーを保持';

  @override
  String get addGuest => 'ゲストを追加';

  @override
  String get addGuestEmail => 'ゲストのメールアドレスを追加';

  @override
  String get removeReminder => 'リマインダーを削除';

  @override
  String get off => 'オフ';

  @override
  String get repeat => '繰り返し';

  @override
  String get repeatNone => 'なし';

  @override
  String get noneValue => 'なし';

  @override
  String get repeatDaily => '毎日';

  @override
  String get repeatWeekly => '毎週';

  @override
  String get repeatMonthly => '毎月';

  @override
  String get repeatYearly => '毎年';

  @override
  String get repeatEvery => '繰り返し間隔';

  @override
  String get repeatOn => '繰り返す曜日';

  @override
  String get repeatEnd => '繰り返しを終了';

  @override
  String get repeatNever => 'なし';

  @override
  String get repeatUntil => '指定日まで';

  @override
  String get repeatAfter => '指定回数後';

  @override
  String get repeatCount => '繰り返し回数';

  @override
  String get repeatDayOfMonth => '月の日';

  @override
  String get repeatMonths => '月';

  @override
  String get repeatOrdinal => '曜日の順番';

  @override
  String get repeatSpecificDays => '特定の曜日';

  @override
  String get repeatFirst => '第 1';

  @override
  String get repeatSecond => '第 2';

  @override
  String get repeatThird => '第 3';

  @override
  String get repeatFourth => '第 4';

  @override
  String get repeatFifth => '第 5';

  @override
  String get repeatSecondToLast => '最後から 2 番目';

  @override
  String get repeatLast => '最後';

  @override
  String get repeatAnyDay => '日';

  @override
  String get repeatWeekday => '平日';

  @override
  String get repeatWeekendDay => '週末';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '月曜日',
      'TU': '火曜日',
      'WE': '水曜日',
      'TH': '木曜日',
      'FR': '金曜日',
      'SA': '土曜日',
      'SU': '日曜日',
      'day': '日',
      'weekday': '平日',
      'weekend': '週末',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString 日ごと';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString 週間ごと';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString か月ごと';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '$countString 年ごと';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第1$days',
      'second': '第2$days',
      'third': '第3$days',
      'fourth': '第4$days',
      'fifth': '第5$days',
      'secondToLast': '最後から2番目の$days',
      'last': '最後の$days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '$months に';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString 回',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '$date まで';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'この繰り返しルールには、このエディターで変更されないオプションが含まれています。';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'このリストではこの繰り返しパターンを使用できません。パターンを変更するか、別のリストを選択してください。';

  @override
  String get taskRecurrenceRequiresDate =>
      'この繰り返しパターンを使用するには、開始日または期限を追加するか、繰り返しをオフにしてください。';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'この繰り返しは $provider では使用できません。';
  }

  @override
  String get importance => '重要度';

  @override
  String get importanceLow => '低';

  @override
  String get importanceNormal => '標準';

  @override
  String get importanceHigh => '高';

  @override
  String get categories => 'カテゴリー';

  @override
  String get scheduleSection => 'スケジュール';

  @override
  String get dueGroup => '期限';

  @override
  String get startGroup => '開始';

  @override
  String get reminderGroup => 'リマインダー';

  @override
  String get organizationSection => '整理';

  @override
  String get actionsSection => '操作';

  @override
  String get advancedSection => '詳細設定';

  @override
  String get addCategory => 'カテゴリーを追加';

  @override
  String get list => 'リスト';

  @override
  String get microsoftMoveUnsupported =>
      'このバージョンでは、Microsoft To Do アカウントのリスト間でタスクを移動できません。';

  @override
  String get createSubtask => 'サブタスクを作成';

  @override
  String get subtasks => 'サブタスク';

  @override
  String get duplicateTask => 'タスクを複製';

  @override
  String get taskDuplicated => 'タスクを複製しました。';

  @override
  String taskDuplicateFailed(String error) {
    return 'タスクを複製できませんでした: $error';
  }

  @override
  String get hideSubtasks => 'サブタスクを非表示';

  @override
  String get hideClosedSubtasks => '完了したサブタスクを非表示';

  @override
  String get moveToTop => '一番上に移動';

  @override
  String get deleteTask => 'タスクを削除';

  @override
  String get newSubtask => '新しいサブタスク';

  @override
  String deleteTaskConfirmation(String title) {
    return '「$title」を削除しますか？';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Google ドキュメントまたは Chat スペースの元のタスクも削除されます。';

  @override
  String get metadata => 'メタデータ';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => '更新日時';

  @override
  String get parent => '親タスク';

  @override
  String get position => '位置';

  @override
  String get webLink => 'ウェブリンク';

  @override
  String get assignment => '割り当て';

  @override
  String get localState => 'ローカル状態';

  @override
  String get pendingSync => '同期待ち';

  @override
  String get synced => '同期済み';

  @override
  String get account => 'アカウント';

  @override
  String get sync => '同期';

  @override
  String get forceFullResync => '完全な再同期を強制';

  @override
  String get forceFullResyncDescription =>
      '接続されているすべてのアカウントからデータを完全に再読み込みします。同期の問題を解決する場合にのみ使用してください。';

  @override
  String get runInBackgroundWhenClosed => 'ウィンドウを閉じてもバックグラウンドで実行を続ける';

  @override
  String get showTrayIcon => 'トレイアイコンを表示';

  @override
  String get startMinimizedToTray => 'トレイに最小化して起動';

  @override
  String get launchAtLogin => 'ログイン時に起動';

  @override
  String get launchAtLoginDescription =>
      'ログイン後もリマインダーが動作するように、BusyMaxをバックグラウンドで起動します。';

  @override
  String get launchAtLoginFailed => 'ログイン時の起動設定を更新できませんでした。';

  @override
  String get requiresTrayIcon => 'トレイアイコンが必要です。';

  @override
  String get syncComplete => '同期が完了しました。';

  @override
  String syncFailed(String error) {
    return '同期に失敗しました: $error';
  }

  @override
  String get notifySyncFailures => '同期失敗時に通知';

  @override
  String get notifyConflicts => '競合時に通知';

  @override
  String get notifyDueToday => '今日が期限のタスクを通知';

  @override
  String get eventReminders => '予定のリマインダー';

  @override
  String get onState => 'オン';

  @override
  String get taskReminders => 'タスクのリマインダー';

  @override
  String get notificationDetailLevel => '通知の詳細度';

  @override
  String get notificationDetailPrivate => '非公開';

  @override
  String get notificationDetailNormal => '標準';

  @override
  String get quietHours => '通知を停止する時間';

  @override
  String get quietHoursDescription => 'この時間帯は通知を一時停止します。';

  @override
  String get quietHoursStart => '通知停止の開始時刻';

  @override
  String get quietHoursEnd => '通知停止の終了時刻';

  @override
  String get notifications => '通知';

  @override
  String get windowsNotificationsUnavailable => 'Windows 通知を利用できません';

  @override
  String get windowsNotificationsUnpackaged =>
      'このパッケージ化されていない開発実行では Windows 通知を使用できません。リマインダーをテストするには、テスト署名済み MSIX をインストールしてください。';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax は Windows 通知を初期化できませんでした。このインストールの問題が解決するまで、リマインダーは表示されません。';

  @override
  String get appearance => '外観';

  @override
  String get theme => 'テーマ';

  @override
  String get themeSystem => 'システム';

  @override
  String get settingsSystem => 'システム';

  @override
  String get themeLight => 'ライト';

  @override
  String get themeDark => 'ダーク';

  @override
  String get themeFamily => 'テーマファミリー';

  @override
  String get themeFamilyYaru => 'Ubuntu ネイティブ（Yaru）';

  @override
  String get localization => '言語と地域';

  @override
  String get currentLocale => '現在のロケール';

  @override
  String get privacy => 'プライバシー';

  @override
  String get redactTaskContentInDiagnostics => '診断情報でタスクの内容を伏せる';

  @override
  String get developerDiagnostics => '開発者向け診断';

  @override
  String get diagnostics => '診断';

  @override
  String get apiInspectorDisabled => 'API インスペクターを表示';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery リビジョン: $revision';
  }

  @override
  String get implementedMethods => '実装済みメソッド';

  @override
  String get supportsTasksScopes => 'tasks および tasks.readonly スコープをサポート';

  @override
  String get requiresTasksScope => 'tasks スコープが必要';

  @override
  String get blockedPendingOperations => 'ブロックされた保留中の操作';

  @override
  String get signInToInspectPendingOperations => '保留中の操作を確認するにはサインインしてください。';

  @override
  String get noBlockedPendingOperations => 'ブロックされた保留中の操作はありません。';

  @override
  String get operationActions => '操作への対応';

  @override
  String pendingOpListId(String id) {
    return 'リスト=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'タスク=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '試行回数=$countString';
  }

  @override
  String get retry => '再試行';

  @override
  String get discard => '破棄';

  @override
  String get discardChangesAction => '破棄';

  @override
  String get discardChanges => '変更を破棄しますか？';

  @override
  String get discardChangesConfirmation => 'このタスクの未保存の編集内容を破棄します。';

  @override
  String get retryCompleted => '再試行が完了しました。';

  @override
  String get discardPendingOperation => '保留中の操作を破棄しますか？';

  @override
  String get discardPendingOperationConfirmation =>
      'ブロックされたローカル操作を削除します。次回の同期時に Google Tasks からデータが再取得されます。';

  @override
  String get pendingOperationDiscarded => '保留中の操作を破棄しました。';

  @override
  String get syncFailureNotificationTitle => 'BusyMax の同期に失敗';

  @override
  String syncFailureNotificationBody(String message) {
    return 'バックグラウンド同期に失敗しました。$message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax の同期競合';

  @override
  String conflictNotificationBody(String summary) {
    return '保留中のローカル変更がブロックされました。$summary';
  }

  @override
  String get dueTodayNotificationTitle => '今日が期限のタスク';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今日が期限のタスクが$countString件あります。',
      one: '今日が期限のタスクが1件あります。',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => '予定のリマインダー';

  @override
  String get taskReminderNotificationTitle => 'タスクのリマインダー';

  @override
  String get eventReminderNotificationBody => '予定がまもなく始まります。';

  @override
  String get taskReminderNotificationBody => 'タスクの期限が近づいています。';

  @override
  String get notificationOpenAction => '開く';

  @override
  String get notificationSnoozeAction => '10分後に再通知';

  @override
  String get notificationDismissAction => '閉じる';

  @override
  String get notificationDetailsHidden => 'プライバシー設定により詳細は非表示です。';

  @override
  String get previousMonth => '前の月';

  @override
  String get nextMonth => '次の月';

  @override
  String get openMonthView => '月表示を開く';

  @override
  String get previousYear => '前の年';

  @override
  String get nextYear => '次の年';

  @override
  String get openYearView => '年表示を開く';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return '第$numberString週';
  }

  @override
  String get resizeAllDayPanel => '終日パネルのサイズを変更';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString件',
      one: '1件',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'このカレンダーは読み取り専用です。';

  @override
  String get selectTimeZone => 'タイムゾーンを選択';

  @override
  String get searchLocations => '場所を検索';

  @override
  String get noLocationsFound => '場所が見つかりません';

  @override
  String get requiredField => 'このフィールドは必須です。';

  @override
  String get providerConnectionDescription => '次のいずれかのプロバイダーからカレンダーとタスクを接続します。';

  @override
  String get appleICloudProvider => 'Apple iCloud カレンダー';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud タスク';

  @override
  String get addAppleICloudAccount => 'Apple iCloud カレンダーアカウントを追加';

  @override
  String get addNextcloudAccount => 'Nextcloud アカウントを追加';

  @override
  String get waitingForAppleICloud => 'Apple iCloud に接続中…';

  @override
  String get waitingForNextcloud => 'Nextcloud の認証を待機中…';

  @override
  String get connectAppleICloudTitle => 'Apple iCloud カレンダーを接続';

  @override
  String get appleAccountEmail => 'Apple アカウントのメールアドレス';

  @override
  String get appleAppSpecificPassword => 'App 用パスワード';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Apple アカウントで 2 要素認証を有効にした後、App 用パスワードを作成してください。';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Apple アカウントのパスワードをリセットすると、App 用パスワードが無効になります。';

  @override
  String get connectNextcloudTitle => 'Nextcloud を接続';

  @override
  String get nextcloudServerUrl => 'Nextcloud サーバーまたは CalDAV アドレス';

  @override
  String get nextcloudServerUrlHelp =>
      'Nextcloud サーバーの URL を入力するか、Nextcloud からコピーしたプライマリ CalDAV アドレスを貼り付けてください。';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax がブラウザーを開きます。そこでアクセスを許可してから BusyMax に戻ってください。';

  @override
  String get connectAccountAction => '接続';

  @override
  String get cancelAccountConnection => '接続をキャンセル';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'アカウントはローカルから削除されましたが、Nextcloud の App パスワードを無効にできませんでした。';

  @override
  String get davReauthenticationRequired => '同期を再開するには、このアカウントを再接続してください。';

  @override
  String get davTemporarilyUnavailable => 'このアカウントは一時的に利用できません。';

  @override
  String get davPermissionChanged => 'サーバーの権限が変更されました。保留中の編集は一時停止されています。';

  @override
  String get davUnsupportedServer => 'このサーバーまたはプロバイダー プロファイルはサポートされていません。';

  @override
  String get collectionSettings => 'カレンダーとタスクリスト';

  @override
  String get calendarContent => 'カレンダーの予定';

  @override
  String get taskContent => 'タスク';

  @override
  String get readOnlySharedCollection => '読み取り専用';

  @override
  String get pendingLocally => 'ローカルで保留中';

  @override
  String get conflictBlocked => '競合によりブロック';

  @override
  String get authenticationBlocked => '再接続するまでブロック';

  @override
  String get operationFailed => '操作に失敗';

  @override
  String get keepServerVersion => 'サーバーのバージョンを保持';

  @override
  String get reapplyLocalChange => 'ローカル変更を確認して再適用';

  @override
  String get duplicateLocalItem => '新しいアイテムとして複製';

  @override
  String get davConnectionState => '接続状態';

  @override
  String get davConnected => '接続済み';

  @override
  String get davConnecting => '接続中…';

  @override
  String get davSignedOut => 'サインアウト済み';

  @override
  String davLastSuccessfulSync(String time) {
    return '最後に成功した同期: $time';
  }

  @override
  String get davNeverSynced => 'まだ同期されていません';

  @override
  String get refreshCollections => 'カレンダーとタスクリストを更新';

  @override
  String nextcloudServerHost(String host) {
    return 'サーバー: $host';
  }

  @override
  String get collectionSupportsEvents => '予定カレンダー';

  @override
  String get collectionSupportsTasks => 'タスクリスト';

  @override
  String get collectionSupportsEventsAndTasks => '予定とタスク';

  @override
  String get writableCollection => '書き込み可能';

  @override
  String get sharedCollection => '共有';

  @override
  String collectionLastSynced(String time) {
    return '最後の同期: $time';
  }

  @override
  String collectionSyncError(String code) {
    return '同期の問題: $code';
  }

  @override
  String get syncConflicts => '同期の競合';

  @override
  String remoteChangedAt(String time) {
    return 'サーバーでの変更: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'ローカル編集: $summary';
  }

  @override
  String get conflictResolutionFailed => '競合を解決できませんでした。';

  @override
  String get recurringEventScope => '繰り返し予定の範囲';

  @override
  String get entireSeries => '予定全体';

  @override
  String get singleOccurrence => 'この予定';

  @override
  String get thisAndFollowingEvents => 'この予定とこれ以降の予定';

  @override
  String get thisAndFutureUnavailable => 'このプロバイダーではサポートされていません。';

  @override
  String get thisAndFutureMoveUnavailable =>
      'この予定とこれ以降の予定を安全に移動することはできません。この予定または予定全体を選択してください。';

  @override
  String get entireSeriesMoveUnavailable =>
      '繰り返しルールがローカルにありません。代わりにこの予定だけを移動してください。';

  @override
  String get copyEventAndDeleteOriginal => '予定をコピーして元の予定を削除しますか？';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax はこの予定を $source から $destination へ直接移動できません。先にコピーを作成し、コピーが成功した場合にのみ元の予定を削除します。予定 ID は変更されます。出席者の回答状況がリセットされ、招待やキャンセルが送信される場合があります。また、会議リンク、添付ファイル、リマインダー、プロバイダー固有のフィールド、繰り返しの例外は引き継がれない場合があります。';
  }

  @override
  String get copyAndDelete => 'コピーして削除';

  @override
  String get chooseRecurringEventScope =>
      'この変更を予定全体、この予定のみ、この予定とこれ以降の予定のどれに適用するか選択してください。';

  @override
  String get taskDueBeforeStart => '期限を開始より前に設定することはできません。';

  @override
  String get taskStartDueTimeModeMismatch => '開始と期限の両方に時刻を設定するか、タスクを終日にしてください。';

  @override
  String deleteCalendarConfirmation(String title) {
    return '「$title」を削除しますか？';
  }

  @override
  String get setCustomCalendarName => 'カスタム名を設定';

  @override
  String get setAction => '設定';

  @override
  String get removeFromMyCalendars => 'マイカレンダーから削除';

  @override
  String get removeAction => '削除';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '「$title」を BusyMax から削除しますか？所有者のカレンダーと予定は削除されません。';
  }

  @override
  String get attachmentUploadUnresolved =>
      'アップロードが完了した可能性があります。再アップロードする前に添付ファイルを更新して結果を確認してください。';

  @override
  String removeCalendarConfirmation(String title) {
    return '「$title」を Google カレンダーのリストから削除しますか？共有カレンダーとその予定は削除されません。';
  }

  @override
  String get calendarCannotRemove => 'このカレンダーはこのアカウントから削除または解除できません。';

  @override
  String get calendarPendingChangesPreventRemoval =>
      '削除または解除する前に、このカレンダーの保留中の変更が同期されるまで待ってください。';

  @override
  String get calendarSubscriptions => 'カレンダーの登録';

  @override
  String get calendarSubscriptionsDescription =>
      '安全な WebCal URL から更新される読み取り専用カレンダーを追加します。';

  @override
  String get addCalendarSubscription => 'カレンダー登録を追加';

  @override
  String get subscriptionName => 'ローカル名';

  @override
  String get subscriptionUrl => '登録 URL';

  @override
  String get subscriptionUrlHelp =>
      'HTTPS または webcal URL を入力してください。BusyMax は完全な URL を安全なストレージに保存します。';

  @override
  String get subscriptionUrlInvalid =>
      'ユーザー情報やフラグメントを含まない有効な HTTPS または webcal URL を入力してください。';

  @override
  String get subscriptionColor => 'ローカルの色';

  @override
  String get subscriptionColorHelp => '#3584E4 のような 6 桁の色を使用してください。';

  @override
  String get subscriptionColorInvalid => '6 桁の 16 進数カラーを入力してください。';

  @override
  String get subscriptionRefreshMode => '更新頻度';

  @override
  String get subscriptionAutomatic => '自動';

  @override
  String get subscriptionHourly => '毎時';

  @override
  String get subscriptionSixHours => '6 時間ごと';

  @override
  String get subscriptionDaily => '毎日';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'ソース: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      '安全なオリジンをプレビューするには有効な URL を入力してください。';

  @override
  String get subscriptionReadOnly => '読み取り専用の登録';

  @override
  String get subscriptionNeverRefreshed => 'まだ更新されていません';

  @override
  String subscriptionLastRefresh(String time) {
    return '最後に成功した更新: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return '次回の更新: $time';
  }

  @override
  String get subscriptionStatusHealthy => '最新';

  @override
  String subscriptionStatusIssue(String code) {
    return '更新の問題: $code';
  }

  @override
  String get refreshNow => '今すぐ更新';

  @override
  String get unsubscribe => '登録を解除';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '「$name」の登録を解除しますか？';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'ローカル登録とキャッシュされた予定を削除します。公開されているカレンダーは変更されません。';

  @override
  String get addSubscriptionAction => '登録を追加';

  @override
  String subscriptionOperationFailed(String error) {
    return 'カレンダー登録に失敗: $error';
  }

  @override
  String get subscriptions => '登録';

  @override
  String get calendarImport => 'カレンダーをインポート';

  @override
  String get calendarImportDescription =>
      'ファイルを選択して予定を確認し、受け入れ先の書き込み可能なカレンダーを選択します。';

  @override
  String get importIcsFile => '.ics ファイルをインポート';

  @override
  String get importIcsPreview => 'カレンダーの予定をインポート';

  @override
  String importEventsFound(int count) {
    return 'インポート可能な予定セット: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return '無効な予定: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return '意図的に省略: $fields';
  }

  @override
  String get noWritableCalendars => '書き込み可能な移行先カレンダーがありません。';

  @override
  String get importDestinationCalendar => '移行先カレンダー';

  @override
  String get importIcsConfirm => '予定をインポート';

  @override
  String get importIcsComplete => 'インポート完了';

  @override
  String importQueued(int count) {
    return 'インポート済みまたはキュー済み: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return '重複をスキップ: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'サポートされない繰り返しセット: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'カレンダーファイルをインポートできませんでした: $error';
  }

  @override
  String get networkOffline => 'オフライン';

  @override
  String get networkOfflineDescription => '接続が復旧すると変更が同期されます。';

  @override
  String get networkOfflineTryAgain => 'オフラインです。インターネットに接続して、もう一度お試しください。';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days';
  }

  @override
  String get repeatSummarySeparator => '';

  @override
  String repeatMonthDayValue(String day) {
    return '$day日';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$firstと$second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$firstと$second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency$month$day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency$monthの$days';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency$monthsの$day';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency$monthsの$days';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第1$days',
      'second': '第2$days',
      'third': '第3$days',
      'fourth': '第4$days',
      'fifth': '第5$days',
      'secondToLast': '最後から2番目の$days',
      'last': '最後の$days',
      'other': '$days',
    });
    return '$frequency$monthの$_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第1$days',
      'second': '第2$days',
      'third': '第3$days',
      'fourth': '第4$days',
      'fifth': '第5$days',
      'secondToLast': '最後から2番目の$days',
      'last': '最後の$days',
      'other': '$days',
    });
    return '$frequency$monthsの$_temp0';
  }

  @override
  String get searchFilters => '検索フィルター';

  @override
  String get searchType => '種類';

  @override
  String get searchDate => '日付';

  @override
  String get searchAnyDate => 'すべての日付（ダウンロード済みデータ）';

  @override
  String get eventLink => '予定のリンク';

  @override
  String get eventLinkOpenFailed => 'リンクを開けませんでした。';

  @override
  String get scheduleRangeIncomplete => '一部の予定を確認できませんでした。ダウンロード済みデータを表示しています。';

  @override
  String get searchThisWeek => '今週';

  @override
  String get searchCustomRange => '期間を指定';

  @override
  String get searchTaskStatus => 'タスクの状態';

  @override
  String get searchTaskDue => 'タスクの期限';

  @override
  String get searchAnyDueState => 'すべての期限状態';

  @override
  String get searchNoDueDate => '期限なし';

  @override
  String get searchPerson => '人物';

  @override
  String get searchSources => '検索元';

  @override
  String get searchClearFilters => 'フィルターをリセット';

  @override
  String get searchFiltersAction => 'フィルター';

  @override
  String get searchNoSources => '検索元が選択されていません';

  @override
  String get searchClearText => 'テキストを消去';

  @override
  String get openSharedCalendar => '共有カレンダーを開く';

  @override
  String get manageCalendarSharing => 'カレンダーの共有を管理';

  @override
  String get shareRecipientEmail => '共有先のメールアドレス';

  @override
  String get shareRole => 'アクセス権';

  @override
  String get addCalendarShare => 'アクセスを追加';

  @override
  String get sharingRefreshFailed =>
      '共有は変更されましたが、権限一覧を更新できませんでした。次の変更前に一覧を再読み込みしてください。';

  @override
  String get sharingRateLimited => '共有は一時的に制限されています。待機時間が終了してから再試行してください。';

  @override
  String get attachmentUploadRateLimited =>
      '添付ファイルのアップロードは一時的に制限されています。待機時間が終了してから再試行してください。';

  @override
  String get sharingPermissionUnavailable => 'このカレンダーの共有権限を取得できません。';

  @override
  String get calendarShareFreeBusy => '空き時間情報のみ';

  @override
  String get calendarShareLimitedRead => '限定された詳細を表示';

  @override
  String get calendarShareRead => 'すべての詳細を表示';

  @override
  String get calendarShareWrite => '予定を編集';

  @override
  String get calendarShareWriteWithoutPrivate => '非公開の詳細を除いて編集';

  @override
  String get calendarShareOwner => '所有者';

  @override
  String get eventLabel => '予定のラベル';

  @override
  String get loadOutlookCategories => 'Outlook カテゴリを読み込む';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlook カテゴリを取得できません。既存の割り当ては保持されます。';

  @override
  String get googleEventType => '予定の種類';

  @override
  String get googleRegularEvent => '通常の予定';

  @override
  String get googleFocusTime => '集中する時間';

  @override
  String get googleOutOfOffice => '不在';

  @override
  String get googleWorkingLocation => '勤務場所';

  @override
  String get googleDeclineInvitations => '重なる招待を辞退';

  @override
  String get googleDeclineNone => '辞退しない';

  @override
  String get googleDeclineNew => '新しい招待を辞退';

  @override
  String get googleDeclineAll => '競合する招待をすべて辞退';

  @override
  String get googleDeclineMessage => '辞退メッセージ';

  @override
  String get googleChatStatus => 'チャットの状態';

  @override
  String get googleChatAvailable => '連絡可能';

  @override
  String get googleChatDoNotDisturb => '通知をミュート';

  @override
  String get googleWorkAtHome => '自宅';

  @override
  String get googleWorkAtOffice => 'オフィス';

  @override
  String get googleWorkAtCustomLocation => 'カスタムの場所';

  @override
  String get googleWorkLocationLabel => '場所の名前';

  @override
  String get googleStatusPrimaryOnly =>
      'Google のステータス予定にはメインの Google カレンダーが必要です。';

  @override
  String unknownEventLabel(String id) {
    return '不明なラベル（$id）';
  }

  @override
  String get calendarOwnerEmail => 'カレンダー所有者のメールアドレス';

  @override
  String registrationSetupTitle(String provider) {
    return '$provider を設定';
  }

  @override
  String get registrationSetupGuide => '設定ガイド';

  @override
  String get registrationGoogleInstructions =>
      '独自の Google Cloud プロジェクトを作成し、Calendar と Tasks API を有効にして、デスクトップ OAuth クライアントの JSON をインポートします。目的のアカウントを認証してください。';

  @override
  String get registrationMicrosoftInstructions =>
      'アプリ登録を許可する Entra テナントでパブリックアプリを登録します。クライアント ID と対象アカウントを入力します。クライアントシークレットは不要です。';

  @override
  String get registrationImportGoogle => 'デスクトップ OAuth JSON を選択';

  @override
  String get registrationValidate => '登録を検証';

  @override
  String get registrationAuthorize => 'ブラウザで認証';

  @override
  String get registrationClientId => 'アプリケーション／クライアント ID';

  @override
  String get registrationTenantId => 'テナント ID';

  @override
  String get registrationAudience => '対応アカウント';

  @override
  String get registrationBothAudience => '個人および組織アカウント';

  @override
  String get registrationOrganizationAudience => '組織アカウント';

  @override
  String get registrationPersonalAudience => '個人アカウント';

  @override
  String get registrationTenantAudience => '単一の組織テナント';

  @override
  String registrationSummary(String clientId) {
    return '登録: $clientId';
  }

  @override
  String get registrationMigrate => '今すぐ移行';

  @override
  String get registrationReplace => '登録を置き換え';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'このアカウントは既存のアカウント専用の元の $provider 登録を使用しています。置き換える場合は $setup を設定して再接続してください。既存のカレンダー、タスク、ローカルの変更は保持されます。';
  }

  @override
  String get registrationContinue => 'このアカウントを引き続き使用';

  @override
  String get registrationGoogleProject => 'Google Cloud プロジェクト';

  @override
  String get registrationMicrosoftApp => 'Microsoft アプリ登録';

  @override
  String get registrationUserOwned => 'ユーザーが提供した登録';

  @override
  String get registrationNativeGoogle => 'Google Android ネイティブ登録';

  @override
  String get registrationShared => '共有登録（移行期間）';

  @override
  String get registrationUnresolved => '登録の出所を確認できません。アカウントのデータは保持されています。';

  @override
  String get registrationOfficialDocumentation => '公式ドキュメント';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'パッケージ: $packageName\n署名ハッシュ: $signatureHash\nリダイレクト URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      '登録のクライアント種別、対応アカウント、権限、リダイレクトを確認してください。インポートした設定は再選択してください。';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'この認証を完了できませんでした。認証をやり直してください。既存の接続は保持されています。';

  @override
  String get oauthPermissionRefused =>
      '認証が拒否されたか、必要な権限がありません。再試行して必要な権限を付与してください。';

  @override
  String get oauthProviderThrottled =>
      'プロバイダーがリクエストを制限しています。しばらく待って再試行してください。既存の接続は保持されています。';

  @override
  String get oauthProviderTemporaryFailure =>
      'プロバイダーの一時的な問題により認証を完了できませんでした。再試行してください。既存の接続は保持されています。';

  @override
  String get oauthAuthorizationTimedOut =>
      '認証がタイムアウトしました。再試行し、インポートした設定は再選択してください。';

  @override
  String get oauthWrongAccount => '再接続用に選択したアカウントで認証してください。既存の接続は保持されています。';

  @override
  String get oauthSecureStorageUnavailable =>
      '安全なストレージを利用できません。アクセスを復旧して再試行してください。';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'リモート認証は取り消されましたが、アカウントのクリーンアップを完了できませんでした。BusyMax を再起動してローカル復旧を再試行してください。';

  @override
  String get addAccount => 'アカウントを追加';

  @override
  String get registrationConnect => '接続';

  @override
  String get registrationBack => '戻る';

  @override
  String get registrationReplaceGoogle => 'デスクトップ OAuth JSON を置き換え';

  @override
  String get registrationSelectedConfiguration => '選択した設定';

  @override
  String get registrationDirectoryId => 'ディレクトリ／テナント ID';

  @override
  String get registrationInvalidId => '有効な UUID を入力してください。';

  @override
  String get registrationExpired =>
      'この設定は期限切れです。接続する前に再インポートするか、登録項目を編集してください。';

  @override
  String get registrationOwnProjectRequired => '自分のプロジェクトまたはテナントの登録を選択してください。';

  @override
  String get registrationSetupFailed => '設定を完了できませんでした。もう一度お試しください。';

  @override
  String get registrationLinkFailed => 'リンクを開けませんでした。ブラウザーを確認して再試行してください。';

  @override
  String get registrationPermissions => 'アクセス許可';

  @override
  String get registrationDesktopClient => 'デスクトップアプリ';

  @override
  String get registrationOpenGoogleConsole => 'Google Cloud Console を開く';

  @override
  String get registrationGoogleAudienceHelp => 'Google の公開とテストユーザーの要件';

  @override
  String get registrationDesktopHelp => 'デスクトップアプリの登録手順';

  @override
  String get registrationOpenEntra => 'Microsoft Entra 管理センターを開く';

  @override
  String get registrationGuideGoogleProject =>
      'Google Cloud Console を開きます。上部のプロジェクト選択からご自身のプロジェクトを選ぶか、New project を選び、名前を入力して Create を選択します。以降の手順でも同じプロジェクトを選択したままにしてください。';

  @override
  String get registrationGuideGoogleAudience =>
      'Google Auth Platform → Branding に移動します。未設定の場合は Get started を選択します。App name に BusyMax を入力し、ご自身の User support email を選んで Next を選択します。Audience ではExternal を選びます。Next を選び、Contact Information にメールアドレスを入力して Next を選択します。User Data Policy に同意し、Continue、Create の順に選択します。設定済みの場合は Branding と Audience を確認します。';

  @override
  String get registrationGuideGooglePermissions =>
      'Google Auth Platform → Data Access → Add or remove scopes を開きます。以下の 5 つのスコープを選び、必要なら Manually add scopes を使います。手動で追加する場合は不足している値を貼り付け、Add to table を選択します。Update、Save の順に選択します。BusyMax にはカレンダーとタスク両方へのアクセスが必要です。';

  @override
  String get registrationGuideGoogleClient =>
      'Google Auth Platform → Clients → Create client を開きます。Application type を Desktop app にし、Name に BusyMax を入力して Create を選択します。作成ダイアログで Download JSON を選び、ファイルを保存します。戻るを選んでフォームに戻り、ファイルを選んでプロジェクトとクライアント ID を確認します。接続を選び、ブラウザーでカレンダーとタスクへのアクセスを許可します。';

  @override
  String get registrationGuideMicrosoftApp =>
      'Microsoft Entra 管理センターにサインインします。Settings でアプリを登録できるテナントを選びます。Entra ID → App registrations → New registration を開きます。Name に BusyMax を入力し、次の手順で対応アカウントの種類を選びます。登録が制限されている場合はテナント管理者にアクセスを依頼してください。';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'アプリ登録で Authentication → Add a platform → Mobile and desktop applications を開きます。以下のリダイレクト URI を選択または入力し、Configure で保存します。BusyMax はシステムのブラウザーを使います。クライアントシークレットは不要です。';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'API permissions → Add a permission → Microsoft Graph → Delegated permissions を開きます。以下のスコープをそれぞれ検索して選び、Add permissions を選択します。User.Read が既にある場合は残します。組織で管理者の同意が必要な場合は、管理者にテナントの Grant admin consent を依頼してください。';

  @override
  String get registrationGuideMicrosoftConnect =>
      '戻るを選んでフォームに戻ります。Application (client) ID を貼り付け、登録と同じ対応アカウントを選びます。単一の組織テナントの場合は Directory (tenant) ID も貼り付けます。接続を選び、ブラウザーで目的のアカウントにサインインします。BusyMax は入力欄をローカルで確認し、Microsoft はブラウザーでのサインイン中に同意を求めます。';

  @override
  String get registrationGoogleImportFailed =>
      'このファイルをインポートできませんでした。有効なデスクトップ OAuth JSON を選択してください。以前の有効な設定は保持されます。';

  @override
  String get registrationGoogleSetupInstructions => 'Google の設定手順';

  @override
  String get registrationMicrosoftSetupInstructions => 'Microsoft の設定手順';

  @override
  String get registrationDesktopConfiguration => 'デスクトップ OAuth 設定';

  @override
  String get registrationNoFileSelected => 'ファイルが選択されていません';

  @override
  String get registrationChooseFile => 'ファイルを選択…';

  @override
  String get registrationReplaceFile => '置き換え…';

  @override
  String get registrationGoogleIntroduction =>
      'ご自身の Google Cloud プロジェクトのデスクトップ OAuth JSON を選択してください。';

  @override
  String get registrationMicrosoftIntroduction =>
      'ご自身の Microsoft アプリ登録の情報を入力してください。';

  @override
  String get registrationSetupInstructions => '設定手順';

  @override
  String get registrationInstructionsDescription => 'アカウントの接続に必要な設定を作成します。';

  @override
  String get registrationEnableApis => 'Calendar と Tasks を有効にする';

  @override
  String get registrationConsentScreen => '同意画面を設定する';

  @override
  String get registrationAppName => 'アプリ名';

  @override
  String get registrationScopes => 'スコープ';

  @override
  String get registrationRedirectUri => 'リダイレクト URI';

  @override
  String get registrationOpenApiLibrary => 'Google API ライブラリを開く';

  @override
  String get registrationOpenBranding => 'Google Auth Platform の Branding を開く';

  @override
  String get registrationOpenDataAccess =>
      'Google Auth Platform の Data Access を開く';

  @override
  String get registrationOpenClients => 'Google Auth Platform の Clients を開く';

  @override
  String get registrationOpenEntraAuthentication =>
      'Authentication 用に Entra のアプリ登録を開く';

  @override
  String get registrationOpenEntraPermissions =>
      'API permissions 用に Entra のアプリ登録を開く';

  @override
  String get registrationCopy => 'コピー';

  @override
  String get registrationCopyAll => 'すべてコピー';

  @override
  String get registrationGuideGoogleApis =>
      'APIs & Services → Library に移動します。Google Calendar API を検索し、ページを開いて Enable を選択します。Library に戻り、Google Tasks API でも同じ操作を行います。';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Supported account types で、個人用は Personal accounts only、組織用は Multiple Entra ID tenants、両方は Any Entra ID Tenant + Personal Microsoft accounts、このディレクトリのみは Single tenant only を選びます。Register を選択します。Overview で Application (client) ID をコピーし、単一テナントの場合は Directory (tenant) ID もコピーします。BusyMax で同じ対応アカウントを選びます。';

  @override
  String get registrationConnectBusyMax => 'BusyMax で接続';

  @override
  String get registrationRecommended => '推奨';

  @override
  String get registrationOtherMethods => 'その他の接続方法';

  @override
  String get registrationWorkspace => 'Google Workspace 組織';

  @override
  String get registrationGoogleCustom => 'カスタム OAuth クライアント';

  @override
  String get registrationMicrosoftCustom => 'カスタム アプリ登録';

  @override
  String get registrationMethodsIntroduction => 'アカウントの接続方法を選んでください。';

  @override
  String get registrationWorkspaceDescription => '組織が管理する設定を使用します。';

  @override
  String get registrationCustomDescription => '自分で管理する登録を使用します。';

  @override
  String get registrationSharedUnavailable =>
      'このビルドでは BusyMax による接続を利用できません。以下の別の接続方法を使用できます。';

  @override
  String get registrationWorkspaceIntroduction =>
      '組織が提供または管理するデスクトップ OAuth JSON を選びます。ファイルから組織の所有権、対象ユーザー、確認状況は証明できません。';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Google Workspace セットアップ手順';

  @override
  String get registrationBusyMaxManaged => 'BusyMax が管理する登録';

  @override
  String get registrationBranding => 'ブランドとドメインを設定';

  @override
  String get registrationPublishing => '通常の使用向けに公開';

  @override
  String get registrationOpenAudience => 'Google Auth Platform の Audience を開く';

  @override
  String get registrationGuideWorkspaceProject =>
      '管理者から Desktop OAuth JSON を受け取るか、Google Cloud Console で Google Workspace 組織が所有するプロジェクトを選択します。作成する場合は［リソースの管理］→［プロジェクトを作成］を開き、［プロジェクト名］を入力し、［親リソース］で組織またはそのフォルダを選んで［作成］を選択します。以降もそのプロジェクトを選択してください。作成には Project Creator、OAuth 設定には OAuth Config Editor、API 有効化には Service Usage Admin または同等の権限が必要です。操作が制限される場合は管理者に相談してください。';

  @override
  String get registrationGuideGoogleBranding =>
      'Branding → App domain でプロジェクトの承認済みドメインを追加してから、ホームページ、プライバシー、利用規約の URL を入力し、Save を選びます。External の本番アプリにはこれらのリンクが必要です。自身のドメインを使い、Google がブランド確認を求める場合は Search Console で所有権を確認します。下の BusyMax のプライバシーリンクはプロジェクトによる busystack.org の所有を証明しません。';

  @override
  String get registrationGuideGooglePublishing =>
      'Audience で Publish app を選び、In production を確認します。通常の使用を Testing のままにしないでください。この Calendar/Tasks の認可と更新トークンは 7 日で期限切れになります。公開と確認は別です。100 人未満の個人利用は警告と人数制限付きで確認を免除される場合があります。広い配布にはブランドとスコープの承認が必要な場合があります。本番の認可も期限切れや取り消しになることがあります。';

  @override
  String get registrationGuideWorkspacePermissions =>
      '管理者とこれらのスコープを確認します。Internal アプリは同意画面へのスコープの記載は不要です。求められた場合は Data Access → Add or remove scopes で値を追加し、Update、Save を選びます。管理者の制限で認可が制限される場合があります。';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      '共有カレンダーとカテゴリの権限は、これらの任意機能を有効にするときに別途求められます。上の必須設定に追加しないでください。';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Google Auth Platform → Branding に移動します。未設定の場合は Get started を選択します。App name に BusyMax を入力し、ご自身の User support email を選んで Next を選択します。Audience ではInternal を選びます。Next を選び、Contact Information にメールアドレスを入力して Next を選択します。User Data Policy に同意し、Continue、Create の順に選択します。設定済みの場合は Branding と Audience を確認します。\n\nInternal はプロジェクトの親組織のアカウントのみ利用でき、管理者の制限も適用されます。テストユーザーの一覧は不要です。BusyMax はダウンロードした JSON からこれらの設定を確認できません。';

  @override
  String get contactsTitle => '連絡先';

  @override
  String get contactsLinkedDescription =>
      '予定のゲストを追加するときに、このアカウントのキャッシュ済み連絡先を使用します。';

  @override
  String get contactsEnableSuggestions => '連絡先の候補を有効にする';

  @override
  String get contactsReadPermissionDescription => '連絡先への読み取り専用アクセスを要求します';

  @override
  String get contactsEnableEditing => '連絡先の編集を有効にする';

  @override
  String get contactsWritePermissionDescription => '連絡先への読み取りおよび書き込みアクセスを要求します';

  @override
  String get contactsSuggestionsEnabled => '連絡先の候補が有効です';

  @override
  String get contactsNeedsAttention => '連絡先の確認が必要です';

  @override
  String get contactsReadWriteAccess => '読み取りおよび書き込みアクセス';

  @override
  String get contactsDisableForAccount => 'このアカウントの連絡先を無効にする';

  @override
  String get contactsOnlyDescription => 'これらのソースはカレンダーおよびタスクのアカウントから独立しています。';

  @override
  String get contactsAddCardDav => 'CardDAV の連絡先を追加';

  @override
  String get contactsAddNextcloud => 'Nextcloud の連絡先を追加';

  @override
  String get contactsUseForAttendees => '出席者の候補に使用';

  @override
  String get contactsServerUrlLabel => 'HTTPS サーバーの URL';

  @override
  String get contactsUsernameLabel => 'ユーザー名';

  @override
  String get contactsPasswordLabel => 'パスワード';
}
