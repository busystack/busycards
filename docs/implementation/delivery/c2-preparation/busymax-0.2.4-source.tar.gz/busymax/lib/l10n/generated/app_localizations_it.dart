// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Italian (`it`).
class AppLocalizationsIt extends AppLocalizations {
  AppLocalizationsIt([String locale = 'it']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax è stato avviato dalle impostazioni di avvio del desktop. Rimuovi la sua voce da lì, poi esci da BusyMax e riaprilo per usare questo interruttore.';

  @override
  String get timeFormat => 'Formato ora';

  @override
  String get firstDayOfWeek => 'Primo giorno della settimana';

  @override
  String get systemDefault => 'Predefinito di sistema';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Predefinito di sistema ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 ore';

  @override
  String get timeFormatTwentyFourHour => '24 ore';

  @override
  String get timeEndOfDay => 'fine giornata';

  @override
  String get timePeriod => 'Periodo del giorno';

  @override
  String get launchAtLoginReadFailed =>
      'Impossibile determinare lo stato dell’avvio all’accesso.';

  @override
  String get launchAtLoginUnavailable =>
      'L’avvio all’accesso non è disponibile su questo sistema.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'L’avvio automatico è attivato dall’amministratore e non può essere modificato qui.';

  @override
  String get settingsSaveFailed =>
      'Impossibile salvare le impostazioni. Le modifiche potrebbero andare perse al riavvio di BusyMax.';

  @override
  String get nextcloudExportCollection => 'Esporta risorse della raccolta';

  @override
  String nextcloudImportItems(int count) {
    return 'Trovate $count risorse di eventi/attività';
  }

  @override
  String get nextcloudSchedulingInbox => 'Posta in arrivo degli inviti';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud elabora questi messaggi nei calendari. La conferma rimuove solo il messaggio, non l’evento.';

  @override
  String get nextcloudInboxEmpty => 'Nessun messaggio di pianificazione.';

  @override
  String get nextcloudAcknowledge => 'Conferma ricezione';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Rimuovere questo messaggio dalla posta in arrivo? L’evento verrà conservato.';

  @override
  String get nextcloudGuestAvailability =>
      'Verifica disponibilità degli invitati';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Conservazione nel cestino del server: $days giorni';
  }

  @override
  String get nextcloudCancelMeeting => 'Annulla riunione';

  @override
  String get nextcloudDeclineAndRemove => 'Rifiuta e rimuovi invito';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Alla sincronizzazione verrà inviato un rifiuto. La riunione dell’organizzatore non verrà annullata.';

  @override
  String get nextcloudAvailabilityUnknown => 'Disponibilità sconosciuta';

  @override
  String get nextcloudAvailabilityFree =>
      'Nessun periodo occupato segnalato per questo intervallo';

  @override
  String get nextcloudAvailabilityBusy => 'Periodi occupati';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud invierà gli aggiornamenti alla sincronizzazione. Il salvataggio locale non conferma la consegna.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Solo l’organizzatore o un delegato autorizzato può modificare i dettagli. Puoi rispondere all’invito dai suoi dettagli.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'Questa riunione non può essere spostata copiandola ed eliminandola. Usa un calendario con la stessa identità di pianificazione.';

  @override
  String get nextcloudSchedulingStatus => 'Stato di pianificazione del server';

  @override
  String get nextcloudImportFollowUp =>
      'Le risorse importate sono salvate localmente. L’aggiornamento dei promemoria è in attesa; non importarle di nuovo.';

  @override
  String get nextcloudNativeImport =>
      'Importa eventi e attività completi senza inviare inviti. Gli UID esistenti vengono ignorati salvo la scelta di nuove copie. Le risorse non supportate sono segnalate singolarmente.';

  @override
  String get nextcloudImportMethod =>
      'Il file contiene messaggi di pianificazione. L’importazione ne salva il contenuto e rimuove METHOD; non elabora inviti o risposte.';

  @override
  String get nextcloudImportCopies => 'Importa nuove copie con nuove identità';

  @override
  String get nextcloudCollectionSettings => 'Impostazioni della raccolta';

  @override
  String get nextcloudSharing => 'Condivisione';

  @override
  String get nextcloudOwned => 'Di proprietà';

  @override
  String get nextcloudShared => 'Condivisa';

  @override
  String get nextcloudDelegated => 'Delegata';

  @override
  String get nextcloudSubscription => 'Abbonamento';

  @override
  String get nextcloudDeleted => 'Eliminata';

  @override
  String get nextcloudMetadataEditable =>
      'Il contenuto è di sola lettura; le proprietà della raccolta sono modificabili.';

  @override
  String get nextcloudServerOrder =>
      'Ordine sul server (separato dalla barra laterale)';

  @override
  String get nextcloudCalendarEnabled => 'Abilitata sul server';

  @override
  String get nextcloudAvailability =>
      'Includi questa raccolta nella disponibilità';

  @override
  String get nextcloudCalendarTimezone =>
      'Fuso orario del calendario (documento VTIMEZONE)';

  @override
  String get nextcloudRefreshPending =>
      'La modifica è salvata su Nextcloud. L’aggiornamento è in attesa; non ripetere la modifica.';

  @override
  String get nextcloudOutcomeUnknown =>
      'Impossibile confermare l’esito sul server. Aggiorna prima di riprovare.';

  @override
  String get nextcloudRemoveShared => 'Rimuovi calendario/elenco condiviso';

  @override
  String get nextcloudRemoveMixed =>
      'Questa raccolta contiene eventi e attività. Eliminandola verranno rimossi entrambi.';

  @override
  String get nextcloudReadAccess => 'Sola lettura';

  @override
  String get nextcloudWriteAccess => 'Lettura e scrittura';

  @override
  String get nextcloudRecipientSearch => 'Cerca persone o gruppi';

  @override
  String get nextcloudNoRecipients =>
      'Nessuna persona o gruppo corrispondente.';

  @override
  String get nextcloudRevokeShare => 'Revoca accesso';

  @override
  String get nextcloudPublish => 'Pubblica collegamento';

  @override
  String get nextcloudUnpublish => 'Interrompi pubblicazione';

  @override
  String get nextcloudPublishWarning =>
      'Chiunque abbia il collegamento pubblicato potrebbe leggere il calendario. Pubblicarlo?';

  @override
  String get nextcloudTrash => 'Calendari e attività eliminati';

  @override
  String get nextcloudTrashEmpty => 'Nessun elemento di calendario eliminato.';

  @override
  String get nextcloudRestore => 'Ripristina';

  @override
  String get nextcloudPermanentDelete => 'Elimina definitivamente';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Eliminare definitivamente questo elemento? Non potrà essere ripristinato dal cestino dei calendari Nextcloud.';

  @override
  String get nextcloudOperationDenied =>
      'Nextcloud non ha consentito questa operazione.';

  @override
  String get nextcloudUnsupported =>
      'Il server non supporta questa operazione.';

  @override
  String get nextcloudPendingChanges =>
      'Salva o scarta le modifiche alla raccolta prima di chiudere.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud non è raggiungibile. Gli elementi in cache e le modifiche in attesa restano invariati.';

  @override
  String get mapsShow => 'Mostra sulla mappa';

  @override
  String get openLink => 'Apri link';

  @override
  String get externalLocationOpenFailed =>
      'Non è stato possibile aprire il luogo in un’app esterna.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'Impossibile riprogrammare l’evento. L’orario salvato non è stato modificato.';

  @override
  String get scheduleRescheduleStale =>
      'Questo evento è cambiato durante il trascinamento. Riprova.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'Il nuovo orario è stato salvato, ma non è stato possibile aggiornare i promemoria.';

  @override
  String get moveUp => 'Sposta su';

  @override
  String get moveDown => 'Sposta giù';

  @override
  String get windowsSupport => 'Supporto';

  @override
  String get windowsThirdPartyLicenses => 'Licenze di terze parti';

  @override
  String get windowsSearch => 'Cerca';

  @override
  String get windowsStartupDisabledByUser =>
      'Disabilitato dall’utente nelle impostazioni di Windows.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Disabilitato da un criterio di Windows.';

  @override
  String get windowsStartupUnavailable =>
      'Disponibile dopo l’installazione di BusyMax da un pacchetto MSIX.';

  @override
  String get windowsReminderExitNotice =>
      'I promemoria si interrompono quando BusyMax viene chiuso completamente. Lascialo in esecuzione in background per riceverli.';

  @override
  String get windowsProductVersionLabel => 'Versione del prodotto';

  @override
  String get windowsPackageVersionLabel => 'Versione del pacchetto Windows';

  @override
  String get windowsUnpackaged => 'Non pacchettizzato';

  @override
  String get windowsAgendaLoadMore => 'Carica altri elementi dell’agenda';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'il lunedì',
      'TU': 'il martedì',
      'WE': 'il mercoledì',
      'TH': 'il giovedì',
      'FR': 'il venerdì',
      'SA': 'il sabato',
      'SU': 'la domenica',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'nei giorni $first e $second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency nei giorni $firstDay e $secondDay di $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency il giorno $day di $firstMonth e $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency nei giorni $firstDay e $secondDay di $firstMonth e $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency nei giorni $days di $firstMonth e $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Collega gli account Google, Microsoft, Calendario Apple iCloud o Nextcloud.';

  @override
  String get googlePermissionsConsentNotice =>
      'Nella schermata delle autorizzazioni di Google, seleziona sia l’autorizzazione per il calendario sia quella per le attività.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Sono necessarie le autorizzazioni per Google Calendar e Google Tasks. Riprova e seleziona entrambe le caselle.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'Questo servizio non è configurato.';

  @override
  String get waitingForGoogleSignIn => 'In attesa dell’accesso a Google...';

  @override
  String get waitingForMicrosoftSignIn =>
      'In attesa dell’accesso a Microsoft...';

  @override
  String get microsoftSignInNotConfigured =>
      'L’accesso a Microsoft non è configurato. Imposta MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Annulla';

  @override
  String get close => 'Chiudi';

  @override
  String get windowMinimize => 'Riduci';

  @override
  String get windowMaximize => 'Ingrandisci';

  @override
  String get windowRestore => 'Ripristina';

  @override
  String get exit => 'Esci';

  @override
  String get options => 'Opzioni';

  @override
  String get hide => 'Nascondi';

  @override
  String get show => 'Mostra';

  @override
  String get export => 'Esporta';

  @override
  String get save => 'Salva';

  @override
  String get settings => 'Impostazioni';

  @override
  String get all => 'Tutto';

  @override
  String get calendarEvents => 'Eventi';

  @override
  String get calendarTasks => 'Attività';

  @override
  String get calendar => 'Calendario';

  @override
  String get calendars => 'Calendari';

  @override
  String get newCalendar => 'Nuovo calendario';

  @override
  String get calendarColor => 'Colore del calendario';

  @override
  String calendarColorOption(int number) {
    return 'Colore $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'Questo provider non supporta la gestione dei calendari in BusyMax.';

  @override
  String get primaryCalendarCannotDelete =>
      'Il calendario principale non può essere eliminato.';

  @override
  String calendarCreateFailed(String error) {
    return 'Impossibile creare il calendario: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'Il calendario è stato creato, ma BusyMax non ha potuto aggiornare l’account. Apparirà dopo la prossima sincronizzazione.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Impossibile aggiornare il calendario: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Impossibile eliminare il calendario: $error';
  }

  @override
  String get newEvent => 'Nuovo evento';

  @override
  String get refreshCalendar => 'Aggiorna calendario';

  @override
  String get openInProvider => 'Apri nel servizio';

  @override
  String get linkedResources => 'Risorse collegate';

  @override
  String get noLinkedResources => 'Nessuna risorsa collegata';

  @override
  String get attachments => 'Allegati';

  @override
  String get attachmentsNotLoaded => 'Allegati non caricati';

  @override
  String get hideFromSchedule => 'Nascondi dall’agenda';

  @override
  String get showInSchedule => 'Mostra nell’agenda';

  @override
  String get noCalendarsSynced => 'Nessun calendario ancora sincronizzato.';

  @override
  String get allDay => 'Tutto il giorno';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString in più';
  }

  @override
  String get noEventsOrTasks => 'Nessun evento o attività';

  @override
  String get scheduleLoading => 'Caricamento agenda...';

  @override
  String get scheduleUnavailable => 'Agenda non disponibile';

  @override
  String get scheduleNoSources =>
      'Nessun calendario o elenco di attività visibile';

  @override
  String get scheduleNoSourcesDescription =>
      'Scegli cosa mostrare nelle Impostazioni, quindi aggiorna l’agenda.';

  @override
  String get scheduleNoSearchResults =>
      'Nessun evento o attività corrispondente';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Prova una ricerca diversa o cancella i filtri attuali.';

  @override
  String get refresh => 'Aggiorna';

  @override
  String get trayOpenBusyMax => 'Apri BusyMax';

  @override
  String get trayShowBusyMax => 'Mostra BusyMax';

  @override
  String get trayNewEvent => 'Nuovo evento…';

  @override
  String get trayNewTask => 'Nuova attività…';

  @override
  String get trayToday => 'Oggi';

  @override
  String get trayAllDay => 'Tutto il giorno';

  @override
  String get trayNow => 'Adesso';

  @override
  String get trayCalendarEvent => 'Evento del calendario';

  @override
  String get trayUntitledEvent => 'Evento senza titolo';

  @override
  String get trayNothingElseToday => 'Nient’altro oggi';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count attività scadono oggi',
      one: '1 attività scade oggi',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Apri l’agenda di oggi';

  @override
  String get traySyncNow => 'Sincronizza ora';

  @override
  String get traySyncing => 'Sincronizzazione…';

  @override
  String get trayNotConnected => 'Non connesso';

  @override
  String get trayNotYetSynced => 'Non ancora sincronizzato';

  @override
  String get trayLastSyncedJustNow => 'Sincronizzato proprio ora';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizzato $count minuti fa',
      one: 'Sincronizzato 1 minuto fa',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizzato $count ore fa',
      one: 'Sincronizzato 1 ora fa',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizzato $count giorni fa',
      one: 'Sincronizzato 1 giorno fa',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Impostazioni';

  @override
  String get trayQuitBusyMax => 'Esci da BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Carica altre attività scadute';

  @override
  String get agendaLoadMoreNoDate => 'Carica altre attività senza data';

  @override
  String get viewDay => 'Giorno';

  @override
  String get viewWeek => 'Settimana';

  @override
  String get viewMonth => 'Mese';

  @override
  String get viewYear => 'Anno';

  @override
  String get viewAgenda => 'Vista agenda';

  @override
  String get scheduleSettings => 'Agenda';

  @override
  String get scheduleDisplaySettings => 'Visualizzazione agenda';

  @override
  String get newEventsAndTasks => 'Nuovi eventi e attività';

  @override
  String get defaultCalendar => 'Calendario predefinito';

  @override
  String get defaultTaskList => 'Elenco attività predefinito';

  @override
  String get lastUsed => 'Ultimo utilizzato';

  @override
  String get scheduleDisplayHoursDescription =>
      'Le viste Giorno e Settimana mostrano inizialmente questo intervallo orario. Gli elementi precedenti o successivi lo estendono quando necessario.';

  @override
  String get scheduleDayStartsAt => 'Inizio giornata';

  @override
  String get scheduleDayEndsAt => 'Fine giornata';

  @override
  String get sourceCalendar => 'Calendario';

  @override
  String get sourceTaskList => 'Elenco di attività';

  @override
  String get createChoiceTitle => 'Crea';

  @override
  String get createEventAtTime => 'Evento';

  @override
  String get createTaskAtDate => 'Attività';

  @override
  String get editEvent => 'Modifica evento';

  @override
  String get eventTitle => 'Titolo dell’evento';

  @override
  String get location => 'Luogo';

  @override
  String get timeSlot => 'Fascia oraria';

  @override
  String get startDateTime => 'Data/ora di inizio';

  @override
  String get endDateTime => 'Data/ora di fine';

  @override
  String get doesNotRepeat => 'Non si ripete';

  @override
  String get defaultReminder => 'Promemoria predefinito';

  @override
  String get guests => 'Invitati';

  @override
  String get noGuests => 'Nessun invitato';

  @override
  String get attendeeRequired => 'Obbligatorio';

  @override
  String get attendeeOptional => 'Facoltativo';

  @override
  String get meetingSection => 'Riunione';

  @override
  String get addGoogleMeet => 'Aggiungi Google Meet';

  @override
  String get addTeamsMeeting => 'Aggiungi riunione Microsoft Teams';

  @override
  String get onlineMeetingAdded => 'Riunione online aggiunta';

  @override
  String get requestResponses => 'Richiedi risposte';

  @override
  String get requestResponsesDescription =>
      'Chiedi agli invitati di rispondere all’invito.';

  @override
  String get hideGuestList => 'Nascondi elenco invitati';

  @override
  String get hideGuestListDescription =>
      'Gli invitati non possono vedere chi altro è stato invitato.';

  @override
  String get allowNewTimeProposals => 'Consenti nuove proposte di orario';

  @override
  String get allowNewTimeProposalsDescription =>
      'Gli invitati possono suggerire un altro orario per la riunione.';

  @override
  String get notifyGuestsTitle => 'Notificare gli invitati?';

  @override
  String get notifyGuestsSaveMessage =>
      'Questa riunione ha degli invitati. Inviare inviti o aggiornamenti dell’evento al salvataggio?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Questa riunione ha degli invitati. Inviare una cancellazione quando viene eliminata?';

  @override
  String get sendUpdates => 'Invia aggiornamenti';

  @override
  String get sendCancellation => 'Invia cancellazione';

  @override
  String get doNotSend => 'Non inviare';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Salvare la riunione?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft invierà inviti o aggiornamenti dell’evento agli invitati.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Eliminare la riunione?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft invierà una cancellazione agli invitati.';

  @override
  String get organizer => 'Organizzatore';

  @override
  String get yourResponse => 'La tua risposta';

  @override
  String get guestResponses => 'Risposte degli invitati';

  @override
  String get respond => 'Rispondi';

  @override
  String get acceptInvitation => 'Accetta';

  @override
  String get tentativeInvitation => 'Provvisorio';

  @override
  String get declineInvitation => 'Rifiuta';

  @override
  String get joinMeeting => 'Partecipa alla riunione';

  @override
  String get responseAccepted => 'Accettata';

  @override
  String get responseTentative => 'Provvisoria';

  @override
  String get responseDeclined => 'Rifiutata';

  @override
  String get responseNeedsAction => 'In attesa di risposta';

  @override
  String get responseNotResponded => 'Nessuna risposta';

  @override
  String get responseOrganizer => 'Organizzatore';

  @override
  String invitationResponseFailed(String error) {
    return 'Impossibile inviare la risposta: $error';
  }

  @override
  String get joinMeetingFailed => 'Impossibile aprire il link della riunione.';

  @override
  String get description => 'Descrizione';

  @override
  String get availabilityShowAs => 'Disponibilità / Mostra come';

  @override
  String get busy => 'Occupato';

  @override
  String get visibility => 'Visibilità';

  @override
  String get defaultVisibility => 'Visibilità predefinita';

  @override
  String get conference => 'Conferenza';

  @override
  String get noConference => 'Nessuna conferenza';

  @override
  String get providerCalendar => 'Calendario del servizio';

  @override
  String get formatBoldShortLabel => 'G';

  @override
  String get formatBoldTooltip => 'Grassetto';

  @override
  String get formatItalicShortLabel => 'C';

  @override
  String get formatItalicTooltip => 'Corsivo';

  @override
  String get formatUnderlineShortLabel => 'S';

  @override
  String get formatUnderlineTooltip => 'Sottolineato';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString minuti prima',
      one: '1 minuto prima',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'All’inizio';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString ore prima',
      one: '1 ora prima',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString giorni prima',
      one: '1 giorno prima',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Libero';

  @override
  String get availabilityTentative => 'Provvisorio';

  @override
  String get availabilityOutOfOffice => 'Fuori sede';

  @override
  String get availabilityWorkingElsewhere => 'Lavora altrove';

  @override
  String get visibilityDefault => 'Predefinita';

  @override
  String get visibilityPublic => 'Pubblica';

  @override
  String get visibilityPrivate => 'Privata';

  @override
  String get visibilityConfidential => 'Riservata';

  @override
  String get sensitivityNormal => 'Normale';

  @override
  String get sensitivityPersonal => 'Personale';

  @override
  String get tasks => 'Attività';

  @override
  String get allTasks => 'Tutte le attività';

  @override
  String tasksInList(String title) {
    return 'Attività in $title';
  }

  @override
  String get taskLists => 'Elenchi di attività';

  @override
  String get navigation => 'Navigazione';

  @override
  String get mainMenu => 'Menu principale';

  @override
  String get keyboardShortcuts => 'Scorciatoie da tastiera';

  @override
  String get shortcutGroupGeneral => 'Generali';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Mostra questo elenco di scorciatoie';

  @override
  String get shortcutGroupNavigation => 'Navigazione';

  @override
  String get shortcutNextPeriod => 'Periodo successivo';

  @override
  String get shortcutNextPeriodDescription =>
      'Settimana successiva nella vista settimanale, mese successivo nella vista mensile e così via';

  @override
  String get shortcutPreviousPeriod => 'Periodo precedente';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Settimana precedente nella vista settimanale, mese precedente nella vista mensile e così via';

  @override
  String get shortcutJumpToToday => 'Vai alla data odierna';

  @override
  String get shortcutGroupView => 'Vista';

  @override
  String get viewSelector => 'Vista';

  @override
  String get shortcutDayView => 'Vista giornaliera';

  @override
  String get shortcutWeekView => 'Vista settimanale';

  @override
  String get shortcutMonthView => 'Vista mensile';

  @override
  String get shortcutYearView => 'Vista annuale';

  @override
  String get shortcutAgendaView => 'Vista agenda';

  @override
  String get shortcutGroupCreateAndEdit => 'Creazione e modifica';

  @override
  String get shortcutSaveItem => 'Salva evento o attività';

  @override
  String get shortcutDeleteItem => 'Elimina evento o attività';

  @override
  String get shortcutGroupTaskEditing => 'Modifica delle attività';

  @override
  String get shortcutCancelEditing => 'Annulla modifica';

  @override
  String get shortcutCancelEditingDescription =>
      'Chiudi la modifica o i dettagli dell’attività';

  @override
  String get aboutBusyMax => 'Informazioni su BusyMax';

  @override
  String get aboutBusyMaxDescription => 'Calendario e attività';

  @override
  String get license => 'Licenza';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Sito web';

  @override
  String get sourceCode => 'Codice sorgente';

  @override
  String get reportAnIssue => 'Segnala un problema';

  @override
  String get sendFeedback => 'Invia feedback';

  @override
  String get feedbackSubmit => 'Invia';

  @override
  String get feedbackCategory => 'Categoria';

  @override
  String get feedbackSelectCategory => 'Seleziona una categoria';

  @override
  String get feedbackCategoryProblem => 'Problema o errore';

  @override
  String get feedbackCategoryFeature => 'Richiesta di funzionalità';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'Problema di privacy o sicurezza';

  @override
  String get feedbackCategoryUsability => 'Problema di usabilità';

  @override
  String get feedbackCategoryOther => 'Altro';

  @override
  String get feedbackSubject => 'Oggetto';

  @override
  String get feedbackDetailedMessage => 'Messaggio dettagliato';

  @override
  String get feedbackReplyEmail =>
      'Indirizzo email per la risposta (facoltativo)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Includi dettagli tecnici';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Aggiunge soltanto il nome e la versione del sistema operativo e le impostazioni locali dell’applicazione. Non vengono inclusi log, dati degli account, nomi di file o altre informazioni diagnostiche.';

  @override
  String get feedbackCategoryRequired => 'Seleziona una categoria.';

  @override
  String get feedbackSubjectLengthError =>
      'L’oggetto deve contenere da 3 a 120 caratteri.';

  @override
  String get feedbackMessageLengthError =>
      'Il messaggio deve contenere da 10 a 5.000 caratteri.';

  @override
  String get feedbackInvalidEmail => 'Inserisci un indirizzo email valido.';

  @override
  String get feedbackConnectionError =>
      'Impossibile connettersi a BusyStack. Controlla la connessione e riprova.';

  @override
  String get feedbackTimeoutError =>
      'La richiesta ha superato il tempo limite. Il feedback non è stato cancellato; riprova.';

  @override
  String get feedbackRateLimitedError =>
      'Sono stati inviati troppi feedback da questa rete. Attendi e riprova.';

  @override
  String get feedbackRejectedError =>
      'Il server ha rifiutato l’invio. Controlla i campi e riprova.';

  @override
  String get feedbackServerError =>
      'BusyStack non può accettare il feedback in questo momento. Il feedback non è stato cancellato; riprova.';

  @override
  String feedbackSuccess(String id) {
    return 'Feedback inviato. Riferimento: $id';
  }

  @override
  String get toggleSidebar => 'Mostra o nascondi la barra laterale';

  @override
  String get showSidebar => 'Mostra il pannello laterale';

  @override
  String get hideSidebar => 'Nascondi il pannello laterale';

  @override
  String get accounts => 'Account';

  @override
  String get currentAccount => 'Account attuale';

  @override
  String get switchAccount => 'Cambia account';

  @override
  String get addGoogleAccount => 'Aggiungi account Google';

  @override
  String get addMicrosoftAccount => 'Aggiungi account Microsoft';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Accesso effettuato';

  @override
  String get removeAccount => 'Rimuovi account…';

  @override
  String get removingAccount => 'Rimozione account…';

  @override
  String get removeAccountDescription =>
      'Interrompi la sincronizzazione e rimuovi i dati di questo account dal dispositivo.';

  @override
  String removeAccountTitle(String account) {
    return 'Rimuovere $account da BusyMax?';
  }

  @override
  String get removeAccountConfirmation =>
      'Questa operazione elimina da questo dispositivo attività, calendari, eventi, promemoria e modifiche offline in sospeso memorizzati nella cache. Le modifiche non sincronizzate andranno perse. Le copie del provider non verranno eliminate.';

  @override
  String get revokeGoogleAccess =>
      'Revoca anche l’accesso di BusyMax a questo account Google';

  @override
  String get revokeGoogleAccessDescription =>
      'Dovrai concedere nuovamente l’accesso prima di riconnetterti.';

  @override
  String get removeAccountAction => 'Rimuovi account';

  @override
  String get removeAccountFailed =>
      'Impossibile completare la rimozione dell’account. Riprova.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'L’account è stato rimosso da questo dispositivo, ma BusyMax non è riuscito a revocare il proprio accesso a Google. Puoi revocarlo dal tuo account Google.';

  @override
  String get newTaskList => 'Nuovo elenco di attività';

  @override
  String taskListCreateFailed(String error) {
    return 'Impossibile creare l’elenco di attività: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Impossibile rinominare l’elenco di attività: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Impossibile eliminare l’elenco di attività: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Sincronizza l’account oppure risolvi le modifiche bloccate di questo elenco di attività in Diagnostica prima di eliminare o rimuovere l’elenco.';

  @override
  String get signInToViewTaskLists =>
      'Accedi per visualizzare gli elenchi di attività.';

  @override
  String get noTaskListsSynced =>
      'Nessun elenco di attività ancora sincronizzato.';

  @override
  String get listActions => 'Azioni dell’elenco';

  @override
  String get rename => 'Rinomina';

  @override
  String get delete => 'Elimina';

  @override
  String get renameList => 'Rinomina elenco';

  @override
  String get deleteList => 'Elimina elenco';

  @override
  String get unshare => 'Rimuovi condivisione';

  @override
  String get readOnlyTaskListCannotRename =>
      'Questo elenco di attività è di sola lettura e non può essere rinominato.';

  @override
  String get taskListCannotDelete =>
      'Questo elenco di attività non può essere eliminato con le autorizzazioni attuali.';

  @override
  String get builtInMicrosoftList => 'Integrato';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Gli elenchi integrati di Microsoft To Do non possono essere rinominati o eliminati.';

  @override
  String deleteListConfirmation(String title) {
    return 'Eliminare “$title” da Google Tasks?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Eliminare “$title” e tutte le sue attività?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Rimuovere la condivisione di “$title” da questo account?';
  }

  @override
  String get deleteEvent => 'Elimina evento';

  @override
  String get title => 'Titolo';

  @override
  String get create => 'Crea';

  @override
  String get newTask => 'Nuova attività';

  @override
  String get clearCompleted => 'Cancella attività completate';

  @override
  String get refreshList => 'Aggiorna elenco';

  @override
  String get refreshAll => 'Aggiorna tutto';

  @override
  String get listRefreshed => 'Elenco aggiornato.';

  @override
  String get allTasksRefreshed => 'Tutti gli account sono stati aggiornati.';

  @override
  String exportedFile(String path) {
    return 'Esportato in $path';
  }

  @override
  String exportFailed(String error) {
    return 'Esportazione non riuscita: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Aggiornamento non riuscito: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Seleziona o crea un elenco di attività per iniziare.';

  @override
  String get signInToViewTasks => 'Accedi per visualizzare le attività.';

  @override
  String get noTasks => 'Nessuna attività.';

  @override
  String get noTasksYet => 'Ancora nessuna attività';

  @override
  String get noTasksYetMessage =>
      'Crea un’attività o aggiorna gli account per iniziare.';

  @override
  String get noTasksInList => 'Nessuna attività in questo elenco.';

  @override
  String get overdue => 'Scadute';

  @override
  String get today => 'Oggi';

  @override
  String get tomorrow => 'Domani';

  @override
  String get upcoming => 'In arrivo';

  @override
  String get noDate => 'Senza data';

  @override
  String get completed => 'Completate';

  @override
  String duePrefix(String date) {
    return 'Scadenza: $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => 'Dettagli attività';

  @override
  String get editTask => 'Modifica attività';

  @override
  String get noTaskSelected => 'Nessuna attività selezionata.';

  @override
  String get noTaskSelectedHelper =>
      'Seleziona un’attività per visualizzarne e modificarne i dettagli.';

  @override
  String get taskUnavailable => 'Attività non disponibile.';

  @override
  String get signInToEditTasks => 'Accedi per modificare le attività.';

  @override
  String get refreshTask => 'Aggiorna attività';

  @override
  String get primarySection => 'Principale';

  @override
  String get statusSection => 'Stato';

  @override
  String get openStatus => 'Aperta';

  @override
  String get doneStatus => 'Completata';

  @override
  String get taskStatus => 'Stato';

  @override
  String get taskStatusNone => 'Nessuno stato';

  @override
  String get taskStatusNeedsAction => 'Richiede azione';

  @override
  String get taskStatusInProcess => 'In corso';

  @override
  String get taskStatusCompleted => 'Completata';

  @override
  String get taskStatusCancelled => 'Annullata';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% completata';
  }

  @override
  String get completionDate => 'Data di completamento';

  @override
  String get priority => 'Priorità';

  @override
  String get priorityNone => 'Nessuna priorità';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorità $priorityString · alta';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorità $priorityString · media';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priorità $priorityString · bassa';
  }

  @override
  String get taskUrl => 'URL dell’attività';

  @override
  String get invalidTaskUrl => 'Inserisci un URL assoluto, incluso lo schema.';

  @override
  String get classification => 'Classificazione';

  @override
  String get classificationPublic =>
      'Quando condivisa, mostra l’attività completa';

  @override
  String get classificationConfidential =>
      'Quando condivisa, mostra solo lo stato occupato';

  @override
  String get classificationPrivate =>
      'Quando condivisa, nascondi questa attività';

  @override
  String get pinTask => 'Fissa attività';

  @override
  String get notes => 'Note';

  @override
  String get dueDate => 'Data di scadenza';

  @override
  String get clearDueDate => 'Cancella data di scadenza';

  @override
  String get dueTime => 'Ora di scadenza';

  @override
  String get startDate => 'Data di inizio';

  @override
  String get startTime => 'Ora di inizio';

  @override
  String get endDate => 'Data di fine';

  @override
  String get endTime => 'Ora di fine';

  @override
  String get reminderDate => 'Data del promemoria';

  @override
  String get reminderTime => 'Ora del promemoria';

  @override
  String get reminder => 'Promemoria';

  @override
  String get addReminder => 'Aggiungi promemoria';

  @override
  String get reminders => 'Promemoria';

  @override
  String get noReminders => 'Nessun promemoria';

  @override
  String get editReminder => 'Modifica promemoria';

  @override
  String get beforeTaskStarts => 'Prima dell’inizio dell’attività';

  @override
  String get beforeTaskDue => 'Prima della scadenza dell’attività';

  @override
  String get afterTaskStarts => 'Dopo l’inizio dell’attività';

  @override
  String get afterTaskDue => 'Dopo la scadenza dell’attività';

  @override
  String get relativeToTaskStart =>
      'Rispetto alla data di inizio dell’attività';

  @override
  String get relativeToTaskDue =>
      'Rispetto alla data di scadenza dell’attività';

  @override
  String get reminderTimeOfDay => 'Ora del giorno';

  @override
  String get absoluteReminder => 'A una data e un’ora';

  @override
  String get reminderAmount => 'Quantità';

  @override
  String get reminderUnit => 'Unità';

  @override
  String get reminderUnitSeconds => 'Secondi';

  @override
  String get reminderUnitMinutes => 'Minuti';

  @override
  String get reminderUnitHours => 'Ore';

  @override
  String get reminderUnitDays => 'Giorni';

  @override
  String get reminderUnitWeeks => 'Settimane';

  @override
  String get reminderAtTaskStart => 'All’inizio dell’attività';

  @override
  String get reminderAtTaskDue => 'Alla scadenza dell’attività';

  @override
  String get unsupportedReminder =>
      'Questo tipo di promemoria viene conservato, ma non è possibile modificarne l’ora.';

  @override
  String get relatedRemindersTitle => 'Conservare i promemoria correlati?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Questa data ha $countString promemoria correlati. Conservarli alla data e all’ora attuali?';
  }

  @override
  String get discardRelatedReminders => 'Scarta promemoria';

  @override
  String get keepRelatedReminders => 'Conserva promemoria';

  @override
  String get addGuest => 'Aggiungi invitato';

  @override
  String get addGuestEmail => 'Aggiungi email dell’invitato';

  @override
  String get removeReminder => 'Rimuovi promemoria';

  @override
  String get off => 'Disattivato';

  @override
  String get repeat => 'Ripeti';

  @override
  String get repeatNone => 'Nessuna ripetizione';

  @override
  String get noneValue => 'Nessuno';

  @override
  String get repeatDaily => 'Ogni giorno';

  @override
  String get repeatWeekly => 'Ogni settimana';

  @override
  String get repeatMonthly => 'Ogni mese';

  @override
  String get repeatYearly => 'Ogni anno';

  @override
  String get repeatEvery => 'Intervallo';

  @override
  String get repeatOn => 'Ripeti il';

  @override
  String get repeatEnd => 'Termina ripetizione';

  @override
  String get repeatNever => 'Mai';

  @override
  String get repeatUntil => 'In data';

  @override
  String get repeatAfter => 'Dopo un numero di occorrenze';

  @override
  String get repeatCount => 'Occorrenze';

  @override
  String get repeatDayOfMonth => 'Giorni del mese';

  @override
  String get repeatMonths => 'Mesi';

  @override
  String get repeatOrdinal => 'Posizione del giorno della settimana';

  @override
  String get repeatSpecificDays => 'Giorni specifici';

  @override
  String get repeatFirst => 'Primo';

  @override
  String get repeatSecond => 'Secondo';

  @override
  String get repeatThird => 'Terzo';

  @override
  String get repeatFourth => 'Quarto';

  @override
  String get repeatFifth => 'Quinto';

  @override
  String get repeatSecondToLast => 'Penultimo';

  @override
  String get repeatLast => 'Ultimo';

  @override
  String get repeatAnyDay => 'Giorno';

  @override
  String get repeatWeekday => 'Giorno feriale';

  @override
  String get repeatWeekendDay => 'Giorno del fine settimana';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'lunedì',
      'TU': 'martedì',
      'WE': 'mercoledì',
      'TH': 'giovedì',
      'FR': 'venerdì',
      'SA': 'sabato',
      'SU': 'domenica',
      'day': 'giorno',
      'weekday': 'giorno feriale',
      'weekend': 'giorno del fine settimana',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Ogni $countString giorni';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Ogni $countString settimane';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Ogni $countString mesi';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Ogni $countString anni';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'il giorno $days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'il primo $days',
      'second': 'il secondo $days',
      'third': 'il terzo $days',
      'fourth': 'il quarto $days',
      'fifth': 'il quinto $days',
      'secondToLast': 'il penultimo $days',
      'last': 'l’ultimo $days',
      'other': 'nei giorni $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'nei mesi $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString volte',
      one: '$countString volta',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'fino al $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'Questa regola di ricorrenza usa opzioni che questo editor non modifica.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'Questo elenco non supporta questo schema di ripetizione. Modifica lo schema o scegli un altro elenco.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Aggiungi una data di inizio o di scadenza per usare questo schema di ripetizione, oppure disattiva la ripetizione.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Questa ricorrenza non può essere usata con $provider.';
  }

  @override
  String get importance => 'Importanza';

  @override
  String get importanceLow => 'Bassa';

  @override
  String get importanceNormal => 'Normale';

  @override
  String get importanceHigh => 'Alta';

  @override
  String get categories => 'Categorie';

  @override
  String get scheduleSection => 'Programmazione';

  @override
  String get dueGroup => 'Scadenza';

  @override
  String get startGroup => 'Inizio';

  @override
  String get reminderGroup => 'Promemoria';

  @override
  String get organizationSection => 'Organizzazione';

  @override
  String get actionsSection => 'Azioni';

  @override
  String get advancedSection => 'Avanzate';

  @override
  String get addCategory => 'Aggiungi categoria';

  @override
  String get list => 'Elenco';

  @override
  String get microsoftMoveUnsupported =>
      'In questa versione non è possibile spostare attività tra elenchi negli account Microsoft To Do.';

  @override
  String get createSubtask => 'Crea sottoattività';

  @override
  String get subtasks => 'Sottoattività';

  @override
  String get duplicateTask => 'Duplica attività';

  @override
  String get taskDuplicated => 'Attività duplicata.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Impossibile duplicare l’attività: $error';
  }

  @override
  String get hideSubtasks => 'Nascondi sottoattività';

  @override
  String get hideClosedSubtasks => 'Nascondi sottoattività chiuse';

  @override
  String get moveToTop => 'Sposta in cima';

  @override
  String get deleteTask => 'Elimina attività';

  @override
  String get newSubtask => 'Nuova sottoattività';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Eliminare «$title»?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Questa operazione elimina anche l’attività originale in Google Docs o negli spazi di Chat.';

  @override
  String get metadata => 'Metadati';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Aggiornato';

  @override
  String get parent => 'Attività principale';

  @override
  String get position => 'Posizione';

  @override
  String get webLink => 'Collegamento web';

  @override
  String get assignment => 'Assegnazione';

  @override
  String get localState => 'Stato locale';

  @override
  String get pendingSync => 'Sincronizzazione in sospeso';

  @override
  String get synced => 'Sincronizzato';

  @override
  String get account => 'Profilo';

  @override
  String get sync => 'Sincronizzazione';

  @override
  String get forceFullResync => 'Forza una risincronizzazione completa';

  @override
  String get forceFullResyncDescription =>
      'Ricarica completamente i dati di ogni account connesso. Usa questa opzione solo per risolvere problemi di sincronizzazione.';

  @override
  String get runInBackgroundWhenClosed =>
      'Continua a funzionare quando la finestra è chiusa';

  @override
  String get showTrayIcon => 'Mostra icona nell’area di notifica';

  @override
  String get startMinimizedToTray =>
      'Avvia ridotto a icona nell’area di notifica';

  @override
  String get launchAtLogin => 'Avvia all’accesso';

  @override
  String get launchAtLoginDescription =>
      'Avvia BusyMax in background affinché i promemoria funzionino dopo l’accesso.';

  @override
  String get launchAtLoginFailed =>
      'Impossibile aggiornare l’avvio all’accesso.';

  @override
  String get requiresTrayIcon => 'Richiede l’icona nell’area di notifica.';

  @override
  String get syncComplete => 'Sincronizzazione completata.';

  @override
  String syncFailed(String error) {
    return 'Sincronizzazione non riuscita: $error';
  }

  @override
  String get notifySyncFailures =>
      'Notifiche in caso di errore di sincronizzazione';

  @override
  String get notifyConflicts => 'Notifiche in caso di conflitto';

  @override
  String get notifyDueToday => 'Notifiche per attività in scadenza oggi';

  @override
  String get eventReminders => 'Promemoria degli eventi';

  @override
  String get onState => 'Attivato';

  @override
  String get taskReminders => 'Promemoria delle attività';

  @override
  String get notificationDetailLevel => 'Livello di dettaglio delle notifiche';

  @override
  String get notificationDetailPrivate => 'Privato';

  @override
  String get notificationDetailNormal => 'Normale';

  @override
  String get quietHours => 'Ore di silenzio';

  @override
  String get quietHoursDescription =>
      'Sospendi le notifiche durante questo periodo.';

  @override
  String get quietHoursStart => 'Inizio delle ore di silenzio';

  @override
  String get quietHoursEnd => 'Fine delle ore di silenzio';

  @override
  String get notifications => 'Notifiche';

  @override
  String get windowsNotificationsUnavailable =>
      'Le notifiche di Windows non sono disponibili';

  @override
  String get windowsNotificationsUnpackaged =>
      'Questa esecuzione di sviluppo non pacchettizzata non può usare le notifiche di Windows. Installa il pacchetto MSIX firmato per i test per verificare i promemoria.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax non ha potuto inizializzare le notifiche di Windows. I promemoria non appariranno finché il problema di installazione non sarà risolto.';

  @override
  String get appearance => 'Aspetto';

  @override
  String get theme => 'Tema';

  @override
  String get themeSystem => 'Sistema';

  @override
  String get settingsSystem => 'Sistema';

  @override
  String get themeLight => 'Chiaro';

  @override
  String get themeDark => 'Scuro';

  @override
  String get themeFamily => 'Famiglia di temi';

  @override
  String get themeFamilyYaru => 'Tema nativo di Ubuntu (Yaru)';

  @override
  String get localization => 'Lingua e area geografica';

  @override
  String get currentLocale => 'Impostazioni locali correnti';

  @override
  String get privacy => 'Riservatezza';

  @override
  String get redactTaskContentInDiagnostics =>
      'Nascondi il contenuto delle attività nelle informazioni diagnostiche';

  @override
  String get developerDiagnostics => 'Diagnostica per sviluppatori';

  @override
  String get diagnostics => 'Diagnostica';

  @override
  String get apiInspectorDisabled => 'Mostra l’ispettore API';

  @override
  String get googleTasksApi => 'API Google Tasks';

  @override
  String discoveryRevision(String revision) {
    return 'Revisione Discovery: $revision';
  }

  @override
  String get implementedMethods => 'Metodi implementati';

  @override
  String get supportsTasksScopes =>
      'Supporta gli ambiti tasks e tasks.readonly';

  @override
  String get requiresTasksScope => 'Richiede l’ambito tasks';

  @override
  String get blockedPendingOperations => 'Operazioni in sospeso bloccate';

  @override
  String get signInToInspectPendingOperations =>
      'Accedi per esaminare le operazioni in sospeso.';

  @override
  String get noBlockedPendingOperations =>
      'Nessuna operazione in sospeso bloccata.';

  @override
  String get operationActions => 'Azioni dell’operazione';

  @override
  String pendingOpListId(String id) {
    return 'elenco=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'attività=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'tentativi=$countString';
  }

  @override
  String get retry => 'Riprova';

  @override
  String get discard => 'Scarta';

  @override
  String get discardChangesAction => 'Scarta';

  @override
  String get discardChanges => 'Scartare le modifiche?';

  @override
  String get discardChangesConfirmation =>
      'Questa azione scarta le modifiche non salvate dell’attività.';

  @override
  String get retryCompleted => 'Nuovo tentativo completato.';

  @override
  String get discardPendingOperation => 'Scartare l’operazione in sospeso?';

  @override
  String get discardPendingOperationConfirmation =>
      'Questa azione rimuove l’operazione locale bloccata. Alla prossima sincronizzazione, i dati verranno ricaricati da Google Tasks.';

  @override
  String get pendingOperationDiscarded => 'Operazione in sospeso scartata.';

  @override
  String get syncFailureNotificationTitle =>
      'Sincronizzazione di BusyMax non riuscita';

  @override
  String syncFailureNotificationBody(String message) {
    return 'Sincronizzazione in background non riuscita. $message';
  }

  @override
  String get conflictNotificationTitle =>
      'Conflitto di sincronizzazione di BusyMax';

  @override
  String conflictNotificationBody(String summary) {
    return 'Una modifica locale in sospeso è stata bloccata. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Attività in scadenza oggi';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString attività scadono oggi.',
      one: 'Un’attività scade oggi.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Promemoria evento';

  @override
  String get taskReminderNotificationTitle => 'Promemoria attività';

  @override
  String get eventReminderNotificationBody => 'L’evento inizierà a breve.';

  @override
  String get taskReminderNotificationBody => 'L’attività scadrà a breve.';

  @override
  String get notificationOpenAction => 'Apri';

  @override
  String get notificationSnoozeAction => 'Posticipa di 10 minuti';

  @override
  String get notificationDismissAction => 'Chiudi';

  @override
  String get notificationDetailsHidden =>
      'I dettagli sono nascosti dalle impostazioni sulla privacy.';

  @override
  String get previousMonth => 'Mese precedente';

  @override
  String get nextMonth => 'Mese successivo';

  @override
  String get openMonthView => 'Apri vista mensile';

  @override
  String get previousYear => 'Anno precedente';

  @override
  String get nextYear => 'Anno successivo';

  @override
  String get openYearView => 'Apri vista annuale';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'Settimana $numberString';
  }

  @override
  String get resizeAllDayPanel =>
      'Ridimensiona il pannello per l’intera giornata';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString elementi',
      one: '1 elemento',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'Questo calendario è di sola lettura.';

  @override
  String get selectTimeZone => 'Seleziona fuso orario';

  @override
  String get searchLocations => 'Cerca località';

  @override
  String get noLocationsFound => 'Nessuna località trovata';

  @override
  String get requiredField => 'Questo campo è obbligatorio.';

  @override
  String get providerConnectionDescription =>
      'Collega calendari e attività a uno di questi provider.';

  @override
  String get appleICloudProvider => 'Calendario Apple iCloud';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Attività Nextcloud';

  @override
  String get addAppleICloudAccount =>
      'Aggiungi account Calendario Apple iCloud';

  @override
  String get addNextcloudAccount => 'Aggiungi account Nextcloud';

  @override
  String get waitingForAppleICloud => 'Connessione ad Apple iCloud…';

  @override
  String get waitingForNextcloud => 'In attesa dell’autorizzazione Nextcloud…';

  @override
  String get connectAppleICloudTitle => 'Collega Calendario Apple iCloud';

  @override
  String get appleAccountEmail => 'E-mail dell’account Apple';

  @override
  String get appleAppSpecificPassword => 'Password specifica per l’app';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Crea una password specifica per l’app dopo aver attivato l’autenticazione a due fattori per il tuo account Apple.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'La reimpostazione della password dell’account Apple revoca le password specifiche per le app.';

  @override
  String get connectNextcloudTitle => 'Collega Nextcloud';

  @override
  String get nextcloudServerUrl => 'Server Nextcloud o indirizzo CalDAV';

  @override
  String get nextcloudServerUrlHelp =>
      'Inserisci l’URL del server Nextcloud o incolla l’indirizzo CalDAV principale copiato da Nextcloud.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax aprirà il browser. Approva l’accesso e torna a BusyMax.';

  @override
  String get connectAccountAction => 'Collega';

  @override
  String get cancelAccountConnection => 'Annulla connessione';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'L’account è stato rimosso localmente, ma non è stato possibile revocare la password dell’app Nextcloud.';

  @override
  String get davReauthenticationRequired =>
      'Ricollega questo account per riprendere la sincronizzazione.';

  @override
  String get davTemporarilyUnavailable =>
      'Questo account è temporaneamente non disponibile.';

  @override
  String get davPermissionChanged =>
      'Le autorizzazioni del server sono cambiate. Le modifiche in sospeso sono in pausa.';

  @override
  String get davUnsupportedServer =>
      'Questo server o profilo provider non è supportato.';

  @override
  String get collectionSettings => 'Calendari ed elenchi di attività';

  @override
  String get calendarContent => 'Eventi del calendario';

  @override
  String get taskContent => 'Attività';

  @override
  String get readOnlySharedCollection => 'Sola lettura';

  @override
  String get pendingLocally => 'In sospeso localmente';

  @override
  String get conflictBlocked => 'Bloccato da un conflitto';

  @override
  String get authenticationBlocked => 'Bloccato fino alla riconnessione';

  @override
  String get operationFailed => 'Operazione non riuscita';

  @override
  String get keepServerVersion => 'Mantieni la versione del server';

  @override
  String get reapplyLocalChange => 'Esamina e riapplica la modifica locale';

  @override
  String get duplicateLocalItem => 'Duplica come nuovo elemento';

  @override
  String get davConnectionState => 'Stato della connessione';

  @override
  String get davConnected => 'Connesso';

  @override
  String get davConnecting => 'Connessione…';

  @override
  String get davSignedOut => 'Disconnesso';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Ultima sincronizzazione riuscita: $time';
  }

  @override
  String get davNeverSynced => 'Non ancora sincronizzato';

  @override
  String get refreshCollections => 'Aggiorna calendari ed elenchi di attività';

  @override
  String nextcloudServerHost(String host) {
    return 'Indirizzo server: $host';
  }

  @override
  String get collectionSupportsEvents => 'Calendario eventi';

  @override
  String get collectionSupportsTasks => 'Elenco di attività';

  @override
  String get collectionSupportsEventsAndTasks => 'Eventi e attività';

  @override
  String get writableCollection => 'Scrivibile';

  @override
  String get sharedCollection => 'Condiviso';

  @override
  String collectionLastSynced(String time) {
    return 'Ultima sincronizzazione: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Problema di sincronizzazione: $code';
  }

  @override
  String get syncConflicts => 'Conflitti di sincronizzazione';

  @override
  String remoteChangedAt(String time) {
    return 'Modifica del server: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Modifica locale: $summary';
  }

  @override
  String get conflictResolutionFailed => 'Impossibile risolvere il conflitto.';

  @override
  String get recurringEventScope => 'Ambito dell’evento ricorrente';

  @override
  String get entireSeries => 'Intera serie';

  @override
  String get singleOccurrence => 'Questo evento';

  @override
  String get thisAndFollowingEvents => 'Questo evento e quelli successivi';

  @override
  String get thisAndFutureUnavailable => 'Non supportato da questo provider.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'Questo evento e quelli successivi non possono essere spostati in modo sicuro. Scegli questo evento o l’intera serie.';

  @override
  String get entireSeriesMoveUnavailable =>
      'La regola di ricorrenza non è disponibile localmente. Sposta invece solo questo evento.';

  @override
  String get copyEventAndDeleteOriginal =>
      'Copiare l’evento ed eliminare l’originale?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax non può spostare direttamente questo evento da $source a $destination. Creerà prima la copia ed eliminerà l’originale solo dopo che la copia sarà riuscita. Gli ID dell’evento cambieranno; gli stati di risposta dei partecipanti potrebbero essere reimpostati e potrebbero essere inviati inviti o annullamenti; i link alle riunioni, gli allegati, i promemoria, i campi specifici del provider e le eccezioni di ricorrenza potrebbero non essere trasferiti.';
  }

  @override
  String get copyAndDelete => 'Copia ed elimina';

  @override
  String get chooseRecurringEventScope =>
      'Scegli se questa modifica si applica all’intera serie, solo a questo evento oppure a questo e agli eventi successivi.';

  @override
  String get taskDueBeforeStart => 'La scadenza non può precedere l\'inizio.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Imposta un orario sia per l’inizio sia per la scadenza, oppure rendi l’attività valida per l’intera giornata.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Eliminare «$title»?';
  }

  @override
  String get setCustomCalendarName => 'Imposta nome personalizzato';

  @override
  String get setAction => 'Imposta';

  @override
  String get removeFromMyCalendars => 'Rimuovi dai miei calendari';

  @override
  String get removeAction => 'Rimuovi';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Rimuovere \"$title\" da BusyMax? Il calendario e gli eventi del proprietario non verranno eliminati.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'Il caricamento potrebbe essere riuscito. Aggiorna gli allegati per verificarlo prima di riprovare.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Rimuovere \"$title\" dall\'elenco di Google Calendar? Il calendario condiviso e i relativi eventi non verranno eliminati.';
  }

  @override
  String get calendarCannotRemove =>
      'Non è possibile eliminare o rimuovere questo calendario da questo account.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Attendi il completamento della sincronizzazione delle modifiche in sospeso del calendario prima di eliminarlo o rimuoverlo.';

  @override
  String get calendarSubscriptions => 'Abbonamenti ai calendari';

  @override
  String get calendarSubscriptionsDescription =>
      'Aggiungi calendari di sola lettura che si aggiornano da un URL WebCal sicuro.';

  @override
  String get addCalendarSubscription => 'Aggiungi abbonamento al calendario';

  @override
  String get subscriptionName => 'Nome locale';

  @override
  String get subscriptionUrl => 'URL abbonamento';

  @override
  String get subscriptionUrlHelp =>
      'Inserisci un URL HTTPS o webcal. BusyMax conserva l’URL completo in un archivio sicuro.';

  @override
  String get subscriptionUrlInvalid =>
      'Inserisci un URL HTTPS o webcal valido senza informazioni utente o frammento.';

  @override
  String get subscriptionColor => 'Colore locale';

  @override
  String get subscriptionColorHelp => 'Usa un colore a sei cifre come #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Inserisci un colore esadecimale di sei cifre.';

  @override
  String get subscriptionRefreshMode => 'Frequenza di aggiornamento';

  @override
  String get subscriptionAutomatic => 'Automatica';

  @override
  String get subscriptionHourly => 'Ogni ora';

  @override
  String get subscriptionSixHours => 'Ogni sei ore';

  @override
  String get subscriptionDaily => 'Ogni giorno';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Origine: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Inserisci un URL valido per visualizzarne l’origine sicura.';

  @override
  String get subscriptionReadOnly => 'Abbonamento di sola lettura';

  @override
  String get subscriptionNeverRefreshed => 'Non ancora aggiornato';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Ultimo aggiornamento riuscito: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Prossimo aggiornamento: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Aggiornato';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Problema di aggiornamento: $code';
  }

  @override
  String get refreshNow => 'Aggiorna ora';

  @override
  String get unsubscribe => 'Annulla abbonamento';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Annullare l’abbonamento a “$name”?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'Rimuove l’abbonamento locale e gli eventi memorizzati nella cache. Il calendario pubblicato non cambia.';

  @override
  String get addSubscriptionAction => 'Aggiungi abbonamento';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Abbonamento al calendario non riuscito: $error';
  }

  @override
  String get subscriptions => 'Abbonamenti';

  @override
  String get calendarImport => 'Importazione calendario';

  @override
  String get calendarImportDescription =>
      'Seleziona un file, rivedi gli eventi e scegli il calendario scrivibile che deve riceverli.';

  @override
  String get importIcsFile => 'Importa file .ics';

  @override
  String get importIcsPreview => 'Importa eventi del calendario';

  @override
  String importEventsFound(int count) {
    return 'Insiemi di eventi importabili: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Eventi non validi: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Ommessi intenzionalmente: $fields';
  }

  @override
  String get noWritableCalendars =>
      'Nessun calendario di destinazione scrivibile disponibile.';

  @override
  String get importDestinationCalendar => 'Calendario di destinazione';

  @override
  String get importIcsConfirm => 'Importa eventi';

  @override
  String get importIcsComplete => 'Importazione completata';

  @override
  String importQueued(int count) {
    return 'Importati o accodati: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Duplicati ignorati: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Insiemi di ricorrenze non supportati: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'Impossibile importare il file del calendario: $error';
  }

  @override
  String get networkOffline => 'Senza connessione';

  @override
  String get networkOfflineDescription =>
      'Le modifiche verranno sincronizzate al ripristino della connessione.';

  @override
  String get networkOfflineTryAgain =>
      'Sei offline. Connettiti a Internet e riprova.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'i giorni $days';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency il giorno $day di $month';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency nei giorni $days di $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency il giorno $day di $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency nei giorni $days di $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'il primo $days di $month',
      'second': 'il secondo $days di $month',
      'third': 'il terzo $days di $month',
      'fourth': 'il quarto $days di $month',
      'fifth': 'il quinto $days di $month',
      'secondToLast': 'il penultimo $days di $month',
      'last': 'l’ultimo $days di $month',
      'other': 'nei giorni $days di $month',
    });
    return '$frequency $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'il primo $days di $months',
      'second': 'il secondo $days di $months',
      'third': 'il terzo $days di $months',
      'fourth': 'il quarto $days di $months',
      'fifth': 'il quinto $days di $months',
      'secondToLast': 'il penultimo $days di $months',
      'last': 'l’ultimo $days di $months',
      'other': 'nei giorni $days di $months',
    });
    return '$frequency $_temp0';
  }

  @override
  String get searchFilters => 'Filtri di ricerca';

  @override
  String get searchType => 'Tipo';

  @override
  String get searchDate => 'Data';

  @override
  String get searchAnyDate => 'Qualsiasi data (dati scaricati)';

  @override
  String get eventLink => 'Link dell’evento';

  @override
  String get eventLinkOpenFailed => 'Impossibile aprire il link.';

  @override
  String get scheduleRangeIncomplete =>
      'Alcuni eventi non sono stati verificati. Sono mostrati i dati scaricati.';

  @override
  String get searchThisWeek => 'Questa settimana';

  @override
  String get searchCustomRange => 'Intervallo personalizzato';

  @override
  String get searchTaskStatus => 'Stato attività';

  @override
  String get searchTaskDue => 'Scadenza attività';

  @override
  String get searchAnyDueState => 'Qualsiasi scadenza';

  @override
  String get searchNoDueDate => 'Senza scadenza';

  @override
  String get searchPerson => 'Persona';

  @override
  String get searchSources => 'Origini';

  @override
  String get searchClearFilters => 'Reimposta filtri';

  @override
  String get searchFiltersAction => 'Filtri';

  @override
  String get searchNoSources => 'Nessuna origine di ricerca selezionata';

  @override
  String get searchClearText => 'Cancella testo';

  @override
  String get openSharedCalendar => 'Apri calendario condiviso';

  @override
  String get manageCalendarSharing => 'Gestisci condivisione del calendario';

  @override
  String get shareRecipientEmail => 'Email del destinatario';

  @override
  String get shareRole => 'Ruolo di accesso';

  @override
  String get addCalendarShare => 'Aggiungi accesso';

  @override
  String get sharingRefreshFailed =>
      'La condivisione è stata modificata, ma l’elenco delle autorizzazioni non è stato aggiornato. Ricaricalo prima di un’altra modifica.';

  @override
  String get sharingRateLimited =>
      'La condivisione è temporaneamente limitata. Riprova al termine dell’attesa.';

  @override
  String get attachmentUploadRateLimited =>
      'Il caricamento degli allegati è temporaneamente limitato. Riprova al termine dell’attesa.';

  @override
  String get sharingPermissionUnavailable =>
      'Le autorizzazioni di condivisione non sono disponibili per questo calendario.';

  @override
  String get calendarShareFreeBusy => 'Solo libero/occupato';

  @override
  String get calendarShareLimitedRead => 'Leggi dettagli limitati';

  @override
  String get calendarShareRead => 'Leggi tutti i dettagli';

  @override
  String get calendarShareWrite => 'Modifica eventi';

  @override
  String get calendarShareWriteWithoutPrivate =>
      'Modifica senza dettagli privati';

  @override
  String get calendarShareOwner => 'Proprietario';

  @override
  String get eventLabel => 'Etichetta evento';

  @override
  String get loadOutlookCategories => 'Carica categorie Outlook';

  @override
  String get outlookCategoriesUnavailable =>
      'Le categorie Outlook non sono disponibili; le assegnazioni esistenti vengono conservate.';

  @override
  String get googleEventType => 'Tipo di evento';

  @override
  String get googleRegularEvent => 'Evento normale';

  @override
  String get googleFocusTime => 'Tempo di concentrazione';

  @override
  String get googleOutOfOffice => 'Fuori sede';

  @override
  String get googleWorkingLocation => 'Luogo di lavoro';

  @override
  String get googleDeclineInvitations => 'Rifiuta gli inviti sovrapposti';

  @override
  String get googleDeclineNone => 'Non rifiutare';

  @override
  String get googleDeclineNew => 'Rifiuta i nuovi inviti';

  @override
  String get googleDeclineAll => 'Rifiuta tutti gli inviti in conflitto';

  @override
  String get googleDeclineMessage => 'Messaggio di rifiuto';

  @override
  String get googleChatStatus => 'Stato chat';

  @override
  String get googleChatAvailable => 'Disponibile';

  @override
  String get googleChatDoNotDisturb => 'Non disturbare';

  @override
  String get googleWorkAtHome => 'Casa';

  @override
  String get googleWorkAtOffice => 'Ufficio';

  @override
  String get googleWorkAtCustomLocation => 'Luogo personalizzato';

  @override
  String get googleWorkLocationLabel => 'Nome del luogo';

  @override
  String get googleStatusPrimaryOnly =>
      'Gli eventi di stato Google richiedono il calendario Google principale.';

  @override
  String unknownEventLabel(String id) {
    return 'Etichetta sconosciuta ($id)';
  }

  @override
  String get calendarOwnerEmail => 'Email del proprietario del calendario';

  @override
  String registrationSetupTitle(String provider) {
    return 'Configura $provider';
  }

  @override
  String get registrationSetupGuide => 'Guida alla configurazione';

  @override
  String get registrationGoogleInstructions =>
      'Crea il tuo progetto Google Cloud, abilita Calendar e Tasks e importa il JSON di un client OAuth desktop. Autorizza l’account desiderato.';

  @override
  String get registrationMicrosoftInstructions =>
      'Usa una registrazione pubblica in un tenant Entra che consenta la registrazione di app. Inserisci ID client e tipi di account. Non serve un segreto client.';

  @override
  String get registrationImportGoogle => 'Seleziona JSON OAuth desktop';

  @override
  String get registrationValidate => 'Convalida registrazione';

  @override
  String get registrationAuthorize => 'Autorizza nel browser';

  @override
  String get registrationClientId => 'ID applicazione/client';

  @override
  String get registrationTenantId => 'ID tenant';

  @override
  String get registrationAudience => 'Account supportati';

  @override
  String get registrationBothAudience => 'Account personali e aziendali';

  @override
  String get registrationOrganizationAudience => 'Account aziendali';

  @override
  String get registrationPersonalAudience => 'Account personali';

  @override
  String get registrationTenantAudience => 'Un tenant aziendale';

  @override
  String registrationSummary(String clientId) {
    return 'Registrazione: $clientId';
  }

  @override
  String get registrationMigrate => 'Migra ora';

  @override
  String get registrationReplace => 'Sostituisci registrazione';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'Questo account usa una registrazione originale di $provider riservata agli account esistenti. Per sostituirla, configura $setup e riconnetti questo account. Calendari, attività e modifiche locali saranno conservati.';
  }

  @override
  String get registrationContinue => 'Continua a usare questo account';

  @override
  String get registrationGoogleProject => 'Progetto Google Cloud';

  @override
  String get registrationMicrosoftApp => 'Registrazione app Microsoft';

  @override
  String get registrationUserOwned => 'Registrazione fornita dall’utente';

  @override
  String get registrationNativeGoogle =>
      'Registrazione nativa Google per Android';

  @override
  String get registrationShared => 'Registrazione condivisa (transizione)';

  @override
  String get registrationUnresolved =>
      'L’origine della registrazione non è identificata. I dati dell’account sono conservati.';

  @override
  String get registrationOfficialDocumentation => 'Documentazione ufficiale';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Pacchetto: $packageName\nHash della firma: $signatureHash\nURI di reindirizzamento: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Controlla il tipo di client, gli account supportati, i permessi e il reindirizzamento della registrazione. Seleziona di nuovo la configurazione importata.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'Impossibile completare questa autorizzazione. Avviala di nuovo; la connessione esistente viene preservata.';

  @override
  String get oauthPermissionRefused =>
      'Autorizzazione rifiutata o permessi necessari mancanti. Riprova e concedi i permessi richiesti.';

  @override
  String get oauthProviderThrottled =>
      'Il provider sta limitando le richieste. Attendi prima di riprovare; la connessione esistente viene preservata.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Un problema temporaneo del provider ha impedito l’autorizzazione. Riprova; la connessione esistente viene preservata.';

  @override
  String get oauthAuthorizationTimedOut =>
      'Il tempo per l’autorizzazione è scaduto. Riprova e seleziona di nuovo la configurazione importata.';

  @override
  String get oauthWrongAccount =>
      'Autorizza l’account selezionato per la riconnessione. La connessione esistente viene preservata.';

  @override
  String get oauthSecureStorageUnavailable =>
      'Archiviazione sicura non disponibile. Ripristina l’accesso e riprova.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'L’autorizzazione remota è stata revocata, ma la pulizia dell’account non è stata completata. Riavvia BusyMax per riprovare il recupero locale.';

  @override
  String get addAccount => 'Aggiungi account';

  @override
  String get registrationConnect => 'Connetti';

  @override
  String get registrationBack => 'Indietro';

  @override
  String get registrationReplaceGoogle => 'Sostituisci JSON OAuth desktop';

  @override
  String get registrationSelectedConfiguration => 'Configurazione selezionata';

  @override
  String get registrationDirectoryId => 'ID directory/tenant';

  @override
  String get registrationInvalidId => 'Inserisci un UUID valido.';

  @override
  String get registrationExpired =>
      'Questa configurazione è scaduta. Importala di nuovo o modifica i campi prima di connetterti.';

  @override
  String get registrationOwnProjectRequired =>
      'Scegli una registrazione del tuo progetto o tenant.';

  @override
  String get registrationSetupFailed =>
      'Impossibile completare la configurazione. Riprova.';

  @override
  String get registrationLinkFailed =>
      'Impossibile aprire il collegamento. Controlla il browser e riprova.';

  @override
  String get registrationPermissions => 'Autorizzazioni';

  @override
  String get registrationDesktopClient => 'Applicazione desktop';

  @override
  String get registrationOpenGoogleConsole => 'Apri Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Requisiti Google per pubblicazione e utenti di prova';

  @override
  String get registrationDesktopHelp =>
      'Istruzioni per registrare applicazioni desktop';

  @override
  String get registrationOpenEntra =>
      'Apri l’interfaccia di amministrazione Microsoft Entra';

  @override
  String get registrationGuideGoogleProject =>
      'Apri Google Cloud Console. Usa il selettore del progetto in alto per scegliere il tuo progetto, oppure scegli New project, inserisci un nome e seleziona Create. Mantieni selezionato questo progetto nei passaggi successivi.';

  @override
  String get registrationGuideGoogleAudience =>
      'Vai a Google Auth Platform → Branding. Se la configurazione non è iniziata, seleziona Get started. Inserisci BusyMax in App name, scegli la tua User support email e seleziona Next. In Audience scegli External. Seleziona Next, inserisci la tua email in Contact Information e seleziona Next. Accetta User Data Policy e seleziona Continue e Create. Se è già configurato, controlla Branding e Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Apri Google Auth Platform → Data Access → Add or remove scopes. Seleziona i cinque ambiti sotto; usa Manually add scopes se necessario. Per l’inserimento manuale, incolla i valori mancanti e seleziona Add to table. Seleziona Update e poi Save. BusyMax richiede l’accesso al calendario e alle attività.';

  @override
  String get registrationGuideGoogleClient =>
      'Apri Google Auth Platform → Clients → Create client. Imposta Application type su Desktop app, inserisci BusyMax in Name e seleziona Create. Nella finestra di creazione seleziona Download JSON e salva il file. Seleziona Indietro per tornare al modulo, scegli quel file e controlla progetto e ID client. Seleziona Connetti e consenti l’accesso al calendario e alle attività nel browser.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Accedi al centro di amministrazione Microsoft Entra. Usa Settings per scegliere un tenant in cui puoi registrare applicazioni. Apri Entra ID → App registrations → New registration. Inserisci BusyMax in Name, poi scegli i tipi di account nel passaggio successivo. Se la registrazione è bloccata, chiedi l’accesso all’amministratore del tenant.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'Nella registrazione apri Authentication → Add a platform → Mobile and desktop applications. Seleziona o inserisci l’URI di reindirizzamento sotto e seleziona Configure per salvarlo. BusyMax usa il browser di sistema. Non serve un segreto client.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Apri API permissions → Add a permission → Microsoft Graph → Delegated permissions. Cerca e seleziona ogni ambito sotto, poi seleziona Add permissions. Mantieni User.Read se già presente. Se l’organizzazione richiede il consenso amministrativo, chiedi a un amministratore di usare Grant admin consent per il tenant.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Seleziona Indietro per tornare al modulo. Incolla Application (client) ID e scegli gli stessi Account supportati della registrazione. Per Un tenant aziendale incolla anche Directory (tenant) ID. Seleziona Connetti e accedi all’account desiderato nel browser. BusyMax controlla i campi localmente; Microsoft chiede il consenso durante l’accesso nel browser.';

  @override
  String get registrationGoogleImportFailed =>
      'Impossibile importare questo file. Seleziona un JSON OAuth desktop valido. L’eventuale selezione valida precedente viene conservata.';

  @override
  String get registrationGoogleSetupInstructions =>
      'Istruzioni di configurazione Google';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Istruzioni di configurazione Microsoft';

  @override
  String get registrationDesktopConfiguration => 'Configurazione OAuth desktop';

  @override
  String get registrationNoFileSelected => 'Nessun file selezionato';

  @override
  String get registrationChooseFile => 'Scegli file…';

  @override
  String get registrationReplaceFile => 'Sostituisci…';

  @override
  String get registrationGoogleIntroduction =>
      'Scegli il JSON OAuth desktop del tuo progetto Google Cloud.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Inserisci i dettagli della tua registrazione di app Microsoft.';

  @override
  String get registrationSetupInstructions => 'Istruzioni di configurazione';

  @override
  String get registrationInstructionsDescription =>
      'Crea la configurazione necessaria per collegare il tuo account.';

  @override
  String get registrationEnableApis => 'Abilitare Calendar e Tasks';

  @override
  String get registrationConsentScreen =>
      'Configurare la schermata di consenso';

  @override
  String get registrationAppName => 'Nome dell’app';

  @override
  String get registrationScopes => 'Ambiti';

  @override
  String get registrationRedirectUri => 'URI di reindirizzamento';

  @override
  String get registrationOpenApiLibrary => 'Apri la libreria API di Google';

  @override
  String get registrationOpenBranding =>
      'Apri Branding in Google Auth Platform';

  @override
  String get registrationOpenDataAccess =>
      'Apri Data Access in Google Auth Platform';

  @override
  String get registrationOpenClients => 'Apri Clients in Google Auth Platform';

  @override
  String get registrationOpenEntraAuthentication =>
      'Apri le registrazioni Entra per Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'Apri le registrazioni Entra per API permissions';

  @override
  String get registrationCopy => 'Copia';

  @override
  String get registrationCopyAll => 'Copia tutto';

  @override
  String get registrationGuideGoogleApis =>
      'Vai a APIs & Services → Library. Cerca Google Calendar API, apri la pagina e seleziona Enable. Torna a Library e ripeti per Google Tasks API.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'In Supported account types scegli Personal accounts only per un account personale, Multiple Entra ID tenants per account aziendali, Any Entra ID Tenant + Personal Microsoft accounts per entrambi, oppure Single tenant only per questa directory. Seleziona Register. In Overview copia Application (client) ID; per un solo tenant copia anche Directory (tenant) ID. Usa l’opzione corrispondente di Account supportati in BusyMax.';

  @override
  String get registrationConnectBusyMax => 'Connetti con BusyMax';

  @override
  String get registrationRecommended => 'Consigliato';

  @override
  String get registrationOtherMethods => 'Altri metodi di connessione';

  @override
  String get registrationWorkspace => 'Organizzazione Google Workspace';

  @override
  String get registrationGoogleCustom => 'Client OAuth personalizzato';

  @override
  String get registrationMicrosoftCustom => 'Registrazione app personalizzata';

  @override
  String get registrationMethodsIntroduction =>
      'Scegli come connettere il tuo account.';

  @override
  String get registrationWorkspaceDescription =>
      'Usa una configurazione gestita dalla tua organizzazione.';

  @override
  String get registrationCustomDescription =>
      'Usa una registrazione che gestisci tu.';

  @override
  String get registrationSharedUnavailable =>
      'La connessione con BusyMax non è disponibile in questa build. Puoi usare un altro metodo qui sotto.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Scegli il JSON OAuth desktop fornito o gestito dalla tua organizzazione. Il file non dimostra la proprietà dell’organizzazione, il pubblico o lo stato di verifica.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Istruzioni di configurazione di Google Workspace';

  @override
  String get registrationBusyMaxManaged => 'Registrazione gestita da BusyMax';

  @override
  String get registrationBranding => 'Configurare marchio e domini';

  @override
  String get registrationPublishing => 'Pubblicare per uso normale';

  @override
  String get registrationOpenAudience =>
      'Apri Audience di Google Auth Platform';

  @override
  String get registrationGuideWorkspaceProject =>
      'Chiedi all’amministratore il JSON OAuth per desktop oppure apri Google Cloud Console e seleziona un progetto della tua organizzazione Google Workspace. Per crearlo, apri Gestisci risorse → Crea progetto, inserisci Nome progetto, scegli l’organizzazione o una sua cartella in Risorsa principale e seleziona Crea. Seleziona quel progetto per i passaggi successivi. Servono Project Creator per la creazione, OAuth Config Editor per configurare OAuth e Service Usage Admin o autorizzazioni equivalenti per abilitare le API. Se un’azione è bloccata, chiedi all’amministratore.';

  @override
  String get registrationGuideGoogleBranding =>
      'In Branding → App domain aggiungi i domini autorizzati del progetto prima delle URL di homepage, privacy e condizioni d’uso, poi scegli Save. Le app External in produzione richiedono questi link. Usa domini tuoi e verificane la proprietà in Search Console quando Google richiede la verifica del marchio. Il link privacy di BusyMax non dimostra che il tuo progetto possieda busystack.org.';

  @override
  String get registrationGuideGooglePublishing =>
      'In Audience scegli Publish app e conferma In production. Non lasciare l’uso normale in Testing: queste autorizzazioni Calendar/Tasks e i token di aggiornamento scadono dopo sette giorni. Pubblicazione e verifica sono separate. L’uso personale con meno di 100 utenti può essere esente da verifica, con avvisi e un limite utenti; una distribuzione più ampia può richiedere approvazione del marchio e degli ambiti. Le autorizzazioni in produzione possono comunque scadere o essere revocate.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Esamina questi ambiti con l’amministratore. Le app Internal non devono elencarli nella schermata di consenso. Se richiesto, apri Data Access → Add or remove scopes, aggiungi i valori, poi Update e Save. I controlli amministrativi possono ancora limitare l’autorizzazione.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'I permessi per calendari condivisi e categorie sono richiesti separatamente quando si attivano queste funzioni facoltative; non aggiungerli alla configurazione obbligatoria.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Vai a Google Auth Platform → Branding. Se la configurazione non è iniziata, seleziona Get started. Inserisci BusyMax in App name, scegli la tua User support email e seleziona Next. In Audience scegli Internal. Seleziona Next, inserisci la tua email in Contact Information e seleziona Next. Accetta User Data Policy e seleziona Continue e Create. Se è già configurato, controlla Branding e Audience.\n\nInternal consente solo account dell’organizzazione principale del progetto, soggetti ai controlli amministrativi. Non serve un elenco di utenti di test. BusyMax non può verificare queste impostazioni dal JSON.';

  @override
  String get contactsTitle => 'Contatti';

  @override
  String get contactsLinkedDescription =>
      'Usa i contatti memorizzati di questo account quando aggiungi invitati agli eventi.';

  @override
  String get contactsEnableSuggestions => 'Attiva i suggerimenti dei contatti';

  @override
  String get contactsReadPermissionDescription =>
      'Richiede l’accesso ai contatti in sola lettura';

  @override
  String get contactsEnableEditing => 'Attiva la modifica dei contatti';

  @override
  String get contactsWritePermissionDescription =>
      'Richiede l’accesso ai contatti in lettura e scrittura';

  @override
  String get contactsSuggestionsEnabled => 'Suggerimenti dei contatti attivati';

  @override
  String get contactsNeedsAttention => 'I contatti richiedono attenzione';

  @override
  String get contactsReadWriteAccess => 'Accesso in lettura e scrittura';

  @override
  String get contactsDisableForAccount =>
      'Disattiva i contatti per questo account';

  @override
  String get contactsOnlyDescription =>
      'Queste fonti sono indipendenti dagli account di calendario e attività.';

  @override
  String get contactsAddCardDav => 'Aggiungi contatti CardDAV';

  @override
  String get contactsAddNextcloud => 'Aggiungi contatti Nextcloud';

  @override
  String get contactsUseForAttendees =>
      'Usa per i suggerimenti dei partecipanti';

  @override
  String get contactsServerUrlLabel => 'URL del server HTTPS';

  @override
  String get contactsUsernameLabel => 'Nome utente';

  @override
  String get contactsPasswordLabel => 'Parola d’accesso';
}
