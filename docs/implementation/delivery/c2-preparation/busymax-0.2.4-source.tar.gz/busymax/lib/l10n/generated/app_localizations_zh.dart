// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax 由桌面的启动设置启动。请在那里移除 BusyMax 的条目，然后完全退出并重新打开 BusyMax，以使用此开关。';

  @override
  String get timeFormat => '时间格式';

  @override
  String get firstDayOfWeek => '一周的第一天';

  @override
  String get systemDefault => '系统默认';

  @override
  String systemDefaultResolved(String weekday) {
    return '系统默认（$weekday）';
  }

  @override
  String get timeFormatTwelveHour => '12小时制';

  @override
  String get timeFormatTwentyFourHour => '24小时制';

  @override
  String get timeEndOfDay => '当天结束';

  @override
  String get timePeriod => '上午/下午';

  @override
  String get launchAtLoginReadFailed => '无法确定登录时启动的状态。';

  @override
  String get launchAtLoginUnavailable => '此系统不支持登录时启动。';

  @override
  String get windowsStartupEnabledByPolicy => '管理员已启用自动启动，无法在此更改。';

  @override
  String get settingsSaveFailed => '无法保存设置。重新启动 BusyMax 时，您的更改可能会丢失。';

  @override
  String get nextcloudExportCollection => '导出集合资源';

  @override
  String nextcloudImportItems(int count) {
    return '找到 $count 个事件/任务资源';
  }

  @override
  String get nextcloudSchedulingInbox => '日程邀请收件箱';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud 会将这些消息处理到日历中。确认消息只会移除收件箱消息，不会删除事件。';

  @override
  String get nextcloudInboxEmpty => '没有日程消息。';

  @override
  String get nextcloudAcknowledge => '确认消息';

  @override
  String get nextcloudAcknowledgeConfirm => '从收件箱移除此消息？日历事件将被保留。';

  @override
  String get nextcloudGuestAvailability => '查看受邀者的空闲时间';

  @override
  String nextcloudTrashRetention(int days) {
    return '服务器回收站保留时间：$days 天';
  }

  @override
  String get nextcloudCancelMeeting => '取消会议';

  @override
  String get nextcloudDeclineAndRemove => '拒绝并移除邀请';

  @override
  String get nextcloudDeclineRemovalWarning => '同步时会发送拒绝回复。此操作不会取消组织者的会议。';

  @override
  String get nextcloudAvailabilityUnknown => '空闲状态未知';

  @override
  String get nextcloudAvailabilityFree => '此时段未报告忙碌时间';

  @override
  String get nextcloudAvailabilityBusy => '忙碌时段';

  @override
  String get nextcloudSchedulingPending => 'Nextcloud 将在同步时发送会议更新。本地保存不代表已送达。';

  @override
  String get nextcloudAttendeeRestrictions =>
      '只有组织者或获授权的代理人才能修改会议详情。您可以在邀请详情中回复。';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      '无法通过复制并删除来移动此会议。请使用同一日程身份下的日历。';

  @override
  String get nextcloudSchedulingStatus => '服务器日程处理状态';

  @override
  String get nextcloudImportFollowUp => '导入的资源已保存在本地。提醒刷新尚未完成；请勿重复导入。';

  @override
  String get nextcloudNativeImport =>
      '导入完整的事件和任务资源，不发送邀请。除非选择新副本，否则会跳过已有 UID。不支持的资源将逐项报告。';

  @override
  String get nextcloudImportMethod => '此文件包含日程消息。导入会保存内容并移除 METHOD，不会处理邀请或回复。';

  @override
  String get nextcloudImportCopies => '以新身份导入为新副本';

  @override
  String get nextcloudCollectionSettings => '集合设置';

  @override
  String get nextcloudSharing => '共享';

  @override
  String get nextcloudOwned => '自有';

  @override
  String get nextcloudShared => '已共享';

  @override
  String get nextcloudDelegated => '已委派';

  @override
  String get nextcloudSubscription => '订阅';

  @override
  String get nextcloudDeleted => '已删除';

  @override
  String get nextcloudMetadataEditable => '日历内容只读，但可以修改集合属性。';

  @override
  String get nextcloudServerOrder => '服务器顺序（独立于侧边栏顺序）';

  @override
  String get nextcloudCalendarEnabled => '在服务器上启用';

  @override
  String get nextcloudAvailability => '将此集合纳入空闲状态计算';

  @override
  String get nextcloudCalendarTimezone => '日历时区（VTIMEZONE 文档）';

  @override
  String get nextcloudRefreshPending => '更改已保存在 Nextcloud。刷新尚未完成；请勿重复更改。';

  @override
  String get nextcloudOutcomeUnknown => '无法确认服务器结果。请刷新后再试。';

  @override
  String get nextcloudRemoveShared => '移除共享日历/列表';

  @override
  String get nextcloudRemoveMixed => '此集合包含事件和任务。删除集合将同时删除两者。';

  @override
  String get nextcloudReadAccess => '只读';

  @override
  String get nextcloudWriteAccess => '读写';

  @override
  String get nextcloudRecipientSearch => '查找人员或群组';

  @override
  String get nextcloudNoRecipients => '没有匹配的人员或群组。';

  @override
  String get nextcloudRevokeShare => '撤销访问权限';

  @override
  String get nextcloudPublish => '发布链接';

  @override
  String get nextcloudUnpublish => '停止发布';

  @override
  String get nextcloudPublishWarning => '拥有发布链接的任何人都可能读取此日历。是否发布？';

  @override
  String get nextcloudTrash => '已删除的日历和任务';

  @override
  String get nextcloudTrashEmpty => '没有已删除的日历项目。';

  @override
  String get nextcloudRestore => '恢复';

  @override
  String get nextcloudPermanentDelete => '永久删除';

  @override
  String get nextcloudPermanentDeleteWarning =>
      '永久删除此项目？之后无法从 Nextcloud 日历回收站恢复。';

  @override
  String get nextcloudOperationDenied => 'Nextcloud 不允许此操作。';

  @override
  String get nextcloudUnsupported => '服务器不支持此操作。';

  @override
  String get nextcloudPendingChanges => '关闭前请保存或放弃集合更改。';

  @override
  String get nextcloudServerUnavailable => '无法连接 Nextcloud。缓存项目和待处理更改保持不变。';

  @override
  String get mapsShow => '在地图上显示';

  @override
  String get openLink => '打开链接';

  @override
  String get externalLocationOpenFailed => '无法在外部应用中打开该位置。';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed => '无法调整日程时间。已保存的时间未更改。';

  @override
  String get scheduleRescheduleStale => '拖动期间此日程已更改。请重试。';

  @override
  String get scheduleRescheduleNotificationsFailed => '新时间已保存，但无法更新提醒。';

  @override
  String get moveUp => '上移';

  @override
  String get moveDown => '下移';

  @override
  String get windowsSupport => '支持';

  @override
  String get windowsThirdPartyLicenses => '第三方许可证';

  @override
  String get windowsSearch => '搜索';

  @override
  String get windowsStartupDisabledByUser => '用户已在 Windows 设置中禁用。';

  @override
  String get windowsStartupDisabledByPolicy => '已由 Windows 策略禁用。';

  @override
  String get windowsStartupUnavailable => '从 MSIX 包安装 BusyMax 后可用。';

  @override
  String get windowsReminderExitNotice =>
      '完全退出 BusyMax 后，提醒将停止。请让应用在后台运行以接收提醒。';

  @override
  String get windowsProductVersionLabel => '产品版本';

  @override
  String get windowsPackageVersionLabel => 'Windows 包版本';

  @override
  String get windowsUnpackaged => '未打包';

  @override
  String get windowsAgendaLoadMore => '加载更多议程项目';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$month的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency$firstMonth和$secondMonth的$day';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$firstMonth和$secondMonth的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency$firstMonth和$secondMonth的$days';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      '连接 Google、Microsoft、Apple iCloud Calendar 或 Nextcloud 账户。';

  @override
  String get googlePermissionsConsentNotice => '在 Google 权限页面上，同时选择日历和任务权限。';

  @override
  String get googlePermissionsRequiredRetry =>
      '必须授予 Google 日历和 Google Tasks 权限。请重试并选中两个复选框。';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => '尚未配置此服务。';

  @override
  String get waitingForGoogleSignIn => '正在等待 Google 登录...';

  @override
  String get waitingForMicrosoftSignIn => '正在等待 Microsoft 登录...';

  @override
  String get microsoftSignInNotConfigured =>
      '尚未配置 Microsoft 登录。请设置 MICROSOFT_OAUTH_CLIENT_ID。';

  @override
  String get cancel => '取消';

  @override
  String get close => '关闭';

  @override
  String get windowMinimize => '最小化';

  @override
  String get windowMaximize => '最大化';

  @override
  String get windowRestore => '还原';

  @override
  String get exit => '退出';

  @override
  String get options => '选项';

  @override
  String get hide => '隐藏';

  @override
  String get show => '显示';

  @override
  String get export => '导出';

  @override
  String get save => '保存';

  @override
  String get settings => '设置';

  @override
  String get all => '全部';

  @override
  String get calendarEvents => '日程';

  @override
  String get calendarTasks => '任务';

  @override
  String get calendar => '日历';

  @override
  String get calendars => '日历';

  @override
  String get newCalendar => '新建日历';

  @override
  String get calendarColor => '日历颜色';

  @override
  String calendarColorOption(int number) {
    return '颜色 $number';
  }

  @override
  String get calendarManagementUnsupported => '此提供商不支持 BusyMax 中的日历管理。';

  @override
  String get primaryCalendarCannotDelete => '无法删除主日历。';

  @override
  String calendarCreateFailed(String error) {
    return '无法创建日历：$error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      '日历已创建，但 BusyMax 无法刷新账户。它将在下次同步后显示。';

  @override
  String calendarUpdateFailed(String error) {
    return '无法更新日历：$error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return '无法删除日历：$error';
  }

  @override
  String get newEvent => '新建日程';

  @override
  String get refreshCalendar => '刷新日历';

  @override
  String get openInProvider => '在服务中打开';

  @override
  String get linkedResources => '关联资源';

  @override
  String get noLinkedResources => '没有关联资源';

  @override
  String get attachments => '附件';

  @override
  String get attachmentsNotLoaded => '附件未加载';

  @override
  String get hideFromSchedule => '从日程中隐藏';

  @override
  String get showInSchedule => '在日程中显示';

  @override
  String get noCalendarsSynced => '尚未同步任何日历。';

  @override
  String get allDay => '全天';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '还有 $countString 项';
  }

  @override
  String get noEventsOrTasks => '没有日程或任务';

  @override
  String get scheduleLoading => '正在加载日程...';

  @override
  String get scheduleUnavailable => '日程不可用';

  @override
  String get scheduleNoSources => '没有可见的日历或任务列表';

  @override
  String get scheduleNoSourcesDescription => '请在设置中选择要显示的内容，然后刷新。';

  @override
  String get scheduleNoSearchResults => '没有匹配的日程或任务';

  @override
  String get scheduleNoSearchResultsDescription => '请尝试其他搜索内容或清除当前筛选条件。';

  @override
  String get refresh => '刷新';

  @override
  String get trayOpenBusyMax => '打开 BusyMax';

  @override
  String get trayShowBusyMax => '显示 BusyMax';

  @override
  String get trayNewEvent => '新日程…';

  @override
  String get trayNewTask => '新任务…';

  @override
  String get trayToday => '今天';

  @override
  String get trayAllDay => '全天';

  @override
  String get trayNow => '现在';

  @override
  String get trayCalendarEvent => '日历日程';

  @override
  String get trayUntitledEvent => '无标题日程';

  @override
  String get trayNothingElseToday => '今天没有其他内容';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $count 个任务到期',
      one: '今天有 1 个任务到期',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => '打开今天的日程';

  @override
  String get traySyncNow => '立即同步';

  @override
  String get traySyncing => '正在同步…';

  @override
  String get trayNotConnected => '未连接';

  @override
  String get trayNotYetSynced => '尚未同步';

  @override
  String get trayLastSyncedJustNow => '刚刚同步';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 分钟前同步',
      one: '1 分钟前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 小时前同步',
      one: '1 小时前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 天前同步',
      one: '1 天前同步',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => '设置';

  @override
  String get trayQuitBusyMax => '退出 BusyMax';

  @override
  String get agendaLoadMoreOverdue => '加载更多逾期任务';

  @override
  String get agendaLoadMoreNoDate => '加载更多无日期任务';

  @override
  String get viewDay => '日';

  @override
  String get viewWeek => '周';

  @override
  String get viewMonth => '月';

  @override
  String get viewYear => '年';

  @override
  String get viewAgenda => '日程';

  @override
  String get scheduleSettings => '日程';

  @override
  String get scheduleDisplaySettings => '日程显示';

  @override
  String get newEventsAndTasks => '新建日程和任务';

  @override
  String get defaultCalendar => '默认日历';

  @override
  String get defaultTaskList => '默认任务列表';

  @override
  String get lastUsed => '最近使用';

  @override
  String get scheduleDisplayHoursDescription =>
      '日视图和周视图最初显示此时间范围。需要时，更早或更晚的项目会扩展该范围。';

  @override
  String get scheduleDayStartsAt => '每日开始时间';

  @override
  String get scheduleDayEndsAt => '每日结束时间';

  @override
  String get sourceCalendar => '日历';

  @override
  String get sourceTaskList => '任务列表';

  @override
  String get createChoiceTitle => '新建';

  @override
  String get createEventAtTime => '日程';

  @override
  String get createTaskAtDate => '任务';

  @override
  String get editEvent => '编辑日程';

  @override
  String get eventTitle => '日程标题';

  @override
  String get location => '地点';

  @override
  String get timeSlot => '时间段';

  @override
  String get startDateTime => '开始日期/时间';

  @override
  String get endDateTime => '结束日期/时间';

  @override
  String get doesNotRepeat => '不重复';

  @override
  String get defaultReminder => '默认提醒';

  @override
  String get guests => '参与者';

  @override
  String get noGuests => '无参与者';

  @override
  String get attendeeRequired => '必需';

  @override
  String get attendeeOptional => '可选';

  @override
  String get meetingSection => '会议';

  @override
  String get addGoogleMeet => '添加 Google Meet';

  @override
  String get addTeamsMeeting => '添加 Microsoft Teams 会议';

  @override
  String get onlineMeetingAdded => '已添加在线会议';

  @override
  String get requestResponses => '请求回复';

  @override
  String get requestResponsesDescription => '要求参与者回复邀请。';

  @override
  String get hideGuestList => '隐藏参与者列表';

  @override
  String get hideGuestListDescription => '参与者无法查看其他受邀者。';

  @override
  String get allowNewTimeProposals => '允许提出新时间';

  @override
  String get allowNewTimeProposalsDescription => '参与者可以建议其他会议时间。';

  @override
  String get notifyGuestsTitle => '通知参与者？';

  @override
  String get notifyGuestsSaveMessage => '此会议有参与者。保存时发送邀请或日程更新吗？';

  @override
  String get notifyGuestsDeleteMessage => '此会议有参与者。删除时发送取消通知吗？';

  @override
  String get sendUpdates => '发送更新';

  @override
  String get sendCancellation => '发送取消通知';

  @override
  String get doNotSend => '不发送';

  @override
  String get microsoftNotifyGuestsSaveTitle => '保存会议？';

  @override
  String get microsoftNotifyGuestsSaveMessage => 'Microsoft 将向参与者发送邀请或日程更新。';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '删除会议？';

  @override
  String get microsoftNotifyGuestsDeleteMessage => 'Microsoft 将向参与者发送取消通知。';

  @override
  String get organizer => '组织者';

  @override
  String get yourResponse => '你的回复';

  @override
  String get guestResponses => '参与者回复';

  @override
  String get respond => '回复';

  @override
  String get acceptInvitation => '接受';

  @override
  String get tentativeInvitation => '暂定';

  @override
  String get declineInvitation => '拒绝';

  @override
  String get joinMeeting => '加入会议';

  @override
  String get responseAccepted => '已接受';

  @override
  String get responseTentative => '暂定';

  @override
  String get responseDeclined => '已拒绝';

  @override
  String get responseNeedsAction => '等待回复';

  @override
  String get responseNotResponded => '未回复';

  @override
  String get responseOrganizer => '组织者';

  @override
  String invitationResponseFailed(String error) {
    return '无法发送回复：$error';
  }

  @override
  String get joinMeetingFailed => '无法打开会议链接。';

  @override
  String get description => '说明';

  @override
  String get availabilityShowAs => '空闲状态 / 显示为';

  @override
  String get busy => '忙碌';

  @override
  String get visibility => '可见性';

  @override
  String get defaultVisibility => '默认可见性';

  @override
  String get conference => '会议';

  @override
  String get noConference => '无会议';

  @override
  String get providerCalendar => '服务日历';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => '粗体';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => '斜体';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => '下划线';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString 分钟前',
      one: '1 分钟前',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => '开始时';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString 小时前',
      one: '1 小时前',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString 天前',
      one: '1 天前',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => '空闲';

  @override
  String get availabilityTentative => '暂定';

  @override
  String get availabilityOutOfOffice => '不在办公室';

  @override
  String get availabilityWorkingElsewhere => '在其他地点办公';

  @override
  String get visibilityDefault => '默认';

  @override
  String get visibilityPublic => '公开';

  @override
  String get visibilityPrivate => '私密';

  @override
  String get visibilityConfidential => '机密';

  @override
  String get sensitivityNormal => '普通';

  @override
  String get sensitivityPersonal => '个人';

  @override
  String get tasks => '任务';

  @override
  String get allTasks => '所有任务';

  @override
  String tasksInList(String title) {
    return '$title中的任务';
  }

  @override
  String get taskLists => '任务列表';

  @override
  String get navigation => '导航';

  @override
  String get mainMenu => '主菜单';

  @override
  String get keyboardShortcuts => '键盘快捷键';

  @override
  String get shortcutGroupGeneral => '常规';

  @override
  String get shortcutKeyboardShortcutsDescription => '显示快捷键参考表';

  @override
  String get shortcutGroupNavigation => '导航';

  @override
  String get shortcutNextPeriod => '下一时段';

  @override
  String get shortcutNextPeriodDescription => '在周视图中前往下一周，在月视图中前往下个月，依此类推';

  @override
  String get shortcutPreviousPeriod => '上一时段';

  @override
  String get shortcutPreviousPeriodDescription => '在周视图中前往上一周，在月视图中前往上个月，依此类推';

  @override
  String get shortcutJumpToToday => '跳转到今天';

  @override
  String get shortcutGroupView => '视图';

  @override
  String get viewSelector => '视图';

  @override
  String get shortcutDayView => '日视图';

  @override
  String get shortcutWeekView => '周视图';

  @override
  String get shortcutMonthView => '月视图';

  @override
  String get shortcutYearView => '年视图';

  @override
  String get shortcutAgendaView => '日程视图';

  @override
  String get shortcutGroupCreateAndEdit => '新建和编辑';

  @override
  String get shortcutSaveItem => '保存日程或任务';

  @override
  String get shortcutDeleteItem => '删除日程或任务';

  @override
  String get shortcutGroupTaskEditing => '任务编辑';

  @override
  String get shortcutCancelEditing => '取消编辑';

  @override
  String get shortcutCancelEditingDescription => '关闭任务编辑或任务详情';

  @override
  String get aboutBusyMax => '关于 BusyMax';

  @override
  String get aboutBusyMaxDescription => '日历和任务';

  @override
  String get license => '许可证';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => '网站';

  @override
  String get sourceCode => '源代码';

  @override
  String get reportAnIssue => '报告问题';

  @override
  String get sendFeedback => '发送反馈';

  @override
  String get feedbackSubmit => '提交';

  @override
  String get feedbackCategory => '类别';

  @override
  String get feedbackSelectCategory => '选择类别';

  @override
  String get feedbackCategoryProblem => '问题或错误';

  @override
  String get feedbackCategoryFeature => '功能请求';

  @override
  String get feedbackCategoryPrivacySecurity => '隐私或安全问题';

  @override
  String get feedbackCategoryUsability => '易用性问题';

  @override
  String get feedbackCategoryOther => '其他';

  @override
  String get feedbackSubject => '主题';

  @override
  String get feedbackDetailedMessage => '详细信息';

  @override
  String get feedbackReplyEmail => '用于接收回复的电子邮件地址（可选）';

  @override
  String get feedbackIncludeTechnicalDetails => '包含技术详情';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      '仅添加您的操作系统名称和版本以及应用区域设置。不包含日志、账户数据、文件名或其他诊断信息。';

  @override
  String get feedbackCategoryRequired => '请选择类别。';

  @override
  String get feedbackSubjectLengthError => '主题必须为 3 至 120 个字符。';

  @override
  String get feedbackMessageLengthError => '消息必须为 10 至 5,000 个字符。';

  @override
  String get feedbackInvalidEmail => '请输入有效的电子邮件地址。';

  @override
  String get feedbackConnectionError => '无法连接到 BusyStack。请检查连接，然后重试。';

  @override
  String get feedbackTimeoutError => '请求超时。您的反馈尚未清除，请重试。';

  @override
  String get feedbackRateLimitedError => '从此网络发送的反馈过多。请稍后再试。';

  @override
  String get feedbackRejectedError => '服务器拒绝了提交。请检查各字段，然后重试。';

  @override
  String get feedbackServerError => 'BusyStack 目前无法接收您的反馈。您的反馈尚未清除，请重试。';

  @override
  String feedbackSuccess(String id) {
    return '反馈已发送。参考编号：$id';
  }

  @override
  String get toggleSidebar => '显示或隐藏侧边栏';

  @override
  String get showSidebar => '显示侧边栏面板';

  @override
  String get hideSidebar => '隐藏侧边栏面板';

  @override
  String get accounts => '账户';

  @override
  String get currentAccount => '当前账户';

  @override
  String get switchAccount => '切换账户';

  @override
  String get addGoogleAccount => '添加 Google 账户';

  @override
  String get addMicrosoftAccount => '添加 Microsoft 账户';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => '已登录';

  @override
  String get removeAccount => '移除账户…';

  @override
  String get removingAccount => '正在移除账户…';

  @override
  String get removeAccountDescription => '停止同步并从此设备移除此账户的数据。';

  @override
  String removeAccountTitle(String account) {
    return '从 BusyMax 中移除 $account？';
  }

  @override
  String get removeAccountConfirmation =>
      '这会从此设备删除缓存的任务、日历、日程、提醒和待处理的离线更改。未同步的更改将会丢失。提供商中的日历、日程、任务列表和任务副本不会被删除。';

  @override
  String get revokeGoogleAccess => '同时撤销 BusyMax 对此 Google 账户的访问权限';

  @override
  String get revokeGoogleAccessDescription => '重新连接之前，您需要再次授予访问权限。';

  @override
  String get removeAccountAction => '移除账户';

  @override
  String get removeAccountFailed => '无法完成账户移除。请重试。';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      '该账户已从此设备移除，但无法撤销 BusyMax 对您的 Google 账户的访问权限。您可以在 Google 账户中手动撤销该权限。';

  @override
  String get newTaskList => '新任务列表';

  @override
  String taskListCreateFailed(String error) {
    return '无法创建任务列表：$error';
  }

  @override
  String taskListRenameFailed(String error) {
    return '无法重命名任务列表：$error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return '无法删除任务列表：$error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      '删除或移除此列表前，请同步账户，或在“诊断”中解决此任务列表被阻止的更改。';

  @override
  String get signInToViewTaskLists => '登录以查看任务列表。';

  @override
  String get noTaskListsSynced => '尚未同步任何任务列表。';

  @override
  String get listActions => '列表操作';

  @override
  String get rename => '重命名';

  @override
  String get delete => '删除';

  @override
  String get renameList => '重命名列表';

  @override
  String get deleteList => '删除列表';

  @override
  String get unshare => '取消共享';

  @override
  String get readOnlyTaskListCannotRename => '此任务列表为只读，无法重命名。';

  @override
  String get taskListCannotDelete => '使用当前权限无法删除此任务列表。';

  @override
  String get builtInMicrosoftList => '内置';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      '无法重命名或删除 Microsoft To Do 内置列表。';

  @override
  String deleteListConfirmation(String title) {
    return '要从 Google Tasks 中删除“$title”吗？';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '要删除“$title”及其所有任务吗？';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return '要取消此账户对“$title”的共享吗？';
  }

  @override
  String get deleteEvent => '删除日程';

  @override
  String get title => '标题';

  @override
  String get create => '新建';

  @override
  String get newTask => '新建任务';

  @override
  String get clearCompleted => '清除已完成项';

  @override
  String get refreshList => '刷新列表';

  @override
  String get refreshAll => '全部刷新';

  @override
  String get listRefreshed => '列表已刷新。';

  @override
  String get allTasksRefreshed => '所有账户均已刷新。';

  @override
  String exportedFile(String path) {
    return '已导出到 $path';
  }

  @override
  String exportFailed(String error) {
    return '导出失败：$error';
  }

  @override
  String refreshFailed(String error) {
    return '刷新失败：$error';
  }

  @override
  String get selectOrCreateTaskList => '请选择或创建任务列表以开始使用。';

  @override
  String get signInToViewTasks => '登录以查看任务。';

  @override
  String get noTasks => '没有任务。';

  @override
  String get noTasksYet => '还没有任务';

  @override
  String get noTasksYetMessage => '创建任务或刷新账户以开始使用。';

  @override
  String get noTasksInList => '此列表中没有任务。';

  @override
  String get overdue => '已逾期';

  @override
  String get today => '今天';

  @override
  String get tomorrow => '明天';

  @override
  String get upcoming => '即将到期';

  @override
  String get noDate => '无日期';

  @override
  String get completed => '已完成';

  @override
  String duePrefix(String date) {
    return '$date 到期';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => '任务详情';

  @override
  String get editTask => '编辑任务';

  @override
  String get noTaskSelected => '未选择任务。';

  @override
  String get noTaskSelectedHelper => '选择任务以查看和编辑详情。';

  @override
  String get taskUnavailable => '任务不可用。';

  @override
  String get signInToEditTasks => '登录以编辑任务。';

  @override
  String get refreshTask => '刷新任务';

  @override
  String get primarySection => '主要信息';

  @override
  String get statusSection => '状态';

  @override
  String get openStatus => '未完成';

  @override
  String get doneStatus => '已完成';

  @override
  String get taskStatus => '状态';

  @override
  String get taskStatusNone => '无状态';

  @override
  String get taskStatusNeedsAction => '需要操作';

  @override
  String get taskStatusInProcess => '进行中';

  @override
  String get taskStatusCompleted => '已完成';

  @override
  String get taskStatusCancelled => '已取消';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '已完成 $percentString%';
  }

  @override
  String get completionDate => '完成日期';

  @override
  String get priority => '优先级';

  @override
  String get priorityNone => '无优先级';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 高';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 中';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 低';
  }

  @override
  String get taskUrl => '任务 URL';

  @override
  String get invalidTaskUrl => '请输入包含方案的绝对 URL。';

  @override
  String get classification => '分类';

  @override
  String get classificationPublic => '共享时显示完整任务';

  @override
  String get classificationConfidential => '共享时仅显示忙碌状态';

  @override
  String get classificationPrivate => '共享时隐藏此任务';

  @override
  String get pinTask => '固定任务';

  @override
  String get notes => '备注';

  @override
  String get dueDate => '截止日期';

  @override
  String get clearDueDate => '清除截止日期';

  @override
  String get dueTime => '截止时间';

  @override
  String get startDate => '开始日期';

  @override
  String get startTime => '开始时间';

  @override
  String get endDate => '结束日期';

  @override
  String get endTime => '结束时间';

  @override
  String get reminderDate => '提醒日期';

  @override
  String get reminderTime => '提醒时间';

  @override
  String get reminder => '提醒';

  @override
  String get addReminder => '添加提醒';

  @override
  String get reminders => '提醒';

  @override
  String get noReminders => '无提醒';

  @override
  String get editReminder => '编辑提醒';

  @override
  String get beforeTaskStarts => '任务开始前';

  @override
  String get beforeTaskDue => '任务到期前';

  @override
  String get afterTaskStarts => '任务开始后';

  @override
  String get afterTaskDue => '任务到期后';

  @override
  String get relativeToTaskStart => '相对于任务开始日期';

  @override
  String get relativeToTaskDue => '相对于任务到期日期';

  @override
  String get reminderTimeOfDay => '时间';

  @override
  String get absoluteReminder => '在指定日期和时间';

  @override
  String get reminderAmount => '数量';

  @override
  String get reminderUnit => '单位';

  @override
  String get reminderUnitSeconds => '秒';

  @override
  String get reminderUnitMinutes => '分钟';

  @override
  String get reminderUnitHours => '小时';

  @override
  String get reminderUnitDays => '天';

  @override
  String get reminderUnitWeeks => '周';

  @override
  String get reminderAtTaskStart => '任务开始时';

  @override
  String get reminderAtTaskDue => '任务到期时';

  @override
  String get unsupportedReminder => '此提醒类型会保留，但无法编辑其时间。';

  @override
  String get relatedRemindersTitle => '保留相关提醒？';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '此日期有 $countString 个相关提醒。要保留它们当前的日期和时间吗？';
  }

  @override
  String get discardRelatedReminders => '舍弃提醒';

  @override
  String get keepRelatedReminders => '保留提醒';

  @override
  String get addGuest => '添加参与者';

  @override
  String get addGuestEmail => '添加参与者电子邮件';

  @override
  String get removeReminder => '移除提醒';

  @override
  String get off => '关闭';

  @override
  String get repeat => '重复';

  @override
  String get repeatNone => '不重复';

  @override
  String get noneValue => '无';

  @override
  String get repeatDaily => '每天';

  @override
  String get repeatWeekly => '每周';

  @override
  String get repeatMonthly => '每月';

  @override
  String get repeatYearly => '每年';

  @override
  String get repeatEvery => '重复间隔';

  @override
  String get repeatOn => '重复日期';

  @override
  String get repeatEnd => '结束重复';

  @override
  String get repeatNever => '从不';

  @override
  String get repeatUntil => '指定日期';

  @override
  String get repeatAfter => '指定次数后';

  @override
  String get repeatCount => '重复次数';

  @override
  String get repeatDayOfMonth => '每月日期';

  @override
  String get repeatMonths => '月份';

  @override
  String get repeatOrdinal => '星期位置';

  @override
  String get repeatSpecificDays => '特定日期';

  @override
  String get repeatFirst => '第一';

  @override
  String get repeatSecond => '第二';

  @override
  String get repeatThird => '第三';

  @override
  String get repeatFourth => '第四';

  @override
  String get repeatFifth => '第五';

  @override
  String get repeatSecondToLast => '倒数第二';

  @override
  String get repeatLast => '最后';

  @override
  String get repeatAnyDay => '日期';

  @override
  String get repeatWeekday => '工作日';

  @override
  String get repeatWeekendDay => '周末';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'day': '日期',
      'weekday': '工作日',
      'weekend': '周末',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 天';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 周';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 个月';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 年';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '在 $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '在 $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '重复 $countString 次',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '直到 $date';
  }

  @override
  String get unsupportedRecurrencePreserved => '此重复规则使用了编辑器不会更改的选项。';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      '此列表不支持此重复模式。请更改模式或选择其他列表。';

  @override
  String get taskRecurrenceRequiresDate => '请添加开始日期或截止日期以使用此重复模式，或关闭重复。';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return '此重复规则不能用于 $provider。';
  }

  @override
  String get importance => '重要性';

  @override
  String get importanceLow => '低';

  @override
  String get importanceNormal => '普通';

  @override
  String get importanceHigh => '高';

  @override
  String get categories => '类别';

  @override
  String get scheduleSection => '日程';

  @override
  String get dueGroup => '截止';

  @override
  String get startGroup => '开始';

  @override
  String get reminderGroup => '提醒';

  @override
  String get organizationSection => '整理';

  @override
  String get actionsSection => '操作';

  @override
  String get advancedSection => '高级';

  @override
  String get addCategory => '添加类别';

  @override
  String get list => '列表';

  @override
  String get microsoftMoveUnsupported => '此版本不支持在 Microsoft To Do 账户的列表之间移动任务。';

  @override
  String get createSubtask => '创建子任务';

  @override
  String get subtasks => '子任务';

  @override
  String get duplicateTask => '复制任务';

  @override
  String get taskDuplicated => '任务已复制。';

  @override
  String taskDuplicateFailed(String error) {
    return '无法复制任务：$error';
  }

  @override
  String get hideSubtasks => '隐藏子任务';

  @override
  String get hideClosedSubtasks => '隐藏已关闭的子任务';

  @override
  String get moveToTop => '移到顶部';

  @override
  String get deleteTask => '删除任务';

  @override
  String get newSubtask => '新建子任务';

  @override
  String deleteTaskConfirmation(String title) {
    return '删除“$title”？';
  }

  @override
  String get deleteAssignedTaskWarning => '这也会删除 Google 文档或 Chat 聊天室中的原始任务。';

  @override
  String get metadata => '元数据';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => '更新时间';

  @override
  String get parent => '父任务';

  @override
  String get position => '位置';

  @override
  String get webLink => '网页链接';

  @override
  String get assignment => '分配';

  @override
  String get localState => '本地状态';

  @override
  String get pendingSync => '等待同步';

  @override
  String get synced => '已同步';

  @override
  String get account => '账户';

  @override
  String get sync => '同步';

  @override
  String get forceFullResync => '强制完全重新同步';

  @override
  String get forceFullResyncDescription =>
      '从每个已连接的账号中重新完整加载所有数据。请仅在排查同步问题时使用此功能。';

  @override
  String get runInBackgroundWhenClosed => '窗口关闭后继续在后台运行';

  @override
  String get showTrayIcon => '显示托盘图标';

  @override
  String get startMinimizedToTray => '启动时最小化到托盘';

  @override
  String get launchAtLogin => '登录时启动';

  @override
  String get launchAtLoginDescription => '在后台启动 BusyMax，以便登录后提醒能够正常工作。';

  @override
  String get launchAtLoginFailed => '无法更新登录时启动设置。';

  @override
  String get requiresTrayIcon => '需要托盘图标。';

  @override
  String get syncComplete => '同步完成。';

  @override
  String syncFailed(String error) {
    return '同步失败：$error';
  }

  @override
  String get notifySyncFailures => '同步失败通知';

  @override
  String get notifyConflicts => '冲突通知';

  @override
  String get notifyDueToday => '今天到期任务通知';

  @override
  String get eventReminders => '日程提醒';

  @override
  String get onState => '开启';

  @override
  String get taskReminders => '任务提醒';

  @override
  String get notificationDetailLevel => '通知详细程度';

  @override
  String get notificationDetailPrivate => '私密';

  @override
  String get notificationDetailNormal => '普通';

  @override
  String get quietHours => '免打扰时段';

  @override
  String get quietHoursDescription => '在此时段暂停通知。';

  @override
  String get quietHoursStart => '免打扰开始时间';

  @override
  String get quietHoursEnd => '免打扰结束时间';

  @override
  String get notifications => '通知';

  @override
  String get windowsNotificationsUnavailable => 'Windows 通知不可用';

  @override
  String get windowsNotificationsUnpackaged =>
      '此未打包的开发版本无法使用 Windows 通知。请安装测试签名的 MSIX 以测试提醒。';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax 无法初始化 Windows 通知。在解决此安装问题之前，提醒不会显示。';

  @override
  String get appearance => '外观';

  @override
  String get theme => '主题';

  @override
  String get themeSystem => '系统';

  @override
  String get settingsSystem => '系统';

  @override
  String get themeLight => '浅色';

  @override
  String get themeDark => '深色';

  @override
  String get themeFamily => '主题系列';

  @override
  String get themeFamilyYaru => 'Ubuntu 原生主题（Yaru）';

  @override
  String get localization => '语言和区域';

  @override
  String get currentLocale => '当前区域设置';

  @override
  String get privacy => '隐私';

  @override
  String get redactTaskContentInDiagnostics => '在诊断信息中隐藏任务内容';

  @override
  String get developerDiagnostics => '开发者诊断';

  @override
  String get diagnostics => '诊断';

  @override
  String get apiInspectorDisabled => '显示 API 检查器';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery 修订版：$revision';
  }

  @override
  String get implementedMethods => '已实现的方法';

  @override
  String get supportsTasksScopes => '支持 tasks 和 tasks.readonly 权限范围';

  @override
  String get requiresTasksScope => '需要 tasks 权限范围';

  @override
  String get blockedPendingOperations => '被阻止的待处理操作';

  @override
  String get signInToInspectPendingOperations => '登录以检查待处理操作。';

  @override
  String get noBlockedPendingOperations => '没有被阻止的待处理操作。';

  @override
  String get operationActions => '操作选项';

  @override
  String pendingOpListId(String id) {
    return '列表=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return '任务=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '尝试次数=$countString';
  }

  @override
  String get retry => '重试';

  @override
  String get discard => '舍弃';

  @override
  String get discardChangesAction => '舍弃';

  @override
  String get discardChanges => '舍弃更改？';

  @override
  String get discardChangesConfirmation => '这将舍弃对此任务所做的未保存编辑。';

  @override
  String get retryCompleted => '重试完成。';

  @override
  String get discardPendingOperation => '舍弃待处理操作？';

  @override
  String get discardPendingOperationConfirmation =>
      '这将移除被阻止的本地操作。下次同步时将从 Google Tasks 刷新数据。';

  @override
  String get pendingOperationDiscarded => '已舍弃待处理操作。';

  @override
  String get syncFailureNotificationTitle => 'BusyMax 同步失败';

  @override
  String syncFailureNotificationBody(String message) {
    return '后台同步失败。$message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax 同步冲突';

  @override
  String conflictNotificationBody(String summary) {
    return '一项待处理的本地更改被阻止。$summary';
  }

  @override
  String get dueTodayNotificationTitle => '今天到期的任务';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $countString 项任务到期。',
      one: '今天有 1 项任务到期。',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => '日程提醒';

  @override
  String get taskReminderNotificationTitle => '任务提醒';

  @override
  String get eventReminderNotificationBody => '日程即将开始。';

  @override
  String get taskReminderNotificationBody => '任务即将到期。';

  @override
  String get notificationOpenAction => '打开';

  @override
  String get notificationSnoozeAction => '10 分钟后提醒';

  @override
  String get notificationDismissAction => '关闭';

  @override
  String get notificationDetailsHidden => '根据隐私设置，详细信息已隐藏。';

  @override
  String get previousMonth => '上个月';

  @override
  String get nextMonth => '下个月';

  @override
  String get openMonthView => '打开月视图';

  @override
  String get previousYear => '上一年';

  @override
  String get nextYear => '下一年';

  @override
  String get openYearView => '打开年视图';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return '第 $numberString 周';
  }

  @override
  String get resizeAllDayPanel => '调整全天面板的大小';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString 项',
      one: '1 项',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => '此日历为只读。';

  @override
  String get selectTimeZone => '选择时区';

  @override
  String get searchLocations => '搜索地点';

  @override
  String get noLocationsFound => '未找到地点';

  @override
  String get requiredField => '此字段为必填项。';

  @override
  String get providerConnectionDescription => '连接以下任一提供商中的日历和任务。';

  @override
  String get appleICloudProvider => 'Apple iCloud 日历';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud 任务';

  @override
  String get addAppleICloudAccount => '添加 Apple iCloud 日历账户';

  @override
  String get addNextcloudAccount => '添加 Nextcloud 账户';

  @override
  String get waitingForAppleICloud => '正在连接 Apple iCloud…';

  @override
  String get waitingForNextcloud => '正在等待 Nextcloud 授权…';

  @override
  String get connectAppleICloudTitle => '连接 Apple iCloud 日历';

  @override
  String get appleAccountEmail => 'Apple 账户电子邮件';

  @override
  String get appleAppSpecificPassword => 'App 专用密码';

  @override
  String get appleAppSpecificPasswordHelp => '为 Apple 账户启用双重认证后，创建 App 专用密码。';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      '重置 Apple 账户密码会撤销 App 专用密码。';

  @override
  String get connectNextcloudTitle => '连接 Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloud 服务器或 CalDAV 地址';

  @override
  String get nextcloudServerUrlHelp =>
      '输入 Nextcloud 服务器 URL，或粘贴从 Nextcloud 复制的主要 CalDAV 地址。';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax 将打开浏览器。请在那里批准访问，然后返回 BusyMax。';

  @override
  String get connectAccountAction => '连接';

  @override
  String get cancelAccountConnection => '取消连接';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      '账户已在本地移除，但无法撤销 Nextcloud App 密码。';

  @override
  String get davReauthenticationRequired => '重新连接此账户以恢复同步。';

  @override
  String get davTemporarilyUnavailable => '此账户暂时不可用。';

  @override
  String get davPermissionChanged => '服务器权限已更改。待处理的编辑已暂停。';

  @override
  String get davUnsupportedServer => '不支持此服务器或提供商配置。';

  @override
  String get collectionSettings => '日历和任务列表';

  @override
  String get calendarContent => '日历日程';

  @override
  String get taskContent => '任务';

  @override
  String get readOnlySharedCollection => '只读';

  @override
  String get pendingLocally => '本地待处理';

  @override
  String get conflictBlocked => '因冲突而阻止';

  @override
  String get authenticationBlocked => '重新连接前阻止';

  @override
  String get operationFailed => '操作失败';

  @override
  String get keepServerVersion => '保留服务器版本';

  @override
  String get reapplyLocalChange => '查看并重新应用本地更改';

  @override
  String get duplicateLocalItem => '复制为新项目';

  @override
  String get davConnectionState => '连接状态';

  @override
  String get davConnected => '已连接';

  @override
  String get davConnecting => '正在连接…';

  @override
  String get davSignedOut => '已退出登录';

  @override
  String davLastSuccessfulSync(String time) {
    return '上次成功同步：$time';
  }

  @override
  String get davNeverSynced => '尚未同步';

  @override
  String get refreshCollections => '刷新日历和任务列表';

  @override
  String nextcloudServerHost(String host) {
    return '服务器：$host';
  }

  @override
  String get collectionSupportsEvents => '日程日历';

  @override
  String get collectionSupportsTasks => '任务列表';

  @override
  String get collectionSupportsEventsAndTasks => '日程和任务';

  @override
  String get writableCollection => '可写';

  @override
  String get sharedCollection => '已共享';

  @override
  String collectionLastSynced(String time) {
    return '上次同步：$time';
  }

  @override
  String collectionSyncError(String code) {
    return '同步问题：$code';
  }

  @override
  String get syncConflicts => '同步冲突';

  @override
  String remoteChangedAt(String time) {
    return '服务器更改：$time';
  }

  @override
  String localPendingEdit(String summary) {
    return '本地编辑：$summary';
  }

  @override
  String get conflictResolutionFailed => '无法解决冲突。';

  @override
  String get recurringEventScope => '重复日程范围';

  @override
  String get entireSeries => '整个系列';

  @override
  String get singleOccurrence => '此事件';

  @override
  String get thisAndFollowingEvents => '此事件及后续事件';

  @override
  String get thisAndFutureUnavailable => '此提供商不支持。';

  @override
  String get thisAndFutureMoveUnavailable => '无法安全移动此日程及后续日程。请选择此日程或整个系列。';

  @override
  String get entireSeriesMoveUnavailable => '本地没有可用的重复规则。请仅移动此日程。';

  @override
  String get copyEventAndDeleteOriginal => '复制日程并删除原日程？';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax 无法将此日程直接从 $source 移动到 $destination。应用会先创建副本，并且仅在复制成功后删除原日程。日程 ID 将发生变化；参与者的回复状态可能会重置，并可能发送邀请或取消通知；会议链接、附件、提醒、提供商特有的字段和重复例外可能无法保留。';
  }

  @override
  String get copyAndDelete => '复制并删除';

  @override
  String get chooseRecurringEventScope => '选择此更改适用于整个系列、仅此日程，还是此日程及后续日程。';

  @override
  String get taskDueBeforeStart => '截止时间不能早于开始时间。';

  @override
  String get taskStartDueTimeModeMismatch => '请同时设置开始和截止时间，或将任务设为全天。';

  @override
  String deleteCalendarConfirmation(String title) {
    return '删除“$title”？';
  }

  @override
  String get setCustomCalendarName => '设置自定义名称';

  @override
  String get setAction => '设置';

  @override
  String get removeFromMyCalendars => '从“我的日历”中移除';

  @override
  String get removeAction => '移除';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '要从 BusyMax 移除“$title”吗？所有者的日历和日程不会被删除。';
  }

  @override
  String get attachmentUploadUnresolved => '上传可能已完成。再次上传前，请刷新附件以确认结果。';

  @override
  String removeCalendarConfirmation(String title) {
    return '要从您的 Google 日历列表中移除“$title”吗？共享日历及其日程不会被删除。';
  }

  @override
  String get calendarCannotRemove => '无法从此账户删除或移除此日历。';

  @override
  String get calendarPendingChangesPreventRemoval =>
      '请等待此日历的待处理更改完成同步，然后再删除或移除它。';

  @override
  String get calendarSubscriptions => '日历订阅';

  @override
  String get calendarSubscriptionsDescription => '添加从安全 WebCal URL 刷新的只读日历。';

  @override
  String get addCalendarSubscription => '添加日历订阅';

  @override
  String get subscriptionName => '本地名称';

  @override
  String get subscriptionUrl => '订阅 URL';

  @override
  String get subscriptionUrlHelp =>
      '输入 HTTPS 或 webcal URL。BusyMax 会将完整 URL 保存在安全存储中。';

  @override
  String get subscriptionUrlInvalid => '请输入不含用户信息或片段的有效 HTTPS 或 webcal URL。';

  @override
  String get subscriptionColor => '本地颜色';

  @override
  String get subscriptionColorHelp => '使用六位颜色，例如 #3584E4。';

  @override
  String get subscriptionColorInvalid => '请输入六位十六进制颜色。';

  @override
  String get subscriptionRefreshMode => '刷新频率';

  @override
  String get subscriptionAutomatic => '自动';

  @override
  String get subscriptionHourly => '每小时';

  @override
  String get subscriptionSixHours => '每六小时';

  @override
  String get subscriptionDaily => '每天';

  @override
  String subscriptionSafeOrigin(String origin) {
    return '来源：$origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable => '请输入有效 URL 以预览其安全来源。';

  @override
  String get subscriptionReadOnly => '只读订阅';

  @override
  String get subscriptionNeverRefreshed => '尚未刷新';

  @override
  String subscriptionLastRefresh(String time) {
    return '上次成功刷新：$time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return '下次刷新：$time';
  }

  @override
  String get subscriptionStatusHealthy => '已是最新';

  @override
  String subscriptionStatusIssue(String code) {
    return '刷新问题：$code';
  }

  @override
  String get refreshNow => '立即刷新';

  @override
  String get unsubscribe => '取消订阅';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '要取消订阅“$name”吗？';
  }

  @override
  String get unsubscribeCalendarConfirmation => '这会移除本地订阅及其缓存的日程。已发布的日历不会更改。';

  @override
  String get addSubscriptionAction => '添加订阅';

  @override
  String subscriptionOperationFailed(String error) {
    return '日历订阅失败：$error';
  }

  @override
  String get subscriptions => '订阅';

  @override
  String get calendarImport => '日历导入';

  @override
  String get calendarImportDescription => '选择文件，查看其中的日程，然后选择接收这些日程的可写日历。';

  @override
  String get importIcsFile => '导入 .ics 文件';

  @override
  String get importIcsPreview => '导入日历日程';

  @override
  String importEventsFound(int count) {
    return '可导入日程集：$count';
  }

  @override
  String importInvalidEvents(int count) {
    return '无效日程：$count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return '有意省略：$fields';
  }

  @override
  String get noWritableCalendars => '没有可用的可写目标日历。';

  @override
  String get importDestinationCalendar => '目标日历';

  @override
  String get importIcsConfirm => '导入日程';

  @override
  String get importIcsComplete => '导入完成';

  @override
  String importQueued(int count) {
    return '已导入或已排队：$count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return '已跳过重复项：$count';
  }

  @override
  String importUnsupportedSets(int count) {
    return '不支持的重复集：$count';
  }

  @override
  String importIcsFailed(String error) {
    return '无法导入日历文件：$error';
  }

  @override
  String get networkOffline => '离线';

  @override
  String get networkOfflineDescription => '恢复连接后将同步更改。';

  @override
  String get networkOfflineTryAgain => '您当前处于离线状态。请连接互联网后重试。';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days';
  }

  @override
  String get repeatSummarySeparator => '';

  @override
  String repeatMonthDayValue(String day) {
    return '$day日';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency$month$day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency$month的$days';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency$months的$day';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency$months的$days';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$frequency$month的$_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$frequency$months的$_temp0';
  }

  @override
  String get searchFilters => '搜索筛选条件';

  @override
  String get searchType => '类型';

  @override
  String get searchDate => '日期';

  @override
  String get searchAnyDate => '任何日期（已下載資料）';

  @override
  String get eventLink => '活動連結';

  @override
  String get eventLinkOpenFailed => '無法開啟連結。';

  @override
  String get scheduleRangeIncomplete => '部分活動無法確認，正在顯示已下載資料。';

  @override
  String get searchThisWeek => '本周';

  @override
  String get searchCustomRange => '自定义范围';

  @override
  String get searchTaskStatus => '任务状态';

  @override
  String get searchTaskDue => '任务到期状态';

  @override
  String get searchAnyDueState => '任何到期状态';

  @override
  String get searchNoDueDate => '无截止日期';

  @override
  String get searchPerson => '人员';

  @override
  String get searchSources => '来源';

  @override
  String get searchClearFilters => '重置筛选条件';

  @override
  String get searchFiltersAction => '筛选';

  @override
  String get searchNoSources => '未选择搜索来源';

  @override
  String get searchClearText => '清除文字';

  @override
  String get openSharedCalendar => '打开共享日历';

  @override
  String get manageCalendarSharing => '管理日历共享';

  @override
  String get shareRecipientEmail => '接收者邮箱';

  @override
  String get shareRole => '访问角色';

  @override
  String get addCalendarShare => '添加访问权限';

  @override
  String get sharingRefreshFailed => '共享更改已成功，但无法刷新权限列表。请在再次更改前重新加载列表。';

  @override
  String get sharingRateLimited => '共享暂时受到限制。请在等待时间结束后重试。';

  @override
  String get attachmentUploadRateLimited => '附件上传暂时受到限制。请在等待时间结束后重试。';

  @override
  String get sharingPermissionUnavailable => '此日历的共享权限不可用。';

  @override
  String get calendarShareFreeBusy => '仅查看忙闲';

  @override
  String get calendarShareLimitedRead => '读取有限详情';

  @override
  String get calendarShareRead => '读取全部详情';

  @override
  String get calendarShareWrite => '编辑日程';

  @override
  String get calendarShareWriteWithoutPrivate => '编辑但不查看私人详情';

  @override
  String get calendarShareOwner => '所有者';

  @override
  String get eventLabel => '日程标签';

  @override
  String get loadOutlookCategories => '加载 Outlook 类别';

  @override
  String get outlookCategoriesUnavailable => 'Outlook 类别不可用；现有分配会保留。';

  @override
  String get googleEventType => '日程类型';

  @override
  String get googleRegularEvent => '普通日程';

  @override
  String get googleFocusTime => '专注时间';

  @override
  String get googleOutOfOffice => '外出';

  @override
  String get googleWorkingLocation => '工作地点';

  @override
  String get googleDeclineInvitations => '拒绝重叠的邀请';

  @override
  String get googleDeclineNone => '不拒绝';

  @override
  String get googleDeclineNew => '拒绝新邀请';

  @override
  String get googleDeclineAll => '拒绝所有冲突邀请';

  @override
  String get googleDeclineMessage => '拒绝消息';

  @override
  String get googleChatStatus => '聊天状态';

  @override
  String get googleChatAvailable => '有空';

  @override
  String get googleChatDoNotDisturb => '勿扰';

  @override
  String get googleWorkAtHome => '家';

  @override
  String get googleWorkAtOffice => '办公室';

  @override
  String get googleWorkAtCustomLocation => '自定义地点';

  @override
  String get googleWorkLocationLabel => '地点名称';

  @override
  String get googleStatusPrimaryOnly => 'Google 状态日程需要您的 Google 主日历。';

  @override
  String unknownEventLabel(String id) {
    return '未知标签（$id）';
  }

  @override
  String get calendarOwnerEmail => '日历所有者的电子邮件地址';

  @override
  String registrationSetupTitle(String provider) {
    return '设置 $provider';
  }

  @override
  String get registrationSetupGuide => '设置指南';

  @override
  String get registrationGoogleInstructions =>
      '创建自己的 Google Cloud 项目，启用 Calendar 和 Tasks API，然后导入桌面 OAuth 客户端的 JSON。请授权预期的账号。';

  @override
  String get registrationMicrosoftInstructions =>
      '在允许应用注册的 Entra 租户中使用公共应用注册。输入客户端 ID 和支持的账号类型。无需客户端密码。';

  @override
  String get registrationImportGoogle => '选择桌面 OAuth JSON';

  @override
  String get registrationValidate => '验证注册';

  @override
  String get registrationAuthorize => '在浏览器中授权';

  @override
  String get registrationClientId => '应用程序／客户端 ID';

  @override
  String get registrationTenantId => '租户 ID';

  @override
  String get registrationAudience => '支持的账号';

  @override
  String get registrationBothAudience => '个人和组织账号';

  @override
  String get registrationOrganizationAudience => '组织账号';

  @override
  String get registrationPersonalAudience => '个人账号';

  @override
  String get registrationTenantAudience => '单个组织租户';

  @override
  String registrationSummary(String clientId) {
    return '注册：$clientId';
  }

  @override
  String get registrationMigrate => '立即迁移';

  @override
  String get registrationReplace => '替换注册';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return '此帐号使用为现有帐号保留的原始 $provider 注册。要替换，请设置 $setup 并重新连接此帐号。现有日历、任务和本地更改会保留。';
  }

  @override
  String get registrationContinue => '继续使用此账号';

  @override
  String get registrationGoogleProject => 'Google Cloud 项目';

  @override
  String get registrationMicrosoftApp => 'Microsoft 应用注册';

  @override
  String get registrationUserOwned => '用户提供的注册';

  @override
  String get registrationNativeGoogle => 'Google Android 原生注册';

  @override
  String get registrationShared => '共享注册（过渡期）';

  @override
  String get registrationUnresolved => '无法确定注册来源。账号数据已保留。';

  @override
  String get registrationOfficialDocumentation => '官方文档';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return '软件包：$packageName\n签名哈希：$signatureHash\n重定向 URI：$redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      '请检查注册的客户端类型、支持的账户、权限和重定向设置。若配置来自导入，请重新选择配置文件。';

  @override
  String get oauthAuthorizationCodeUnusable => '此次授权未能完成。请重新开始授权；现有连接已保留。';

  @override
  String get oauthPermissionRefused => '授权被拒绝或缺少所需权限。请重试并授予所需权限。';

  @override
  String get oauthProviderThrottled => '服务提供方正在限制请求。请稍后重试；现有连接已保留。';

  @override
  String get oauthProviderTemporaryFailure => '服务提供方的临时问题导致授权未能完成。请重试；现有连接已保留。';

  @override
  String get oauthAuthorizationTimedOut => '授权超时。请重试；若配置来自导入，请重新选择配置文件。';

  @override
  String get oauthWrongAccount => '请授权为重新连接而选定的账户。现有连接已保留。';

  @override
  String get oauthSecureStorageUnavailable => '安全存储不可用。请恢复安全存储访问后重试。';

  @override
  String get oauthRevokedRemovalIncomplete =>
      '远程授权已撤销，但账户清理未能完成。请重启 BusyMax 以重试本地恢复。';

  @override
  String get addAccount => '添加账户';

  @override
  String get registrationConnect => '连接';

  @override
  String get registrationBack => '返回';

  @override
  String get registrationReplaceGoogle => '替换桌面 OAuth JSON';

  @override
  String get registrationSelectedConfiguration => '已选择的配置';

  @override
  String get registrationDirectoryId => '目录／租户 ID';

  @override
  String get registrationInvalidId => '请输入有效的 UUID。';

  @override
  String get registrationExpired => '此配置已过期。请重新导入或修改注册字段后再连接。';

  @override
  String get registrationOwnProjectRequired => '请选择您自己的项目或租户中的注册。';

  @override
  String get registrationSetupFailed => '无法完成设置，请重试。';

  @override
  String get registrationLinkFailed => '无法打开链接。请检查浏览器后重试。';

  @override
  String get registrationPermissions => '权限';

  @override
  String get registrationDesktopClient => '桌面应用';

  @override
  String get registrationOpenGoogleConsole => '打开 Google Cloud 控制台';

  @override
  String get registrationGoogleAudienceHelp => 'Google 发布和测试用户要求';

  @override
  String get registrationDesktopHelp => '桌面应用注册说明';

  @override
  String get registrationOpenEntra => '打开 Microsoft Entra 管理中心';

  @override
  String get registrationGuideGoogleProject =>
      '打开 Google Cloud Console。使用顶部的项目选择器选择您自己的项目，或选择 New project，输入名称后选择 Create。后续步骤请保持选中此项目。';

  @override
  String get registrationGuideGoogleAudience =>
      '进入 Google Auth Platform → Branding。如果尚未开始设置，选择 Get started。在 App name 中输入 BusyMax，选择您自己的 User support email，然后选择 Next。在 Audience 中，请选择 External。选择 Next，在 Contact Information 中输入您的邮箱，再选择 Next。接受 User Data Policy，然后选择 Continue 和 Create。如果已完成设置，请检查 Branding 和 Audience。';

  @override
  String get registrationGuideGooglePermissions =>
      '打开 Google Auth Platform → Data Access → Add or remove scopes。选择下面五个权限范围；必要时使用 Manually add scopes。手动输入时，粘贴缺少的值并选择 Add to table。选择 Update，再选择 Save。BusyMax 需要日历和任务的访问权限。';

  @override
  String get registrationGuideGoogleClient =>
      '打开 Google Auth Platform → Clients → Create client。将 Application type 设为 Desktop app，在 Name 中输入 BusyMax 并选择 Create。在创建对话框中选择 Download JSON 并保存文件。选择返回以回到表单，选择该文件并检查项目和客户端 ID。选择连接，然后在浏览器中批准日历和任务访问权限。';

  @override
  String get registrationGuideMicrosoftApp =>
      '登录 Microsoft Entra 管理中心。使用 Settings 选择允许您注册应用的租户。打开 Entra ID → App registrations → New registration。在 Name 中输入 BusyMax，然后在下一步选择支持的帐号类型。如果注册被禁止，请向租户管理员申请权限。';

  @override
  String get registrationGuideMicrosoftRedirect =>
      '在应用注册中打开 Authentication → Add a platform → Mobile and desktop applications。选择或输入下面的重定向 URI，然后选择 Configure 保存。BusyMax 使用系统浏览器。不需要客户端密码。';

  @override
  String get registrationGuideMicrosoftPermissions =>
      '打开 API permissions → Add a permission → Microsoft Graph → Delegated permissions。搜索并选择下面每个权限范围，然后选择 Add permissions。如果已有 User.Read，请保留。如果组织要求管理员同意，请让管理员使用租户的 Grant admin consent。';

  @override
  String get registrationGuideMicrosoftConnect =>
      '选择返回以回到表单。粘贴 Application (client) ID，并选择与注册一致的支持帐号选项。如果选择一个组织租户，还需粘贴 Directory (tenant) ID。选择连接并在浏览器中登录目标帐号。BusyMax 在本地检查字段；Microsoft 在浏览器登录时请求您的同意。';

  @override
  String get registrationGoogleImportFailed =>
      '无法导入此文件。请选择有效的桌面 OAuth JSON。之前的有效选择会保留。';

  @override
  String get registrationGoogleSetupInstructions => 'Google 设置说明';

  @override
  String get registrationMicrosoftSetupInstructions => 'Microsoft 设置说明';

  @override
  String get registrationDesktopConfiguration => '桌面 OAuth 配置';

  @override
  String get registrationNoFileSelected => '未选择文件';

  @override
  String get registrationChooseFile => '选择文件…';

  @override
  String get registrationReplaceFile => '替换…';

  @override
  String get registrationGoogleIntroduction =>
      '选择您自己的 Google Cloud 项目的桌面 OAuth JSON。';

  @override
  String get registrationMicrosoftIntroduction => '输入您自己的 Microsoft 应用注册信息。';

  @override
  String get registrationSetupInstructions => '设置说明';

  @override
  String get registrationInstructionsDescription => '创建连接帐号所需的配置。';

  @override
  String get registrationEnableApis => '启用 Calendar 和 Tasks';

  @override
  String get registrationConsentScreen => '配置同意屏幕';

  @override
  String get registrationAppName => '应用名称';

  @override
  String get registrationScopes => '权限范围';

  @override
  String get registrationRedirectUri => '重定向 URI';

  @override
  String get registrationOpenApiLibrary => '打开 Google API 库';

  @override
  String get registrationOpenBranding => '打开 Google Auth Platform 的 Branding';

  @override
  String get registrationOpenDataAccess =>
      '打开 Google Auth Platform 的 Data Access';

  @override
  String get registrationOpenClients => '打开 Google Auth Platform 的 Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      '打开 Entra 应用注册以设置 Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      '打开 Entra 应用注册以设置 API permissions';

  @override
  String get registrationCopy => '复制';

  @override
  String get registrationCopyAll => '全部复制';

  @override
  String get registrationGuideGoogleApis =>
      '进入 APIs & Services → Library。搜索 Google Calendar API，打开其页面并选择 Enable。返回 Library，对 Google Tasks API 重复此操作。';

  @override
  String get registrationGuideMicrosoftAudience =>
      '在 Supported account types 中，个人帐号选择 Personal accounts only，组织帐号选择 Multiple Entra ID tenants，同时支持两者选择 Any Entra ID Tenant + Personal Microsoft accounts，仅限此目录选择 Single tenant only。选择 Register。在 Overview 中复制 Application (client) ID；单一租户还需复制 Directory (tenant) ID。在 BusyMax 中选择对应的支持帐号选项。';

  @override
  String get registrationConnectBusyMax => '通过 BusyMax 连接';

  @override
  String get registrationRecommended => '推荐';

  @override
  String get registrationOtherMethods => '其他连接方式';

  @override
  String get registrationWorkspace => 'Google Workspace 组织';

  @override
  String get registrationGoogleCustom => '自定义 OAuth 客户端';

  @override
  String get registrationMicrosoftCustom => '自定义应用注册';

  @override
  String get registrationMethodsIntroduction => '选择连接帐号的方式。';

  @override
  String get registrationWorkspaceDescription => '使用组织管理的配置。';

  @override
  String get registrationCustomDescription => '使用自行管理的注册。';

  @override
  String get registrationSharedUnavailable =>
      '此版本无法通过 BusyMax 连接。您可以使用以下其他连接方式。';

  @override
  String get registrationWorkspaceIntroduction =>
      '选择组织提供或管理的桌面 OAuth JSON。文件不能证明组织所有权、受众或验证状态。';

  @override
  String get registrationWorkspaceSetupInstructions => 'Google Workspace 设置说明';

  @override
  String get registrationBusyMaxManaged => 'BusyMax 管理的注册';

  @override
  String get registrationBranding => '配置品牌和域名';

  @override
  String get registrationPublishing => '发布以供日常使用';

  @override
  String get registrationOpenAudience => '打开 Google Auth Platform Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      '向管理员索取 Desktop OAuth JSON，或打开 Google Cloud Console 并选择您的 Google Workspace 组织拥有的项目。若要创建项目，打开“管理资源”→“创建项目”，输入“项目名称”，在“父级资源”中选择您的组织或其文件夹，然后选择“创建”。后续步骤保持选中该项目。创建需要 Project Creator 权限，配置 OAuth 需要 OAuth Config Editor，启用 API 需要 Service Usage Admin 或同等权限。若操作受阻，请联系管理员。';

  @override
  String get registrationGuideGoogleBranding =>
      '在 Branding → App domain 中，先添加项目的授权域名，再输入主页、隐私政策和服务条款 URL，然后选择 Save。External 生产应用需要这些链接。请使用自己拥有的域名，并在 Google 要求品牌验证时通过 Search Console 验证所有权。下方 BusyMax 隐私链接不能证明您的项目拥有 busystack.org。';

  @override
  String get registrationGuideGooglePublishing =>
      '在 Audience 中选择 Publish app 并确认 In production。日常使用不要停留在 Testing：这些 Calendar/Tasks 授权和刷新令牌会在七天后过期。发布与验证是两回事。少于 100 人的个人使用可能免于验证，但仍有未验证警告和人数限制；更广泛分发可能需要品牌和权限范围批准。生产授权仍可能过期或被撤销。';

  @override
  String get registrationGuideWorkspacePermissions =>
      '与管理员检查以下权限范围。Internal 应用不需要在同意屏幕中列出权限范围。如管理员要求，请打开 Data Access → Add or remove scopes，添加这些值，然后选择 Update 和 Save。管理员控制仍可能限制授权。';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      '共享日历和类别权限会在启用相应可选功能时单独请求；不要将其添加到上述必需设置中。';

  @override
  String get registrationGuideWorkspaceAudience =>
      '进入 Google Auth Platform → Branding。如果尚未开始设置，选择 Get started。在 App name 中输入 BusyMax，选择您自己的 User support email，然后选择 Next。在 Audience 中，请选择 Internal。选择 Next，在 Contact Information 中输入您的邮箱，再选择 Next。接受 User Data Policy，然后选择 Continue 和 Create。如果已完成设置，请检查 Branding 和 Audience。\n\nInternal 仅允许项目父组织中的帐号，并受管理员控制。不需要测试用户列表。BusyMax 无法从下载的 JSON 验证这些控制台设置。';

  @override
  String get contactsTitle => '联系人';

  @override
  String get contactsLinkedDescription => '添加日程参与者时使用此账号缓存的联系人。';

  @override
  String get contactsEnableSuggestions => '启用联系人建议';

  @override
  String get contactsReadPermissionDescription => '请求联系人只读权限';

  @override
  String get contactsEnableEditing => '启用联系人编辑';

  @override
  String get contactsWritePermissionDescription => '请求联系人读写权限';

  @override
  String get contactsSuggestionsEnabled => '联系人建议已启用';

  @override
  String get contactsNeedsAttention => '联系人需要处理';

  @override
  String get contactsReadWriteAccess => '读写权限';

  @override
  String get contactsDisableForAccount => '停用此账号的联系人';

  @override
  String get contactsOnlyDescription => '这些来源独立于日历和任务账号。';

  @override
  String get contactsAddCardDav => '添加 CardDAV 联系人';

  @override
  String get contactsAddNextcloud => '添加 Nextcloud 联系人';

  @override
  String get contactsUseForAttendees => '用于参与者建议';

  @override
  String get contactsServerUrlLabel => 'HTTPS 服务器网址';

  @override
  String get contactsUsernameLabel => '用户名';

  @override
  String get contactsPasswordLabel => '密码';
}

/// The translations for Chinese, using the Han script (`zh_Hans`).
class AppLocalizationsZhHans extends AppLocalizationsZh {
  AppLocalizationsZhHans() : super('zh_Hans');

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax 由桌面的启动设置启动。请在那里移除 BusyMax 的条目，然后完全退出并重新打开 BusyMax，以使用此开关。';

  @override
  String get timeFormat => '时间格式';

  @override
  String get firstDayOfWeek => '一周的第一天';

  @override
  String get systemDefault => '系统默认';

  @override
  String systemDefaultResolved(String weekday) {
    return '系统默认（$weekday）';
  }

  @override
  String get timeFormatTwelveHour => '12小时制';

  @override
  String get timeFormatTwentyFourHour => '24小时制';

  @override
  String get timeEndOfDay => '当天结束';

  @override
  String get timePeriod => '上午/下午';

  @override
  String get launchAtLoginReadFailed => '无法确定登录时启动的状态。';

  @override
  String get launchAtLoginUnavailable => '此系统不支持登录时启动。';

  @override
  String get windowsStartupEnabledByPolicy => '管理员已启用自动启动，无法在此更改。';

  @override
  String get settingsSaveFailed => '无法保存设置。重新启动 BusyMax 时，您的更改可能会丢失。';

  @override
  String get nextcloudExportCollection => '导出集合资源';

  @override
  String nextcloudImportItems(int count) {
    return '找到 $count 个事件/任务资源';
  }

  @override
  String get nextcloudSchedulingInbox => '日程邀请收件箱';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud 会将这些消息处理到日历中。确认消息只会移除收件箱消息，不会删除事件。';

  @override
  String get nextcloudInboxEmpty => '没有日程消息。';

  @override
  String get nextcloudAcknowledge => '确认消息';

  @override
  String get nextcloudAcknowledgeConfirm => '从收件箱移除此消息？日历事件将被保留。';

  @override
  String get nextcloudGuestAvailability => '查看受邀者的空闲时间';

  @override
  String nextcloudTrashRetention(int days) {
    return '服务器回收站保留时间：$days 天';
  }

  @override
  String get nextcloudCancelMeeting => '取消会议';

  @override
  String get nextcloudDeclineAndRemove => '拒绝并移除邀请';

  @override
  String get nextcloudDeclineRemovalWarning => '同步时会发送拒绝回复。此操作不会取消组织者的会议。';

  @override
  String get nextcloudAvailabilityUnknown => '空闲状态未知';

  @override
  String get nextcloudAvailabilityFree => '此时段未报告忙碌时间';

  @override
  String get nextcloudAvailabilityBusy => '忙碌时段';

  @override
  String get nextcloudSchedulingPending => 'Nextcloud 将在同步时发送会议更新。本地保存不代表已送达。';

  @override
  String get nextcloudAttendeeRestrictions =>
      '只有组织者或获授权的代理人才能修改会议详情。您可以在邀请详情中回复。';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      '无法通过复制并删除来移动此会议。请使用同一日程身份下的日历。';

  @override
  String get nextcloudSchedulingStatus => '服务器日程处理状态';

  @override
  String get nextcloudImportFollowUp => '导入的资源已保存在本地。提醒刷新尚未完成；请勿重复导入。';

  @override
  String get nextcloudNativeImport =>
      '导入完整的事件和任务资源，不发送邀请。除非选择新副本，否则会跳过已有 UID。不支持的资源将逐项报告。';

  @override
  String get nextcloudImportMethod => '此文件包含日程消息。导入会保存内容并移除 METHOD，不会处理邀请或回复。';

  @override
  String get nextcloudImportCopies => '以新身份导入为新副本';

  @override
  String get nextcloudCollectionSettings => '集合设置';

  @override
  String get nextcloudSharing => '共享';

  @override
  String get nextcloudOwned => '自有';

  @override
  String get nextcloudShared => '已共享';

  @override
  String get nextcloudDelegated => '已委派';

  @override
  String get nextcloudSubscription => '订阅';

  @override
  String get nextcloudDeleted => '已删除';

  @override
  String get nextcloudMetadataEditable => '日历内容只读，但可以修改集合属性。';

  @override
  String get nextcloudServerOrder => '服务器顺序（独立于侧边栏顺序）';

  @override
  String get nextcloudCalendarEnabled => '在服务器上启用';

  @override
  String get nextcloudAvailability => '将此集合纳入空闲状态计算';

  @override
  String get nextcloudCalendarTimezone => '日历时区（VTIMEZONE 文档）';

  @override
  String get nextcloudRefreshPending => '更改已保存在 Nextcloud。刷新尚未完成；请勿重复更改。';

  @override
  String get nextcloudOutcomeUnknown => '无法确认服务器结果。请刷新后再试。';

  @override
  String get nextcloudRemoveShared => '移除共享日历/列表';

  @override
  String get nextcloudRemoveMixed => '此集合包含事件和任务。删除集合将同时删除两者。';

  @override
  String get nextcloudReadAccess => '只读';

  @override
  String get nextcloudWriteAccess => '读写';

  @override
  String get nextcloudRecipientSearch => '查找人员或群组';

  @override
  String get nextcloudNoRecipients => '没有匹配的人员或群组。';

  @override
  String get nextcloudRevokeShare => '撤销访问权限';

  @override
  String get nextcloudPublish => '发布链接';

  @override
  String get nextcloudUnpublish => '停止发布';

  @override
  String get nextcloudPublishWarning => '拥有发布链接的任何人都可能读取此日历。是否发布？';

  @override
  String get nextcloudTrash => '已删除的日历和任务';

  @override
  String get nextcloudTrashEmpty => '没有已删除的日历项目。';

  @override
  String get nextcloudRestore => '恢复';

  @override
  String get nextcloudPermanentDelete => '永久删除';

  @override
  String get nextcloudPermanentDeleteWarning =>
      '永久删除此项目？之后无法从 Nextcloud 日历回收站恢复。';

  @override
  String get nextcloudOperationDenied => 'Nextcloud 不允许此操作。';

  @override
  String get nextcloudUnsupported => '服务器不支持此操作。';

  @override
  String get nextcloudPendingChanges => '关闭前请保存或放弃集合更改。';

  @override
  String get nextcloudServerUnavailable => '无法连接 Nextcloud。缓存项目和待处理更改保持不变。';

  @override
  String get mapsShow => '在地图上显示';

  @override
  String get openLink => '打开链接';

  @override
  String get externalLocationOpenFailed => '无法在外部应用中打开该位置。';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed => '无法调整日程时间。已保存的时间未更改。';

  @override
  String get scheduleRescheduleStale => '拖动期间此日程已更改。请重试。';

  @override
  String get scheduleRescheduleNotificationsFailed => '新时间已保存，但无法更新提醒。';

  @override
  String get moveUp => '上移';

  @override
  String get moveDown => '下移';

  @override
  String get windowsSupport => '支持';

  @override
  String get windowsThirdPartyLicenses => '第三方许可证';

  @override
  String get windowsSearch => '搜索';

  @override
  String get windowsStartupDisabledByUser => '用户已在 Windows 设置中禁用。';

  @override
  String get windowsStartupDisabledByPolicy => '已由 Windows 策略禁用。';

  @override
  String get windowsStartupUnavailable => '从 MSIX 包安装 BusyMax 后可用。';

  @override
  String get windowsReminderExitNotice =>
      '完全退出 BusyMax 后，提醒将停止。请让应用在后台运行以接收提醒。';

  @override
  String get windowsProductVersionLabel => '产品版本';

  @override
  String get windowsPackageVersionLabel => 'Windows 包版本';

  @override
  String get windowsUnpackaged => '未打包';

  @override
  String get windowsAgendaLoadMore => '加载更多议程项目';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$month的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency$firstMonth和$secondMonth的$day';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$firstMonth和$secondMonth的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency$firstMonth和$secondMonth的$days';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      '连接 Google、Microsoft、Apple iCloud Calendar 或 Nextcloud 账户。';

  @override
  String get googlePermissionsConsentNotice => '在 Google 权限页面上，同时选择日历和任务权限。';

  @override
  String get googlePermissionsRequiredRetry =>
      '必须授予 Google 日历和 Google Tasks 权限。请重试并选中两个复选框。';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => '尚未配置此服务。';

  @override
  String get waitingForGoogleSignIn => '正在等待 Google 登录...';

  @override
  String get waitingForMicrosoftSignIn => '正在等待 Microsoft 登录...';

  @override
  String get microsoftSignInNotConfigured =>
      '尚未配置 Microsoft 登录。请设置 MICROSOFT_OAUTH_CLIENT_ID。';

  @override
  String get cancel => '取消';

  @override
  String get close => '关闭';

  @override
  String get windowMinimize => '最小化';

  @override
  String get windowMaximize => '最大化';

  @override
  String get windowRestore => '还原';

  @override
  String get exit => '退出';

  @override
  String get options => '选项';

  @override
  String get hide => '隐藏';

  @override
  String get show => '显示';

  @override
  String get export => '导出';

  @override
  String get save => '保存';

  @override
  String get settings => '设置';

  @override
  String get all => '全部';

  @override
  String get calendarEvents => '日程';

  @override
  String get calendarTasks => '任务';

  @override
  String get calendar => '日历';

  @override
  String get calendars => '日历';

  @override
  String get newCalendar => '新建日历';

  @override
  String get calendarColor => '日历颜色';

  @override
  String calendarColorOption(int number) {
    return '颜色 $number';
  }

  @override
  String get calendarManagementUnsupported => '此提供商不支持 BusyMax 中的日历管理。';

  @override
  String get primaryCalendarCannotDelete => '无法删除主日历。';

  @override
  String calendarCreateFailed(String error) {
    return '无法创建日历：$error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      '日历已创建，但 BusyMax 无法刷新账户。它将在下次同步后显示。';

  @override
  String calendarUpdateFailed(String error) {
    return '无法更新日历：$error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return '无法删除日历：$error';
  }

  @override
  String get newEvent => '新建日程';

  @override
  String get refreshCalendar => '刷新日历';

  @override
  String get openInProvider => '在服务中打开';

  @override
  String get linkedResources => '关联资源';

  @override
  String get noLinkedResources => '没有关联资源';

  @override
  String get attachments => '附件';

  @override
  String get attachmentsNotLoaded => '附件未加载';

  @override
  String get hideFromSchedule => '从日程中隐藏';

  @override
  String get showInSchedule => '在日程中显示';

  @override
  String get noCalendarsSynced => '尚未同步任何日历。';

  @override
  String get allDay => '全天';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '还有 $countString 项';
  }

  @override
  String get noEventsOrTasks => '没有日程或任务';

  @override
  String get scheduleLoading => '正在加载日程...';

  @override
  String get scheduleUnavailable => '日程不可用';

  @override
  String get scheduleNoSources => '没有可见的日历或任务列表';

  @override
  String get scheduleNoSourcesDescription => '请在设置中选择要显示的内容，然后刷新。';

  @override
  String get scheduleNoSearchResults => '没有匹配的日程或任务';

  @override
  String get scheduleNoSearchResultsDescription => '请尝试其他搜索内容或清除当前筛选条件。';

  @override
  String get refresh => '刷新';

  @override
  String get trayOpenBusyMax => '打开 BusyMax';

  @override
  String get trayShowBusyMax => '显示 BusyMax';

  @override
  String get trayNewEvent => '新日程…';

  @override
  String get trayNewTask => '新任务…';

  @override
  String get trayToday => '今天';

  @override
  String get trayAllDay => '全天';

  @override
  String get trayNow => '现在';

  @override
  String get trayCalendarEvent => '日历日程';

  @override
  String get trayUntitledEvent => '无标题日程';

  @override
  String get trayNothingElseToday => '今天没有其他内容';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $count 个任务到期',
      one: '今天有 1 个任务到期',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => '打开今天的日程';

  @override
  String get traySyncNow => '立即同步';

  @override
  String get traySyncing => '正在同步…';

  @override
  String get trayNotConnected => '未连接';

  @override
  String get trayNotYetSynced => '尚未同步';

  @override
  String get trayLastSyncedJustNow => '刚刚同步';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 分钟前同步',
      one: '1 分钟前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 小时前同步',
      one: '1 小时前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 天前同步',
      one: '1 天前同步',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => '设置';

  @override
  String get trayQuitBusyMax => '退出 BusyMax';

  @override
  String get agendaLoadMoreOverdue => '加载更多逾期任务';

  @override
  String get agendaLoadMoreNoDate => '加载更多无日期任务';

  @override
  String get viewDay => '日';

  @override
  String get viewWeek => '周';

  @override
  String get viewMonth => '月';

  @override
  String get viewYear => '年';

  @override
  String get viewAgenda => '日程';

  @override
  String get scheduleSettings => '日程';

  @override
  String get scheduleDisplaySettings => '日程显示';

  @override
  String get newEventsAndTasks => '新建日程和任务';

  @override
  String get defaultCalendar => '默认日历';

  @override
  String get defaultTaskList => '默认任务列表';

  @override
  String get lastUsed => '最近使用';

  @override
  String get scheduleDisplayHoursDescription =>
      '日视图和周视图最初显示此时间范围。需要时，更早或更晚的项目会扩展该范围。';

  @override
  String get scheduleDayStartsAt => '每日开始时间';

  @override
  String get scheduleDayEndsAt => '每日结束时间';

  @override
  String get sourceCalendar => '日历';

  @override
  String get sourceTaskList => '任务列表';

  @override
  String get createChoiceTitle => '新建';

  @override
  String get createEventAtTime => '日程';

  @override
  String get createTaskAtDate => '任务';

  @override
  String get editEvent => '编辑日程';

  @override
  String get eventTitle => '日程标题';

  @override
  String get location => '地点';

  @override
  String get timeSlot => '时间段';

  @override
  String get startDateTime => '开始日期/时间';

  @override
  String get endDateTime => '结束日期/时间';

  @override
  String get doesNotRepeat => '不重复';

  @override
  String get defaultReminder => '默认提醒';

  @override
  String get guests => '参与者';

  @override
  String get noGuests => '无参与者';

  @override
  String get attendeeRequired => '必需';

  @override
  String get attendeeOptional => '可选';

  @override
  String get meetingSection => '会议';

  @override
  String get addGoogleMeet => '添加 Google Meet';

  @override
  String get addTeamsMeeting => '添加 Microsoft Teams 会议';

  @override
  String get onlineMeetingAdded => '已添加在线会议';

  @override
  String get requestResponses => '请求回复';

  @override
  String get requestResponsesDescription => '要求参与者回复邀请。';

  @override
  String get hideGuestList => '隐藏参与者列表';

  @override
  String get hideGuestListDescription => '参与者无法查看其他受邀者。';

  @override
  String get allowNewTimeProposals => '允许提出新时间';

  @override
  String get allowNewTimeProposalsDescription => '参与者可以建议其他会议时间。';

  @override
  String get notifyGuestsTitle => '通知参与者？';

  @override
  String get notifyGuestsSaveMessage => '此会议有参与者。保存时发送邀请或日程更新吗？';

  @override
  String get notifyGuestsDeleteMessage => '此会议有参与者。删除时发送取消通知吗？';

  @override
  String get sendUpdates => '发送更新';

  @override
  String get sendCancellation => '发送取消通知';

  @override
  String get doNotSend => '不发送';

  @override
  String get microsoftNotifyGuestsSaveTitle => '保存会议？';

  @override
  String get microsoftNotifyGuestsSaveMessage => 'Microsoft 将向参与者发送邀请或日程更新。';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '删除会议？';

  @override
  String get microsoftNotifyGuestsDeleteMessage => 'Microsoft 将向参与者发送取消通知。';

  @override
  String get organizer => '组织者';

  @override
  String get yourResponse => '你的回复';

  @override
  String get guestResponses => '参与者回复';

  @override
  String get respond => '回复';

  @override
  String get acceptInvitation => '接受';

  @override
  String get tentativeInvitation => '暂定';

  @override
  String get declineInvitation => '拒绝';

  @override
  String get joinMeeting => '加入会议';

  @override
  String get responseAccepted => '已接受';

  @override
  String get responseTentative => '暂定';

  @override
  String get responseDeclined => '已拒绝';

  @override
  String get responseNeedsAction => '等待回复';

  @override
  String get responseNotResponded => '未回复';

  @override
  String get responseOrganizer => '组织者';

  @override
  String invitationResponseFailed(String error) {
    return '无法发送回复：$error';
  }

  @override
  String get joinMeetingFailed => '无法打开会议链接。';

  @override
  String get description => '说明';

  @override
  String get availabilityShowAs => '空闲状态 / 显示为';

  @override
  String get busy => '忙碌';

  @override
  String get visibility => '可见性';

  @override
  String get defaultVisibility => '默认可见性';

  @override
  String get conference => '会议';

  @override
  String get noConference => '无会议';

  @override
  String get providerCalendar => '服务日历';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => '粗体';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => '斜体';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => '下划线';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString 分钟前',
      one: '1 分钟前',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => '开始时';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString 小时前',
      one: '1 小时前',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString 天前',
      one: '1 天前',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => '空闲';

  @override
  String get availabilityTentative => '暂定';

  @override
  String get availabilityOutOfOffice => '不在办公室';

  @override
  String get availabilityWorkingElsewhere => '在其他地点办公';

  @override
  String get visibilityDefault => '默认';

  @override
  String get visibilityPublic => '公开';

  @override
  String get visibilityPrivate => '私密';

  @override
  String get visibilityConfidential => '机密';

  @override
  String get sensitivityNormal => '普通';

  @override
  String get sensitivityPersonal => '个人';

  @override
  String get tasks => '任务';

  @override
  String get allTasks => '所有任务';

  @override
  String tasksInList(String title) {
    return '$title中的任务';
  }

  @override
  String get taskLists => '任务列表';

  @override
  String get navigation => '导航';

  @override
  String get mainMenu => '主菜单';

  @override
  String get keyboardShortcuts => '键盘快捷键';

  @override
  String get shortcutGroupGeneral => '常规';

  @override
  String get shortcutKeyboardShortcutsDescription => '显示快捷键参考表';

  @override
  String get shortcutGroupNavigation => '导航';

  @override
  String get shortcutNextPeriod => '下一时段';

  @override
  String get shortcutNextPeriodDescription => '在周视图中前往下一周，在月视图中前往下个月，依此类推';

  @override
  String get shortcutPreviousPeriod => '上一时段';

  @override
  String get shortcutPreviousPeriodDescription => '在周视图中前往上一周，在月视图中前往上个月，依此类推';

  @override
  String get shortcutJumpToToday => '跳转到今天';

  @override
  String get shortcutGroupView => '视图';

  @override
  String get viewSelector => '视图';

  @override
  String get shortcutDayView => '日视图';

  @override
  String get shortcutWeekView => '周视图';

  @override
  String get shortcutMonthView => '月视图';

  @override
  String get shortcutYearView => '年视图';

  @override
  String get shortcutAgendaView => '日程视图';

  @override
  String get shortcutGroupCreateAndEdit => '新建和编辑';

  @override
  String get shortcutSaveItem => '保存日程或任务';

  @override
  String get shortcutDeleteItem => '删除日程或任务';

  @override
  String get shortcutGroupTaskEditing => '任务编辑';

  @override
  String get shortcutCancelEditing => '取消编辑';

  @override
  String get shortcutCancelEditingDescription => '关闭任务编辑或任务详情';

  @override
  String get aboutBusyMax => '关于 BusyMax';

  @override
  String get aboutBusyMaxDescription => '日历和任务';

  @override
  String get license => '许可证';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => '网站';

  @override
  String get sourceCode => '源代码';

  @override
  String get reportAnIssue => '报告问题';

  @override
  String get sendFeedback => '发送反馈';

  @override
  String get feedbackSubmit => '提交';

  @override
  String get feedbackCategory => '类别';

  @override
  String get feedbackSelectCategory => '选择类别';

  @override
  String get feedbackCategoryProblem => '问题或错误';

  @override
  String get feedbackCategoryFeature => '功能请求';

  @override
  String get feedbackCategoryPrivacySecurity => '隐私或安全问题';

  @override
  String get feedbackCategoryUsability => '易用性问题';

  @override
  String get feedbackCategoryOther => '其他';

  @override
  String get feedbackSubject => '主题';

  @override
  String get feedbackDetailedMessage => '详细信息';

  @override
  String get feedbackReplyEmail => '用于接收回复的电子邮件地址（可选）';

  @override
  String get feedbackIncludeTechnicalDetails => '包含技术详情';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      '仅添加您的操作系统名称和版本以及应用区域设置。不包含日志、账户数据、文件名或其他诊断信息。';

  @override
  String get feedbackCategoryRequired => '请选择类别。';

  @override
  String get feedbackSubjectLengthError => '主题必须为 3 至 120 个字符。';

  @override
  String get feedbackMessageLengthError => '消息必须为 10 至 5,000 个字符。';

  @override
  String get feedbackInvalidEmail => '请输入有效的电子邮件地址。';

  @override
  String get feedbackConnectionError => '无法连接到 BusyStack。请检查连接，然后重试。';

  @override
  String get feedbackTimeoutError => '请求超时。您的反馈尚未清除，请重试。';

  @override
  String get feedbackRateLimitedError => '从此网络发送的反馈过多。请稍后再试。';

  @override
  String get feedbackRejectedError => '服务器拒绝了提交。请检查各字段，然后重试。';

  @override
  String get feedbackServerError => 'BusyStack 目前无法接收您的反馈。您的反馈尚未清除，请重试。';

  @override
  String feedbackSuccess(String id) {
    return '反馈已发送。参考编号：$id';
  }

  @override
  String get toggleSidebar => '显示或隐藏侧边栏';

  @override
  String get showSidebar => '显示侧边栏面板';

  @override
  String get hideSidebar => '隐藏侧边栏面板';

  @override
  String get accounts => '账户';

  @override
  String get currentAccount => '当前账户';

  @override
  String get switchAccount => '切换账户';

  @override
  String get addGoogleAccount => '添加 Google 账户';

  @override
  String get addMicrosoftAccount => '添加 Microsoft 账户';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => '已登录';

  @override
  String get removeAccount => '移除账户…';

  @override
  String get removingAccount => '正在移除账户…';

  @override
  String get removeAccountDescription => '停止同步并从此设备移除此账户的数据。';

  @override
  String removeAccountTitle(String account) {
    return '从 BusyMax 中移除 $account？';
  }

  @override
  String get removeAccountConfirmation =>
      '这会从此设备删除缓存的任务、日历、日程、提醒和待处理的离线更改。未同步的更改将会丢失。提供商中的日历、日程、任务列表和任务副本不会被删除。';

  @override
  String get revokeGoogleAccess => '同时撤销 BusyMax 对此 Google 账户的访问权限';

  @override
  String get revokeGoogleAccessDescription => '重新连接之前，您需要再次授予访问权限。';

  @override
  String get removeAccountAction => '移除账户';

  @override
  String get removeAccountFailed => '无法完成账户移除。请重试。';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      '该账户已从此设备移除，但无法撤销 BusyMax 对您的 Google 账户的访问权限。您可以在 Google 账户中手动撤销该权限。';

  @override
  String get newTaskList => '新任务列表';

  @override
  String taskListCreateFailed(String error) {
    return '无法创建任务列表：$error';
  }

  @override
  String taskListRenameFailed(String error) {
    return '无法重命名任务列表：$error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return '无法删除任务列表：$error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      '删除或移除此列表前，请同步账户，或在“诊断”中解决此任务列表被阻止的更改。';

  @override
  String get signInToViewTaskLists => '登录以查看任务列表。';

  @override
  String get noTaskListsSynced => '尚未同步任何任务列表。';

  @override
  String get listActions => '列表操作';

  @override
  String get rename => '重命名';

  @override
  String get delete => '删除';

  @override
  String get renameList => '重命名列表';

  @override
  String get deleteList => '删除列表';

  @override
  String get unshare => '取消共享';

  @override
  String get readOnlyTaskListCannotRename => '此任务列表为只读，无法重命名。';

  @override
  String get taskListCannotDelete => '使用当前权限无法删除此任务列表。';

  @override
  String get builtInMicrosoftList => '内置';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      '无法重命名或删除 Microsoft To Do 内置列表。';

  @override
  String deleteListConfirmation(String title) {
    return '要从 Google Tasks 中删除“$title”吗？';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '要删除“$title”及其所有任务吗？';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return '要取消此账户对“$title”的共享吗？';
  }

  @override
  String get deleteEvent => '删除日程';

  @override
  String get title => '标题';

  @override
  String get create => '新建';

  @override
  String get newTask => '新建任务';

  @override
  String get clearCompleted => '清除已完成项';

  @override
  String get refreshList => '刷新列表';

  @override
  String get refreshAll => '全部刷新';

  @override
  String get listRefreshed => '列表已刷新。';

  @override
  String get allTasksRefreshed => '所有账户均已刷新。';

  @override
  String exportedFile(String path) {
    return '已导出到 $path';
  }

  @override
  String exportFailed(String error) {
    return '导出失败：$error';
  }

  @override
  String refreshFailed(String error) {
    return '刷新失败：$error';
  }

  @override
  String get selectOrCreateTaskList => '请选择或创建任务列表以开始使用。';

  @override
  String get signInToViewTasks => '登录以查看任务。';

  @override
  String get noTasks => '没有任务。';

  @override
  String get noTasksYet => '还没有任务';

  @override
  String get noTasksYetMessage => '创建任务或刷新账户以开始使用。';

  @override
  String get noTasksInList => '此列表中没有任务。';

  @override
  String get overdue => '已逾期';

  @override
  String get today => '今天';

  @override
  String get tomorrow => '明天';

  @override
  String get upcoming => '即将到期';

  @override
  String get noDate => '无日期';

  @override
  String get completed => '已完成';

  @override
  String duePrefix(String date) {
    return '$date 到期';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => '任务详情';

  @override
  String get editTask => '编辑任务';

  @override
  String get noTaskSelected => '未选择任务。';

  @override
  String get noTaskSelectedHelper => '选择任务以查看和编辑详情。';

  @override
  String get taskUnavailable => '任务不可用。';

  @override
  String get signInToEditTasks => '登录以编辑任务。';

  @override
  String get refreshTask => '刷新任务';

  @override
  String get primarySection => '主要信息';

  @override
  String get statusSection => '状态';

  @override
  String get openStatus => '未完成';

  @override
  String get doneStatus => '已完成';

  @override
  String get taskStatus => '状态';

  @override
  String get taskStatusNone => '无状态';

  @override
  String get taskStatusNeedsAction => '需要操作';

  @override
  String get taskStatusInProcess => '进行中';

  @override
  String get taskStatusCompleted => '已完成';

  @override
  String get taskStatusCancelled => '已取消';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '已完成 $percentString%';
  }

  @override
  String get completionDate => '完成日期';

  @override
  String get priority => '优先级';

  @override
  String get priorityNone => '无优先级';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 高';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 中';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '优先级 $priorityString · 低';
  }

  @override
  String get taskUrl => '任务 URL';

  @override
  String get invalidTaskUrl => '请输入包含方案的绝对 URL。';

  @override
  String get classification => '分类';

  @override
  String get classificationPublic => '共享时显示完整任务';

  @override
  String get classificationConfidential => '共享时仅显示忙碌状态';

  @override
  String get classificationPrivate => '共享时隐藏此任务';

  @override
  String get pinTask => '固定任务';

  @override
  String get notes => '备注';

  @override
  String get dueDate => '截止日期';

  @override
  String get clearDueDate => '清除截止日期';

  @override
  String get dueTime => '截止时间';

  @override
  String get startDate => '开始日期';

  @override
  String get startTime => '开始时间';

  @override
  String get endDate => '结束日期';

  @override
  String get endTime => '结束时间';

  @override
  String get reminderDate => '提醒日期';

  @override
  String get reminderTime => '提醒时间';

  @override
  String get reminder => '提醒';

  @override
  String get addReminder => '添加提醒';

  @override
  String get reminders => '提醒';

  @override
  String get noReminders => '无提醒';

  @override
  String get editReminder => '编辑提醒';

  @override
  String get beforeTaskStarts => '任务开始前';

  @override
  String get beforeTaskDue => '任务到期前';

  @override
  String get afterTaskStarts => '任务开始后';

  @override
  String get afterTaskDue => '任务到期后';

  @override
  String get relativeToTaskStart => '相对于任务开始日期';

  @override
  String get relativeToTaskDue => '相对于任务到期日期';

  @override
  String get reminderTimeOfDay => '时间';

  @override
  String get absoluteReminder => '在指定日期和时间';

  @override
  String get reminderAmount => '数量';

  @override
  String get reminderUnit => '单位';

  @override
  String get reminderUnitSeconds => '秒';

  @override
  String get reminderUnitMinutes => '分钟';

  @override
  String get reminderUnitHours => '小时';

  @override
  String get reminderUnitDays => '天';

  @override
  String get reminderUnitWeeks => '周';

  @override
  String get reminderAtTaskStart => '任务开始时';

  @override
  String get reminderAtTaskDue => '任务到期时';

  @override
  String get unsupportedReminder => '此提醒类型会保留，但无法编辑其时间。';

  @override
  String get relatedRemindersTitle => '保留相关提醒？';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '此日期有 $countString 个相关提醒。要保留它们当前的日期和时间吗？';
  }

  @override
  String get discardRelatedReminders => '舍弃提醒';

  @override
  String get keepRelatedReminders => '保留提醒';

  @override
  String get addGuest => '添加参与者';

  @override
  String get addGuestEmail => '添加参与者电子邮件';

  @override
  String get removeReminder => '移除提醒';

  @override
  String get off => '关闭';

  @override
  String get repeat => '重复';

  @override
  String get repeatNone => '不重复';

  @override
  String get noneValue => '无';

  @override
  String get repeatDaily => '每天';

  @override
  String get repeatWeekly => '每周';

  @override
  String get repeatMonthly => '每月';

  @override
  String get repeatYearly => '每年';

  @override
  String get repeatEvery => '重复间隔';

  @override
  String get repeatOn => '重复日期';

  @override
  String get repeatEnd => '结束重复';

  @override
  String get repeatNever => '从不';

  @override
  String get repeatUntil => '指定日期';

  @override
  String get repeatAfter => '指定次数后';

  @override
  String get repeatCount => '重复次数';

  @override
  String get repeatDayOfMonth => '每月日期';

  @override
  String get repeatMonths => '月份';

  @override
  String get repeatOrdinal => '星期位置';

  @override
  String get repeatSpecificDays => '特定日期';

  @override
  String get repeatFirst => '第一';

  @override
  String get repeatSecond => '第二';

  @override
  String get repeatThird => '第三';

  @override
  String get repeatFourth => '第四';

  @override
  String get repeatFifth => '第五';

  @override
  String get repeatSecondToLast => '倒数第二';

  @override
  String get repeatLast => '最后';

  @override
  String get repeatAnyDay => '日期';

  @override
  String get repeatWeekday => '工作日';

  @override
  String get repeatWeekendDay => '周末';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'day': '日期',
      'weekday': '工作日',
      'weekend': '周末',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 天';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 周';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 个月';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 年';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '在 $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '在 $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '重复 $countString 次',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '直到 $date';
  }

  @override
  String get unsupportedRecurrencePreserved => '此重复规则使用了编辑器不会更改的选项。';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      '此列表不支持此重复模式。请更改模式或选择其他列表。';

  @override
  String get taskRecurrenceRequiresDate => '请添加开始日期或截止日期以使用此重复模式，或关闭重复。';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return '此重复规则不能用于 $provider。';
  }

  @override
  String get importance => '重要性';

  @override
  String get importanceLow => '低';

  @override
  String get importanceNormal => '普通';

  @override
  String get importanceHigh => '高';

  @override
  String get categories => '类别';

  @override
  String get scheduleSection => '日程';

  @override
  String get dueGroup => '截止';

  @override
  String get startGroup => '开始';

  @override
  String get reminderGroup => '提醒';

  @override
  String get organizationSection => '整理';

  @override
  String get actionsSection => '操作';

  @override
  String get advancedSection => '高级';

  @override
  String get addCategory => '添加类别';

  @override
  String get list => '列表';

  @override
  String get microsoftMoveUnsupported => '此版本不支持在 Microsoft To Do 账户的列表之间移动任务。';

  @override
  String get createSubtask => '创建子任务';

  @override
  String get subtasks => '子任务';

  @override
  String get duplicateTask => '复制任务';

  @override
  String get taskDuplicated => '任务已复制。';

  @override
  String taskDuplicateFailed(String error) {
    return '无法复制任务：$error';
  }

  @override
  String get hideSubtasks => '隐藏子任务';

  @override
  String get hideClosedSubtasks => '隐藏已关闭的子任务';

  @override
  String get moveToTop => '移到顶部';

  @override
  String get deleteTask => '删除任务';

  @override
  String get newSubtask => '新建子任务';

  @override
  String deleteTaskConfirmation(String title) {
    return '删除“$title”？';
  }

  @override
  String get deleteAssignedTaskWarning => '这也会删除 Google 文档或 Chat 聊天室中的原始任务。';

  @override
  String get metadata => '元数据';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => '更新时间';

  @override
  String get parent => '父任务';

  @override
  String get position => '位置';

  @override
  String get webLink => '网页链接';

  @override
  String get assignment => '分配';

  @override
  String get localState => '本地状态';

  @override
  String get pendingSync => '等待同步';

  @override
  String get synced => '已同步';

  @override
  String get account => '账户';

  @override
  String get sync => '同步';

  @override
  String get forceFullResync => '强制完全重新同步';

  @override
  String get forceFullResyncDescription =>
      '从每个已连接的账号中重新完整加载所有数据。请仅在排查同步问题时使用此功能。';

  @override
  String get runInBackgroundWhenClosed => '窗口关闭后继续在后台运行';

  @override
  String get showTrayIcon => '显示托盘图标';

  @override
  String get startMinimizedToTray => '启动时最小化到托盘';

  @override
  String get launchAtLogin => '登录时启动';

  @override
  String get launchAtLoginDescription => '在后台启动 BusyMax，以便登录后提醒能够正常工作。';

  @override
  String get launchAtLoginFailed => '无法更新登录时启动设置。';

  @override
  String get requiresTrayIcon => '需要托盘图标。';

  @override
  String get syncComplete => '同步完成。';

  @override
  String syncFailed(String error) {
    return '同步失败：$error';
  }

  @override
  String get notifySyncFailures => '同步失败通知';

  @override
  String get notifyConflicts => '冲突通知';

  @override
  String get notifyDueToday => '今天到期任务通知';

  @override
  String get eventReminders => '日程提醒';

  @override
  String get onState => '开启';

  @override
  String get taskReminders => '任务提醒';

  @override
  String get notificationDetailLevel => '通知详细程度';

  @override
  String get notificationDetailPrivate => '私密';

  @override
  String get notificationDetailNormal => '普通';

  @override
  String get quietHours => '免打扰时段';

  @override
  String get quietHoursDescription => '在此时段暂停通知。';

  @override
  String get quietHoursStart => '免打扰开始时间';

  @override
  String get quietHoursEnd => '免打扰结束时间';

  @override
  String get notifications => '通知';

  @override
  String get windowsNotificationsUnavailable => 'Windows 通知不可用';

  @override
  String get windowsNotificationsUnpackaged =>
      '此未打包的开发版本无法使用 Windows 通知。请安装测试签名的 MSIX 以测试提醒。';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax 无法初始化 Windows 通知。在解决此安装问题之前，提醒不会显示。';

  @override
  String get appearance => '外观';

  @override
  String get theme => '主题';

  @override
  String get themeSystem => '系统';

  @override
  String get settingsSystem => '系统';

  @override
  String get themeLight => '浅色';

  @override
  String get themeDark => '深色';

  @override
  String get themeFamily => '主题系列';

  @override
  String get themeFamilyYaru => 'Ubuntu 原生主题（Yaru）';

  @override
  String get localization => '语言和区域';

  @override
  String get currentLocale => '当前区域设置';

  @override
  String get privacy => '隐私';

  @override
  String get redactTaskContentInDiagnostics => '在诊断信息中隐藏任务内容';

  @override
  String get developerDiagnostics => '开发者诊断';

  @override
  String get diagnostics => '诊断';

  @override
  String get apiInspectorDisabled => '显示 API 检查器';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery 修订版：$revision';
  }

  @override
  String get implementedMethods => '已实现的方法';

  @override
  String get supportsTasksScopes => '支持 tasks 和 tasks.readonly 权限范围';

  @override
  String get requiresTasksScope => '需要 tasks 权限范围';

  @override
  String get blockedPendingOperations => '被阻止的待处理操作';

  @override
  String get signInToInspectPendingOperations => '登录以检查待处理操作。';

  @override
  String get noBlockedPendingOperations => '没有被阻止的待处理操作。';

  @override
  String get operationActions => '操作选项';

  @override
  String pendingOpListId(String id) {
    return '列表=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return '任务=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '尝试次数=$countString';
  }

  @override
  String get retry => '重试';

  @override
  String get discard => '舍弃';

  @override
  String get discardChangesAction => '舍弃';

  @override
  String get discardChanges => '舍弃更改？';

  @override
  String get discardChangesConfirmation => '这将舍弃对此任务所做的未保存编辑。';

  @override
  String get retryCompleted => '重试完成。';

  @override
  String get discardPendingOperation => '舍弃待处理操作？';

  @override
  String get discardPendingOperationConfirmation =>
      '这将移除被阻止的本地操作。下次同步时将从 Google Tasks 刷新数据。';

  @override
  String get pendingOperationDiscarded => '已舍弃待处理操作。';

  @override
  String get syncFailureNotificationTitle => 'BusyMax 同步失败';

  @override
  String syncFailureNotificationBody(String message) {
    return '后台同步失败。$message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax 同步冲突';

  @override
  String conflictNotificationBody(String summary) {
    return '一项待处理的本地更改被阻止。$summary';
  }

  @override
  String get dueTodayNotificationTitle => '今天到期的任务';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $countString 项任务到期。',
      one: '今天有 1 项任务到期。',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => '日程提醒';

  @override
  String get taskReminderNotificationTitle => '任务提醒';

  @override
  String get eventReminderNotificationBody => '日程即将开始。';

  @override
  String get taskReminderNotificationBody => '任务即将到期。';

  @override
  String get notificationOpenAction => '打开';

  @override
  String get notificationSnoozeAction => '10 分钟后提醒';

  @override
  String get notificationDismissAction => '关闭';

  @override
  String get notificationDetailsHidden => '根据隐私设置，详细信息已隐藏。';

  @override
  String get previousMonth => '上个月';

  @override
  String get nextMonth => '下个月';

  @override
  String get openMonthView => '打开月视图';

  @override
  String get previousYear => '上一年';

  @override
  String get nextYear => '下一年';

  @override
  String get openYearView => '打开年视图';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return '第 $numberString 周';
  }

  @override
  String get resizeAllDayPanel => '调整全天面板的大小';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString 项',
      one: '1 项',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => '此日历为只读。';

  @override
  String get selectTimeZone => '选择时区';

  @override
  String get searchLocations => '搜索地点';

  @override
  String get noLocationsFound => '未找到地点';

  @override
  String get requiredField => '此字段为必填项。';

  @override
  String get providerConnectionDescription => '连接以下任一提供商中的日历和任务。';

  @override
  String get appleICloudProvider => 'Apple iCloud 日历';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud 任务';

  @override
  String get addAppleICloudAccount => '添加 Apple iCloud 日历账户';

  @override
  String get addNextcloudAccount => '添加 Nextcloud 账户';

  @override
  String get waitingForAppleICloud => '正在连接 Apple iCloud…';

  @override
  String get waitingForNextcloud => '正在等待 Nextcloud 授权…';

  @override
  String get connectAppleICloudTitle => '连接 Apple iCloud 日历';

  @override
  String get appleAccountEmail => 'Apple 账户电子邮件';

  @override
  String get appleAppSpecificPassword => 'App 专用密码';

  @override
  String get appleAppSpecificPasswordHelp => '为 Apple 账户启用双重认证后，创建 App 专用密码。';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      '重置 Apple 账户密码会撤销 App 专用密码。';

  @override
  String get connectNextcloudTitle => '连接 Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloud 服务器或 CalDAV 地址';

  @override
  String get nextcloudServerUrlHelp =>
      '输入 Nextcloud 服务器 URL，或粘贴从 Nextcloud 复制的主要 CalDAV 地址。';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax 将打开浏览器。请在那里批准访问，然后返回 BusyMax。';

  @override
  String get connectAccountAction => '连接';

  @override
  String get cancelAccountConnection => '取消连接';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      '账户已在本地移除，但无法撤销 Nextcloud App 密码。';

  @override
  String get davReauthenticationRequired => '重新连接此账户以恢复同步。';

  @override
  String get davTemporarilyUnavailable => '此账户暂时不可用。';

  @override
  String get davPermissionChanged => '服务器权限已更改。待处理的编辑已暂停。';

  @override
  String get davUnsupportedServer => '不支持此服务器或提供商配置。';

  @override
  String get collectionSettings => '日历和任务列表';

  @override
  String get calendarContent => '日历日程';

  @override
  String get taskContent => '任务';

  @override
  String get readOnlySharedCollection => '只读';

  @override
  String get pendingLocally => '本地待处理';

  @override
  String get conflictBlocked => '因冲突而阻止';

  @override
  String get authenticationBlocked => '重新连接前阻止';

  @override
  String get operationFailed => '操作失败';

  @override
  String get keepServerVersion => '保留服务器版本';

  @override
  String get reapplyLocalChange => '查看并重新应用本地更改';

  @override
  String get duplicateLocalItem => '复制为新项目';

  @override
  String get davConnectionState => '连接状态';

  @override
  String get davConnected => '已连接';

  @override
  String get davConnecting => '正在连接…';

  @override
  String get davSignedOut => '已退出登录';

  @override
  String davLastSuccessfulSync(String time) {
    return '上次成功同步：$time';
  }

  @override
  String get davNeverSynced => '尚未同步';

  @override
  String get refreshCollections => '刷新日历和任务列表';

  @override
  String nextcloudServerHost(String host) {
    return '服务器：$host';
  }

  @override
  String get collectionSupportsEvents => '日程日历';

  @override
  String get collectionSupportsTasks => '任务列表';

  @override
  String get collectionSupportsEventsAndTasks => '日程和任务';

  @override
  String get writableCollection => '可写';

  @override
  String get sharedCollection => '已共享';

  @override
  String collectionLastSynced(String time) {
    return '上次同步：$time';
  }

  @override
  String collectionSyncError(String code) {
    return '同步问题：$code';
  }

  @override
  String get syncConflicts => '同步冲突';

  @override
  String remoteChangedAt(String time) {
    return '服务器更改：$time';
  }

  @override
  String localPendingEdit(String summary) {
    return '本地编辑：$summary';
  }

  @override
  String get conflictResolutionFailed => '无法解决冲突。';

  @override
  String get recurringEventScope => '重复日程范围';

  @override
  String get entireSeries => '整个系列';

  @override
  String get singleOccurrence => '此事件';

  @override
  String get thisAndFollowingEvents => '此事件及后续事件';

  @override
  String get thisAndFutureUnavailable => '此提供商不支持。';

  @override
  String get thisAndFutureMoveUnavailable => '无法安全移动此日程及后续日程。请选择此日程或整个系列。';

  @override
  String get entireSeriesMoveUnavailable => '本地没有可用的重复规则。请仅移动此日程。';

  @override
  String get copyEventAndDeleteOriginal => '复制日程并删除原日程？';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax 无法将此日程直接从 $source 移动到 $destination。应用会先创建副本，并且仅在复制成功后删除原日程。日程 ID 将发生变化；参与者的回复状态可能会重置，并可能发送邀请或取消通知；会议链接、附件、提醒、提供商特有的字段和重复例外可能无法保留。';
  }

  @override
  String get copyAndDelete => '复制并删除';

  @override
  String get chooseRecurringEventScope => '选择此更改适用于整个系列、仅此日程，还是此日程及后续日程。';

  @override
  String get taskDueBeforeStart => '截止时间不能早于开始时间。';

  @override
  String get taskStartDueTimeModeMismatch => '请同时设置开始和截止时间，或将任务设为全天。';

  @override
  String deleteCalendarConfirmation(String title) {
    return '删除“$title”？';
  }

  @override
  String get setCustomCalendarName => '设置自定义名称';

  @override
  String get setAction => '设置';

  @override
  String get removeFromMyCalendars => '从“我的日历”中移除';

  @override
  String get removeAction => '移除';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '要从 BusyMax 移除“$title”吗？所有者的日历和日程不会被删除。';
  }

  @override
  String get attachmentUploadUnresolved => '上传可能已完成。再次上传前，请刷新附件以确认结果。';

  @override
  String removeCalendarConfirmation(String title) {
    return '要从您的 Google 日历列表中移除“$title”吗？共享日历及其日程不会被删除。';
  }

  @override
  String get calendarCannotRemove => '无法从此账户删除或移除此日历。';

  @override
  String get calendarPendingChangesPreventRemoval =>
      '请等待此日历的待处理更改完成同步，然后再删除或移除它。';

  @override
  String get calendarSubscriptions => '日历订阅';

  @override
  String get calendarSubscriptionsDescription => '添加从安全 WebCal URL 刷新的只读日历。';

  @override
  String get addCalendarSubscription => '添加日历订阅';

  @override
  String get subscriptionName => '本地名称';

  @override
  String get subscriptionUrl => '订阅 URL';

  @override
  String get subscriptionUrlHelp =>
      '输入 HTTPS 或 webcal URL。BusyMax 会将完整 URL 保存在安全存储中。';

  @override
  String get subscriptionUrlInvalid => '请输入不含用户信息或片段的有效 HTTPS 或 webcal URL。';

  @override
  String get subscriptionColor => '本地颜色';

  @override
  String get subscriptionColorHelp => '使用六位颜色，例如 #3584E4。';

  @override
  String get subscriptionColorInvalid => '请输入六位十六进制颜色。';

  @override
  String get subscriptionRefreshMode => '刷新频率';

  @override
  String get subscriptionAutomatic => '自动';

  @override
  String get subscriptionHourly => '每小时';

  @override
  String get subscriptionSixHours => '每六小时';

  @override
  String get subscriptionDaily => '每天';

  @override
  String subscriptionSafeOrigin(String origin) {
    return '来源：$origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable => '请输入有效 URL 以预览其安全来源。';

  @override
  String get subscriptionReadOnly => '只读订阅';

  @override
  String get subscriptionNeverRefreshed => '尚未刷新';

  @override
  String subscriptionLastRefresh(String time) {
    return '上次成功刷新：$time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return '下次刷新：$time';
  }

  @override
  String get subscriptionStatusHealthy => '已是最新';

  @override
  String subscriptionStatusIssue(String code) {
    return '刷新问题：$code';
  }

  @override
  String get refreshNow => '立即刷新';

  @override
  String get unsubscribe => '取消订阅';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '要取消订阅“$name”吗？';
  }

  @override
  String get unsubscribeCalendarConfirmation => '这会移除本地订阅及其缓存的日程。已发布的日历不会更改。';

  @override
  String get addSubscriptionAction => '添加订阅';

  @override
  String subscriptionOperationFailed(String error) {
    return '日历订阅失败：$error';
  }

  @override
  String get subscriptions => '订阅';

  @override
  String get calendarImport => '日历导入';

  @override
  String get calendarImportDescription => '选择文件，查看其中的日程，然后选择接收这些日程的可写日历。';

  @override
  String get importIcsFile => '导入 .ics 文件';

  @override
  String get importIcsPreview => '导入日历日程';

  @override
  String importEventsFound(int count) {
    return '可导入日程集：$count';
  }

  @override
  String importInvalidEvents(int count) {
    return '无效日程：$count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return '有意省略：$fields';
  }

  @override
  String get noWritableCalendars => '没有可用的可写目标日历。';

  @override
  String get importDestinationCalendar => '目标日历';

  @override
  String get importIcsConfirm => '导入日程';

  @override
  String get importIcsComplete => '导入完成';

  @override
  String importQueued(int count) {
    return '已导入或已排队：$count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return '已跳过重复项：$count';
  }

  @override
  String importUnsupportedSets(int count) {
    return '不支持的重复集：$count';
  }

  @override
  String importIcsFailed(String error) {
    return '无法导入日历文件：$error';
  }

  @override
  String get networkOffline => '离线';

  @override
  String get networkOfflineDescription => '恢复连接后将同步更改。';

  @override
  String get networkOfflineTryAgain => '您当前处于离线状态。请连接互联网后重试。';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days';
  }

  @override
  String get repeatSummarySeparator => '';

  @override
  String repeatMonthDayValue(String day) {
    return '$day日';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency$month$day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency$month的$days';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency$months的$day';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency$months的$days';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$frequency$month的$_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一个$days',
      'second': '第二个$days',
      'third': '第三个$days',
      'fourth': '第四个$days',
      'fifth': '第五个$days',
      'secondToLast': '倒数第二个$days',
      'last': '最后一个$days',
      'other': '$days',
    });
    return '$frequency$months的$_temp0';
  }

  @override
  String get searchFilters => '搜索筛选条件';

  @override
  String get searchType => '类型';

  @override
  String get searchDate => '日期';

  @override
  String get searchAnyDate => '任何日期（已下载数据）';

  @override
  String get eventLink => '日程链接';

  @override
  String get eventLinkOpenFailed => '无法打开链接。';

  @override
  String get scheduleRangeIncomplete => '部分日程无法核实，正在显示已下载数据。';

  @override
  String get searchThisWeek => '本周';

  @override
  String get searchCustomRange => '自定义范围';

  @override
  String get searchTaskStatus => '任务状态';

  @override
  String get searchTaskDue => '任务到期状态';

  @override
  String get searchAnyDueState => '任何到期状态';

  @override
  String get searchNoDueDate => '无截止日期';

  @override
  String get searchPerson => '人员';

  @override
  String get searchSources => '来源';

  @override
  String get searchClearFilters => '重置筛选条件';

  @override
  String get searchFiltersAction => '筛选';

  @override
  String get searchNoSources => '未选择搜索来源';

  @override
  String get searchClearText => '清除文字';

  @override
  String get openSharedCalendar => '打开共享日历';

  @override
  String get manageCalendarSharing => '管理日历共享';

  @override
  String get shareRecipientEmail => '接收者邮箱';

  @override
  String get shareRole => '访问角色';

  @override
  String get addCalendarShare => '添加访问权限';

  @override
  String get sharingRefreshFailed => '共享更改已成功，但无法刷新权限列表。请在再次更改前重新加载列表。';

  @override
  String get sharingRateLimited => '共享暂时受到限制。请在等待时间结束后重试。';

  @override
  String get attachmentUploadRateLimited => '附件上传暂时受到限制。请在等待时间结束后重试。';

  @override
  String get sharingPermissionUnavailable => '此日历的共享权限不可用。';

  @override
  String get calendarShareFreeBusy => '仅查看忙闲';

  @override
  String get calendarShareLimitedRead => '读取有限详情';

  @override
  String get calendarShareRead => '读取全部详情';

  @override
  String get calendarShareWrite => '编辑日程';

  @override
  String get calendarShareWriteWithoutPrivate => '编辑但不查看私人详情';

  @override
  String get calendarShareOwner => '所有者';

  @override
  String get eventLabel => '日程标签';

  @override
  String get loadOutlookCategories => '加载 Outlook 类别';

  @override
  String get outlookCategoriesUnavailable => 'Outlook 类别不可用；现有分配会保留。';

  @override
  String get googleEventType => '日程类型';

  @override
  String get googleRegularEvent => '普通日程';

  @override
  String get googleFocusTime => '专注时间';

  @override
  String get googleOutOfOffice => '外出';

  @override
  String get googleWorkingLocation => '工作地点';

  @override
  String get googleDeclineInvitations => '拒绝重叠的邀请';

  @override
  String get googleDeclineNone => '不拒绝';

  @override
  String get googleDeclineNew => '拒绝新邀请';

  @override
  String get googleDeclineAll => '拒绝所有冲突邀请';

  @override
  String get googleDeclineMessage => '拒绝消息';

  @override
  String get googleChatStatus => '聊天状态';

  @override
  String get googleChatAvailable => '有空';

  @override
  String get googleChatDoNotDisturb => '勿扰';

  @override
  String get googleWorkAtHome => '家';

  @override
  String get googleWorkAtOffice => '办公室';

  @override
  String get googleWorkAtCustomLocation => '自定义地点';

  @override
  String get googleWorkLocationLabel => '地点名称';

  @override
  String get googleStatusPrimaryOnly => 'Google 状态日程需要您的 Google 主日历。';

  @override
  String unknownEventLabel(String id) {
    return '未知标签（$id）';
  }

  @override
  String get calendarOwnerEmail => '日历所有者的电子邮件地址';

  @override
  String registrationSetupTitle(String provider) {
    return '设置 $provider';
  }

  @override
  String get registrationSetupGuide => '设置指南';

  @override
  String get registrationGoogleInstructions =>
      '创建自己的 Google Cloud 项目，启用 Calendar 和 Tasks API，然后导入桌面 OAuth 客户端的 JSON。请授权预期的账号。';

  @override
  String get registrationMicrosoftInstructions =>
      '在允许应用注册的 Entra 租户中使用公共应用注册。输入客户端 ID 和支持的账号类型。无需客户端密码。';

  @override
  String get registrationImportGoogle => '选择桌面 OAuth JSON';

  @override
  String get registrationValidate => '验证注册';

  @override
  String get registrationAuthorize => '在浏览器中授权';

  @override
  String get registrationClientId => '应用程序／客户端 ID';

  @override
  String get registrationTenantId => '租户 ID';

  @override
  String get registrationAudience => '支持的账号';

  @override
  String get registrationBothAudience => '个人和组织账号';

  @override
  String get registrationOrganizationAudience => '组织账号';

  @override
  String get registrationPersonalAudience => '个人账号';

  @override
  String get registrationTenantAudience => '单个组织租户';

  @override
  String registrationSummary(String clientId) {
    return '注册：$clientId';
  }

  @override
  String get registrationMigrate => '立即迁移';

  @override
  String get registrationReplace => '替换注册';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return '此帐号使用为现有帐号保留的原始 $provider 注册。要替换，请设置 $setup 并重新连接此帐号。现有日历、任务和本地更改会保留。';
  }

  @override
  String get registrationContinue => '继续使用此账号';

  @override
  String get registrationGoogleProject => 'Google Cloud 项目';

  @override
  String get registrationMicrosoftApp => 'Microsoft 应用注册';

  @override
  String get registrationUserOwned => '用户提供的注册';

  @override
  String get registrationNativeGoogle => 'Google Android 原生注册';

  @override
  String get registrationShared => '共享注册（过渡期）';

  @override
  String get registrationUnresolved => '无法确定注册来源。账号数据已保留。';

  @override
  String get registrationOfficialDocumentation => '官方文档';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return '软件包：$packageName\n签名哈希：$signatureHash\n重定向 URI：$redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      '请检查注册的客户端类型、支持的账户、权限和重定向设置。若配置来自导入，请重新选择配置文件。';

  @override
  String get oauthAuthorizationCodeUnusable => '此次授权未能完成。请重新开始授权；现有连接已保留。';

  @override
  String get oauthPermissionRefused => '授权被拒绝或缺少所需权限。请重试并授予所需权限。';

  @override
  String get oauthProviderThrottled => '服务提供方正在限制请求。请稍后重试；现有连接已保留。';

  @override
  String get oauthProviderTemporaryFailure => '服务提供方的临时问题导致授权未能完成。请重试；现有连接已保留。';

  @override
  String get oauthAuthorizationTimedOut => '授权超时。请重试；若配置来自导入，请重新选择配置文件。';

  @override
  String get oauthWrongAccount => '请授权为重新连接而选定的账户。现有连接已保留。';

  @override
  String get oauthSecureStorageUnavailable => '安全存储不可用。请恢复安全存储访问后重试。';

  @override
  String get oauthRevokedRemovalIncomplete =>
      '远程授权已撤销，但账户清理未能完成。请重启 BusyMax 以重试本地恢复。';

  @override
  String get addAccount => '添加账户';

  @override
  String get registrationConnect => '连接';

  @override
  String get registrationBack => '返回';

  @override
  String get registrationReplaceGoogle => '替换桌面 OAuth JSON';

  @override
  String get registrationSelectedConfiguration => '已选择的配置';

  @override
  String get registrationDirectoryId => '目录／租户 ID';

  @override
  String get registrationInvalidId => '请输入有效的 UUID。';

  @override
  String get registrationExpired => '此配置已过期。请重新导入或修改注册字段后再连接。';

  @override
  String get registrationOwnProjectRequired => '请选择您自己的项目或租户中的注册。';

  @override
  String get registrationSetupFailed => '无法完成设置，请重试。';

  @override
  String get registrationLinkFailed => '无法打开链接。请检查浏览器后重试。';

  @override
  String get registrationPermissions => '权限';

  @override
  String get registrationDesktopClient => '桌面应用';

  @override
  String get registrationOpenGoogleConsole => '打开 Google Cloud 控制台';

  @override
  String get registrationGoogleAudienceHelp => 'Google 发布和测试用户要求';

  @override
  String get registrationDesktopHelp => '桌面应用注册说明';

  @override
  String get registrationOpenEntra => '打开 Microsoft Entra 管理中心';

  @override
  String get registrationGuideGoogleProject =>
      '打开 Google Cloud Console。使用顶部的项目选择器选择您自己的项目，或选择 New project，输入名称后选择 Create。后续步骤请保持选中此项目。';

  @override
  String get registrationGuideGoogleAudience =>
      '进入 Google Auth Platform → Branding。如果尚未开始设置，选择 Get started。在 App name 中输入 BusyMax，选择您自己的 User support email，然后选择 Next。在 Audience 中，请选择 External。选择 Next，在 Contact Information 中输入您的邮箱，再选择 Next。接受 User Data Policy，然后选择 Continue 和 Create。如果已完成设置，请检查 Branding 和 Audience。';

  @override
  String get registrationGuideGooglePermissions =>
      '打开 Google Auth Platform → Data Access → Add or remove scopes。选择下面五个权限范围；必要时使用 Manually add scopes。手动输入时，粘贴缺少的值并选择 Add to table。选择 Update，再选择 Save。BusyMax 需要日历和任务的访问权限。';

  @override
  String get registrationGuideGoogleClient =>
      '打开 Google Auth Platform → Clients → Create client。将 Application type 设为 Desktop app，在 Name 中输入 BusyMax 并选择 Create。在创建对话框中选择 Download JSON 并保存文件。选择返回以回到表单，选择该文件并检查项目和客户端 ID。选择连接，然后在浏览器中批准日历和任务访问权限。';

  @override
  String get registrationGuideMicrosoftApp =>
      '登录 Microsoft Entra 管理中心。使用 Settings 选择允许您注册应用的租户。打开 Entra ID → App registrations → New registration。在 Name 中输入 BusyMax，然后在下一步选择支持的帐号类型。如果注册被禁止，请向租户管理员申请权限。';

  @override
  String get registrationGuideMicrosoftRedirect =>
      '在应用注册中打开 Authentication → Add a platform → Mobile and desktop applications。选择或输入下面的重定向 URI，然后选择 Configure 保存。BusyMax 使用系统浏览器。不需要客户端密码。';

  @override
  String get registrationGuideMicrosoftPermissions =>
      '打开 API permissions → Add a permission → Microsoft Graph → Delegated permissions。搜索并选择下面每个权限范围，然后选择 Add permissions。如果已有 User.Read，请保留。如果组织要求管理员同意，请让管理员使用租户的 Grant admin consent。';

  @override
  String get registrationGuideMicrosoftConnect =>
      '选择返回以回到表单。粘贴 Application (client) ID，并选择与注册一致的支持帐号选项。如果选择一个组织租户，还需粘贴 Directory (tenant) ID。选择连接并在浏览器中登录目标帐号。BusyMax 在本地检查字段；Microsoft 在浏览器登录时请求您的同意。';

  @override
  String get registrationGoogleImportFailed =>
      '无法导入此文件。请选择有效的桌面 OAuth JSON。之前的有效选择会保留。';

  @override
  String get registrationGoogleSetupInstructions => 'Google 设置说明';

  @override
  String get registrationMicrosoftSetupInstructions => 'Microsoft 设置说明';

  @override
  String get registrationDesktopConfiguration => '桌面 OAuth 配置';

  @override
  String get registrationNoFileSelected => '未选择文件';

  @override
  String get registrationChooseFile => '选择文件…';

  @override
  String get registrationReplaceFile => '替换…';

  @override
  String get registrationGoogleIntroduction =>
      '选择您自己的 Google Cloud 项目的桌面 OAuth JSON。';

  @override
  String get registrationMicrosoftIntroduction => '输入您自己的 Microsoft 应用注册信息。';

  @override
  String get registrationSetupInstructions => '设置说明';

  @override
  String get registrationInstructionsDescription => '创建连接帐号所需的配置。';

  @override
  String get registrationEnableApis => '启用 Calendar 和 Tasks';

  @override
  String get registrationConsentScreen => '配置同意屏幕';

  @override
  String get registrationAppName => '应用名称';

  @override
  String get registrationScopes => '权限范围';

  @override
  String get registrationRedirectUri => '重定向 URI';

  @override
  String get registrationOpenApiLibrary => '打开 Google API 库';

  @override
  String get registrationOpenBranding => '打开 Google Auth Platform 的 Branding';

  @override
  String get registrationOpenDataAccess =>
      '打开 Google Auth Platform 的 Data Access';

  @override
  String get registrationOpenClients => '打开 Google Auth Platform 的 Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      '打开 Entra 应用注册以设置 Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      '打开 Entra 应用注册以设置 API permissions';

  @override
  String get registrationCopy => '复制';

  @override
  String get registrationCopyAll => '全部复制';

  @override
  String get registrationGuideGoogleApis =>
      '进入 APIs & Services → Library。搜索 Google Calendar API，打开其页面并选择 Enable。返回 Library，对 Google Tasks API 重复此操作。';

  @override
  String get registrationGuideMicrosoftAudience =>
      '在 Supported account types 中，个人帐号选择 Personal accounts only，组织帐号选择 Multiple Entra ID tenants，同时支持两者选择 Any Entra ID Tenant + Personal Microsoft accounts，仅限此目录选择 Single tenant only。选择 Register。在 Overview 中复制 Application (client) ID；单一租户还需复制 Directory (tenant) ID。在 BusyMax 中选择对应的支持帐号选项。';

  @override
  String get registrationConnectBusyMax => '通过 BusyMax 连接';

  @override
  String get registrationRecommended => '推荐';

  @override
  String get registrationOtherMethods => '其他连接方式';

  @override
  String get registrationWorkspace => 'Google Workspace 组织';

  @override
  String get registrationGoogleCustom => '自定义 OAuth 客户端';

  @override
  String get registrationMicrosoftCustom => '自定义应用注册';

  @override
  String get registrationMethodsIntroduction => '选择连接帐号的方式。';

  @override
  String get registrationWorkspaceDescription => '使用组织管理的配置。';

  @override
  String get registrationCustomDescription => '使用自行管理的注册。';

  @override
  String get registrationSharedUnavailable =>
      '此版本无法通过 BusyMax 连接。您可以使用以下其他连接方式。';

  @override
  String get registrationWorkspaceIntroduction =>
      '选择组织提供或管理的桌面 OAuth JSON。文件不能证明组织所有权、受众或验证状态。';

  @override
  String get registrationWorkspaceSetupInstructions => 'Google Workspace 设置说明';

  @override
  String get registrationBusyMaxManaged => 'BusyMax 管理的注册';

  @override
  String get registrationBranding => '配置品牌和域名';

  @override
  String get registrationPublishing => '发布以供日常使用';

  @override
  String get registrationOpenAudience => '打开 Google Auth Platform Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      '向管理员索取 Desktop OAuth JSON，或打开 Google Cloud Console 并选择您的 Google Workspace 组织拥有的项目。若要创建项目，打开“管理资源”→“创建项目”，输入“项目名称”，在“父级资源”中选择您的组织或其文件夹，然后选择“创建”。后续步骤保持选中该项目。创建需要 Project Creator 权限，配置 OAuth 需要 OAuth Config Editor，启用 API 需要 Service Usage Admin 或同等权限。若操作受阻，请联系管理员。';

  @override
  String get registrationGuideGoogleBranding =>
      '在 Branding → App domain 中，先添加项目的授权域名，再输入主页、隐私政策和服务条款 URL，然后选择 Save。External 生产应用需要这些链接。请使用自己拥有的域名，并在 Google 要求品牌验证时通过 Search Console 验证所有权。下方 BusyMax 隐私链接不能证明您的项目拥有 busystack.org。';

  @override
  String get registrationGuideGooglePublishing =>
      '在 Audience 中选择 Publish app 并确认 In production。日常使用不要停留在 Testing：这些 Calendar/Tasks 授权和刷新令牌会在七天后过期。发布与验证是两回事。少于 100 人的个人使用可能免于验证，但仍有未验证警告和人数限制；更广泛分发可能需要品牌和权限范围批准。生产授权仍可能过期或被撤销。';

  @override
  String get registrationGuideWorkspacePermissions =>
      '与管理员检查以下权限范围。Internal 应用不需要在同意屏幕中列出权限范围。如管理员要求，请打开 Data Access → Add or remove scopes，添加这些值，然后选择 Update 和 Save。管理员控制仍可能限制授权。';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      '共享日历和类别权限会在启用相应可选功能时单独请求；不要将其添加到上述必需设置中。';

  @override
  String get registrationGuideWorkspaceAudience =>
      '进入 Google Auth Platform → Branding。如果尚未开始设置，选择 Get started。在 App name 中输入 BusyMax，选择您自己的 User support email，然后选择 Next。在 Audience 中，请选择 Internal。选择 Next，在 Contact Information 中输入您的邮箱，再选择 Next。接受 User Data Policy，然后选择 Continue 和 Create。如果已完成设置，请检查 Branding 和 Audience。\n\nInternal 仅允许项目父组织中的帐号，并受管理员控制。不需要测试用户列表。BusyMax 无法从下载的 JSON 验证这些控制台设置。';

  @override
  String get contactsTitle => '联系人';

  @override
  String get contactsLinkedDescription => '添加日程参与者时使用此账号缓存的联系人。';

  @override
  String get contactsEnableSuggestions => '启用联系人建议';

  @override
  String get contactsReadPermissionDescription => '请求联系人只读权限';

  @override
  String get contactsEnableEditing => '启用联系人编辑';

  @override
  String get contactsWritePermissionDescription => '请求联系人读写权限';

  @override
  String get contactsSuggestionsEnabled => '联系人建议已启用';

  @override
  String get contactsNeedsAttention => '联系人需要处理';

  @override
  String get contactsReadWriteAccess => '读写权限';

  @override
  String get contactsDisableForAccount => '停用此账号的联系人';

  @override
  String get contactsOnlyDescription => '这些来源独立于日历和任务账号。';

  @override
  String get contactsAddCardDav => '添加 CardDAV 联系人';

  @override
  String get contactsAddNextcloud => '添加 Nextcloud 联系人';

  @override
  String get contactsUseForAttendees => '用于参与者建议';

  @override
  String get contactsServerUrlLabel => 'HTTPS 服务器网址';

  @override
  String get contactsUsernameLabel => '用户名';

  @override
  String get contactsPasswordLabel => '密码';
}

/// The translations for Chinese, using the Han script (`zh_Hant`).
class AppLocalizationsZhHant extends AppLocalizationsZh {
  AppLocalizationsZhHant() : super('zh_Hant');

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax 由桌面的啟動設定啟動。請在那裡移除 BusyMax 的項目，然後完全結束並重新開啟 BusyMax，以使用此開關。';

  @override
  String get timeFormat => '時間格式';

  @override
  String get firstDayOfWeek => '一週的第一天';

  @override
  String get systemDefault => '系統預設';

  @override
  String systemDefaultResolved(String weekday) {
    return '系統預設（$weekday）';
  }

  @override
  String get timeFormatTwelveHour => '12小時制';

  @override
  String get timeFormatTwentyFourHour => '24小時制';

  @override
  String get timeEndOfDay => '當天結束';

  @override
  String get timePeriod => '上午/下午';

  @override
  String get launchAtLoginReadFailed => '無法確定登入時啟動的狀態。';

  @override
  String get launchAtLoginUnavailable => '此系統不支援登入時啟動。';

  @override
  String get windowsStartupEnabledByPolicy => '管理員已啟用自動啟動，無法在此變更。';

  @override
  String get settingsSaveFailed => '無法儲存設定。重新啟動 BusyMax 時，您的變更可能會遺失。';

  @override
  String get nextcloudExportCollection => '匯出集合資源';

  @override
  String nextcloudImportItems(int count) {
    return '找到 $count 個事件／工作資源';
  }

  @override
  String get nextcloudSchedulingInbox => '行程邀請收件匣';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud 會將這些訊息處理到行事曆中。確認訊息只會移除收件匣訊息，不會刪除事件。';

  @override
  String get nextcloudInboxEmpty => '沒有行程訊息。';

  @override
  String get nextcloudAcknowledge => '確認訊息';

  @override
  String get nextcloudAcknowledgeConfirm => '從收件匣移除此訊息？行事曆事件將會保留。';

  @override
  String get nextcloudGuestAvailability => '查看受邀者的空閒時間';

  @override
  String nextcloudTrashRetention(int days) {
    return '伺服器垃圾桶保留時間：$days 天';
  }

  @override
  String get nextcloudCancelMeeting => '取消會議';

  @override
  String get nextcloudDeclineAndRemove => '拒絕並移除邀請';

  @override
  String get nextcloudDeclineRemovalWarning => '同步時會傳送拒絕回覆。此操作不會取消主辦人的會議。';

  @override
  String get nextcloudAvailabilityUnknown => '空閒狀態未知';

  @override
  String get nextcloudAvailabilityFree => '此時段未回報忙碌時間';

  @override
  String get nextcloudAvailabilityBusy => '忙碌時段';

  @override
  String get nextcloudSchedulingPending => 'Nextcloud 將在同步時傳送會議更新。本機儲存不代表已送達。';

  @override
  String get nextcloudAttendeeRestrictions =>
      '只有主辦人或獲授權的代理人才能修改會議詳細資料。您可在邀請詳細資料中回覆。';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      '無法透過複製並刪除來移動此會議。請使用同一行程身分下的行事曆。';

  @override
  String get nextcloudSchedulingStatus => '伺服器行程處理狀態';

  @override
  String get nextcloudImportFollowUp => '匯入的資源已儲存在本機。提醒更新尚未完成；請勿重複匯入。';

  @override
  String get nextcloudNativeImport =>
      '匯入完整的事件和工作資源，不傳送邀請。除非選擇新副本，否則會略過現有 UID。不支援的資源將逐項回報。';

  @override
  String get nextcloudImportMethod => '此檔案包含行程訊息。匯入會儲存內容並移除 METHOD，不會處理邀請或回覆。';

  @override
  String get nextcloudImportCopies => '以新身分匯入為新副本';

  @override
  String get nextcloudCollectionSettings => '集合設定';

  @override
  String get nextcloudSharing => '共用';

  @override
  String get nextcloudOwned => '自有';

  @override
  String get nextcloudShared => '已共用';

  @override
  String get nextcloudDelegated => '已委派';

  @override
  String get nextcloudSubscription => '訂閱';

  @override
  String get nextcloudDeleted => '已刪除';

  @override
  String get nextcloudMetadataEditable => '行事曆內容唯讀，但可修改集合屬性。';

  @override
  String get nextcloudServerOrder => '伺服器順序（獨立於側邊欄順序）';

  @override
  String get nextcloudCalendarEnabled => '在伺服器上啟用';

  @override
  String get nextcloudAvailability => '將此集合納入空閒狀態計算';

  @override
  String get nextcloudCalendarTimezone => '行事曆時區（VTIMEZONE 文件）';

  @override
  String get nextcloudRefreshPending => '變更已儲存在 Nextcloud。更新尚未完成；請勿重複變更。';

  @override
  String get nextcloudOutcomeUnknown => '無法確認伺服器結果。請重新整理後再試。';

  @override
  String get nextcloudRemoveShared => '移除共用行事曆／清單';

  @override
  String get nextcloudRemoveMixed => '此集合包含事件和工作。刪除集合將同時刪除兩者。';

  @override
  String get nextcloudReadAccess => '唯讀';

  @override
  String get nextcloudWriteAccess => '讀寫';

  @override
  String get nextcloudRecipientSearch => '尋找人員或群組';

  @override
  String get nextcloudNoRecipients => '沒有符合的人員或群組。';

  @override
  String get nextcloudRevokeShare => '撤銷存取權';

  @override
  String get nextcloudPublish => '發佈連結';

  @override
  String get nextcloudUnpublish => '停止發佈';

  @override
  String get nextcloudPublishWarning => '擁有發佈連結的任何人都可能讀取此行事曆。是否發佈？';

  @override
  String get nextcloudTrash => '已刪除的行事曆和工作';

  @override
  String get nextcloudTrashEmpty => '沒有已刪除的行事曆項目。';

  @override
  String get nextcloudRestore => '還原';

  @override
  String get nextcloudPermanentDelete => '永久刪除';

  @override
  String get nextcloudPermanentDeleteWarning =>
      '永久刪除此項目？之後無法從 Nextcloud 行事曆垃圾桶還原。';

  @override
  String get nextcloudOperationDenied => 'Nextcloud 不允許此操作。';

  @override
  String get nextcloudUnsupported => '伺服器不支援此操作。';

  @override
  String get nextcloudPendingChanges => '關閉前請儲存或捨棄集合變更。';

  @override
  String get nextcloudServerUnavailable => '無法連線至 Nextcloud。快取項目和待處理變更保持不變。';

  @override
  String get mapsShow => '在地圖上顯示';

  @override
  String get openLink => '開啟連結';

  @override
  String get externalLocationOpenFailed => '無法在外部應用程式中開啟該位置。';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed => '無法調整行程時間。已儲存的時間未變更。';

  @override
  String get scheduleRescheduleStale => '拖曳期間此行程已變更。請重試。';

  @override
  String get scheduleRescheduleNotificationsFailed => '新時間已儲存，但無法更新提醒。';

  @override
  String get moveUp => '上移';

  @override
  String get moveDown => '下移';

  @override
  String get windowsSupport => '支援';

  @override
  String get windowsThirdPartyLicenses => '第三方授權';

  @override
  String get windowsSearch => '搜尋';

  @override
  String get windowsStartupDisabledByUser => '使用者已在 Windows 設定中停用。';

  @override
  String get windowsStartupDisabledByPolicy => '已由 Windows 原則停用。';

  @override
  String get windowsStartupUnavailable => '從 MSIX 套件安裝 BusyMax 後即可使用。';

  @override
  String get windowsReminderExitNotice =>
      '完全結束 BusyMax 後，提醒會停止。請讓應用程式在背景執行以接收提醒。';

  @override
  String get windowsProductVersionLabel => '產品版本';

  @override
  String get windowsPackageVersionLabel => 'Windows 套件版本';

  @override
  String get windowsUnpackaged => '未封裝';

  @override
  String get windowsAgendaLoadMore => '載入更多議程項目';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$month的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency$firstMonth和$secondMonth的$day';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency$firstMonth和$secondMonth的$firstDay和$secondDay';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency$firstMonth和$secondMonth的$days';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      '連接 Google、Microsoft、Apple iCloud Calendar 或 Nextcloud 帳戶。';

  @override
  String get googlePermissionsConsentNotice => '在 Google 權限畫面中，同時選取行事曆和待辦事項權限。';

  @override
  String get googlePermissionsRequiredRetry =>
      '必須授予 Google 日曆和 Google Tasks 權限。請再試一次並勾選兩個核取方塊。';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => '尚未設定此服務。';

  @override
  String get waitingForGoogleSignIn => '正在等候 Google 登入...';

  @override
  String get waitingForMicrosoftSignIn => '正在等候 Microsoft 登入...';

  @override
  String get microsoftSignInNotConfigured =>
      '尚未設定 Microsoft 登入。請設定 MICROSOFT_OAUTH_CLIENT_ID。';

  @override
  String get cancel => '取消';

  @override
  String get close => '關閉';

  @override
  String get windowMinimize => '最小化';

  @override
  String get windowMaximize => '最大化';

  @override
  String get windowRestore => '還原';

  @override
  String get exit => '結束';

  @override
  String get options => '選項';

  @override
  String get hide => '隱藏';

  @override
  String get show => '顯示';

  @override
  String get export => '匯出';

  @override
  String get save => '儲存';

  @override
  String get settings => '設定';

  @override
  String get all => '全部';

  @override
  String get calendarEvents => '活動';

  @override
  String get calendarTasks => '待辦事項';

  @override
  String get calendar => '行事曆';

  @override
  String get calendars => '行事曆';

  @override
  String get newCalendar => '新增行事曆';

  @override
  String get calendarColor => '行事曆顏色';

  @override
  String calendarColorOption(int number) {
    return '顏色 $number';
  }

  @override
  String get calendarManagementUnsupported => '此提供者不支援 BusyMax 中的行事曆管理。';

  @override
  String get primaryCalendarCannotDelete => '無法刪除主要行事曆。';

  @override
  String calendarCreateFailed(String error) {
    return '無法建立行事曆：$error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      '行事曆已建立，但 BusyMax 無法重新整理帳戶。它會在下次同步後顯示。';

  @override
  String calendarUpdateFailed(String error) {
    return '無法更新行事曆：$error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return '無法刪除行事曆：$error';
  }

  @override
  String get newEvent => '新增活動';

  @override
  String get refreshCalendar => '重新整理行事曆';

  @override
  String get openInProvider => '在服務中開啟';

  @override
  String get linkedResources => '關聯資源';

  @override
  String get noLinkedResources => '沒有關聯資源';

  @override
  String get attachments => '附件';

  @override
  String get attachmentsNotLoaded => '附件尚未載入';

  @override
  String get hideFromSchedule => '從行程中隱藏';

  @override
  String get showInSchedule => '在行程中顯示';

  @override
  String get noCalendarsSynced => '尚未同步任何行事曆。';

  @override
  String get allDay => '全天';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '還有 $countString 項';
  }

  @override
  String get noEventsOrTasks => '沒有活動或待辦事項';

  @override
  String get scheduleLoading => '正在載入行程...';

  @override
  String get scheduleUnavailable => '無法使用行程';

  @override
  String get scheduleNoSources => '沒有可見的行事曆或待辦清單';

  @override
  String get scheduleNoSourcesDescription => '請在設定中選擇要顯示的內容，然後重新整理。';

  @override
  String get scheduleNoSearchResults => '沒有相符的活動或待辦事項';

  @override
  String get scheduleNoSearchResultsDescription => '請嘗試其他搜尋內容或清除目前的篩選條件。';

  @override
  String get refresh => '重新整理';

  @override
  String get trayOpenBusyMax => '打開 BusyMax';

  @override
  String get trayShowBusyMax => '顯示 BusyMax';

  @override
  String get trayNewEvent => '新增活動…';

  @override
  String get trayNewTask => '新增待辦事項…';

  @override
  String get trayToday => '今天';

  @override
  String get trayAllDay => '全天';

  @override
  String get trayNow => '現在';

  @override
  String get trayCalendarEvent => '行事曆活動';

  @override
  String get trayUntitledEvent => '未命名活動';

  @override
  String get trayNothingElseToday => '今天沒有其他內容';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $count 個任務到期',
      one: '今天有 1 個任務到期',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => '打開今天的日程';

  @override
  String get traySyncNow => '立即同步';

  @override
  String get traySyncing => '正在同步…';

  @override
  String get trayNotConnected => '未連接';

  @override
  String get trayNotYetSynced => '尚未同步';

  @override
  String get trayLastSyncedJustNow => '剛剛同步';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 分鐘前同步',
      one: '1 分鐘前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 小時前同步',
      one: '1 小時前同步',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 天前同步',
      one: '1 天前同步',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => '設定';

  @override
  String get trayQuitBusyMax => '結束 BusyMax';

  @override
  String get agendaLoadMoreOverdue => '載入更多逾期待辦事項';

  @override
  String get agendaLoadMoreNoDate => '載入更多無日期待辦事項';

  @override
  String get viewDay => '日';

  @override
  String get viewWeek => '週';

  @override
  String get viewMonth => '月';

  @override
  String get viewYear => '年';

  @override
  String get viewAgenda => '行程';

  @override
  String get scheduleSettings => '行程';

  @override
  String get scheduleDisplaySettings => '行程顯示';

  @override
  String get newEventsAndTasks => '新增行程和工作';

  @override
  String get defaultCalendar => '預設行事曆';

  @override
  String get defaultTaskList => '預設工作清單';

  @override
  String get lastUsed => '最近使用';

  @override
  String get scheduleDisplayHoursDescription =>
      '日檢視和週檢視一開始會顯示此時間範圍。必要時，較早或較晚的項目會擴大此範圍。';

  @override
  String get scheduleDayStartsAt => '每日開始時間';

  @override
  String get scheduleDayEndsAt => '每日結束時間';

  @override
  String get sourceCalendar => '行事曆';

  @override
  String get sourceTaskList => '待辦清單';

  @override
  String get createChoiceTitle => '新增';

  @override
  String get createEventAtTime => '活動';

  @override
  String get createTaskAtDate => '待辦事項';

  @override
  String get editEvent => '編輯活動';

  @override
  String get eventTitle => '活動標題';

  @override
  String get location => '地點';

  @override
  String get timeSlot => '時段';

  @override
  String get startDateTime => '開始日期/時間';

  @override
  String get endDateTime => '結束日期/時間';

  @override
  String get doesNotRepeat => '不重複';

  @override
  String get defaultReminder => '預設提醒';

  @override
  String get guests => '參與者';

  @override
  String get noGuests => '無參與者';

  @override
  String get attendeeRequired => '必要';

  @override
  String get attendeeOptional => '選用';

  @override
  String get meetingSection => '會議';

  @override
  String get addGoogleMeet => '添加 Google Meet';

  @override
  String get addTeamsMeeting => '添加 Microsoft Teams 會議';

  @override
  String get onlineMeetingAdded => '已添加在線會議';

  @override
  String get requestResponses => '要求回覆';

  @override
  String get requestResponsesDescription => '要求參與者回復邀請。';

  @override
  String get hideGuestList => '隱藏參與者清單';

  @override
  String get hideGuestListDescription => '參與者無法查看其他受邀者。';

  @override
  String get allowNewTimeProposals => '允許提出新時間';

  @override
  String get allowNewTimeProposalsDescription => '參與者可以建議其他會議時間。';

  @override
  String get notifyGuestsTitle => '通知參與者？';

  @override
  String get notifyGuestsSaveMessage => '此會議有參與者。保存時發送邀請或活動更新嗎？';

  @override
  String get notifyGuestsDeleteMessage => '此會議有參與者。刪除時發送取消通知嗎？';

  @override
  String get sendUpdates => '傳送更新';

  @override
  String get sendCancellation => '傳送取消通知';

  @override
  String get doNotSend => '不要傳送';

  @override
  String get microsoftNotifyGuestsSaveTitle => '保存會議？';

  @override
  String get microsoftNotifyGuestsSaveMessage => 'Microsoft 將向參與者發送邀請或活動更新。';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '刪除會議？';

  @override
  String get microsoftNotifyGuestsDeleteMessage => 'Microsoft 將向參與者發送取消通知。';

  @override
  String get organizer => '主辦人';

  @override
  String get yourResponse => '你的回覆';

  @override
  String get guestResponses => '參與者回覆';

  @override
  String get respond => '回復';

  @override
  String get acceptInvitation => '接受';

  @override
  String get tentativeInvitation => '暫定';

  @override
  String get declineInvitation => '拒絕';

  @override
  String get joinMeeting => '加入會議';

  @override
  String get responseAccepted => '已接受';

  @override
  String get responseTentative => '暫定';

  @override
  String get responseDeclined => '已拒絕';

  @override
  String get responseNeedsAction => '等待回復';

  @override
  String get responseNotResponded => '未回復';

  @override
  String get responseOrganizer => '組織者';

  @override
  String invitationResponseFailed(String error) {
    return '無法發送回復：$error';
  }

  @override
  String get joinMeetingFailed => '無法打開會議鏈接。';

  @override
  String get description => '說明';

  @override
  String get availabilityShowAs => '空閒狀態 / 顯示為';

  @override
  String get busy => '忙碌';

  @override
  String get visibility => '顯示設定';

  @override
  String get defaultVisibility => '預設顯示設定';

  @override
  String get conference => '會議';

  @override
  String get noConference => '無會議';

  @override
  String get providerCalendar => '服務行事曆';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => '粗體';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => '斜體';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => '底線';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString 分鐘前',
      one: '1 分鐘前',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => '開始時';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString 小時前',
      one: '1 小時前',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString 天前',
      one: '1 天前',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => '有空';

  @override
  String get availabilityTentative => '暫定';

  @override
  String get availabilityOutOfOffice => '不在辦公室';

  @override
  String get availabilityWorkingElsewhere => '在其他地點工作';

  @override
  String get visibilityDefault => '預設';

  @override
  String get visibilityPublic => '公開';

  @override
  String get visibilityPrivate => '私人';

  @override
  String get visibilityConfidential => '機密';

  @override
  String get sensitivityNormal => '一般';

  @override
  String get sensitivityPersonal => '個人';

  @override
  String get tasks => '待辦事項';

  @override
  String get allTasks => '所有待辦事項';

  @override
  String tasksInList(String title) {
    return '$title中的待辦事項';
  }

  @override
  String get taskLists => '待辦清單';

  @override
  String get navigation => '導覽';

  @override
  String get mainMenu => '主選單';

  @override
  String get keyboardShortcuts => '鍵盤快速鍵';

  @override
  String get shortcutGroupGeneral => '一般';

  @override
  String get shortcutKeyboardShortcutsDescription => '顯示快速鍵參考表';

  @override
  String get shortcutGroupNavigation => '導覽';

  @override
  String get shortcutNextPeriod => '下一時段';

  @override
  String get shortcutNextPeriodDescription => '在週檢視中前往下一週，在月檢視中前往下個月，依此類推';

  @override
  String get shortcutPreviousPeriod => '上一時段';

  @override
  String get shortcutPreviousPeriodDescription => '在週檢視中前往上一週，在月檢視中前往上個月，依此類推';

  @override
  String get shortcutJumpToToday => '跳至今天';

  @override
  String get shortcutGroupView => '檢視';

  @override
  String get viewSelector => '檢視';

  @override
  String get shortcutDayView => '日檢視';

  @override
  String get shortcutWeekView => '週檢視';

  @override
  String get shortcutMonthView => '月檢視';

  @override
  String get shortcutYearView => '年檢視';

  @override
  String get shortcutAgendaView => '行程檢視';

  @override
  String get shortcutGroupCreateAndEdit => '新增和編輯';

  @override
  String get shortcutSaveItem => '儲存活動或待辦事項';

  @override
  String get shortcutDeleteItem => '刪除活動或待辦事項';

  @override
  String get shortcutGroupTaskEditing => '待辦事項編輯';

  @override
  String get shortcutCancelEditing => '取消編輯';

  @override
  String get shortcutCancelEditingDescription => '關閉待辦事項編輯或詳細資料';

  @override
  String get aboutBusyMax => '關於 BusyMax';

  @override
  String get aboutBusyMaxDescription => '行事曆與待辦事項';

  @override
  String get license => '授權';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => '網站';

  @override
  String get sourceCode => '原始碼';

  @override
  String get reportAnIssue => '回報問題';

  @override
  String get sendFeedback => '傳送意見';

  @override
  String get feedbackSubmit => '提交';

  @override
  String get feedbackCategory => '類別';

  @override
  String get feedbackSelectCategory => '選擇類別';

  @override
  String get feedbackCategoryProblem => '問題或錯誤';

  @override
  String get feedbackCategoryFeature => '功能請求';

  @override
  String get feedbackCategoryPrivacySecurity => '隱私權或安全性疑慮';

  @override
  String get feedbackCategoryUsability => '易用性疑慮';

  @override
  String get feedbackCategoryOther => '其他';

  @override
  String get feedbackSubject => '主旨';

  @override
  String get feedbackDetailedMessage => '詳細訊息';

  @override
  String get feedbackReplyEmail => '回覆用電子郵件地址（選填）';

  @override
  String get feedbackIncludeTechnicalDetails => '包含技術詳細資料';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      '只會加入您的作業系統名稱與版本和應用程式語系。不會包含記錄、帳戶資料、檔案名稱或其他診斷資訊。';

  @override
  String get feedbackCategoryRequired => '請選擇類別。';

  @override
  String get feedbackSubjectLengthError => '主旨必須介於 3 到 120 個字元之間。';

  @override
  String get feedbackMessageLengthError => '訊息必須介於 10 到 5,000 個字元之間。';

  @override
  String get feedbackInvalidEmail => '請輸入有效的電子郵件地址。';

  @override
  String get feedbackConnectionError => '無法連線至 BusyStack。請檢查連線，然後再試一次。';

  @override
  String get feedbackTimeoutError => '要求逾時。您的意見尚未清除，請再試一次。';

  @override
  String get feedbackRateLimitedError => '此網路已傳送太多意見。請稍候再試。';

  @override
  String get feedbackRejectedError => '伺服器拒絕了提交內容。請檢查各欄位，然後再試一次。';

  @override
  String get feedbackServerError => 'BusyStack 目前無法接收您的意見。您的意見尚未清除，請再試一次。';

  @override
  String feedbackSuccess(String id) {
    return '意見已傳送。參考編號：$id';
  }

  @override
  String get toggleSidebar => '顯示或隱藏側邊欄';

  @override
  String get showSidebar => '顯示側邊欄面板';

  @override
  String get hideSidebar => '隱藏側邊欄面板';

  @override
  String get accounts => '帳戶';

  @override
  String get currentAccount => '目前帳戶';

  @override
  String get switchAccount => '切換帳戶';

  @override
  String get addGoogleAccount => '新增 Google 帳戶';

  @override
  String get addMicrosoftAccount => '新增 Microsoft 帳戶';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => '已登入';

  @override
  String get removeAccount => '移除帳戶…';

  @override
  String get removingAccount => '正在移除帳戶…';

  @override
  String get removeAccountDescription => '停止同步並從此裝置移除此帳戶的資料。';

  @override
  String removeAccountTitle(String account) {
    return '從 BusyMax 中移除 $account？';
  }

  @override
  String get removeAccountConfirmation =>
      '這會從此設備刪除緩存的任務、日曆、活動、提醒和待處理的離線更改。未同步的更改將會丟失。提供商中的日曆、活動、任務列表和任務副本不會被刪除。';

  @override
  String get revokeGoogleAccess => '同時撤銷 BusyMax 對此 Google 帳戶的存取權';

  @override
  String get revokeGoogleAccessDescription => '重新連結前，您必須再次授予存取權。';

  @override
  String get removeAccountAction => '移除帳戶';

  @override
  String get removeAccountFailed => '無法完成帳戶移除。請再試一次。';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      '該帳戶已從此裝置移除，但無法撤銷 BusyMax 對您的 Google 帳戶的存取權。您可以在 Google 帳戶中手動撤銷該權限。';

  @override
  String get newTaskList => '新任務列表';

  @override
  String taskListCreateFailed(String error) {
    return '無法創建任務列表：$error';
  }

  @override
  String taskListRenameFailed(String error) {
    return '無法重命名任務列表：$error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return '無法刪除任務列表：$error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      '刪除或移除此清單前，請同步帳戶，或在「診斷」中解決此工作清單遭封鎖的變更。';

  @override
  String get signInToViewTaskLists => '登入以查看待辦清單。';

  @override
  String get noTaskListsSynced => '尚未同步任何待辦清單。';

  @override
  String get listActions => '清單動作';

  @override
  String get rename => '重新命名';

  @override
  String get delete => '刪除';

  @override
  String get renameList => '重新命名清單';

  @override
  String get deleteList => '刪除清單';

  @override
  String get unshare => '取消共享';

  @override
  String get readOnlyTaskListCannotRename => '此任務列表為只讀，無法重命名。';

  @override
  String get taskListCannotDelete => '使用當前權限無法刪除此任務列表。';

  @override
  String get builtInMicrosoftList => '內建';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      '無法重新命名或刪除 Microsoft To Do 內建清單。';

  @override
  String deleteListConfirmation(String title) {
    return '要從 Google Tasks 中刪除“$title”嗎？';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '要刪除“$title”及其所有任務嗎？';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return '要取消此賬戶對“$title”的共享嗎？';
  }

  @override
  String get deleteEvent => '刪除活動';

  @override
  String get title => '標題';

  @override
  String get create => '新增';

  @override
  String get newTask => '新增待辦事項';

  @override
  String get clearCompleted => '清除已完成項目';

  @override
  String get refreshList => '重新整理清單';

  @override
  String get refreshAll => '全部重新整理';

  @override
  String get listRefreshed => '清單已重新整理。';

  @override
  String get allTasksRefreshed => '所有帳戶都已重新整理。';

  @override
  String exportedFile(String path) {
    return '已匯出至 $path';
  }

  @override
  String exportFailed(String error) {
    return '匯出失敗：$error';
  }

  @override
  String refreshFailed(String error) {
    return '重新整理失敗：$error';
  }

  @override
  String get selectOrCreateTaskList => '請選擇或建立待辦清單以開始使用。';

  @override
  String get signInToViewTasks => '登入以查看待辦事項。';

  @override
  String get noTasks => '沒有待辦事項。';

  @override
  String get noTasksYet => '還沒有待辦事項';

  @override
  String get noTasksYetMessage => '建立待辦事項或重新整理帳戶以開始使用。';

  @override
  String get noTasksInList => '此清單中沒有待辦事項。';

  @override
  String get overdue => '已逾期';

  @override
  String get today => '今天';

  @override
  String get tomorrow => '明天';

  @override
  String get upcoming => '即將到期';

  @override
  String get noDate => '無日期';

  @override
  String get completed => '已完成';

  @override
  String duePrefix(String date) {
    return '$date 到期';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => '待辦事項詳細資料';

  @override
  String get editTask => '編輯待辦事項';

  @override
  String get noTaskSelected => '未選取待辦事項。';

  @override
  String get noTaskSelectedHelper => '選擇待辦事項以查看和編輯詳細資料。';

  @override
  String get taskUnavailable => '無法使用待辦事項。';

  @override
  String get signInToEditTasks => '登入以編輯待辦事項。';

  @override
  String get refreshTask => '重新整理待辦事項';

  @override
  String get primarySection => '主要資訊';

  @override
  String get statusSection => '狀態';

  @override
  String get openStatus => '未完成';

  @override
  String get doneStatus => '已完成';

  @override
  String get taskStatus => '狀態';

  @override
  String get taskStatusNone => '無狀態';

  @override
  String get taskStatusNeedsAction => '需要動作';

  @override
  String get taskStatusInProcess => '進行中';

  @override
  String get taskStatusCompleted => '已完成';

  @override
  String get taskStatusCancelled => '已取消';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '已完成 $percentString%';
  }

  @override
  String get completionDate => '完成日期';

  @override
  String get priority => '優先順序';

  @override
  String get priorityNone => '無優先順序';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先級 $priorityString · 高';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先級 $priorityString · 中';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return '優先級 $priorityString · 低';
  }

  @override
  String get taskUrl => '任務 URL';

  @override
  String get invalidTaskUrl => '請輸入包含方案的絕對 URL。';

  @override
  String get classification => '分類';

  @override
  String get classificationPublic => '共享時顯示完整任務';

  @override
  String get classificationConfidential => '共享時僅顯示忙碌狀態';

  @override
  String get classificationPrivate => '共享時隱藏此任務';

  @override
  String get pinTask => '固定任務';

  @override
  String get notes => '備註';

  @override
  String get dueDate => '到期日';

  @override
  String get clearDueDate => '清除到期日';

  @override
  String get dueTime => '到期時間';

  @override
  String get startDate => '開始日期';

  @override
  String get startTime => '開始時間';

  @override
  String get endDate => '結束日期';

  @override
  String get endTime => '結束時間';

  @override
  String get reminderDate => '提醒日期';

  @override
  String get reminderTime => '提醒時間';

  @override
  String get reminder => '提醒';

  @override
  String get addReminder => '添加提醒';

  @override
  String get reminders => '提醒';

  @override
  String get noReminders => '無提醒';

  @override
  String get editReminder => '編輯提醒';

  @override
  String get beforeTaskStarts => '待辦事項開始前';

  @override
  String get beforeTaskDue => '待辦事項到期前';

  @override
  String get afterTaskStarts => '任務開始後';

  @override
  String get afterTaskDue => '任務到期後';

  @override
  String get relativeToTaskStart => '相對於任務開始日期';

  @override
  String get relativeToTaskDue => '相對於任務到期日期';

  @override
  String get reminderTimeOfDay => '時間';

  @override
  String get absoluteReminder => '在指定日期和時間';

  @override
  String get reminderAmount => '數量';

  @override
  String get reminderUnit => '單位';

  @override
  String get reminderUnitSeconds => '秒';

  @override
  String get reminderUnitMinutes => '分鐘';

  @override
  String get reminderUnitHours => '小時';

  @override
  String get reminderUnitDays => '天';

  @override
  String get reminderUnitWeeks => '週';

  @override
  String get reminderAtTaskStart => '任務開始時';

  @override
  String get reminderAtTaskDue => '任務到期時';

  @override
  String get unsupportedReminder => '此提醒類型會保留，但無法編輯其時間。';

  @override
  String get relatedRemindersTitle => '保留相關提醒？';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '此日期有 $countString 個相關提醒。要保留它們當前的日期和時間嗎？';
  }

  @override
  String get discardRelatedReminders => '捨棄提醒';

  @override
  String get keepRelatedReminders => '保留提醒';

  @override
  String get addGuest => '新增參與者';

  @override
  String get addGuestEmail => '新增參與者電子郵件';

  @override
  String get removeReminder => '移除提醒';

  @override
  String get off => '關閉';

  @override
  String get repeat => '重複';

  @override
  String get repeatNone => '不重複';

  @override
  String get noneValue => '無';

  @override
  String get repeatDaily => '每天';

  @override
  String get repeatWeekly => '每週';

  @override
  String get repeatMonthly => '每月';

  @override
  String get repeatYearly => '每年';

  @override
  String get repeatEvery => '重複間隔';

  @override
  String get repeatOn => '重複日期';

  @override
  String get repeatEnd => '結束重複';

  @override
  String get repeatNever => '永不';

  @override
  String get repeatUntil => '指定日期';

  @override
  String get repeatAfter => '指定次數後';

  @override
  String get repeatCount => '重複次數';

  @override
  String get repeatDayOfMonth => '每月日期';

  @override
  String get repeatMonths => '月份';

  @override
  String get repeatOrdinal => '星期位置';

  @override
  String get repeatSpecificDays => '特定日期';

  @override
  String get repeatFirst => '第一';

  @override
  String get repeatSecond => '第二';

  @override
  String get repeatThird => '第三';

  @override
  String get repeatFourth => '第四';

  @override
  String get repeatFifth => '第五';

  @override
  String get repeatSecondToLast => '倒數第二';

  @override
  String get repeatLast => '最後';

  @override
  String get repeatAnyDay => '日期';

  @override
  String get repeatWeekday => '工作日';

  @override
  String get repeatWeekendDay => '週末';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': '星期一',
      'TU': '星期二',
      'WE': '星期三',
      'TH': '星期四',
      'FR': '星期五',
      'SA': '星期六',
      'SU': '星期日',
      'day': '日期',
      'weekday': '工作日',
      'weekend': '週末',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 天';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 週';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 個月';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '每 $countString 年';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '在 $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一個$days',
      'second': '第二個$days',
      'third': '第三個$days',
      'fourth': '第四個$days',
      'fifth': '第五個$days',
      'secondToLast': '倒數第二個$days',
      'last': '最後一個$days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '在 $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '重複 $countString 次',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return '直到 $date';
  }

  @override
  String get unsupportedRecurrencePreserved => '此重複規則使用了編輯器不會更改的選項。';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      '此清單不支援此重複模式。請變更模式或選擇其他清單。';

  @override
  String get taskRecurrenceRequiresDate => '請新增開始日期或截止日期以使用此重複模式，或關閉重複。';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return '此重複規則無法用於 $provider。';
  }

  @override
  String get importance => '重要性';

  @override
  String get importanceLow => '低';

  @override
  String get importanceNormal => '一般';

  @override
  String get importanceHigh => '高';

  @override
  String get categories => '類別';

  @override
  String get scheduleSection => '行程';

  @override
  String get dueGroup => '到期';

  @override
  String get startGroup => '開始';

  @override
  String get reminderGroup => '提醒';

  @override
  String get organizationSection => '整理';

  @override
  String get actionsSection => '動作';

  @override
  String get advancedSection => '進階';

  @override
  String get addCategory => '新增類別';

  @override
  String get list => '清單';

  @override
  String get microsoftMoveUnsupported =>
      '此版本不支援在 Microsoft To Do 帳戶的清單之間移動待辦事項。';

  @override
  String get createSubtask => '建立子待辦事項';

  @override
  String get subtasks => '子待辦事項';

  @override
  String get duplicateTask => '複製待辦事項';

  @override
  String get taskDuplicated => '任務已複製。';

  @override
  String taskDuplicateFailed(String error) {
    return '無法複製任務：$error';
  }

  @override
  String get hideSubtasks => '隱藏子工作項目';

  @override
  String get hideClosedSubtasks => '隱藏已關閉的子工作項目';

  @override
  String get moveToTop => '移至頂端';

  @override
  String get deleteTask => '刪除待辦事項';

  @override
  String get newSubtask => '新增子待辦事項';

  @override
  String deleteTaskConfirmation(String title) {
    return '要刪除「$title」嗎？';
  }

  @override
  String get deleteAssignedTaskWarning => '這也會刪除 Google 文件或 Chat 聊天室中的原始工作。';

  @override
  String get metadata => '中繼資料';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => '更新時間';

  @override
  String get parent => '上層待辦事項';

  @override
  String get position => '位置';

  @override
  String get webLink => '網頁連結';

  @override
  String get assignment => '指派';

  @override
  String get localState => '本機狀態';

  @override
  String get pendingSync => '等候同步';

  @override
  String get synced => '已同步';

  @override
  String get account => '帳戶';

  @override
  String get sync => '同步';

  @override
  String get forceFullResync => '強制完整重新同步';

  @override
  String get forceFullResyncDescription =>
      '從每個已連結的帳號完整重新載入所有資料。僅在疑難排解同步問題時使用此功能。';

  @override
  String get runInBackgroundWhenClosed => '視窗關閉後繼續在背景執行';

  @override
  String get showTrayIcon => '顯示系統匣圖示';

  @override
  String get startMinimizedToTray => '啟動時最小化至系統匣';

  @override
  String get launchAtLogin => '登入時啟動';

  @override
  String get launchAtLoginDescription => '在背景啟動 BusyMax，讓提醒在登入後正常運作。';

  @override
  String get launchAtLoginFailed => '無法更新登入時啟動設定。';

  @override
  String get requiresTrayIcon => '需要系統匣圖示。';

  @override
  String get syncComplete => '同步完成。';

  @override
  String syncFailed(String error) {
    return '同步失敗：$error';
  }

  @override
  String get notifySyncFailures => '同步失敗通知';

  @override
  String get notifyConflicts => '衝突通知';

  @override
  String get notifyDueToday => '今天到期待辦事項通知';

  @override
  String get eventReminders => '活動提醒';

  @override
  String get onState => '開啟';

  @override
  String get taskReminders => '待辦事項提醒';

  @override
  String get notificationDetailLevel => '通知詳細程度';

  @override
  String get notificationDetailPrivate => '私人';

  @override
  String get notificationDetailNormal => '一般';

  @override
  String get quietHours => '勿擾時段';

  @override
  String get quietHoursDescription => '在此時段暫停通知。';

  @override
  String get quietHoursStart => '勿擾開始時間';

  @override
  String get quietHoursEnd => '勿擾結束時間';

  @override
  String get notifications => '通知';

  @override
  String get windowsNotificationsUnavailable => 'Windows 通知無法使用';

  @override
  String get windowsNotificationsUnpackaged =>
      '此未封裝的開發版本無法使用 Windows 通知。請安裝測試簽署的 MSIX 以測試提醒。';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax 無法初始化 Windows 通知。在解決此安裝問題之前，提醒不會顯示。';

  @override
  String get appearance => '外觀';

  @override
  String get theme => '主題';

  @override
  String get themeSystem => '系統';

  @override
  String get settingsSystem => '系統';

  @override
  String get themeLight => '淺色';

  @override
  String get themeDark => '深色';

  @override
  String get themeFamily => '主題系列';

  @override
  String get themeFamilyYaru => 'Ubuntu 原生主題（Yaru）';

  @override
  String get localization => '語言與地區';

  @override
  String get currentLocale => '目前語系';

  @override
  String get privacy => '隱私權';

  @override
  String get redactTaskContentInDiagnostics => '在診斷資訊中隱藏待辦事項內容';

  @override
  String get developerDiagnostics => '開發人員診斷';

  @override
  String get diagnostics => '診斷';

  @override
  String get apiInspectorDisabled => '顯示 API 檢查器';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery 修訂版本：$revision';
  }

  @override
  String get implementedMethods => '已實作的方法';

  @override
  String get supportsTasksScopes => '支援 tasks 和 tasks.readonly 權限範圍';

  @override
  String get requiresTasksScope => '需要 tasks 權限範圍';

  @override
  String get blockedPendingOperations => '遭封鎖的待處理作業';

  @override
  String get signInToInspectPendingOperations => '登入以檢查待處理作業。';

  @override
  String get noBlockedPendingOperations => '沒有遭封鎖的待處理作業。';

  @override
  String get operationActions => '操作選項';

  @override
  String pendingOpListId(String id) {
    return '清單=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return '待辦事項=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '嘗試次數=$countString';
  }

  @override
  String get retry => '再試一次';

  @override
  String get discard => '捨棄';

  @override
  String get discardChangesAction => '捨棄';

  @override
  String get discardChanges => '要捨棄變更嗎？';

  @override
  String get discardChangesConfirmation => '這會捨棄此待辦事項中尚未儲存的編輯內容。';

  @override
  String get retryCompleted => '重試完成。';

  @override
  String get discardPendingOperation => '要捨棄待處理作業嗎？';

  @override
  String get discardPendingOperationConfirmation =>
      '這會移除遭封鎖的本機作業。下次同步時將從 Google Tasks 重新整理資料。';

  @override
  String get pendingOperationDiscarded => '已捨棄待處理作業。';

  @override
  String get syncFailureNotificationTitle => 'BusyMax 同步失敗';

  @override
  String syncFailureNotificationBody(String message) {
    return '背景同步失敗。$message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax 同步衝突';

  @override
  String conflictNotificationBody(String summary) {
    return '一項擱置中的本機變更已被封鎖。$summary';
  }

  @override
  String get dueTodayNotificationTitle => '今天到期的待辦事項';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '今天有 $countString 項待辦事項到期。',
      one: '今天有 1 項待辦事項到期。',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => '活動提醒';

  @override
  String get taskReminderNotificationTitle => '待辦事項提醒';

  @override
  String get eventReminderNotificationBody => '活動即將開始。';

  @override
  String get taskReminderNotificationBody => '待辦事項即將到期。';

  @override
  String get notificationOpenAction => '開啟';

  @override
  String get notificationSnoozeAction => '10 分鐘後提醒';

  @override
  String get notificationDismissAction => '關閉';

  @override
  String get notificationDetailsHidden => '根據隱私權設定，詳細資料已隱藏。';

  @override
  String get previousMonth => '上個月';

  @override
  String get nextMonth => '下個月';

  @override
  String get openMonthView => '開啟月檢視';

  @override
  String get previousYear => '上一年';

  @override
  String get nextYear => '下一年';

  @override
  String get openYearView => '開啟年檢視';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return '第 $numberString 週';
  }

  @override
  String get resizeAllDayPanel => '調整全天面板大小';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString 項',
      one: '1 項',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => '此行事曆為唯讀。';

  @override
  String get selectTimeZone => '選擇時區';

  @override
  String get searchLocations => '搜索地點';

  @override
  String get noLocationsFound => '未找到地點';

  @override
  String get requiredField => '此字段為必填項。';

  @override
  String get providerConnectionDescription => '連接以下任一提供商中的日曆和任務。';

  @override
  String get appleICloudProvider => 'Apple iCloud 行事曆';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud 待辦事項';

  @override
  String get addAppleICloudAccount => '新增 Apple iCloud 行事曆帳戶';

  @override
  String get addNextcloudAccount => '新增 Nextcloud 帳戶';

  @override
  String get waitingForAppleICloud => '正在連接 Apple iCloud…';

  @override
  String get waitingForNextcloud => '正在等待 Nextcloud 授權…';

  @override
  String get connectAppleICloudTitle => '連接 Apple iCloud 行事曆';

  @override
  String get appleAccountEmail => 'Apple 賬戶電子郵件';

  @override
  String get appleAppSpecificPassword => 'App 專用密碼';

  @override
  String get appleAppSpecificPasswordHelp => '為 Apple 賬戶啓用雙重認證後，創建 App 專用密碼。';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      '重置 Apple 賬戶密碼會撤銷 App 專用密碼。';

  @override
  String get connectNextcloudTitle => '連接 Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloud 伺服器或 CalDAV 位址';

  @override
  String get nextcloudServerUrlHelp =>
      '輸入 Nextcloud 服務器 URL，或粘貼從 Nextcloud 複製的主要 CalDAV 地址。';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax 將打開瀏覽器。請在那裡批准訪問，然後返回 BusyMax。';

  @override
  String get connectAccountAction => '連接';

  @override
  String get cancelAccountConnection => '取消連接';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      '賬戶已在本地移除，但無法撤銷 Nextcloud App 密碼。';

  @override
  String get davReauthenticationRequired => '重新連接此賬戶以恢復同步。';

  @override
  String get davTemporarilyUnavailable => '此賬戶暫時不可用。';

  @override
  String get davPermissionChanged => '服務器權限已更改。待處理的編輯已暫停。';

  @override
  String get davUnsupportedServer => '不支持此服務器或提供商配置。';

  @override
  String get collectionSettings => '行事曆和待辦清單';

  @override
  String get calendarContent => '行事曆活動';

  @override
  String get taskContent => '待辦事項';

  @override
  String get readOnlySharedCollection => '唯讀';

  @override
  String get pendingLocally => '本機擱置中';

  @override
  String get conflictBlocked => '因衝突而封鎖';

  @override
  String get authenticationBlocked => '重新連接前阻止';

  @override
  String get operationFailed => '操作失敗';

  @override
  String get keepServerVersion => '保留伺服器版本';

  @override
  String get reapplyLocalChange => '查看並重新應用本地更改';

  @override
  String get duplicateLocalItem => '複製為新項目';

  @override
  String get davConnectionState => '連線狀態';

  @override
  String get davConnected => '已連線';

  @override
  String get davConnecting => '正在連線…';

  @override
  String get davSignedOut => '已登出';

  @override
  String davLastSuccessfulSync(String time) {
    return '上次成功同步：$time';
  }

  @override
  String get davNeverSynced => '尚未同步';

  @override
  String get refreshCollections => '刷新日曆和任務列表';

  @override
  String nextcloudServerHost(String host) {
    return '服務器：$host';
  }

  @override
  String get collectionSupportsEvents => '活動日曆';

  @override
  String get collectionSupportsTasks => '任務列表';

  @override
  String get collectionSupportsEventsAndTasks => '活動和任務';

  @override
  String get writableCollection => '可寫';

  @override
  String get sharedCollection => '已共享';

  @override
  String collectionLastSynced(String time) {
    return '上次同步：$time';
  }

  @override
  String collectionSyncError(String code) {
    return '同步問題：$code';
  }

  @override
  String get syncConflicts => '同步衝突';

  @override
  String remoteChangedAt(String time) {
    return '服務器更改：$time';
  }

  @override
  String localPendingEdit(String summary) {
    return '本地編輯：$summary';
  }

  @override
  String get conflictResolutionFailed => '無法解決衝突。';

  @override
  String get recurringEventScope => '重複活動範圍';

  @override
  String get entireSeries => '整個系列';

  @override
  String get singleOccurrence => '此事件';

  @override
  String get thisAndFollowingEvents => '此事件及後續事件';

  @override
  String get thisAndFutureUnavailable => '此提供者不支援。';

  @override
  String get thisAndFutureMoveUnavailable => '無法安全移動此活動及後續活動。請選擇此活動或整個系列。';

  @override
  String get entireSeriesMoveUnavailable => '本機沒有可用的重複規則。請只移動此活動。';

  @override
  String get copyEventAndDeleteOriginal => '複製活動並刪除原活動？';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax 無法將此活動直接從 $source 移動到 $destination。應用程式會先建立副本，並且只在複製成功後刪除原活動。活動 ID 將會變更；參與者的回覆狀態可能會重設，並可能傳送邀請或取消通知；會議連結、附件、提醒、提供者特有的欄位和重複例外可能無法保留。';
  }

  @override
  String get copyAndDelete => '複製並刪除';

  @override
  String get chooseRecurringEventScope => '選擇此變更適用於整個系列、僅此活動，還是此活動及後續活動。';

  @override
  String get taskDueBeforeStart => '到期時間不得早於開始時間。';

  @override
  String get taskStartDueTimeModeMismatch => '請同時設定開始與到期時間，或將待辦事項設為全天。';

  @override
  String deleteCalendarConfirmation(String title) {
    return '要刪除「$title」嗎？';
  }

  @override
  String get setCustomCalendarName => '設定自訂名稱';

  @override
  String get setAction => '設定';

  @override
  String get removeFromMyCalendars => '從「我的日曆」移除';

  @override
  String get removeAction => '移除';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '要從 BusyMax 移除「$title」嗎？擁有者的日曆及活動不會被刪除。';
  }

  @override
  String get attachmentUploadUnresolved => '上傳可能已完成。再次上傳前，請重新整理附件以確認結果。';

  @override
  String removeCalendarConfirmation(String title) {
    return '要從您的 Google 日曆清單移除「$title」嗎？共用日曆及其活動不會被刪除。';
  }

  @override
  String get calendarCannotRemove => '無法從此賬戶刪除或移除此日曆。';

  @override
  String get calendarPendingChangesPreventRemoval =>
      '請等待此日曆的待處理更改完成同步，然後再刪除或移除它。';

  @override
  String get calendarSubscriptions => '行事曆訂閱';

  @override
  String get calendarSubscriptionsDescription => '添加從安全 WebCal URL 刷新的只讀日曆。';

  @override
  String get addCalendarSubscription => '新增行事曆訂閱';

  @override
  String get subscriptionName => '本機名稱';

  @override
  String get subscriptionUrl => '訂閱 URL';

  @override
  String get subscriptionUrlHelp =>
      '輸入 HTTPS 或 webcal URL。BusyMax 會將完整 URL 保存在安全存儲中。';

  @override
  String get subscriptionUrlInvalid => '請輸入不含用戶信息或片段的有效 HTTPS 或 webcal URL。';

  @override
  String get subscriptionColor => '本地顏色';

  @override
  String get subscriptionColorHelp => '使用六位顏色，例如 #3584E4。';

  @override
  String get subscriptionColorInvalid => '請輸入六位十六進制顏色。';

  @override
  String get subscriptionRefreshMode => '刷新頻率';

  @override
  String get subscriptionAutomatic => '自動';

  @override
  String get subscriptionHourly => '每小時';

  @override
  String get subscriptionSixHours => '每六小時';

  @override
  String get subscriptionDaily => '每天';

  @override
  String subscriptionSafeOrigin(String origin) {
    return '來源：$origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable => '請輸入有效 URL 以預覽其安全來源。';

  @override
  String get subscriptionReadOnly => '只讀訂閱';

  @override
  String get subscriptionNeverRefreshed => '尚未刷新';

  @override
  String subscriptionLastRefresh(String time) {
    return '上次成功刷新：$time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return '下次刷新：$time';
  }

  @override
  String get subscriptionStatusHealthy => '已是最新';

  @override
  String subscriptionStatusIssue(String code) {
    return '刷新問題：$code';
  }

  @override
  String get refreshNow => '立即重新整理';

  @override
  String get unsubscribe => '取消訂閱';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '要取消訂閱“$name”嗎？';
  }

  @override
  String get unsubscribeCalendarConfirmation => '這會移除本地訂閱及其緩存的活動。已發佈的日曆不會更改。';

  @override
  String get addSubscriptionAction => '添加訂閱';

  @override
  String subscriptionOperationFailed(String error) {
    return '日曆訂閱失敗：$error';
  }

  @override
  String get subscriptions => '訂閱';

  @override
  String get calendarImport => '匯入行事曆';

  @override
  String get calendarImportDescription => '選擇文件，查看其中的活動，然後選擇接收這些活動的可寫日曆。';

  @override
  String get importIcsFile => '匯入 .ics 檔案';

  @override
  String get importIcsPreview => '匯入行事曆活動';

  @override
  String importEventsFound(int count) {
    return '可導入活動集：$count';
  }

  @override
  String importInvalidEvents(int count) {
    return '無效活動：$count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return '有意省略：$fields';
  }

  @override
  String get noWritableCalendars => '沒有可用的可寫目標日曆。';

  @override
  String get importDestinationCalendar => '目標日曆';

  @override
  String get importIcsConfirm => '導入活動';

  @override
  String get importIcsComplete => '匯入完成';

  @override
  String importQueued(int count) {
    return '已導入或已排隊：$count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return '已跳過重複項：$count';
  }

  @override
  String importUnsupportedSets(int count) {
    return '不支持的重複集：$count';
  }

  @override
  String importIcsFailed(String error) {
    return '無法導入日曆文件：$error';
  }

  @override
  String get networkOffline => '離線';

  @override
  String get networkOfflineDescription => '連線恢復後將同步變更。';

  @override
  String get networkOfflineTryAgain => '您目前處於離線狀態。請連接網際網路後再試一次。';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days';
  }

  @override
  String get repeatSummarySeparator => '';

  @override
  String repeatMonthDayValue(String day) {
    return '$day日';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first、$second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first和$second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first、$rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency$month$day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency$month的$days';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency$months的$day';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency$months的$days';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一個$days',
      'second': '第二個$days',
      'third': '第三個$days',
      'fourth': '第四個$days',
      'fifth': '第五個$days',
      'secondToLast': '倒數第二個$days',
      'last': '最後一個$days',
      'other': '$days',
    });
    return '$frequency$month的$_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': '第一個$days',
      'second': '第二個$days',
      'third': '第三個$days',
      'fourth': '第四個$days',
      'fifth': '第五個$days',
      'secondToLast': '倒數第二個$days',
      'last': '最後一個$days',
      'other': '$days',
    });
    return '$frequency$months的$_temp0';
  }

  @override
  String get searchFilters => '搜尋篩選條件';

  @override
  String get searchType => '類型';

  @override
  String get searchDate => '日期';

  @override
  String get searchAnyDate => '任何日期（已下載資料）';

  @override
  String get eventLink => '活動連結';

  @override
  String get eventLinkOpenFailed => '無法開啟連結。';

  @override
  String get scheduleRangeIncomplete => '部分活動無法確認，正在顯示已下載資料。';

  @override
  String get searchThisWeek => '本週';

  @override
  String get searchCustomRange => '自訂範圍';

  @override
  String get searchTaskStatus => '工作狀態';

  @override
  String get searchTaskDue => '工作到期狀態';

  @override
  String get searchAnyDueState => '任何到期狀態';

  @override
  String get searchNoDueDate => '無截止日期';

  @override
  String get searchPerson => '人員';

  @override
  String get searchSources => '來源';

  @override
  String get searchClearFilters => '重設篩選條件';

  @override
  String get searchFiltersAction => '篩選';

  @override
  String get searchNoSources => '未選取搜尋來源';

  @override
  String get searchClearText => '清除文字';

  @override
  String get openSharedCalendar => '開啟共用行事曆';

  @override
  String get manageCalendarSharing => '管理行事曆共用';

  @override
  String get shareRecipientEmail => '收件者電子郵件';

  @override
  String get shareRole => '存取角色';

  @override
  String get addCalendarShare => '新增存取權';

  @override
  String get sharingRefreshFailed => '共用設定已變更，但無法重新整理權限清單。再次變更前請重新載入清單。';

  @override
  String get sharingRateLimited => '共用暫時受到限制。請在等待時間結束後重試。';

  @override
  String get attachmentUploadRateLimited => '附件上傳暫時受到限制。請在等待時間結束後重試。';

  @override
  String get sharingPermissionUnavailable => '此行事曆的共用權限無法使用。';

  @override
  String get calendarShareFreeBusy => '僅顯示忙閒';

  @override
  String get calendarShareLimitedRead => '讀取有限詳情';

  @override
  String get calendarShareRead => '讀取全部詳情';

  @override
  String get calendarShareWrite => '編輯行事曆事件';

  @override
  String get calendarShareWriteWithoutPrivate => '編輯但不顯示私人詳情';

  @override
  String get calendarShareOwner => '擁有者';

  @override
  String get eventLabel => '事件標籤';

  @override
  String get loadOutlookCategories => '載入 Outlook 類別';

  @override
  String get outlookCategoriesUnavailable => 'Outlook 類別無法使用；現有指派會保留。';

  @override
  String get googleEventType => '事件類型';

  @override
  String get googleRegularEvent => '一般事件';

  @override
  String get googleFocusTime => '專注時間';

  @override
  String get googleOutOfOffice => '不在辦公室';

  @override
  String get googleWorkingLocation => '工作地點';

  @override
  String get googleDeclineInvitations => '拒絕重疊邀請';

  @override
  String get googleDeclineNone => '不要拒絕';

  @override
  String get googleDeclineNew => '拒絕新邀請';

  @override
  String get googleDeclineAll => '拒絕所有衝突邀請';

  @override
  String get googleDeclineMessage => '拒絕訊息';

  @override
  String get googleChatStatus => '聊天狀態';

  @override
  String get googleChatAvailable => '有空';

  @override
  String get googleChatDoNotDisturb => '零打擾';

  @override
  String get googleWorkAtHome => '家中';

  @override
  String get googleWorkAtOffice => '辦公室';

  @override
  String get googleWorkAtCustomLocation => '自訂地點';

  @override
  String get googleWorkLocationLabel => '地點名稱';

  @override
  String get googleStatusPrimaryOnly => 'Google 狀態事件需要您的 Google 主要行事曆。';

  @override
  String unknownEventLabel(String id) {
    return '未知標籤（$id）';
  }

  @override
  String get calendarOwnerEmail => '行事曆擁有者的電子郵件地址';

  @override
  String registrationSetupTitle(String provider) {
    return '設定 $provider';
  }

  @override
  String get registrationSetupGuide => '設定指南';

  @override
  String get registrationGoogleInstructions =>
      '建立自己的 Google Cloud 專案，啟用 Calendar 和 Tasks API，然後匯入桌面 OAuth 用戶端的 JSON。請授權預期的帳戶。';

  @override
  String get registrationMicrosoftInstructions =>
      '在允許應用程式註冊的 Entra 租戶中使用公用應用程式註冊。輸入用戶端 ID 和支援的帳戶類型。無需用戶端密碼。';

  @override
  String get registrationImportGoogle => '選擇桌面 OAuth JSON';

  @override
  String get registrationValidate => '驗證註冊';

  @override
  String get registrationAuthorize => '在瀏覽器中授權';

  @override
  String get registrationClientId => '應用程式／用戶端 ID';

  @override
  String get registrationTenantId => '租戶 ID';

  @override
  String get registrationAudience => '支援的帳戶';

  @override
  String get registrationBothAudience => '個人和組織帳戶';

  @override
  String get registrationOrganizationAudience => '組織帳戶';

  @override
  String get registrationPersonalAudience => '個人帳戶';

  @override
  String get registrationTenantAudience => '單一組織租戶';

  @override
  String registrationSummary(String clientId) {
    return '註冊：$clientId';
  }

  @override
  String get registrationMigrate => '立即移轉';

  @override
  String get registrationReplace => '取代註冊';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return '此帳號使用為現有帳號保留的原始 $provider 註冊。若要取代，請設定 $setup 並重新連接此帳號。現有日曆、工作事項和本機變更將保留。';
  }

  @override
  String get registrationContinue => '繼續使用此帳戶';

  @override
  String get registrationGoogleProject => 'Google Cloud 專案';

  @override
  String get registrationMicrosoftApp => 'Microsoft 應用程式註冊';

  @override
  String get registrationUserOwned => '使用者提供的註冊';

  @override
  String get registrationNativeGoogle => 'Google Android 原生註冊';

  @override
  String get registrationShared => '共用註冊（過渡期）';

  @override
  String get registrationUnresolved => '無法確定註冊來源。帳戶資料已保留。';

  @override
  String get registrationOfficialDocumentation => '官方文件';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return '套件：$packageName\n簽章雜湊：$signatureHash\n重新導向 URI：$redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      '請檢查註冊的用戶端類型、支援的帳戶、權限和重新導向設定。若設定來自匯入，請重新選擇設定檔。';

  @override
  String get oauthAuthorizationCodeUnusable => '此次授權未能完成。請重新開始授權；現有連線已保留。';

  @override
  String get oauthPermissionRefused => '授權遭拒或缺少所需權限。請重試並授予所需權限。';

  @override
  String get oauthProviderThrottled => '服務提供者正在限制請求。請稍後重試；現有連線已保留。';

  @override
  String get oauthProviderTemporaryFailure => '服務提供者的暫時問題導致授權未能完成。請重試；現有連線已保留。';

  @override
  String get oauthAuthorizationTimedOut => '授權逾時。請重試；若設定來自匯入，請重新選擇設定檔。';

  @override
  String get oauthWrongAccount => '請授權為重新連線而選定的帳戶。現有連線已保留。';

  @override
  String get oauthSecureStorageUnavailable => '安全儲存空間無法使用。請恢復存取後重試。';

  @override
  String get oauthRevokedRemovalIncomplete =>
      '遠端授權已撤銷，但帳戶清理未能完成。請重新啟動 BusyMax 以重試本機復原。';

  @override
  String get addAccount => '新增帳戶';

  @override
  String get registrationConnect => '連線';

  @override
  String get registrationBack => '返回';

  @override
  String get registrationReplaceGoogle => '取代桌面 OAuth JSON';

  @override
  String get registrationSelectedConfiguration => '已選取的設定';

  @override
  String get registrationDirectoryId => '目錄／租用戶 ID';

  @override
  String get registrationInvalidId => '請輸入有效的 UUID。';

  @override
  String get registrationExpired => '此設定已過期。請重新匯入或修改註冊欄位後再連線。';

  @override
  String get registrationOwnProjectRequired => '請選取您自己的專案或租用戶中的註冊。';

  @override
  String get registrationSetupFailed => '無法完成設定，請重試。';

  @override
  String get registrationLinkFailed => '無法開啟連結。請檢查瀏覽器後重試。';

  @override
  String get registrationPermissions => '權限';

  @override
  String get registrationDesktopClient => '桌面應用程式';

  @override
  String get registrationOpenGoogleConsole => '開啟 Google Cloud 控制台';

  @override
  String get registrationGoogleAudienceHelp => 'Google 發布及測試使用者要求';

  @override
  String get registrationDesktopHelp => '桌面應用程式註冊說明';

  @override
  String get registrationOpenEntra => '開啟 Microsoft Entra 管理中心';

  @override
  String get registrationGuideGoogleProject =>
      '開啟 Google Cloud Console。使用頂端的專案選擇器選擇您自己的專案，或選擇 New project，輸入名稱後選擇 Create。後續步驟請保持選取此專案。';

  @override
  String get registrationGuideGoogleAudience =>
      '進入 Google Auth Platform → Branding。如果尚未開始設定，選擇 Get started。在 App name 中輸入 BusyMax，選擇您自己的 User support email，然後選擇 Next。在 Audience 中，請選擇 External。選擇 Next，在 Contact Information 中輸入您的電子郵件，再選擇 Next。接受 User Data Policy，然後選擇 Continue 和 Create。如果已完成設定，請檢查 Branding 和 Audience。';

  @override
  String get registrationGuideGooglePermissions =>
      '開啟 Google Auth Platform → Data Access → Add or remove scopes。選擇下列五個權限範圍；必要時使用 Manually add scopes。手動輸入時，貼上缺少的值並選擇 Add to table。選擇 Update，再選擇 Save。BusyMax 需要日曆和工作事項的存取權限。';

  @override
  String get registrationGuideGoogleClient =>
      '開啟 Google Auth Platform → Clients → Create client。將 Application type 設為 Desktop app，在 Name 中輸入 BusyMax 並選擇 Create。在建立對話方塊中選擇 Download JSON 並儲存檔案。選擇返回以回到表單，選取該檔案並檢查專案和用戶端 ID。選擇連接，然後在瀏覽器中核准日曆和工作事項的存取權限。';

  @override
  String get registrationGuideMicrosoftApp =>
      '登入 Microsoft Entra 管理中心。使用 Settings 選擇允許您註冊應用程式的租用戶。開啟 Entra ID → App registrations → New registration。在 Name 中輸入 BusyMax，然後在下一步選擇支援的帳號類型。如果無法註冊，請向租用戶管理員申請權限。';

  @override
  String get registrationGuideMicrosoftRedirect =>
      '在應用程式註冊中開啟 Authentication → Add a platform → Mobile and desktop applications。選擇或輸入下列重新導向 URI，然後選擇 Configure 儲存。BusyMax 使用系統瀏覽器。不需要用戶端密碼。';

  @override
  String get registrationGuideMicrosoftPermissions =>
      '開啟 API permissions → Add a permission → Microsoft Graph → Delegated permissions。搜尋並選擇下列每個權限範圍，然後選擇 Add permissions。如果已有 User.Read，請保留。如果組織要求管理員同意，請讓管理員使用租用戶的 Grant admin consent。';

  @override
  String get registrationGuideMicrosoftConnect =>
      '選擇返回以回到表單。貼上 Application (client) ID，並選擇與註冊一致的支援帳號選項。如果選擇單一組織租用戶，還需貼上 Directory (tenant) ID。選擇連接並在瀏覽器中登入目標帳號。BusyMax 在本機檢查欄位；Microsoft 在瀏覽器登入時要求您的同意。';

  @override
  String get registrationGoogleImportFailed =>
      '無法匯入此檔案。請選取有效的桌面 OAuth JSON。先前的有效選擇會保留。';

  @override
  String get registrationGoogleSetupInstructions => 'Google 設定說明';

  @override
  String get registrationMicrosoftSetupInstructions => 'Microsoft 設定說明';

  @override
  String get registrationDesktopConfiguration => '桌面 OAuth 設定';

  @override
  String get registrationNoFileSelected => '尚未選取檔案';

  @override
  String get registrationChooseFile => '選取檔案…';

  @override
  String get registrationReplaceFile => '取代…';

  @override
  String get registrationGoogleIntroduction =>
      '選取您自己的 Google Cloud 專案的桌面 OAuth JSON。';

  @override
  String get registrationMicrosoftIntroduction => '輸入您自己的 Microsoft 應用程式註冊資訊。';

  @override
  String get registrationSetupInstructions => '設定說明';

  @override
  String get registrationInstructionsDescription => '建立連接帳號所需的設定。';

  @override
  String get registrationEnableApis => '啟用 Calendar 和 Tasks';

  @override
  String get registrationConsentScreen => '設定同意畫面';

  @override
  String get registrationAppName => '應用程式名稱';

  @override
  String get registrationScopes => '權限範圍';

  @override
  String get registrationRedirectUri => '重新導向 URI';

  @override
  String get registrationOpenApiLibrary => '開啟 Google API 程式庫';

  @override
  String get registrationOpenBranding => '開啟 Google Auth Platform 的 Branding';

  @override
  String get registrationOpenDataAccess =>
      '開啟 Google Auth Platform 的 Data Access';

  @override
  String get registrationOpenClients => '開啟 Google Auth Platform 的 Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      '開啟 Entra 應用程式註冊以設定 Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      '開啟 Entra 應用程式註冊以設定 API permissions';

  @override
  String get registrationCopy => '複製';

  @override
  String get registrationCopyAll => '全部複製';

  @override
  String get registrationGuideGoogleApis =>
      '進入 APIs & Services → Library。搜尋 Google Calendar API，開啟其頁面並選擇 Enable。返回 Library，對 Google Tasks API 重複此操作。';

  @override
  String get registrationGuideMicrosoftAudience =>
      '在 Supported account types 中，個人帳號選擇 Personal accounts only，組織帳號選擇 Multiple Entra ID tenants，同時支援兩者選擇 Any Entra ID Tenant + Personal Microsoft accounts，僅限此目錄選擇 Single tenant only。選擇 Register。在 Overview 中複製 Application (client) ID；單一租用戶還需複製 Directory (tenant) ID。在 BusyMax 中選擇對應的支援帳號選項。';

  @override
  String get registrationConnectBusyMax => '透過 BusyMax 連接';

  @override
  String get registrationRecommended => '建議';

  @override
  String get registrationOtherMethods => '其他連接方式';

  @override
  String get registrationWorkspace => 'Google Workspace 組織';

  @override
  String get registrationGoogleCustom => '自訂 OAuth 用戶端';

  @override
  String get registrationMicrosoftCustom => '自訂應用程式註冊';

  @override
  String get registrationMethodsIntroduction => '選擇連接帳號的方式。';

  @override
  String get registrationWorkspaceDescription => '使用組織管理的設定。';

  @override
  String get registrationCustomDescription => '使用自行管理的註冊。';

  @override
  String get registrationSharedUnavailable =>
      '此版本無法透過 BusyMax 連接。您可以使用以下其他連接方式。';

  @override
  String get registrationWorkspaceIntroduction =>
      '選擇組織提供或管理的桌面 OAuth JSON。檔案無法證明組織所有權、對象或驗證狀態。';

  @override
  String get registrationWorkspaceSetupInstructions => 'Google Workspace 設定說明';

  @override
  String get registrationBusyMaxManaged => 'BusyMax 管理的註冊';

  @override
  String get registrationBranding => '設定品牌和網域';

  @override
  String get registrationPublishing => '發佈供日常使用';

  @override
  String get registrationOpenAudience => '開啟 Google Auth Platform Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      '向管理員索取 Desktop OAuth JSON，或開啟 Google Cloud Console 並選取您的 Google Workspace 組織擁有的專案。若要建立專案，開啟「管理資源」→「建立專案」，輸入「專案名稱」，在「上層資源」中選取您的組織或其資料夾，再選取「建立」。後續步驟保持選取該專案。建立需要 Project Creator 權限，設定 OAuth 需要 OAuth Config Editor，啟用 API 需要 Service Usage Admin 或同等權限。若操作受阻，請聯絡管理員。';

  @override
  String get registrationGuideGoogleBranding =>
      '在 Branding → App domain 中，先新增專案的授權網域，再輸入首頁、隱私權政策和服務條款 URL，然後選擇 Save。External 正式應用程式需要這些連結。請使用自己擁有的網域，並在 Google 要求品牌驗證時透過 Search Console 驗證所有權。下方 BusyMax 隱私連結無法證明您的專案擁有 busystack.org。';

  @override
  String get registrationGuideGooglePublishing =>
      '在 Audience 中選擇 Publish app 並確認 In production。日常使用不要停留在 Testing：這些 Calendar/Tasks 授權和更新權杖會在七天後到期。發佈與驗證是兩回事。少於 100 人的個人使用可能免於驗證，但仍有未驗證警告和人數限制；更廣泛散布可能需要品牌和權限範圍核准。正式授權仍可能到期或遭撤銷。';

  @override
  String get registrationGuideWorkspacePermissions =>
      '與管理員檢查以下權限範圍。Internal 應用程式不需要在同意畫面中列出權限範圍。如管理員要求，請開啟 Data Access → Add or remove scopes，新增這些值，然後選擇 Update 和 Save。管理員控制仍可能限制授權。';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      '共用日曆和類別權限會在啟用相應選用功能時個別要求；不要將其加入上述必要設定。';

  @override
  String get registrationGuideWorkspaceAudience =>
      '進入 Google Auth Platform → Branding。如果尚未開始設定，選擇 Get started。在 App name 中輸入 BusyMax，選擇您自己的 User support email，然後選擇 Next。在 Audience 中，請選擇 Internal。選擇 Next，在 Contact Information 中輸入您的電子郵件，再選擇 Next。接受 User Data Policy，然後選擇 Continue 和 Create。如果已完成設定，請檢查 Branding 和 Audience。\n\nInternal 僅允許專案父組織中的帳號，並受管理員控制。不需要測試使用者清單。BusyMax 無法從下載的 JSON 驗證這些主控台設定。';

  @override
  String get contactsTitle => '聯絡人';

  @override
  String get contactsLinkedDescription => '新增活動來賓時使用此帳號快取的聯絡人。';

  @override
  String get contactsEnableSuggestions => '啟用聯絡人建議';

  @override
  String get contactsReadPermissionDescription => '要求聯絡人的唯讀權限';

  @override
  String get contactsEnableEditing => '啟用聯絡人編輯';

  @override
  String get contactsWritePermissionDescription => '要求聯絡人的讀寫權限';

  @override
  String get contactsSuggestionsEnabled => '已啟用聯絡人建議';

  @override
  String get contactsNeedsAttention => '聯絡人需要處理';

  @override
  String get contactsReadWriteAccess => '讀寫權限';

  @override
  String get contactsDisableForAccount => '停用此帳號的聯絡人';

  @override
  String get contactsOnlyDescription => '這些來源獨立於行事曆和工作帳號。';

  @override
  String get contactsAddCardDav => '新增 CardDAV 聯絡人';

  @override
  String get contactsAddNextcloud => '新增 Nextcloud 聯絡人';

  @override
  String get contactsUseForAttendees => '用於參與者建議';

  @override
  String get contactsServerUrlLabel => 'HTTPS 伺服器網址';

  @override
  String get contactsUsernameLabel => '使用者名稱';

  @override
  String get contactsPasswordLabel => '密碼';
}
