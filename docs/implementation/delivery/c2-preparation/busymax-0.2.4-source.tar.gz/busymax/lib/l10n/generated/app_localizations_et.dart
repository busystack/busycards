// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Estonian (`et`).
class AppLocalizationsEt extends AppLocalizations {
  AppLocalizationsEt([String locale = 'et']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax käivitati töölaua automaatkäivituse seadete kaudu. Eemalda sealt selle kirje, seejärel sulge BusyMax täielikult ja ava see lüliti kasutamiseks uuesti.';

  @override
  String get timeFormat => 'Kellaajavorming';

  @override
  String get firstDayOfWeek => 'Nädala esimene päev';

  @override
  String get systemDefault => 'Süsteemi vaikeväärtus';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Süsteemi vaikeväärtus ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12-tunnine';

  @override
  String get timeFormatTwentyFourHour => '24-tunnine';

  @override
  String get timeEndOfDay => 'päeva lõpp';

  @override
  String get timePeriod => 'Päevaosa';

  @override
  String get launchAtLoginReadFailed =>
      'Sisselogimisel käivitamise olekut ei õnnestunud tuvastada.';

  @override
  String get launchAtLoginUnavailable =>
      'Sisselogimisel käivitamine pole selles süsteemis saadaval.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'Administraator on automaatkäivituse lubanud ja seda ei saa siin muuta.';

  @override
  String get settingsSaveFailed =>
      'Seadeid ei õnnestunud salvestada. Muudatused võivad BusyMaxi taaskäivitamisel kaduda.';

  @override
  String get nextcloudExportCollection => 'Ekspordi kogu ressursid';

  @override
  String nextcloudImportItems(int count) {
    return 'Leiti $count sündmuse/ülesande ressurssi';
  }

  @override
  String get nextcloudSchedulingInbox => 'Kutsete postkast';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud töötleb need sõnumid sinu kalendritesse. Kinnitamine eemaldab ainult sõnumi, mitte sündmuse.';

  @override
  String get nextcloudInboxEmpty => 'Ajastussõnumeid pole.';

  @override
  String get nextcloudAcknowledge => 'Kinnita sõnumi kättesaamine';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Kas eemaldada see sõnum postkastist? Kalendrisündmus säilib.';

  @override
  String get nextcloudGuestAvailability => 'Kontrolli külaliste saadavust';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Serveri prügikasti säilitusaeg: $days päeva';
  }

  @override
  String get nextcloudCancelMeeting => 'Tühista koosolek';

  @override
  String get nextcloudDeclineAndRemove => 'Keeldu ja eemalda kutse';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Eemaldamine saadab sünkroonimisel keeldumise. See ei tühista korraldaja koosolekut.';

  @override
  String get nextcloudAvailabilityUnknown => 'Saadavus teadmata';

  @override
  String get nextcloudAvailabilityFree =>
      'Selles ajavahemikus hõivatud aegu ei teatatud';

  @override
  String get nextcloudAvailabilityBusy => 'Hõivatud ajad';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud saadab koosoleku uuendused sünkroonimisel. Kohalik salvestamine ei kinnita kohaletoimetamist.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Koosoleku andmeid saab muuta ainult korraldaja või volitatud esindaja. Kutsele saad vastata selle üksikasjades.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'Koosolekut ei saa teisaldada kopeerimise ja kustutamisega. Kasuta sama ajastusidentiteediga kalendrit.';

  @override
  String get nextcloudSchedulingStatus => 'Serveri ajastusolek';

  @override
  String get nextcloudImportFollowUp =>
      'Imporditud ressursid salvestati kohalikult. Meeldetuletuste uuendamine on ootel; ära impordi uuesti.';

  @override
  String get nextcloudNativeImport =>
      'Impordi täielikud sündmused ja ülesanded kutseid saatmata. Olemasolevad UID-d jäetakse vahele, kui sa ei vali uusi koopiaid. Toetamata ressursid teatatakse eraldi.';

  @override
  String get nextcloudImportMethod =>
      'Fail sisaldab ajastussõnumeid. Import salvestab sisu ja eemaldab METHOD-välja; see ei töötle kutseid ega vastuseid.';

  @override
  String get nextcloudImportCopies =>
      'Impordi uute koopiatena uute identiteetidega';

  @override
  String get nextcloudCollectionSettings => 'Kogu seaded';

  @override
  String get nextcloudSharing => 'Jagamine';

  @override
  String get nextcloudOwned => 'Enda oma';

  @override
  String get nextcloudShared => 'Jagatud';

  @override
  String get nextcloudDelegated => 'Delegeeritud';

  @override
  String get nextcloudSubscription => 'Tellimus';

  @override
  String get nextcloudDeleted => 'Kustutatud';

  @override
  String get nextcloudMetadataEditable =>
      'Kalendri sisu on kirjutuskaitstud; kogu omadusi saab muuta.';

  @override
  String get nextcloudServerOrder =>
      'Serveri järjestus (külgriba järjestusest eraldi)';

  @override
  String get nextcloudCalendarEnabled => 'Serveris lubatud';

  @override
  String get nextcloudAvailability => 'Arvesta kogu saadavuse määramisel';

  @override
  String get nextcloudCalendarTimezone =>
      'Kalendri ajavöönd (VTIMEZONE-dokument)';

  @override
  String get nextcloudRefreshPending =>
      'Muudatus salvestati Nextcloudi. Värskendamine on ootel; ära korda muudatust.';

  @override
  String get nextcloudOutcomeUnknown =>
      'Serveri tulemust ei saanud kinnitada. Värskenda enne uuesti proovimist.';

  @override
  String get nextcloudRemoveShared => 'Eemalda jagatud kalender/loend';

  @override
  String get nextcloudRemoveMixed =>
      'Kogu sisaldab sündmusi ja ülesandeid. Kustutamine eemaldab mõlemad.';

  @override
  String get nextcloudReadAccess => 'Ainult lugemine';

  @override
  String get nextcloudWriteAccess => 'Lugemine ja kirjutamine';

  @override
  String get nextcloudRecipientSearch => 'Otsi inimesi või rühmi';

  @override
  String get nextcloudNoRecipients => 'Sobivaid inimesi ega rühmi pole.';

  @override
  String get nextcloudRevokeShare => 'Tühista juurdepääs';

  @override
  String get nextcloudPublish => 'Avalda link';

  @override
  String get nextcloudUnpublish => 'Lõpeta avaldamine';

  @override
  String get nextcloudPublishWarning =>
      'Avaldatud lingiga inimesed võivad saada kalendrit lugeda. Kas avaldada?';

  @override
  String get nextcloudTrash => 'Kustutatud kalendrid ja ülesanded';

  @override
  String get nextcloudTrashEmpty => 'Kustutatud kalendrikirjeid pole.';

  @override
  String get nextcloudRestore => 'Taasta';

  @override
  String get nextcloudPermanentDelete => 'Kustuta jäädavalt';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Kas kustutada jäädavalt? Seda ei saa Nextcloudi kalendriprügikastist taastada.';

  @override
  String get nextcloudOperationDenied => 'Nextcloud ei lubanud seda toimingut.';

  @override
  String get nextcloudUnsupported => 'Server ei toeta seda toimingut.';

  @override
  String get nextcloudPendingChanges =>
      'Enne sulgemist salvesta või hülga kogu muudatused.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloudiga ei saa ühendust. Vahemälu ja ootel muudatused jäävad alles.';

  @override
  String get mapsShow => 'Näita kaardil';

  @override
  String get openLink => 'Ava link';

  @override
  String get externalLocationOpenFailed =>
      'Asukohta ei saanud välises rakenduses avada.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'Sündmuse aega ei saanud muuta. Salvestatud aeg jäi muutmata.';

  @override
  String get scheduleRescheduleStale =>
      'Sündmus muutus lohistamise ajal. Palun proovi uuesti.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'Uus aeg salvestati, kuid meeldetuletusi ei saanud värskendada.';

  @override
  String get moveUp => 'Liiguta üles';

  @override
  String get moveDown => 'Liiguta alla';

  @override
  String get windowsSupport => 'Tugi';

  @override
  String get windowsThirdPartyLicenses => 'Kolmandate osapoolte litsentsid';

  @override
  String get windowsSearch => 'Otsi';

  @override
  String get windowsStartupDisabledByUser =>
      'Kasutaja keelas selle Windowsi sätetes.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Windowsi poliitika on selle keelanud.';

  @override
  String get windowsStartupUnavailable =>
      'Saadaval pärast BusyMaxi installimist MSIX-paketist.';

  @override
  String get windowsReminderExitNotice =>
      'BusyMaxi täielikul sulgemisel meeldetuletused peatuvad. Nende saamiseks jätke rakendus taustal tööle.';

  @override
  String get windowsProductVersionLabel => 'Toote versioon';

  @override
  String get windowsPackageVersionLabel => 'Windowsi paketi versioon';

  @override
  String get windowsUnpackaged => 'Pakkimata';

  @override
  String get windowsAgendaLoadMore => 'Laadi rohkem päevakava üksusi';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'esmaspäeviti',
      'TU': 'teisipäeviti',
      'WE': 'kolmapäeviti',
      'TH': 'neljapäeviti',
      'FR': 'reedeti',
      'SA': 'laupäeviti',
      'SU': 'pühapäeviti',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return '$first ja $second päeval';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $month $firstDay ja $secondDay päeval';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency $firstMonth ja $secondMonth $day päeval';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency $firstMonth ja $secondMonth $firstDay ja $secondDay päeval';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency $firstMonth ja $secondMonth $days päeval';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Ühendage Google’i, Microsofti, Apple iCloud Calendari või Nextcloudi kontod.';

  @override
  String get googlePermissionsConsentNotice =>
      'Valige Google’i õiguste kuval nii kalendri kui ka ülesannete õigused.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google Calendari ja Google Tasksi õigused on nõutavad. Proovige uuesti ja märkige mõlemad ruudud.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'See teenusepakkuja pole seadistatud.';

  @override
  String get waitingForGoogleSignIn => 'Google’isse sisselogimise ootel...';

  @override
  String get waitingForMicrosoftSignIn => 'Microsofti sisselogimise ootel...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsofti sisselogimine pole seadistatud. Määrake MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Tühista';

  @override
  String get close => 'Sulge';

  @override
  String get windowMinimize => 'Minimeeri';

  @override
  String get windowMaximize => 'Maksimeeri';

  @override
  String get windowRestore => 'Taasta';

  @override
  String get exit => 'Välju';

  @override
  String get options => 'Valikud';

  @override
  String get hide => 'Peida';

  @override
  String get show => 'Kuva';

  @override
  String get export => 'Ekspordi';

  @override
  String get save => 'Salvesta';

  @override
  String get settings => 'Seaded';

  @override
  String get all => 'Kõik';

  @override
  String get calendarEvents => 'Sündmused';

  @override
  String get calendarTasks => 'Ülesanded';

  @override
  String get calendar => 'Kalender';

  @override
  String get calendars => 'Kalendrid';

  @override
  String get newCalendar => 'Uus kalender';

  @override
  String get calendarColor => 'Kalendri värv';

  @override
  String calendarColorOption(int number) {
    return 'Värv $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'See teenusepakkuja ei toeta BusyMaxis kalendrite haldamist.';

  @override
  String get primaryCalendarCannotDelete => 'Põhikalendrit ei saa kustutada.';

  @override
  String calendarCreateFailed(String error) {
    return 'Kalendri loomine nurjus: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'Kalender loodi, kuid BusyMax ei saanud kontot värskendada. See ilmub pärast järgmist sünkroonimist.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Kalendri värskendamine nurjus: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Kalendri kustutamine nurjus: $error';
  }

  @override
  String get newEvent => 'Uus sündmus';

  @override
  String get refreshCalendar => 'Värskenda kalendrit';

  @override
  String get openInProvider => 'Ava teenuses';

  @override
  String get linkedResources => 'Seotud ressursid';

  @override
  String get noLinkedResources => 'Seotud ressursse pole';

  @override
  String get attachments => 'Manused';

  @override
  String get attachmentsNotLoaded => 'Manuseid ei laaditud';

  @override
  String get hideFromSchedule => 'Peida ajakavast';

  @override
  String get showInSchedule => 'Kuva ajakavas';

  @override
  String get noCalendarsSynced => 'Ühtegi kalendrit pole veel sünkroonitud.';

  @override
  String get allDay => 'Kogu päev';

  @override
  String moreItems(int count) {
    return '+$count veel';
  }

  @override
  String get noEventsOrTasks => 'Sündmusi ega ülesandeid pole';

  @override
  String get scheduleLoading => 'Ajakava laadimine...';

  @override
  String get scheduleUnavailable => 'Ajakava pole saadaval';

  @override
  String get scheduleNoSources =>
      'Nähtavaid kalendreid ega ülesandeloendeid pole';

  @override
  String get scheduleNoSourcesDescription =>
      'Valige seadetes, mida kuvada, ja seejärel värskendage.';

  @override
  String get scheduleNoSearchResults =>
      'Sobivaid sündmusi ega ülesandeid ei leitud';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Proovige teistsugust otsingut või eemaldage praegused filtrid.';

  @override
  String get refresh => 'Värskenda';

  @override
  String get trayOpenBusyMax => 'Ava BusyMax';

  @override
  String get trayShowBusyMax => 'Näita BusyMaxi';

  @override
  String get trayNewEvent => 'Uus sündmus…';

  @override
  String get trayNewTask => 'Uus ülesanne…';

  @override
  String get trayToday => 'Täna';

  @override
  String get trayAllDay => 'Kogu päev';

  @override
  String get trayNow => 'Praegu';

  @override
  String get trayCalendarEvent => 'Kalendrisündmus';

  @override
  String get trayUntitledEvent => 'Pealkirjata sündmus';

  @override
  String get trayNothingElseToday => 'Täna pole rohkem midagi';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Täna on tähtajaks $count ülesannet',
      one: 'Täna on tähtajaks 1 ülesanne',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Ava tänane päevakava';

  @override
  String get traySyncNow => 'Sünkrooni kohe';

  @override
  String get traySyncing => 'Sünkroonimine…';

  @override
  String get trayNotConnected => 'Pole ühendatud';

  @override
  String get trayNotYetSynced => 'Veel sünkroonimata';

  @override
  String get trayLastSyncedJustNow => 'Viimati sünkrooniti just nüüd';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Viimati sünkrooniti $count minutit tagasi',
      one: 'Viimati sünkrooniti 1 minut tagasi',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Viimati sünkrooniti $count tundi tagasi',
      one: 'Viimati sünkrooniti 1 tund tagasi',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Viimati sünkrooniti $count päeva tagasi',
      one: 'Viimati sünkrooniti 1 päev tagasi',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Seaded';

  @override
  String get trayQuitBusyMax => 'Välju BusyMaxist';

  @override
  String get agendaLoadMoreOverdue => 'Laadi veel tähtaja ületanud ülesandeid';

  @override
  String get agendaLoadMoreNoDate => 'Laadi veel kuupäevata ülesandeid';

  @override
  String get viewDay => 'Päev';

  @override
  String get viewWeek => 'Nädal';

  @override
  String get viewMonth => 'Kuu';

  @override
  String get viewYear => 'Aasta';

  @override
  String get viewAgenda => 'Päevakava';

  @override
  String get scheduleSettings => 'Ajakava';

  @override
  String get scheduleDisplaySettings => 'Ajakava kuvamine';

  @override
  String get newEventsAndTasks => 'Uued sündmused ja ülesanded';

  @override
  String get defaultCalendar => 'Vaikekalender';

  @override
  String get defaultTaskList => 'Vaikimisi ülesannete loend';

  @override
  String get lastUsed => 'Viimati kasutatud';

  @override
  String get scheduleDisplayHoursDescription =>
      'Päeva- ja nädalavaade avanevad nende kellaaegade piires. Vajaduse korral laiendavad varasemad ja hilisemad kirjed vahemikku.';

  @override
  String get scheduleDayStartsAt => 'Päev algab';

  @override
  String get scheduleDayEndsAt => 'Päev lõpeb';

  @override
  String get sourceCalendar => 'Kalender';

  @override
  String get sourceTaskList => 'Ülesandeloend';

  @override
  String get createChoiceTitle => 'Loo';

  @override
  String get createEventAtTime => 'Sündmus';

  @override
  String get createTaskAtDate => 'Ülesanne';

  @override
  String get editEvent => 'Muuda sündmust';

  @override
  String get eventTitle => 'Sündmuse pealkiri';

  @override
  String get location => 'Asukoht';

  @override
  String get timeSlot => 'Ajavahemik';

  @override
  String get startDateTime => 'Alguskuupäev ja -kellaaeg';

  @override
  String get endDateTime => 'Lõppkuupäev ja -kellaaeg';

  @override
  String get doesNotRepeat => 'Ei kordu';

  @override
  String get defaultReminder => 'Vaikemeeldetuletus';

  @override
  String get guests => 'Külalised';

  @override
  String get noGuests => 'Külalisi pole';

  @override
  String get attendeeRequired => 'Nõutud';

  @override
  String get attendeeOptional => 'Valikuline';

  @override
  String get meetingSection => 'Koosolek';

  @override
  String get addGoogleMeet => 'Lisa Google Meet';

  @override
  String get addTeamsMeeting => 'Lisa Microsoft Teamsi koosolek';

  @override
  String get onlineMeetingAdded => 'Veebikoosolek lisatud';

  @override
  String get requestResponses => 'Küsi vastuseid';

  @override
  String get requestResponsesDescription =>
      'Paluge külalistel kutsele vastata.';

  @override
  String get hideGuestList => 'Peida külaliste loend';

  @override
  String get hideGuestListDescription => 'Külalised ei näe, keda veel kutsuti.';

  @override
  String get allowNewTimeProposals => 'Luba uusi ajapakkumisi';

  @override
  String get allowNewTimeProposalsDescription =>
      'Külalised saavad soovitada muud koosolekuaega.';

  @override
  String get notifyGuestsTitle => 'Kas teavitada külalisi?';

  @override
  String get notifyGuestsSaveMessage =>
      'Sellel koosolekul on külalised. Kas saata salvestamisel kutsed või sündmuse uuendused?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Sellel koosolekul on külalised. Kas saata kustutamisel tühistus?';

  @override
  String get sendUpdates => 'Saada uuendused';

  @override
  String get sendCancellation => 'Saada tühistus';

  @override
  String get doNotSend => 'Ära saada';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Kas salvestada koosolek?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft saadab külalistele kutsed või sündmuse uuendused.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Kas kustutada koosolek?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft saadab külalistele tühistuse.';

  @override
  String get organizer => 'Korraldaja';

  @override
  String get yourResponse => 'Sinu vastus';

  @override
  String get guestResponses => 'Külaliste vastused';

  @override
  String get respond => 'Vasta';

  @override
  String get acceptInvitation => 'Nõustu';

  @override
  String get tentativeInvitation => 'Esialgne';

  @override
  String get declineInvitation => 'Keeldu';

  @override
  String get joinMeeting => 'Liitu koosolekuga';

  @override
  String get responseAccepted => 'Nõustutud';

  @override
  String get responseTentative => 'Esialgne';

  @override
  String get responseDeclined => 'Keeldutud';

  @override
  String get responseNeedsAction => 'Vastust oodatakse';

  @override
  String get responseNotResponded => 'Vastus puudub';

  @override
  String get responseOrganizer => 'Korraldaja';

  @override
  String invitationResponseFailed(String error) {
    return 'Sinu vastust ei saanud saata: $error';
  }

  @override
  String get joinMeetingFailed => 'Koosolekulinki ei saanud avada.';

  @override
  String get description => 'Kirjeldus';

  @override
  String get availabilityShowAs => 'Hõivatus / Kuva kui';

  @override
  String get busy => 'Hõivatud';

  @override
  String get visibility => 'Nähtavus';

  @override
  String get defaultVisibility => 'Vaikimisi nähtavus';

  @override
  String get conference => 'Konverents';

  @override
  String get noConference => 'Konverentsi pole';

  @override
  String get providerCalendar => 'Teenuse kalender';

  @override
  String get formatBoldShortLabel => 'R';

  @override
  String get formatBoldTooltip => 'Rasvane';

  @override
  String get formatItalicShortLabel => 'K';

  @override
  String get formatItalicTooltip => 'Kursiiv';

  @override
  String get formatUnderlineShortLabel => 'A';

  @override
  String get formatUnderlineTooltip => 'Allajoonitud';

  @override
  String reminderMinutesBefore(int minutes) {
    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutes minutit varem',
      one: '1 minut varem',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'Algusajal';

  @override
  String reminderHoursBefore(int hours) {
    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hours tundi varem',
      one: '1 tund varem',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$days päeva varem',
      one: '1 päev varem',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Vaba';

  @override
  String get availabilityTentative => 'Esialgne';

  @override
  String get availabilityOutOfOffice => 'Kontorist väljas';

  @override
  String get availabilityWorkingElsewhere => 'Töötab mujal';

  @override
  String get visibilityDefault => 'Vaikimisi';

  @override
  String get visibilityPublic => 'Avalik';

  @override
  String get visibilityPrivate => 'Privaatne';

  @override
  String get visibilityConfidential => 'Konfidentsiaalne';

  @override
  String get sensitivityNormal => 'Tavaline';

  @override
  String get sensitivityPersonal => 'Isiklik';

  @override
  String get tasks => 'Ülesanded';

  @override
  String get allTasks => 'Kõik ülesanded';

  @override
  String tasksInList(String title) {
    return 'Loendi „$title” ülesanded';
  }

  @override
  String get taskLists => 'Ülesandeloendid';

  @override
  String get navigation => 'Navigeerimine';

  @override
  String get mainMenu => 'Peamenüü';

  @override
  String get keyboardShortcuts => 'Klaviatuuri otseteed';

  @override
  String get shortcutGroupGeneral => 'Üldine';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Kuva klaviatuuri otseteede loend';

  @override
  String get shortcutGroupNavigation => 'Navigeerimine';

  @override
  String get shortcutNextPeriod => 'Järgmine periood';

  @override
  String get shortcutNextPeriodDescription =>
      'Nädalavaates järgmine nädal, kuuvaates järgmine kuu jne';

  @override
  String get shortcutPreviousPeriod => 'Eelmine periood';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Nädalavaates eelmine nädal, kuuvaates eelmine kuu jne';

  @override
  String get shortcutJumpToToday => 'Mine tänasele kuupäevale';

  @override
  String get shortcutGroupView => 'Vaade';

  @override
  String get viewSelector => 'Vaade';

  @override
  String get shortcutDayView => 'Päevavaade';

  @override
  String get shortcutWeekView => 'Nädalavaade';

  @override
  String get shortcutMonthView => 'Kuuvaade';

  @override
  String get shortcutYearView => 'Aastavaade';

  @override
  String get shortcutAgendaView => 'Päevakavavaade';

  @override
  String get shortcutGroupCreateAndEdit => 'Loomine ja muutmine';

  @override
  String get shortcutSaveItem => 'Salvesta sündmus või ülesanne';

  @override
  String get shortcutDeleteItem => 'Kustuta sündmus või ülesanne';

  @override
  String get shortcutGroupTaskEditing => 'Ülesande muutmine';

  @override
  String get shortcutCancelEditing => 'Tühista muutmine';

  @override
  String get shortcutCancelEditingDescription =>
      'Sulge ülesande muutmine või ülesande üksikasjad';

  @override
  String get aboutBusyMax => 'Teave BusyMaxi kohta';

  @override
  String get aboutBusyMaxDescription => 'Kalender ja ülesanded';

  @override
  String get license => 'Litsents';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Veebisait';

  @override
  String get sourceCode => 'Lähtekood';

  @override
  String get reportAnIssue => 'Teata probleemist';

  @override
  String get sendFeedback => 'Saada tagasisidet';

  @override
  String get feedbackSubmit => 'Saada';

  @override
  String get feedbackCategory => 'Kategooria';

  @override
  String get feedbackSelectCategory => 'Valige kategooria';

  @override
  String get feedbackCategoryProblem => 'Probleem või viga';

  @override
  String get feedbackCategoryFeature => 'Funktsioonisoov';

  @override
  String get feedbackCategoryPrivacySecurity => 'Privaatsus- või turbeprobleem';

  @override
  String get feedbackCategoryUsability => 'Kasutatavusprobleem';

  @override
  String get feedbackCategoryOther => 'Muu';

  @override
  String get feedbackSubject => 'Teema';

  @override
  String get feedbackDetailedMessage => 'Üksikasjalik sõnum';

  @override
  String get feedbackReplyEmail => 'Vastamise e-posti aadress (valikuline)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Lisa tehnilised üksikasjad';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Lisatakse ainult teie operatsioonisüsteemi nimi ja versioon ning rakenduse keel ja piirkonnaseaded. Logisid, kontoandmeid, failinimesid ega muid diagnostikaandmeid ei lisata.';

  @override
  String get feedbackCategoryRequired => 'Valige kategooria.';

  @override
  String get feedbackSubjectLengthError =>
      'Teema peab olema 3–120 tähemärki pikk.';

  @override
  String get feedbackMessageLengthError =>
      'Sõnum peab olema 10–5000 tähemärki pikk.';

  @override
  String get feedbackInvalidEmail => 'Sisestage kehtiv e-posti aadress.';

  @override
  String get feedbackConnectionError =>
      'BusyStackiga ei saanud ühendust luua. Kontrollige ühendust ja proovige uuesti.';

  @override
  String get feedbackTimeoutError =>
      'Päring aegus. Teie tagasisidet ei kustutatud; proovige uuesti.';

  @override
  String get feedbackRateLimitedError =>
      'Sellest võrgust on saadetud liiga palju tagasisidet. Oodake ja proovige uuesti.';

  @override
  String get feedbackRejectedError =>
      'Server lükkas saatmise tagasi. Kontrollige välju ja proovige uuesti.';

  @override
  String get feedbackServerError =>
      'BusyStack ei saa praegu teie tagasisidet vastu võtta. Teie tagasisidet ei kustutatud; proovige uuesti.';

  @override
  String feedbackSuccess(String id) {
    return 'Tagasiside saadetud. Viide: $id';
  }

  @override
  String get toggleSidebar => 'Kuva või peida külgriba';

  @override
  String get showSidebar => 'Kuva külgpaneel';

  @override
  String get hideSidebar => 'Peida külgpaneel';

  @override
  String get accounts => 'Kontod';

  @override
  String get currentAccount => 'Praegune konto';

  @override
  String get switchAccount => 'Vaheta kontot';

  @override
  String get addGoogleAccount => 'Lisa Google’i konto';

  @override
  String get addMicrosoftAccount => 'Lisa Microsofti konto';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Sisse logitud';

  @override
  String get removeAccount => 'Eemalda konto…';

  @override
  String get removingAccount => 'Konto eemaldamine…';

  @override
  String get removeAccountDescription =>
      'Lõpeta sünkroonimine ja eemalda selle konto andmed seadmest.';

  @override
  String removeAccountTitle(String account) {
    return 'Kas eemaldada $account BusyMaxist?';
  }

  @override
  String get removeAccountConfirmation =>
      'See kustutab sellest seadmest vahemällu salvestatud ülesanded, kalendrid, sündmused, meeldetuletused ja ootel võrguühenduseta muudatused. Sünkroonimata muudatused lähevad kaotsi. Teenusepakkuja kalendrite, sündmuste, ülesandeloendite ja ülesannete koopiaid ei kustutata.';

  @override
  String get revokeGoogleAccess =>
      'Tühista ka BusyMaxi juurdepääs sellele Google’i kontole';

  @override
  String get revokeGoogleAccessDescription =>
      'Enne uuesti ühendamist peate juurdepääsu uuesti andma.';

  @override
  String get removeAccountAction => 'Eemalda konto';

  @override
  String get removeAccountFailed =>
      'Konto eemaldamist ei saanud lõpetada. Proovige uuesti.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'Konto eemaldati sellest seadmest, kuid BusyMaxi juurdepääsu teie Google’i kontole ei saanud tühistada. Saate selle oma Google’i kontol käsitsi tühistada.';

  @override
  String get newTaskList => 'Uus ülesandeloend';

  @override
  String taskListCreateFailed(String error) {
    return 'Ülesandeloendi loomine ebaõnnestus: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Ülesandeloendi ümbernimetamine ebaõnnestus: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Ülesandeloendi kustutamine ebaõnnestus: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Enne loendi kustutamist või eemaldamist sünkroonige konto või lahendage selle ülesandeloendi blokeeritud muudatused jaotises Diagnostika.';

  @override
  String get signInToViewTaskLists =>
      'Ülesandeloendite vaatamiseks logige sisse.';

  @override
  String get noTaskListsSynced =>
      'Ühtegi ülesandeloendit pole veel sünkroonitud.';

  @override
  String get listActions => 'Loendi toimingud';

  @override
  String get rename => 'Nimeta ümber';

  @override
  String get delete => 'Kustuta';

  @override
  String get renameList => 'Nimeta loend ümber';

  @override
  String get deleteList => 'Kustuta loend';

  @override
  String get unshare => 'Lõpeta jagamine';

  @override
  String get readOnlyTaskListCannotRename =>
      'See ülesandeloend on kirjutuskaitstud ja seda ei saa ümber nimetada.';

  @override
  String get taskListCannotDelete =>
      'Seda ülesandeloendit ei saa praeguste õigustega kustutada.';

  @override
  String get builtInMicrosoftList => 'Sisseehitatud';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Microsoft To Do sisseehitatud loendeid ei saa ümber nimetada ega kustutada.';

  @override
  String deleteListConfirmation(String title) {
    return 'Kas kustutada „$title” Google Tasksist?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Kas kustutada „$title” ja kõik selle ülesanded?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Kas lõpetada „$title” jagamine selle kontoga?';
  }

  @override
  String get deleteEvent => 'Kustuta sündmus';

  @override
  String get title => 'Pealkiri';

  @override
  String get create => 'Loo';

  @override
  String get newTask => 'Uus ülesanne';

  @override
  String get clearCompleted => 'Eemalda lõpetatud ülesanded';

  @override
  String get refreshList => 'Värskenda loendit';

  @override
  String get refreshAll => 'Värskenda kõiki';

  @override
  String get listRefreshed => 'Loend on värskendatud.';

  @override
  String get allTasksRefreshed => 'Kõik kontod on värskendatud.';

  @override
  String exportedFile(String path) {
    return 'Eksporditud asukohta $path';
  }

  @override
  String exportFailed(String error) {
    return 'Eksportimine nurjus: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Värskendamine nurjus: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Alustamiseks valige või looge ülesandeloend.';

  @override
  String get signInToViewTasks => 'Ülesannete vaatamiseks logige sisse.';

  @override
  String get noTasks => 'Ülesandeid pole.';

  @override
  String get noTasksYet => 'Ülesandeid veel pole';

  @override
  String get noTasksYetMessage =>
      'Alustamiseks looge ülesanne või värskendage kontosid.';

  @override
  String get noTasksInList => 'Selles loendis pole ülesandeid.';

  @override
  String get overdue => 'Tähtaja ületanud';

  @override
  String get today => 'Täna';

  @override
  String get tomorrow => 'Homme';

  @override
  String get upcoming => 'Tulekul';

  @override
  String get noDate => 'Kuupäevata';

  @override
  String get completed => 'Lõpetatud';

  @override
  String duePrefix(String date) {
    return 'Tähtaeg $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => 'Ülesande üksikasjad';

  @override
  String get editTask => 'Muuda ülesannet';

  @override
  String get noTaskSelected => 'Ülesannet pole valitud.';

  @override
  String get noTaskSelectedHelper =>
      'Üksikasjade vaatamiseks ja muutmiseks valige ülesanne.';

  @override
  String get taskUnavailable => 'Ülesanne pole saadaval.';

  @override
  String get signInToEditTasks => 'Ülesannete muutmiseks logige sisse.';

  @override
  String get refreshTask => 'Värskenda ülesannet';

  @override
  String get primarySection => 'Põhiteave';

  @override
  String get statusSection => 'Olek';

  @override
  String get openStatus => 'Pooleli';

  @override
  String get doneStatus => 'Tehtud';

  @override
  String get taskStatus => 'Olek';

  @override
  String get taskStatusNone => 'Olek puudub';

  @override
  String get taskStatusNeedsAction => 'Vajab tegevust';

  @override
  String get taskStatusInProcess => 'Töös';

  @override
  String get taskStatusCompleted => 'Lõpetatud';

  @override
  String get taskStatusCancelled => 'Tühistatud';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return 'Lõpetatud $percentString%';
  }

  @override
  String get completionDate => 'Lõpetamise kuupäev';

  @override
  String get priority => 'Prioriteet';

  @override
  String get priorityNone => 'Prioriteet puudub';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioriteet $priorityString · kõrge';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioriteet $priorityString · keskmine';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioriteet $priorityString · madal';
  }

  @override
  String get taskUrl => 'Ülesande URL';

  @override
  String get invalidTaskUrl => 'Sisestage absoluutne URL koos skeemiga.';

  @override
  String get classification => 'Klassifikatsioon';

  @override
  String get classificationPublic => 'Jagamisel näita kogu ülesannet';

  @override
  String get classificationConfidential => 'Jagamisel näita ainult hõivatust';

  @override
  String get classificationPrivate => 'Jagamisel peida see ülesanne';

  @override
  String get pinTask => 'Kinnita ülesanne';

  @override
  String get notes => 'Märkmed';

  @override
  String get dueDate => 'Tähtaeg';

  @override
  String get clearDueDate => 'Eemalda tähtaeg';

  @override
  String get dueTime => 'Tähtaja kellaaeg';

  @override
  String get startDate => 'Alguskuupäev';

  @override
  String get startTime => 'Alguskellaaeg';

  @override
  String get endDate => 'Lõppkuupäev';

  @override
  String get endTime => 'Lõppkellaaeg';

  @override
  String get reminderDate => 'Meeldetuletuse kuupäev';

  @override
  String get reminderTime => 'Meeldetuletuse kellaaeg';

  @override
  String get reminder => 'Meeldetuletus';

  @override
  String get addReminder => 'Lisa meeldetuletus';

  @override
  String get reminders => 'Meeldetuletused';

  @override
  String get noReminders => 'Meeldetuletusi pole';

  @override
  String get editReminder => 'Muuda meeldetuletust';

  @override
  String get beforeTaskStarts => 'Enne ülesande algust';

  @override
  String get beforeTaskDue => 'Enne ülesande tähtaega';

  @override
  String get afterTaskStarts => 'Pärast ülesande algust';

  @override
  String get afterTaskDue => 'Pärast ülesande tähtaega';

  @override
  String get relativeToTaskStart => 'Ülesande alguskuupäeva suhtes';

  @override
  String get relativeToTaskDue => 'Ülesande tähtaja suhtes';

  @override
  String get reminderTimeOfDay => 'Kellaaeg';

  @override
  String get absoluteReminder => 'Kuupäeval ja kellaajal';

  @override
  String get reminderAmount => 'Kogus';

  @override
  String get reminderUnit => 'Ühik';

  @override
  String get reminderUnitSeconds => 'Sekundit';

  @override
  String get reminderUnitMinutes => 'Minutit';

  @override
  String get reminderUnitHours => 'Tundi';

  @override
  String get reminderUnitDays => 'Päeva';

  @override
  String get reminderUnitWeeks => 'Nädalat';

  @override
  String get reminderAtTaskStart => 'Ülesande alguses';

  @override
  String get reminderAtTaskDue => 'Ülesande tähtajal';

  @override
  String get unsupportedReminder =>
      'See meeldetuletuse tüüp säilitatakse, kuid selle aega ei saa muuta.';

  @override
  String get relatedRemindersTitle => 'Kas säilitada seotud meeldetuletused?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Sellel kuupäeval on $countString seotud meeldetuletust. Kas säilitada need praegusel kuupäeval ja kellaajal?';
  }

  @override
  String get discardRelatedReminders => 'Hülga meeldetuletused';

  @override
  String get keepRelatedReminders => 'Säilita meeldetuletused';

  @override
  String get addGuest => 'Lisa külaline';

  @override
  String get addGuestEmail => 'Lisa külalise e-posti aadress';

  @override
  String get removeReminder => 'Eemalda meeldetuletus';

  @override
  String get off => 'Väljas';

  @override
  String get repeat => 'Kordus';

  @override
  String get repeatNone => 'Ei kordu';

  @override
  String get noneValue => 'Puudub';

  @override
  String get repeatDaily => 'Iga päev';

  @override
  String get repeatWeekly => 'Iga nädal';

  @override
  String get repeatMonthly => 'Iga kuu';

  @override
  String get repeatYearly => 'Iga aasta';

  @override
  String get repeatEvery => 'Kordusintervall';

  @override
  String get repeatOn => 'Kordub';

  @override
  String get repeatEnd => 'Lõpeta kordus';

  @override
  String get repeatNever => 'Mitte kunagi';

  @override
  String get repeatUntil => 'Kuupäeval';

  @override
  String get repeatAfter => 'Pärast korduste arvu täitumist';

  @override
  String get repeatCount => 'Korduste arv';

  @override
  String get repeatDayOfMonth => 'Kuu päevad';

  @override
  String get repeatMonths => 'Kuud';

  @override
  String get repeatOrdinal => 'Nädalapäeva järjekord';

  @override
  String get repeatSpecificDays => 'Kindlad päevad';

  @override
  String get repeatFirst => 'Esimene';

  @override
  String get repeatSecond => 'Teine';

  @override
  String get repeatThird => 'Kolmas';

  @override
  String get repeatFourth => 'Neljas';

  @override
  String get repeatFifth => 'Viies';

  @override
  String get repeatSecondToLast => 'Eelviimane';

  @override
  String get repeatLast => 'Viimane';

  @override
  String get repeatAnyDay => 'Päev';

  @override
  String get repeatWeekday => 'Tööpäev';

  @override
  String get repeatWeekendDay => 'Nädalavahetuse päev';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'esmaspäev',
      'TU': 'teisipäev',
      'WE': 'kolmapäev',
      'TH': 'neljapäev',
      'FR': 'reede',
      'SA': 'laupäev',
      'SU': 'pühapäev',
      'day': 'päev',
      'weekday': 'tööpäev',
      'weekend': 'nädalavahetuse päev',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Iga $countString päeva järel';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Iga $countString nädala järel';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Iga $countString kuu järel';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Iga $countString aasta järel';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return '$days päeval';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'esimene $days',
      'second': 'teine $days',
      'third': 'kolmas $days',
      'fourth': 'neljas $days',
      'fifth': 'viies $days',
      'secondToLast': 'eelviimane $days',
      'last': 'viimane $days',
      'other': '$days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return '$months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString korda',
      one: '$countString kord',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'kuni kuupäevani $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'See kordusreegel kasutab valikuid, mida see redaktor ei muuda.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'See loend ei toeta seda kordusmustrit. Muuda mustrit või vali teine loend.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Selle kordusmustri kasutamiseks lisa algus- või tähtpäev või lülita kordamine välja.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Seda kordust ei saa teenusega $provider kasutada.';
  }

  @override
  String get importance => 'Tähtsus';

  @override
  String get importanceLow => 'Madal';

  @override
  String get importanceNormal => 'Tavaline';

  @override
  String get importanceHigh => 'Kõrge';

  @override
  String get categories => 'Kategooriad';

  @override
  String get scheduleSection => 'Ajakava';

  @override
  String get dueGroup => 'Tähtaeg';

  @override
  String get startGroup => 'Algus';

  @override
  String get reminderGroup => 'Meeldetuletus';

  @override
  String get organizationSection => 'Korraldus';

  @override
  String get actionsSection => 'Toimingud';

  @override
  String get advancedSection => 'Täpsemad seaded';

  @override
  String get addCategory => 'Lisa kategooria';

  @override
  String get list => 'Loend';

  @override
  String get microsoftMoveUnsupported =>
      'Selles versioonis ei toetata Microsoft To Do kontodel ülesannete teisaldamist loendite vahel.';

  @override
  String get createSubtask => 'Loo alamülesanne';

  @override
  String get subtasks => 'Alamülesanded';

  @override
  String get duplicateTask => 'Loo ülesandest koopia';

  @override
  String get taskDuplicated => 'Ülesanne dubleeriti.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Ülesande dubleerimine ebaõnnestus: $error';
  }

  @override
  String get hideSubtasks => 'Peida alamülesanded';

  @override
  String get hideClosedSubtasks => 'Peida lõpetatud alamülesanded';

  @override
  String get moveToTop => 'Teisalda kõige üles';

  @override
  String get deleteTask => 'Kustuta ülesanne';

  @override
  String get newSubtask => 'Uus alamülesanne';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Kas kustutada „$title”?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'See kustutab ka algse ülesande Google Docsis või Chati ruumides.';

  @override
  String get metadata => 'Metaandmed';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Uuendatud';

  @override
  String get parent => 'Ülemülesanne';

  @override
  String get position => 'Asukoht';

  @override
  String get webLink => 'Veebilink';

  @override
  String get assignment => 'Määramine';

  @override
  String get localState => 'Kohalik olek';

  @override
  String get pendingSync => 'Sünkroonimise ootel';

  @override
  String get synced => 'Sünkroonitud';

  @override
  String get account => 'Konto';

  @override
  String get sync => 'Sünkroonimine';

  @override
  String get forceFullResync => 'Sunni täielik uuesti sünkroonimine';

  @override
  String get forceFullResyncDescription =>
      'Laadib kõigi ühendatud kontode andmed täielikult uuesti. Kasutage seda ainult sünkroonimisprobleemide tõrkeotsinguks.';

  @override
  String get runInBackgroundWhenClosed =>
      'Jätka töötamist, kui aken on suletud';

  @override
  String get showTrayIcon => 'Kuva süsteemisalve ikoon';

  @override
  String get startMinimizedToTray => 'Käivita minimeerituna süsteemisalves';

  @override
  String get launchAtLogin => 'Käivita sisselogimisel';

  @override
  String get launchAtLoginDescription =>
      'BusyMax käivitatakse taustal, et meeldetuletused töötaksid pärast sisselogimist.';

  @override
  String get launchAtLoginFailed =>
      'Sisselogimisel käivitamise seadet ei saanud uuendada.';

  @override
  String get requiresTrayIcon => 'Nõuab süsteemisalve ikooni.';

  @override
  String get syncComplete => 'Sünkroonimine on lõpetatud.';

  @override
  String syncFailed(String error) {
    return 'Sünkroonimine nurjus: $error';
  }

  @override
  String get notifySyncFailures => 'Teavitused sünkroonimise nurjumisel';

  @override
  String get notifyConflicts => 'Teavitused konfliktide korral';

  @override
  String get notifyDueToday => 'Täna tähtuvate ülesannete teavitused';

  @override
  String get eventReminders => 'Sündmuste meeldetuletused';

  @override
  String get onState => 'Sees';

  @override
  String get taskReminders => 'Ülesannete meeldetuletused';

  @override
  String get notificationDetailLevel => 'Teavituste üksikasjalikkus';

  @override
  String get notificationDetailPrivate => 'Privaatne';

  @override
  String get notificationDetailNormal => 'Tavaline';

  @override
  String get quietHours => 'Vaikne aeg';

  @override
  String get quietHoursDescription => 'Peata teavitused selleks ajavahemikuks.';

  @override
  String get quietHoursStart => 'Vaikse aja algus';

  @override
  String get quietHoursEnd => 'Vaikse aja lõpp';

  @override
  String get notifications => 'Teavitused';

  @override
  String get windowsNotificationsUnavailable =>
      'Windowsi teavitused pole saadaval';

  @override
  String get windowsNotificationsUnpackaged =>
      'See pakendamata arendusversioon ei saa Windowsi teavitusi kasutada. Meeldetuletuste testimiseks paigalda testallkirjastatud MSIX.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax ei saanud Windowsi teavitusi lähtestada. Meeldetuletusi ei kuvata enne, kui see paigaldusprobleem on lahendatud.';

  @override
  String get appearance => 'Välimus';

  @override
  String get theme => 'Kujundus';

  @override
  String get themeSystem => 'Süsteem';

  @override
  String get settingsSystem => 'Süsteem';

  @override
  String get themeLight => 'Hele';

  @override
  String get themeDark => 'Tume';

  @override
  String get themeFamily => 'Kujunduse perekond';

  @override
  String get themeFamilyYaru => 'Ubuntu algupärane kujundus (Yaru)';

  @override
  String get localization => 'Keel ja piirkond';

  @override
  String get currentLocale => 'Praegune lokaat';

  @override
  String get privacy => 'Privaatsus';

  @override
  String get redactTaskContentInDiagnostics =>
      'Peida diagnostikas ülesannete sisu';

  @override
  String get developerDiagnostics => 'Arendaja diagnostika';

  @override
  String get diagnostics => 'Diagnostika';

  @override
  String get apiInspectorDisabled => 'Kuva API-inspektor';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery versioon: $revision';
  }

  @override
  String get implementedMethods => 'Rakendatud meetodid';

  @override
  String get supportsTasksScopes =>
      'Toetab õiguse ulatusi tasks ja tasks.readonly';

  @override
  String get requiresTasksScope => 'Nõuab õiguse ulatust tasks';

  @override
  String get blockedPendingOperations => 'Blokeeritud ootel toimingud';

  @override
  String get signInToInspectPendingOperations =>
      'Ootel toimingute kontrollimiseks logige sisse.';

  @override
  String get noBlockedPendingOperations => 'Blokeeritud ootel toiminguid pole.';

  @override
  String get operationActions => 'Toimingu tegevused';

  @override
  String pendingOpListId(String id) {
    return 'loend=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'ülesanne=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    return 'katseid=$count';
  }

  @override
  String get retry => 'Proovi uuesti';

  @override
  String get discard => 'Hülga';

  @override
  String get discardChangesAction => 'Hülga';

  @override
  String get discardChanges => 'Kas hüljata muudatused?';

  @override
  String get discardChangesConfirmation =>
      'See hülgab ülesande salvestamata muudatused.';

  @override
  String get retryCompleted => 'Uuesti proovimine lõpetatud.';

  @override
  String get discardPendingOperation => 'Kas hüljata ootel toiming?';

  @override
  String get discardPendingOperationConfirmation =>
      'See eemaldab blokeeritud kohaliku toimingu. Järgmine sünkroonimine laadib andmed Google Tasksist uuesti.';

  @override
  String get pendingOperationDiscarded => 'Ootel toiming hüljatud.';

  @override
  String get syncFailureNotificationTitle => 'BusyMaxi sünkroonimine nurjus';

  @override
  String syncFailureNotificationBody(String message) {
    return 'Taustal sünkroonimine nurjus. $message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMaxi sünkroonimiskonflikt';

  @override
  String conflictNotificationBody(String summary) {
    return 'Ootel kohalik muudatus blokeeriti. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Täna tähtuvad ülesanded';

  @override
  String dueTodayNotificationBody(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count ülesannet tähtub täna.',
      one: 'Üks ülesanne tähtub täna.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Sündmuse meeldetuletus';

  @override
  String get taskReminderNotificationTitle => 'Ülesande meeldetuletus';

  @override
  String get eventReminderNotificationBody => 'Sündmus algab varsti.';

  @override
  String get taskReminderNotificationBody => 'Ülesande tähtaeg on varsti.';

  @override
  String get notificationOpenAction => 'Ava';

  @override
  String get notificationSnoozeAction => 'Lükka 10 minutit edasi';

  @override
  String get notificationDismissAction => 'Sulge';

  @override
  String get notificationDetailsHidden =>
      'Üksikasjad on privaatsusseadete tõttu peidetud.';

  @override
  String get previousMonth => 'Eelmine kuu';

  @override
  String get nextMonth => 'Järgmine kuu';

  @override
  String get openMonthView => 'Ava kuuvaade';

  @override
  String get previousYear => 'Eelmine aasta';

  @override
  String get nextYear => 'Järgmine aasta';

  @override
  String get openYearView => 'Ava aastavaade';

  @override
  String weekNumberTooltip(int number) {
    return 'Nädal $number';
  }

  @override
  String get resizeAllDayPanel => 'Muuda kogu päeva paneeli suurust';

  @override
  String scheduleItemCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count kirjet',
      one: '1 kirje',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'See kalender on kirjutuskaitstud.';

  @override
  String get selectTimeZone => 'Valige ajavöönd';

  @override
  String get searchLocations => 'Otsi asukohti';

  @override
  String get noLocationsFound => 'Asukohti ei leitud';

  @override
  String get requiredField => 'See väli on kohustuslik.';

  @override
  String get providerConnectionDescription =>
      'Ühendage kalendrid ja ülesanded ühega neist teenusepakkujatest.';

  @override
  String get appleICloudProvider => 'Apple iCloudi kalender';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloudi ülesanded';

  @override
  String get addAppleICloudAccount => 'Lisa Apple iCloud Calendari konto';

  @override
  String get addNextcloudAccount => 'Lisa Nextcloudi konto';

  @override
  String get waitingForAppleICloud => 'Apple iCloudiga ühendamine…';

  @override
  String get waitingForNextcloud => 'Nextcloudi autoriseerimise ootel…';

  @override
  String get connectAppleICloudTitle => 'Ühenda Apple iCloud Calendar';

  @override
  String get appleAccountEmail => 'Apple’i konto e-post';

  @override
  String get appleAppSpecificPassword => 'Rakendusepõhine parool';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Loo rakendusepõhine parool pärast Apple’i konto kaheastmelise autentimise lubamist.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Apple’i konto parooli lähtestamine tühistab rakendusepõhised paroolid.';

  @override
  String get connectNextcloudTitle => 'Ühenda Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloudi server või CalDAV-aadress';

  @override
  String get nextcloudServerUrlHelp =>
      'Sisestage Nextcloudi serveri URL või kleepige Nextcloudist kopeeritud peamine CalDAV-aadress.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax avab brauseri. Kinnita juurdepääs seal ja naase seejärel BusyMaxi.';

  @override
  String get connectAccountAction => 'Ühenda';

  @override
  String get cancelAccountConnection => 'Tühista ühendus';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'Konto eemaldati kohalikult, kuid Nextcloudi rakenduse parooli ei saanud tühistada.';

  @override
  String get davReauthenticationRequired =>
      'Sünkroonimise jätkamiseks ühenda see konto uuesti.';

  @override
  String get davTemporarilyUnavailable => 'See konto pole ajutiselt saadaval.';

  @override
  String get davPermissionChanged =>
      'Serveriõigused muutusid. Ootel muudatused on peatatud.';

  @override
  String get davUnsupportedServer =>
      'Seda serverit või teenusepakkuja profiili ei toetata.';

  @override
  String get collectionSettings => 'Kalendrid ja ülesandeloendid';

  @override
  String get calendarContent => 'Kalendrisündmused';

  @override
  String get taskContent => 'Ülesanded';

  @override
  String get readOnlySharedCollection => 'Kirjutuskaitstud';

  @override
  String get pendingLocally => 'Kohapeal ootel';

  @override
  String get conflictBlocked => 'Konflikti tõttu blokeeritud';

  @override
  String get authenticationBlocked => 'Blokeeritud kuni taasühendamiseni';

  @override
  String get operationFailed => 'Toiming nurjus';

  @override
  String get keepServerVersion => 'Säilita serveri versioon';

  @override
  String get reapplyLocalChange =>
      'Vaata kohalik muudatus üle ja rakenda uuesti';

  @override
  String get duplicateLocalItem => 'Dubleeri uue üksusena';

  @override
  String get davConnectionState => 'Ühenduse olek';

  @override
  String get davConnected => 'Ühendatud';

  @override
  String get davConnecting => 'Ühendamine…';

  @override
  String get davSignedOut => 'Välja logitud';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Viimane õnnestunud sünkroonimine: $time';
  }

  @override
  String get davNeverSynced => 'Veel sünkroonimata';

  @override
  String get refreshCollections => 'Värskenda kalendreid ja ülesandeloendeid';

  @override
  String nextcloudServerHost(String host) {
    return 'Serveri aadress: $host';
  }

  @override
  String get collectionSupportsEvents => 'Sündmuste kalender';

  @override
  String get collectionSupportsTasks => 'Ülesandeloend';

  @override
  String get collectionSupportsEventsAndTasks => 'Sündmused ja ülesanded';

  @override
  String get writableCollection => 'Kirjutatav';

  @override
  String get sharedCollection => 'Jagatud';

  @override
  String collectionLastSynced(String time) {
    return 'Viimati sünkroonitud: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Sünkroonimisprobleem: $code';
  }

  @override
  String get syncConflicts => 'Sünkroonimiskonfliktid';

  @override
  String remoteChangedAt(String time) {
    return 'Server muutis: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Kohalik muudatus: $summary';
  }

  @override
  String get conflictResolutionFailed => 'Konflikti ei saanud lahendada.';

  @override
  String get recurringEventScope => 'Korduva sündmuse ulatus';

  @override
  String get entireSeries => 'Kogu sari';

  @override
  String get singleOccurrence => 'See sündmus';

  @override
  String get thisAndFollowingEvents => 'See ja järgmised sündmused';

  @override
  String get thisAndFutureUnavailable => 'See teenusepakkuja ei toeta seda.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'Seda ja järgnevaid sündmusi ei saa turvaliselt teisaldada. Valige see sündmus või kogu sari.';

  @override
  String get entireSeriesMoveUnavailable =>
      'Kordusreegel pole kohalikult saadaval. Teisalda selle asemel ainult see sündmus.';

  @override
  String get copyEventAndDeleteOriginal =>
      'Kas kopeerida sündmus ja kustutada algne?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax ei saa seda sündmust otse kalendrist $source kalendrisse $destination teisaldada. Esmalt luuakse koopia ja algne sündmus kustutatakse alles pärast edukat kopeerimist. Sündmuse ID-d muutuvad; osalejate vastuseolekud võivad lähtestuda ning võidakse saata kutseid või tühistusi; konverentsilingid, manused, meeldetuletused, teenusepakkuja väljad ja korduse erandid ei pruugi üle kanduda.';
  }

  @override
  String get copyAndDelete => 'Kopeeri ja kustuta';

  @override
  String get chooseRecurringEventScope =>
      'Valige, kas see muudatus rakendub kogu sarjale, ainult sellele sündmusele või sellele ja järgnevatele sündmustele.';

  @override
  String get taskDueBeforeStart => 'Tähtaeg ei tohi olla enne algust.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Määrake nii algus- kui ka tähtaja kellaaeg või tehke ülesanne kogu päeva ülesandeks.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Kas kustutada „$title”?';
  }

  @override
  String get setCustomCalendarName => 'Määra kohandatud nimi';

  @override
  String get setAction => 'Määra';

  @override
  String get removeFromMyCalendars => 'Eemalda minu kalendritest';

  @override
  String get removeAction => 'Eemalda';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Kas eemaldada „$title” BusyMaxist? Omaniku kalendrit ega sündmusi ei kustutata.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'Üleslaadimine võis õnnestuda. Enne uut üleslaadimist värskendage manuseid ja kontrollige tulemust.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Kas eemaldada „$title” teie Google’i kalendrite loendist? Jagatud kalendrit ega selle sündmusi ei kustutata.';
  }

  @override
  String get calendarCannotRemove =>
      'Seda kalendrit ei saa sellest kontost kustutada ega eemaldada.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Enne kalendri kustutamist või eemaldamist oodake, kuni selle ootel muudatused on sünkroonitud.';

  @override
  String get calendarSubscriptions => 'Kalendritellimused';

  @override
  String get calendarSubscriptionsDescription =>
      'Lisage kirjutuskaitstud kalendreid, mida värskendatakse turvalise WebCali URL-i kaudu.';

  @override
  String get addCalendarSubscription => 'Lisa kalendritellimus';

  @override
  String get subscriptionName => 'Kohalik nimi';

  @override
  String get subscriptionUrl => 'Tellimuse URL';

  @override
  String get subscriptionUrlHelp =>
      'Sisestage HTTPS- või webcal-URL. BusyMax hoiab täielikku URL-i turvalises salvestusruumis.';

  @override
  String get subscriptionUrlInvalid =>
      'Sisestage kehtiv HTTPS- või webcal-URL ilma kasutajateabe või fragmendita.';

  @override
  String get subscriptionColor => 'Kohalik värv';

  @override
  String get subscriptionColorHelp =>
      'Kasutage kuuekohalist värvi, näiteks #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Sisestage kuuekohaline kuueteistkümnendsüsteemi värv.';

  @override
  String get subscriptionRefreshMode => 'Värskendussagedus';

  @override
  String get subscriptionAutomatic => 'Automaatne';

  @override
  String get subscriptionHourly => 'Iga tunni järel';

  @override
  String get subscriptionSixHours => 'Iga kuue tunni järel';

  @override
  String get subscriptionDaily => 'Iga päev';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Allikas: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Turvalise allika eelvaateks sisesta kehtiv URL.';

  @override
  String get subscriptionReadOnly => 'Kirjutuskaitstud tellimus';

  @override
  String get subscriptionNeverRefreshed => 'Veel värskendamata';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Viimane edukas värskendus: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Järgmine värskendus: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Ajaga kaasas';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Värskendusprobleem: $code';
  }

  @override
  String get refreshNow => 'Värskenda kohe';

  @override
  String get unsubscribe => 'Tühista tellimus';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Kas tühistada „$name” tellimus?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'See eemaldab kohaliku tellimuse ja selle vahemällu salvestatud sündmused. Avaldatud kalendrit ei muudeta.';

  @override
  String get addSubscriptionAction => 'Lisa tellimus';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Kalendritellimus nurjus: $error';
  }

  @override
  String get subscriptions => 'Tellimused';

  @override
  String get calendarImport => 'Kalendri import';

  @override
  String get calendarImportDescription =>
      'Valige fail, vaadake selle sündmused üle ja valige seejärel kirjutatav kalender, kuhu need lisada.';

  @override
  String get importIcsFile => 'Impordi .ics-fail';

  @override
  String get importIcsPreview => 'Impordi kalendrisündmused';

  @override
  String importEventsFound(int count) {
    return 'Imporditavad sündmusekomplektid: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Sobimatud sündmused: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Tahtlikult välja jäetud: $fields';
  }

  @override
  String get noWritableCalendars => 'Sobivat kirjutatavat sihtkalendrit pole.';

  @override
  String get importDestinationCalendar => 'Sihtkalender';

  @override
  String get importIcsConfirm => 'Impordi sündmused';

  @override
  String get importIcsComplete => 'Import lõpetatud';

  @override
  String importQueued(int count) {
    return 'Imporditud või järjekorda lisatud: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Vahele jäetud duplikaadid: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Toetamata korduskomplektid: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'Kalendrifaili ei saanud importida: $error';
  }

  @override
  String get networkOffline => 'Võrguühenduseta';

  @override
  String get networkOfflineDescription =>
      'Muudatused sünkroonitakse ühenduse taastumisel.';

  @override
  String get networkOfflineTryAgain =>
      'Võrguühendus puudub. Looge internetiühendus ja proovige uuesti.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return '$days päeval';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day.';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {
      'jan': 'jaanuaris',
      'feb': 'veebruaris',
      'mar': 'märtsis',
      'apr': 'aprillis',
      'may': 'mais',
      'jun': 'juunis',
      'jul': 'juulis',
      'aug': 'augustis',
      'sep': 'septembris',
      'oct': 'oktoobris',
      'nov': 'novembris',
      'dec': 'detsembris',
      'other': '$month',
    });
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first ja $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency $month $day päeval';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency $month $days päeval';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency $months $day päeval';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency $months $days päeval';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'esimene',
      'second': 'teine',
      'third': 'kolmas',
      'fourth': 'neljas',
      'fifth': 'viies',
      'secondToLast': 'eelviimane',
      'last': 'viimane',
      'other': '',
    });
    return '$frequency $month: $_temp0 $days';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'esimene',
      'second': 'teine',
      'third': 'kolmas',
      'fourth': 'neljas',
      'fifth': 'viies',
      'secondToLast': 'eelviimane',
      'last': 'viimane',
      'other': '',
    });
    return '$frequency $months: $_temp0 $days';
  }

  @override
  String get searchFilters => 'Otsingufiltrid';

  @override
  String get searchType => 'Tüüp';

  @override
  String get searchDate => 'Kuupäev';

  @override
  String get searchAnyDate => 'Kõik kuupäevad (allalaaditud andmed)';

  @override
  String get eventLink => 'Sündmuse link';

  @override
  String get eventLinkOpenFailed => 'Linki ei õnnestunud avada.';

  @override
  String get scheduleRangeIncomplete =>
      'Mõnda sündmust ei saanud kontrollida. Kuvatakse allalaaditud andmed.';

  @override
  String get searchThisWeek => 'See nädal';

  @override
  String get searchCustomRange => 'Kohandatud vahemik';

  @override
  String get searchTaskStatus => 'Ülesande olek';

  @override
  String get searchTaskDue => 'Ülesande tähtaeg';

  @override
  String get searchAnyDueState => 'Kõik tähtajad';

  @override
  String get searchNoDueDate => 'Tähtajata';

  @override
  String get searchPerson => 'Isik';

  @override
  String get searchSources => 'Allikad';

  @override
  String get searchClearFilters => 'Lähtesta filtrid';

  @override
  String get searchFiltersAction => 'Filtrid';

  @override
  String get searchNoSources => 'Otsinguallikaid pole valitud';

  @override
  String get searchClearText => 'Tühjenda tekst';

  @override
  String get openSharedCalendar => 'Ava jagatud kalender';

  @override
  String get manageCalendarSharing => 'Halda kalendri jagamist';

  @override
  String get shareRecipientEmail => 'Saaja e-posti aadress';

  @override
  String get shareRole => 'Juurdepääsu roll';

  @override
  String get addCalendarShare => 'Lisa juurdepääs';

  @override
  String get sharingRefreshFailed =>
      'Jagamine muudeti, kuid õiguste loendit ei saanud värskendada. Värskenda loendit enne järgmist muudatust.';

  @override
  String get sharingRateLimited =>
      'Jagamine on ajutiselt piiratud. Proovi pärast ooteaja lõppu uuesti.';

  @override
  String get attachmentUploadRateLimited =>
      'Manuste üleslaadimine on ajutiselt piiratud. Proovi pärast ooteaja lõppu uuesti.';

  @override
  String get sharingPermissionUnavailable =>
      'Selle kalendri jagamisõigused pole saadaval.';

  @override
  String get calendarShareFreeBusy => 'Ainult vaba/hõivatud';

  @override
  String get calendarShareLimitedRead => 'Loe piiratud üksikasju';

  @override
  String get calendarShareRead => 'Loe kõiki üksikasju';

  @override
  String get calendarShareWrite => 'Muuda sündmusi';

  @override
  String get calendarShareWriteWithoutPrivate =>
      'Muuda ilma privaatsete üksikasjadeta';

  @override
  String get calendarShareOwner => 'Omanik';

  @override
  String get eventLabel => 'Sündmuse silt';

  @override
  String get loadOutlookCategories => 'Laadi Outlooki kategooriad';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlooki kategooriad pole saadaval; senised määrangud säilivad.';

  @override
  String get googleEventType => 'Sündmuse tüüp';

  @override
  String get googleRegularEvent => 'Tavaline sündmus';

  @override
  String get googleFocusTime => 'Keskendumisaeg';

  @override
  String get googleOutOfOffice => 'Kontorist väljas';

  @override
  String get googleWorkingLocation => 'Tööasukoht';

  @override
  String get googleDeclineInvitations => 'Keeldu kattuvatest kutsetest';

  @override
  String get googleDeclineNone => 'Ära keeldu';

  @override
  String get googleDeclineNew => 'Keeldu uutest kutsetest';

  @override
  String get googleDeclineAll => 'Keeldu kõigist kattuvatest kutsetest';

  @override
  String get googleDeclineMessage => 'Keeldumissõnum';

  @override
  String get googleChatStatus => 'Vestluse olek';

  @override
  String get googleChatAvailable => 'Saadaval';

  @override
  String get googleChatDoNotDisturb => 'Ära sega';

  @override
  String get googleWorkAtHome => 'Kodus';

  @override
  String get googleWorkAtOffice => 'Kontoris';

  @override
  String get googleWorkAtCustomLocation => 'Kohandatud asukoht';

  @override
  String get googleWorkLocationLabel => 'Asukoha nimi';

  @override
  String get googleStatusPrimaryOnly =>
      'Google’i olekusündmused nõuavad peamist Google’i kalendrit.';

  @override
  String unknownEventLabel(String id) {
    return 'Tundmatu silt ($id)';
  }

  @override
  String get calendarOwnerEmail => 'Kalendri omaniku e-posti aadress';

  @override
  String registrationSetupTitle(String provider) {
    return 'Seadista $provider';
  }

  @override
  String get registrationSetupGuide => 'Seadistusjuhend';

  @override
  String get registrationGoogleInstructions =>
      'Loo oma Google Cloudi projekt, luba Calendar ja Tasks ning impordi töölaua OAuth-kliendi JSON-fail. Autoriseeri soovitud konto.';

  @override
  String get registrationMicrosoftInstructions =>
      'Kasuta avalikku rakenduse registreeringut Entra rentnikus, mis lubab registreerimist. Sisesta kliendi ID ja kontotüübid. Kliendisaladust pole vaja.';

  @override
  String get registrationImportGoogle => 'Vali töölaua OAuthi JSON';

  @override
  String get registrationValidate => 'Kontrolli registreeringut';

  @override
  String get registrationAuthorize => 'Autoriseeri brauseris';

  @override
  String get registrationClientId => 'Rakenduse/kliendi ID';

  @override
  String get registrationTenantId => 'Rentniku ID';

  @override
  String get registrationAudience => 'Toetatud kontod';

  @override
  String get registrationBothAudience => 'Isiklikud ja organisatsiooni kontod';

  @override
  String get registrationOrganizationAudience => 'Organisatsiooni kontod';

  @override
  String get registrationPersonalAudience => 'Isiklikud kontod';

  @override
  String get registrationTenantAudience => 'Üks organisatsiooni rentnik';

  @override
  String registrationSummary(String clientId) {
    return 'Registreering: $clientId';
  }

  @override
  String get registrationMigrate => 'Migreeri kohe';

  @override
  String get registrationReplace => 'Asenda registreering';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'See konto kasutab algset $provider registreeringut, mis on mõeldud olemasolevatele kontodele. Asendamiseks seadista $setup ja ühenda konto uuesti. Kalendrid, ülesanded ja kohalikud muudatused säilivad.';
  }

  @override
  String get registrationContinue => 'Jätka selle konto kasutamist';

  @override
  String get registrationGoogleProject => 'Google Cloudi projekt';

  @override
  String get registrationMicrosoftApp => 'Microsofti rakenduse registreering';

  @override
  String get registrationUserOwned => 'Kasutaja antud registreering';

  @override
  String get registrationNativeGoogle =>
      'Google Androidi natiivne registreering';

  @override
  String get registrationShared => 'Ühine registreering (üleminek)';

  @override
  String get registrationUnresolved =>
      'Registreeringu päritolu on teadmata. Konto andmed säilivad.';

  @override
  String get registrationOfficialDocumentation => 'Ametlik dokumentatsioon';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Pakett: $packageName\nAllkirja räsi: $signatureHash\nÜmbersuunamise URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Kontrolli registreeringu klienditüüpi, toetatud kontosid, õigusi ja ümbersuunamist. Vali imporditud seadistus uuesti.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'Seda autoriseerimist ei saanud lõpetada. Alusta uuesti; olemasolev ühendus säilib.';

  @override
  String get oauthPermissionRefused =>
      'Autoriseerimisest keelduti või nõutud õigused puuduvad. Proovi uuesti ja anna vajalikud õigused.';

  @override
  String get oauthProviderThrottled =>
      'Teenusepakkuja piirab päringuid. Oota enne uut katset; olemasolev ühendus säilib.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Teenusepakkuja ajutine probleem takistas autoriseerimist. Proovi uuesti; olemasolev ühendus säilib.';

  @override
  String get oauthAuthorizationTimedOut =>
      'Autoriseerimise aeg sai läbi. Proovi uuesti ja vali imporditud seadistus uuesti.';

  @override
  String get oauthWrongAccount =>
      'Autoriseeri taasühendamiseks valitud konto. Olemasolev ühendus säilib.';

  @override
  String get oauthSecureStorageUnavailable =>
      'Turvaline salvestus pole saadaval. Taasta juurdepääs ja proovi uuesti.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'Kaugautoriseerimine tühistati, kuid konto puhastamist ei saanud lõpetada. Taaskäivita BusyMax kohaliku taastamise uuesti proovimiseks.';

  @override
  String get addAccount => 'Lisa konto';

  @override
  String get registrationConnect => 'Ühenda';

  @override
  String get registrationBack => 'Tagasi';

  @override
  String get registrationReplaceGoogle => 'Asenda töölaua OAuthi JSON';

  @override
  String get registrationSelectedConfiguration => 'Valitud seadistus';

  @override
  String get registrationDirectoryId => 'Kataloogi/rentniku ID';

  @override
  String get registrationInvalidId => 'Sisesta kehtiv UUID.';

  @override
  String get registrationExpired =>
      'See seadistus aegus. Impordi see uuesti või muuda enne ühendamist registreeringu välju.';

  @override
  String get registrationOwnProjectRequired =>
      'Vali oma projekti või rentniku registreering.';

  @override
  String get registrationSetupFailed =>
      'Seadistust ei saanud lõpetada. Proovi uuesti.';

  @override
  String get registrationLinkFailed =>
      'Linki ei saanud avada. Kontrolli brauserit ja proovi uuesti.';

  @override
  String get registrationPermissions => 'Õigused';

  @override
  String get registrationDesktopClient => 'Töölauarakendus';

  @override
  String get registrationOpenGoogleConsole => 'Ava Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Google’i avaldamise ja testkasutajate nõuded';

  @override
  String get registrationDesktopHelp =>
      'Töölauarakenduse registreerimise juhised';

  @override
  String get registrationOpenEntra => 'Ava Microsoft Entra halduskeskus';

  @override
  String get registrationGuideGoogleProject =>
      'Ava Google Cloud Console. Vali ülemise projektivaliku kaudu oma projekt või vali New project, sisesta nimi ja vali Create. Jäta see projekt järgmisteks sammudeks valituks.';

  @override
  String get registrationGuideGoogleAudience =>
      'Ava Google Auth Platform → Branding. Kui seadistust pole alustatud, vali Get started. Sisesta väljale App name BusyMax, vali oma User support email ja vali Next. Vali jaotises Audience External. Vali Next, sisesta oma e-post jaotises Contact Information ning vali Next. Nõustu User Data Policyga ja vali Continue ning Create. Olemasoleva seadistuse puhul vaata üle Branding ja Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Ava Google Auth Platform → Data Access → Add or remove scopes. Vali allolevad viis õiguste ulatust; vajadusel kasuta Manually add scopes. Käsitsi sisestamisel kleebi puuduvad väärtused ja vali Add to table. Vali Update ja seejärel Save. BusyMax vajab kalendri ja ülesannete kasutusõigust.';

  @override
  String get registrationGuideGoogleClient =>
      'Ava Google Auth Platform → Clients → Create client. Määra Application type väärtuseks Desktop app, sisesta väljale Name BusyMax ja vali Create. Vali loomisdialoogis Download JSON ja salvesta fail. Vali Tagasi, et naasta vormile, vali see fail ning kontrolli projekti ja kliendi ID-d. Vali Ühenda ning luba brauseris ligipääs kalendrile ja ülesannetele.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Logi sisse Microsoft Entra halduskeskusse. Vali Settingsi kaudu rentnik, kus saad rakendusi registreerida. Ava Entra ID → App registrations → New registration. Sisesta väljale Name BusyMax ja vali järgmises sammus toetatud kontotüübid. Kui registreerimine on blokeeritud, küsi rentniku administraatorilt õigust.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'Ava registreeringus Authentication → Add a platform → Mobile and desktop applications. Vali või sisesta allolev ümbersuunamise URI ning salvesta valikuga Configure. BusyMax kasutab süsteemi brauserit. Kliendisaladust pole vaja.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Ava API permissions → Add a permission → Microsoft Graph → Delegated permissions. Otsi ja vali iga allolev õiguse ulatus ning vali Add permissions. Säilita User.Read, kui see on juba olemas. Kui organisatsioon nõuab administraatori nõusolekut, palu administraatoril kasutada rentniku jaoks Grant admin consent.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Vali Tagasi, et naasta vormile. Kleebi Application (client) ID ja vali samad toetatud kontod kui registreeringus. Ühe organisatsiooni rentniku puhul kleebi ka Directory (tenant) ID. Vali Ühenda ja logi brauseris soovitud kontole sisse. BusyMax kontrollib välju kohapeal; Microsoft küsib sinu nõusolekut brauseris sisselogimisel.';

  @override
  String get registrationGoogleImportFailed =>
      'Seda faili ei saanud importida. Vali kehtiv töölaua OAuthi JSON. Eelmine kehtiv valik säilib.';

  @override
  String get registrationGoogleSetupInstructions =>
      'Google’i seadistamisjuhised';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Microsofti seadistamisjuhised';

  @override
  String get registrationDesktopConfiguration => 'Töölaua OAuthi seadistus';

  @override
  String get registrationNoFileSelected => 'Faili pole valitud';

  @override
  String get registrationChooseFile => 'Vali fail…';

  @override
  String get registrationReplaceFile => 'Asenda…';

  @override
  String get registrationGoogleIntroduction =>
      'Vali oma Google Cloudi projekti töölaua OAuthi JSON-fail.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Sisesta oma Microsofti rakenduse registreeringu andmed.';

  @override
  String get registrationSetupInstructions => 'Seadistamisjuhised';

  @override
  String get registrationInstructionsDescription =>
      'Loo konto ühendamiseks vajalik seadistus.';

  @override
  String get registrationEnableApis => 'Luba Calendar ja Tasks';

  @override
  String get registrationConsentScreen => 'Seadista nõusolekukuva';

  @override
  String get registrationAppName => 'Rakenduse nimi';

  @override
  String get registrationScopes => 'Õiguste ulatused';

  @override
  String get registrationRedirectUri => 'Ümbersuunamise URI';

  @override
  String get registrationOpenApiLibrary => 'Ava Google’i API-teek';

  @override
  String get registrationOpenBranding => 'Ava Google Auth Platformi Branding';

  @override
  String get registrationOpenDataAccess =>
      'Ava Google Auth Platformi Data Access';

  @override
  String get registrationOpenClients => 'Ava Google Auth Platformi Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      'Ava Entra rakenduste registreeringud Authenticationi jaoks';

  @override
  String get registrationOpenEntraPermissions =>
      'Ava Entra rakenduste registreeringud API permissionsi jaoks';

  @override
  String get registrationCopy => 'Kopeeri';

  @override
  String get registrationCopyAll => 'Kopeeri kõik';

  @override
  String get registrationGuideGoogleApis =>
      'Ava APIs & Services → Library. Otsi Google Calendar API, ava selle leht ja vali Enable. Naase Library juurde ning korda Google Tasks API jaoks.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Vali jaotises Supported account types isikliku konto jaoks Personal accounts only, organisatsioonikontode jaoks Multiple Entra ID tenants, mõlema jaoks Any Entra ID Tenant + Personal Microsoft accounts või selle kataloogi jaoks Single tenant only. Vali Register. Kopeeri Overview lehelt Application (client) ID; ühe rentniku puhul ka Directory (tenant) ID. Vali BusyMaxis vastav toetatud kontode valik.';

  @override
  String get registrationConnectBusyMax => 'Ühenda BusyMaxiga';

  @override
  String get registrationRecommended => 'Soovitatav';

  @override
  String get registrationOtherMethods => 'Muud ühendusviisid';

  @override
  String get registrationWorkspace => 'Google Workspace’i organisatsioon';

  @override
  String get registrationGoogleCustom => 'Oma OAuthi klient';

  @override
  String get registrationMicrosoftCustom => 'Oma rakenduse registreering';

  @override
  String get registrationMethodsIntroduction =>
      'Vali, kuidas oma konto ühendada.';

  @override
  String get registrationWorkspaceDescription =>
      'Kasuta oma organisatsiooni hallatavat seadistust.';

  @override
  String get registrationCustomDescription =>
      'Kasuta enda hallatavat registreeringut.';

  @override
  String get registrationSharedUnavailable =>
      'BusyMaxiga ühendamine pole selles järgus saadaval. Allpool saad kasutada muud ühendusviisi.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Vali organisatsiooni antud või hallatav töölaua OAuthi JSON. Fail ei tõenda organisatsiooni omandiõigust, sihtrühma ega kinnitamise olekut.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Google Workspace’i seadistusjuhised';

  @override
  String get registrationBusyMaxManaged => 'BusyMaxi hallatav registreering';

  @override
  String get registrationBranding => 'Seadista bränding ja domeenid';

  @override
  String get registrationPublishing => 'Avalda tavakasutuseks';

  @override
  String get registrationOpenAudience => 'Ava Google Auth Platformi Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      'Küsi administraatorilt töölaua OAuth JSON või ava Google Cloud Console ja vali oma Google Workspace’i organisatsioonile kuuluv projekt. Loomiseks ava Ressursside haldamine → Loo projekt, sisesta Projekti nimi, vali Ülemressursi väljal oma organisatsioon või selle kaust ja vali Loo. Vali see projekt järgmisteks sammudeks. Loomiseks on vaja Project Creator õigust, OAuthi seadistamiseks OAuth Config Editor õigust ning APIde lubamiseks Service Usage Admin õigust või samaväärseid õigusi. Blokeeringu korral küsi abi administraatorilt.';

  @override
  String get registrationGuideGoogleBranding =>
      'Lisa jaotises Branding → App domain kõigepealt projekti lubatud domeenid ja siis avalehe, privaatsuse ning kasutustingimuste URLid. Vali Save. Tootmises External-rakendused vajavad neid linke. Kasuta enda domeene ja kinnita omand Search Console’is, kui Google nõuab brändi kinnitamist. BusyMaxi privaatsuslink ei tõenda, et sinu projekt omab busystack.org-i.';

  @override
  String get registrationGuideGooglePublishing =>
      'Vali jaotises Audience Publish app ja kinnita In production. Ära jäta tavakasutust olekusse Testing: need Calendar/Tasksi volitused ja värskendustõendid aeguvad seitsme päevaga. Avaldamine ja kinnitamine on eraldi. Alla 100 kasutajaga isiklik kasutus võib kinnitamisest vabastatud olla, hoiatuste ja kasutajapiiranguga; laiem levitamine võib nõuda brändi ja õiguste kinnitamist. Ka tootmisvolitused võivad aeguda või tühistatud saada.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Vaata need õigused administraatoriga üle. Internal-rakendused ei pea neid nõusolekukuval loetlema. Kui seda nõutakse, ava Data Access → Add or remove scopes, lisa väärtused ning vali Update ja Save. Administraatori piirangud võivad volitust siiski takistada.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'Jagatud kalendrite ja kategooriate õigusi küsitakse eraldi vastavate valikuliste funktsioonide lubamisel; ära lisa neid ülaltoodud kohustuslikku seadistusse.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Ava Google Auth Platform → Branding. Kui seadistust pole alustatud, vali Get started. Sisesta väljale App name BusyMax, vali oma User support email ja vali Next. Vali jaotises Audience Internal. Vali Next, sisesta oma e-post jaotises Contact Information ning vali Next. Nõustu User Data Policyga ja vali Continue ning Create. Olemasoleva seadistuse puhul vaata üle Branding ja Audience.\n\nInternal lubab vaid projekti emaorganisatsiooni kontosid administraatori piirangute kohaselt. Testkasutajate loendit pole vaja. BusyMax ei saa neid konsoolisätteid JSON-faili põhjal kontrollida.';

  @override
  String get contactsTitle => 'Kontaktid';

  @override
  String get contactsLinkedDescription =>
      'Kasuta sündmuse külaliste lisamisel selle konto vahemällu salvestatud kontakte.';

  @override
  String get contactsEnableSuggestions => 'Luba kontaktisoovitused';

  @override
  String get contactsReadPermissionDescription =>
      'Taotleb kontaktidele kirjutuskaitstud juurdepääsu';

  @override
  String get contactsEnableEditing => 'Luba kontaktide muutmine';

  @override
  String get contactsWritePermissionDescription =>
      'Taotleb kontaktidele lugemis- ja kirjutusõigust';

  @override
  String get contactsSuggestionsEnabled => 'Kontaktisoovitused on lubatud';

  @override
  String get contactsNeedsAttention => 'Kontaktid vajavad tähelepanu';

  @override
  String get contactsReadWriteAccess => 'Lugemis- ja kirjutusõigus';

  @override
  String get contactsDisableForAccount => 'Keela selle konto kontaktid';

  @override
  String get contactsOnlyDescription =>
      'Need allikad on kalendri- ja ülesandekontodest sõltumatud.';

  @override
  String get contactsAddCardDav => 'Lisa CardDAV-i kontaktid';

  @override
  String get contactsAddNextcloud => 'Lisa Nextcloudi kontaktid';

  @override
  String get contactsUseForAttendees => 'Kasuta osalejate soovitamiseks';

  @override
  String get contactsServerUrlLabel => 'HTTPS-serveri URL';

  @override
  String get contactsUsernameLabel => 'Kasutajanimi';

  @override
  String get contactsPasswordLabel => 'Parool';
}
