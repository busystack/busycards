// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax se inició desde los ajustes de inicio del escritorio. Elimina su entrada allí y luego sal de BusyMax y vuelve a abrirlo para usar este interruptor.';

  @override
  String get timeFormat => 'Formato de hora';

  @override
  String get firstDayOfWeek => 'Primer día de la semana';

  @override
  String get systemDefault => 'Predeterminado del sistema';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Predeterminado del sistema ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 horas';

  @override
  String get timeFormatTwentyFourHour => '24 horas';

  @override
  String get timeEndOfDay => 'fin del día';

  @override
  String get timePeriod => 'Período del día';

  @override
  String get launchAtLoginReadFailed =>
      'No se pudo determinar el estado del inicio automático.';

  @override
  String get launchAtLoginUnavailable =>
      'El inicio automático no está disponible en este sistema.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'Tu administrador ha activado el inicio automático y no se puede cambiar aquí.';

  @override
  String get settingsSaveFailed =>
      'No se pudo guardar la configuración. Los cambios podrían perderse al reiniciar BusyMax.';

  @override
  String get nextcloudExportCollection => 'Exportar recursos de la colección';

  @override
  String nextcloudImportItems(int count) {
    return 'Se encontraron $count recursos de eventos/tareas';
  }

  @override
  String get nextcloudSchedulingInbox => 'Bandeja de invitaciones';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud procesa estos mensajes en tus calendarios. Confirmar un mensaje elimina solo el mensaje, no el evento.';

  @override
  String get nextcloudInboxEmpty => 'No hay mensajes de planificación.';

  @override
  String get nextcloudAcknowledge => 'Confirmar recepción';

  @override
  String get nextcloudAcknowledgeConfirm =>
      '¿Eliminar este mensaje de la bandeja? Se conservará el evento.';

  @override
  String get nextcloudGuestAvailability =>
      'Consultar disponibilidad de invitados';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Retención en la papelera del servidor: $days días';
  }

  @override
  String get nextcloudCancelMeeting => 'Cancelar reunión';

  @override
  String get nextcloudDeclineAndRemove => 'Rechazar y quitar invitación';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Al sincronizar se enviará un rechazo. No se cancela la reunión del organizador.';

  @override
  String get nextcloudAvailabilityUnknown => 'Disponibilidad desconocida';

  @override
  String get nextcloudAvailabilityFree =>
      'No se notificaron períodos ocupados para este intervalo';

  @override
  String get nextcloudAvailabilityBusy => 'Períodos ocupados';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud enviará las actualizaciones al sincronizar. Guardar localmente no confirma la entrega.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Solo el organizador o un delegado autorizado puede cambiar los detalles. Puedes responder a la invitación desde sus detalles.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'No se puede mover esta reunión mediante copia y eliminación. Usa un calendario con la misma identidad de planificación.';

  @override
  String get nextcloudSchedulingStatus =>
      'Estado de planificación del servidor';

  @override
  String get nextcloudImportFollowUp =>
      'Los recursos importados se guardaron localmente. La actualización de recordatorios está pendiente; no los importes de nuevo.';

  @override
  String get nextcloudNativeImport =>
      'Importar eventos y tareas completos sin enviar invitaciones. Se omiten los UID existentes salvo que elijas nuevas copias. Los recursos no compatibles se indican individualmente.';

  @override
  String get nextcloudImportMethod =>
      'Este archivo contiene mensajes de planificación. La importación guarda su contenido y elimina METHOD; no procesa invitaciones ni respuestas.';

  @override
  String get nextcloudImportCopies =>
      'Importar como nuevas copias con nuevas identidades';

  @override
  String get nextcloudCollectionSettings => 'Configuración de la colección';

  @override
  String get nextcloudSharing => 'Compartir';

  @override
  String get nextcloudOwned => 'Propia';

  @override
  String get nextcloudShared => 'Compartida';

  @override
  String get nextcloudDelegated => 'Delegada';

  @override
  String get nextcloudSubscription => 'Suscripción';

  @override
  String get nextcloudDeleted => 'Eliminada';

  @override
  String get nextcloudMetadataEditable =>
      'El contenido es de solo lectura; se pueden cambiar las propiedades de la colección.';

  @override
  String get nextcloudServerOrder =>
      'Orden del servidor (independiente de la barra lateral)';

  @override
  String get nextcloudCalendarEnabled => 'Habilitada en el servidor';

  @override
  String get nextcloudAvailability =>
      'Incluir esta colección en la disponibilidad';

  @override
  String get nextcloudCalendarTimezone =>
      'Zona horaria del calendario (documento VTIMEZONE)';

  @override
  String get nextcloudRefreshPending =>
      'El cambio se guardó en Nextcloud. La actualización está pendiente; no repitas el cambio.';

  @override
  String get nextcloudOutcomeUnknown =>
      'No se pudo confirmar el resultado en el servidor. Actualiza antes de volver a intentarlo.';

  @override
  String get nextcloudRemoveShared => 'Quitar calendario/lista compartida';

  @override
  String get nextcloudRemoveMixed =>
      'Esta colección contiene eventos y tareas. Al eliminarla se borrarán ambos.';

  @override
  String get nextcloudReadAccess => 'Solo lectura';

  @override
  String get nextcloudWriteAccess => 'Lectura y escritura';

  @override
  String get nextcloudRecipientSearch => 'Buscar personas o grupos';

  @override
  String get nextcloudNoRecipients => 'No hay personas ni grupos coincidentes.';

  @override
  String get nextcloudRevokeShare => 'Revocar acceso';

  @override
  String get nextcloudPublish => 'Publicar enlace';

  @override
  String get nextcloudUnpublish => 'Dejar de publicar';

  @override
  String get nextcloudPublishWarning =>
      'Quien tenga el enlace publicado podría leer este calendario. ¿Publicarlo?';

  @override
  String get nextcloudTrash => 'Calendarios y tareas eliminados';

  @override
  String get nextcloudTrashEmpty =>
      'No hay elementos de calendario eliminados.';

  @override
  String get nextcloudRestore => 'Restaurar';

  @override
  String get nextcloudPermanentDelete => 'Eliminar permanentemente';

  @override
  String get nextcloudPermanentDeleteWarning =>
      '¿Eliminar este elemento permanentemente? No podrá restaurarse desde la papelera de calendarios de Nextcloud.';

  @override
  String get nextcloudOperationDenied =>
      'Nextcloud no permitió esta operación.';

  @override
  String get nextcloudUnsupported => 'El servidor no admite esta operación.';

  @override
  String get nextcloudPendingChanges =>
      'Guarda o descarta los cambios de la colección antes de cerrar.';

  @override
  String get nextcloudServerUnavailable =>
      'No se pudo conectar con Nextcloud. La caché y los cambios pendientes permanecen intactos.';

  @override
  String get mapsShow => 'Mostrar en el mapa';

  @override
  String get openLink => 'Abrir enlace';

  @override
  String get externalLocationOpenFailed =>
      'No se pudo abrir la ubicación en una aplicación externa.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'No se pudo reprogramar el evento. Su horario guardado no ha cambiado.';

  @override
  String get scheduleRescheduleStale =>
      'Este evento cambió mientras lo arrastrabas. Inténtalo de nuevo.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'Se guardó el nuevo horario, pero no se pudieron actualizar los recordatorios.';

  @override
  String get moveUp => 'Mover hacia arriba';

  @override
  String get moveDown => 'Mover hacia abajo';

  @override
  String get windowsSupport => 'Soporte';

  @override
  String get windowsThirdPartyLicenses => 'Licencias de terceros';

  @override
  String get windowsSearch => 'Buscar';

  @override
  String get windowsStartupDisabledByUser =>
      'Desactivado por el usuario en Configuración de Windows.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Desactivado por una directiva de Windows.';

  @override
  String get windowsStartupUnavailable =>
      'Disponible después de instalar BusyMax desde un paquete MSIX.';

  @override
  String get windowsReminderExitNotice =>
      'Los recordatorios se detienen al cerrar BusyMax por completo. Déjalo ejecutándose en segundo plano para recibirlos.';

  @override
  String get windowsProductVersionLabel => 'Versión del producto';

  @override
  String get windowsPackageVersionLabel => 'Versión del paquete de Windows';

  @override
  String get windowsUnpackaged => 'Sin empaquetar';

  @override
  String get windowsAgendaLoadMore => 'Cargar más elementos de la agenda';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'lunes',
      'TU': 'martes',
      'WE': 'miércoles',
      'TH': 'jueves',
      'FR': 'viernes',
      'SA': 'sábado',
      'SU': 'domingo',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'los días $first y $second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency los días $firstDay y $secondDay de $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency el día $day de $firstMonth y $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency los días $firstDay y $secondDay de $firstMonth y $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency los días $days de $firstMonth y $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Conecta cuentas de Google, Microsoft, Calendario de Apple iCloud o Nextcloud.';

  @override
  String get googlePermissionsConsentNotice =>
      'En la pantalla de permisos de Google, selecciona los permisos de Calendario y Tareas.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Los permisos de Google Calendar y Google Tasks son obligatorios. Inténtalo de nuevo y selecciona ambas casillas.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'Este proveedor no está configurado.';

  @override
  String get waitingForGoogleSignIn =>
      'Esperando el inicio de sesión de Google...';

  @override
  String get waitingForMicrosoftSignIn =>
      'Esperando el inicio de sesión de Microsoft...';

  @override
  String get microsoftSignInNotConfigured =>
      'El inicio de sesión de Microsoft no está configurado. Define MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Cancelar';

  @override
  String get close => 'Cerrar';

  @override
  String get windowMinimize => 'Minimizar';

  @override
  String get windowMaximize => 'Maximizar';

  @override
  String get windowRestore => 'Restaurar';

  @override
  String get exit => 'Salir';

  @override
  String get options => 'Opciones';

  @override
  String get hide => 'Ocultar';

  @override
  String get show => 'Mostrar';

  @override
  String get export => 'Exportar';

  @override
  String get save => 'Guardar';

  @override
  String get settings => 'Configuración';

  @override
  String get all => 'Todo';

  @override
  String get calendarEvents => 'Eventos';

  @override
  String get calendarTasks => 'Tareas';

  @override
  String get calendar => 'Calendario';

  @override
  String get calendars => 'Calendarios';

  @override
  String get newCalendar => 'Nuevo calendario';

  @override
  String get calendarColor => 'Color del calendario';

  @override
  String calendarColorOption(int number) {
    return 'Opción de color $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'Este proveedor no admite la gestión de calendarios en BusyMax.';

  @override
  String get primaryCalendarCannotDelete =>
      'El calendario principal no se puede eliminar.';

  @override
  String calendarCreateFailed(String error) {
    return 'No se pudo crear el calendario: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'El calendario se creó, pero BusyMax no pudo actualizar la cuenta. Aparecerá después de la próxima sincronización.';

  @override
  String calendarUpdateFailed(String error) {
    return 'No se pudo actualizar el calendario: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'No se pudo eliminar el calendario: $error';
  }

  @override
  String get newEvent => 'Nuevo evento';

  @override
  String get refreshCalendar => 'Actualizar calendario';

  @override
  String get openInProvider => 'Abrir en el proveedor';

  @override
  String get linkedResources => 'Recursos vinculados';

  @override
  String get noLinkedResources => 'No hay recursos vinculados';

  @override
  String get attachments => 'Archivos adjuntos';

  @override
  String get attachmentsNotLoaded => 'Archivos adjuntos no cargados';

  @override
  String get hideFromSchedule => 'Ocultar de la agenda';

  @override
  String get showInSchedule => 'Mostrar en la agenda';

  @override
  String get noCalendarsSynced => 'Aún no hay calendarios sincronizados.';

  @override
  String get allDay => 'Todo el día';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString más';
  }

  @override
  String get noEventsOrTasks => 'No hay eventos ni tareas';

  @override
  String get scheduleLoading => 'Cargando la agenda...';

  @override
  String get scheduleUnavailable => 'Agenda no disponible';

  @override
  String get scheduleNoSources =>
      'No hay calendarios ni listas de tareas visibles';

  @override
  String get scheduleNoSourcesDescription =>
      'Elige qué mostrar en Configuración y, después, actualiza la agenda.';

  @override
  String get scheduleNoSearchResults => 'No hay eventos ni tareas coincidentes';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Prueba con otra búsqueda o borra los filtros actuales.';

  @override
  String get refresh => 'Actualizar';

  @override
  String get trayOpenBusyMax => 'Abrir BusyMax';

  @override
  String get trayShowBusyMax => 'Mostrar BusyMax';

  @override
  String get trayNewEvent => 'Evento nuevo…';

  @override
  String get trayNewTask => 'Tarea nueva…';

  @override
  String get trayToday => 'Hoy';

  @override
  String get trayAllDay => 'Todo el día';

  @override
  String get trayNow => 'Ahora';

  @override
  String get trayCalendarEvent => 'Evento del calendario';

  @override
  String get trayUntitledEvent => 'Evento sin título';

  @override
  String get trayNothingElseToday => 'Nada más hoy';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count tareas vencen hoy',
      one: '1 tarea vence hoy',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Abrir la agenda de hoy';

  @override
  String get traySyncNow => 'Sincronizar ahora';

  @override
  String get traySyncing => 'Sincronizando…';

  @override
  String get trayNotConnected => 'No conectado';

  @override
  String get trayNotYetSynced => 'Aún no sincronizado';

  @override
  String get trayLastSyncedJustNow => 'Sincronizado ahora mismo';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado hace $count minutos',
      one: 'Sincronizado hace 1 minuto',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado hace $count horas',
      one: 'Sincronizado hace 1 hora',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado hace $count días',
      one: 'Sincronizado hace 1 día',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Configuración';

  @override
  String get trayQuitBusyMax => 'Salir de BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Cargar más tareas vencidas';

  @override
  String get agendaLoadMoreNoDate => 'Cargar más tareas sin fecha';

  @override
  String get viewDay => 'Día';

  @override
  String get viewWeek => 'Semana';

  @override
  String get viewMonth => 'Mes';

  @override
  String get viewYear => 'Año';

  @override
  String get viewAgenda => 'Vista de agenda';

  @override
  String get scheduleSettings => 'Agenda';

  @override
  String get scheduleDisplaySettings => 'Visualización de agenda';

  @override
  String get newEventsAndTasks => 'Nuevos eventos y tareas';

  @override
  String get defaultCalendar => 'Calendario predeterminado';

  @override
  String get defaultTaskList => 'Lista de tareas predeterminada';

  @override
  String get lastUsed => 'Último utilizado';

  @override
  String get scheduleDisplayHoursDescription =>
      'Las vistas de día y semana muestran inicialmente este intervalo horario. Los elementos anteriores o posteriores lo amplían cuando es necesario.';

  @override
  String get scheduleDayStartsAt => 'El día empieza a las';

  @override
  String get scheduleDayEndsAt => 'El día termina a las';

  @override
  String get sourceCalendar => 'Calendario';

  @override
  String get sourceTaskList => 'Lista de tareas';

  @override
  String get createChoiceTitle => 'Crear';

  @override
  String get createEventAtTime => 'Evento';

  @override
  String get createTaskAtDate => 'Tarea';

  @override
  String get editEvent => 'Editar evento';

  @override
  String get eventTitle => 'Título del evento';

  @override
  String get location => 'Ubicación';

  @override
  String get timeSlot => 'Franja horaria';

  @override
  String get startDateTime => 'Fecha/hora de inicio';

  @override
  String get endDateTime => 'Fecha/hora de fin';

  @override
  String get doesNotRepeat => 'No se repite';

  @override
  String get defaultReminder => 'Recordatorio predeterminado';

  @override
  String get guests => 'Invitados';

  @override
  String get noGuests => 'No hay invitados';

  @override
  String get attendeeRequired => 'Obligatorio';

  @override
  String get attendeeOptional => 'Opcional';

  @override
  String get meetingSection => 'Reunión';

  @override
  String get addGoogleMeet => 'Añadir Google Meet';

  @override
  String get addTeamsMeeting => 'Añadir reunión de Microsoft Teams';

  @override
  String get onlineMeetingAdded => 'Reunión en línea añadida';

  @override
  String get requestResponses => 'Solicitar respuestas';

  @override
  String get requestResponsesDescription =>
      'Pide a los invitados que respondan a la invitación.';

  @override
  String get hideGuestList => 'Ocultar la lista de invitados';

  @override
  String get hideGuestListDescription =>
      'Los invitados no pueden ver quién más ha sido invitado.';

  @override
  String get allowNewTimeProposals => 'Permitir nuevas propuestas de horario';

  @override
  String get allowNewTimeProposalsDescription =>
      'Los invitados pueden sugerir otra hora para la reunión.';

  @override
  String get notifyGuestsTitle => '¿Notificar a los invitados?';

  @override
  String get notifyGuestsSaveMessage =>
      'Esta reunión tiene invitados. ¿Enviar invitaciones o actualizaciones del evento al guardarla?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Esta reunión tiene invitados. ¿Enviar una cancelación al eliminarla?';

  @override
  String get sendUpdates => 'Enviar actualizaciones';

  @override
  String get sendCancellation => 'Enviar cancelación';

  @override
  String get doNotSend => 'No enviar';

  @override
  String get microsoftNotifyGuestsSaveTitle => '¿Guardar la reunión?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft enviará invitaciones o actualizaciones del evento a los invitados.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => '¿Eliminar la reunión?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft enviará una cancelación a los invitados.';

  @override
  String get organizer => 'Organizador';

  @override
  String get yourResponse => 'Tu respuesta';

  @override
  String get guestResponses => 'Respuestas de los invitados';

  @override
  String get respond => 'Responder';

  @override
  String get acceptInvitation => 'Aceptar';

  @override
  String get tentativeInvitation => 'Provisional';

  @override
  String get declineInvitation => 'Rechazar';

  @override
  String get joinMeeting => 'Unirse a la reunión';

  @override
  String get responseAccepted => 'Aceptada';

  @override
  String get responseTentative => 'Provisional';

  @override
  String get responseDeclined => 'Rechazada';

  @override
  String get responseNeedsAction => 'Esperando respuesta';

  @override
  String get responseNotResponded => 'Sin respuesta';

  @override
  String get responseOrganizer => 'Organizador';

  @override
  String invitationResponseFailed(String error) {
    return 'No se pudo enviar tu respuesta: $error';
  }

  @override
  String get joinMeetingFailed => 'No se pudo abrir el enlace de la reunión.';

  @override
  String get description => 'Descripción';

  @override
  String get availabilityShowAs => 'Disponibilidad / Mostrar como';

  @override
  String get busy => 'Ocupado';

  @override
  String get visibility => 'Visibilidad';

  @override
  String get defaultVisibility => 'Visibilidad predeterminada';

  @override
  String get conference => 'Conferencia';

  @override
  String get noConference => 'Sin conferencia';

  @override
  String get providerCalendar => 'Calendario del proveedor';

  @override
  String get formatBoldShortLabel => 'N';

  @override
  String get formatBoldTooltip => 'Negrita';

  @override
  String get formatItalicShortLabel => 'C';

  @override
  String get formatItalicTooltip => 'Cursiva';

  @override
  String get formatUnderlineShortLabel => 'S';

  @override
  String get formatUnderlineTooltip => 'Subrayado';

  @override
  String reminderMinutesBefore(int minutes) {
    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutes minutos antes',
      one: '1 minuto antes',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'A la hora de inicio';

  @override
  String reminderHoursBefore(int hours) {
    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hours horas antes',
      one: '1 hora antes',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$days días antes',
      one: '1 día antes',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Libre';

  @override
  String get availabilityTentative => 'Provisional';

  @override
  String get availabilityOutOfOffice => 'Fuera de la oficina';

  @override
  String get availabilityWorkingElsewhere => 'Trabajando en otro lugar';

  @override
  String get visibilityDefault => 'Predeterminada';

  @override
  String get visibilityPublic => 'Pública';

  @override
  String get visibilityPrivate => 'Privada';

  @override
  String get visibilityConfidential => 'Confidencial';

  @override
  String get sensitivityNormal => 'Normal';

  @override
  String get sensitivityPersonal => 'Personal';

  @override
  String get tasks => 'Tareas';

  @override
  String get allTasks => 'Todas las tareas';

  @override
  String tasksInList(String title) {
    return 'Tareas en $title';
  }

  @override
  String get taskLists => 'Listas de tareas';

  @override
  String get navigation => 'Navegación';

  @override
  String get mainMenu => 'Menú principal';

  @override
  String get keyboardShortcuts => 'Atajos de teclado';

  @override
  String get shortcutGroupGeneral => 'Atajos generales';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Mostrar esta referencia de atajos';

  @override
  String get shortcutGroupNavigation => 'Navegación';

  @override
  String get shortcutNextPeriod => 'Periodo siguiente';

  @override
  String get shortcutNextPeriodDescription =>
      'Semana siguiente en la vista semanal, mes siguiente en la vista mensual, etc.';

  @override
  String get shortcutPreviousPeriod => 'Periodo anterior';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Semana anterior en la vista semanal, mes anterior en la vista mensual, etc.';

  @override
  String get shortcutJumpToToday => 'Ir a la fecha de hoy';

  @override
  String get shortcutGroupView => 'Vista';

  @override
  String get viewSelector => 'Vista';

  @override
  String get shortcutDayView => 'Vista de día';

  @override
  String get shortcutWeekView => 'Vista de semana';

  @override
  String get shortcutMonthView => 'Vista de mes';

  @override
  String get shortcutYearView => 'Vista de año';

  @override
  String get shortcutAgendaView => 'Vista de agenda';

  @override
  String get shortcutGroupCreateAndEdit => 'Crear y editar';

  @override
  String get shortcutSaveItem => 'Guardar evento o tarea';

  @override
  String get shortcutDeleteItem => 'Eliminar evento o tarea';

  @override
  String get shortcutGroupTaskEditing => 'Edición de tareas';

  @override
  String get shortcutCancelEditing => 'Cancelar edición';

  @override
  String get shortcutCancelEditingDescription =>
      'Cerrar la edición o los detalles de la tarea';

  @override
  String get aboutBusyMax => 'Acerca de BusyMax';

  @override
  String get aboutBusyMaxDescription => 'Calendario y tareas';

  @override
  String get license => 'Licencia';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Sitio web';

  @override
  String get sourceCode => 'Código fuente';

  @override
  String get reportAnIssue => 'Informar de un problema';

  @override
  String get sendFeedback => 'Enviar comentarios';

  @override
  String get feedbackSubmit => 'Enviar';

  @override
  String get feedbackCategory => 'Categoría';

  @override
  String get feedbackSelectCategory => 'Selecciona una categoría';

  @override
  String get feedbackCategoryProblem => 'Problema o error';

  @override
  String get feedbackCategoryFeature => 'Solicitud de función';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'Problema de privacidad o seguridad';

  @override
  String get feedbackCategoryUsability => 'Problema de usabilidad';

  @override
  String get feedbackCategoryOther => 'Otro';

  @override
  String get feedbackSubject => 'Asunto';

  @override
  String get feedbackDetailedMessage => 'Mensaje detallado';

  @override
  String get feedbackReplyEmail =>
      'Correo electrónico para recibir una respuesta (opcional)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Incluir detalles técnicos';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Incluye únicamente el nombre y la versión del sistema operativo y la configuración regional de la aplicación. No se incluyen registros, datos de cuenta, nombres de archivos ni otros diagnósticos.';

  @override
  String get feedbackCategoryRequired => 'Selecciona una categoría.';

  @override
  String get feedbackSubjectLengthError =>
      'El asunto debe tener entre 3 y 120 caracteres.';

  @override
  String get feedbackMessageLengthError =>
      'El mensaje debe tener entre 10 y 5.000 caracteres.';

  @override
  String get feedbackInvalidEmail =>
      'Introduce una dirección de correo electrónico válida.';

  @override
  String get feedbackConnectionError =>
      'No se pudo conectar con BusyStack. Comprueba tu conexión e inténtalo de nuevo.';

  @override
  String get feedbackTimeoutError =>
      'Se agotó el tiempo de espera de la solicitud. Tus comentarios no se han borrado; inténtalo de nuevo.';

  @override
  String get feedbackRateLimitedError =>
      'Se han enviado demasiados comentarios desde esta red. Espera e inténtalo de nuevo.';

  @override
  String get feedbackRejectedError =>
      'El servidor rechazó el envío. Revisa los campos e inténtalo de nuevo.';

  @override
  String get feedbackServerError =>
      'BusyStack no puede aceptar tus comentarios ahora. Tus comentarios no se han borrado; inténtalo de nuevo.';

  @override
  String feedbackSuccess(String id) {
    return 'Comentarios enviados. Referencia: $id';
  }

  @override
  String get toggleSidebar => 'Mostrar u ocultar la barra lateral';

  @override
  String get showSidebar => 'Mostrar panel lateral';

  @override
  String get hideSidebar => 'Ocultar panel lateral';

  @override
  String get accounts => 'Cuentas';

  @override
  String get currentAccount => 'Cuenta actual';

  @override
  String get switchAccount => 'Cambiar cuenta';

  @override
  String get addGoogleAccount => 'Añadir cuenta de Google';

  @override
  String get addMicrosoftAccount => 'Añadir cuenta de Microsoft';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Sesión iniciada';

  @override
  String get removeAccount => 'Eliminar cuenta…';

  @override
  String get removingAccount => 'Eliminando cuenta…';

  @override
  String get removeAccountDescription =>
      'Detener la sincronización y eliminar de este dispositivo los datos de esta cuenta.';

  @override
  String removeAccountTitle(String account) {
    return '¿Quitar $account de BusyMax?';
  }

  @override
  String get removeAccountConfirmation =>
      'Esto elimina de este dispositivo las tareas, calendarios, eventos, recordatorios y cambios sin conexión pendientes almacenados en caché. Se perderán los cambios no sincronizados. No se eliminan las copias de calendarios, eventos, listas de tareas ni tareas del proveedor.';

  @override
  String get revokeGoogleAccess =>
      'Revocar también el acceso de BusyMax a esta cuenta de Google';

  @override
  String get revokeGoogleAccessDescription =>
      'Tendrás que volver a conceder acceso antes de reconectar la cuenta.';

  @override
  String get removeAccountAction => 'Eliminar cuenta';

  @override
  String get removeAccountFailed =>
      'No se pudo terminar de eliminar la cuenta. Inténtalo de nuevo.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'La cuenta se eliminó de este dispositivo, pero BusyMax no pudo revocar su acceso a tu cuenta de Google. Puedes revocarlo desde tu cuenta de Google.';

  @override
  String get newTaskList => 'Lista de tareas nueva';

  @override
  String taskListCreateFailed(String error) {
    return 'No se pudo crear la lista de tareas: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'No se pudo cambiar el nombre de la lista de tareas: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'No se pudo eliminar la lista de tareas: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Sincroniza la cuenta o resuelve los cambios bloqueados de esta lista de tareas en Diagnóstico antes de eliminar o quitar la lista.';

  @override
  String get signInToViewTaskLists =>
      'Inicia sesión para ver las listas de tareas.';

  @override
  String get noTaskListsSynced => 'Aún no hay listas de tareas sincronizadas.';

  @override
  String get listActions => 'Acciones de lista';

  @override
  String get rename => 'Cambiar nombre';

  @override
  String get delete => 'Eliminar';

  @override
  String get renameList => 'Cambiar nombre de lista';

  @override
  String get deleteList => 'Eliminar lista';

  @override
  String get unshare => 'Dejar de compartir';

  @override
  String get readOnlyTaskListCannotRename =>
      'Esta lista de tareas es de solo lectura y no se puede cambiar su nombre.';

  @override
  String get taskListCannotDelete =>
      'No se puede eliminar esta lista de tareas con tus permisos actuales.';

  @override
  String get builtInMicrosoftList => 'Integrada';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Las listas integradas de Microsoft To Do no se pueden cambiar de nombre ni eliminar.';

  @override
  String deleteListConfirmation(String title) {
    return '¿Eliminar «$title» de Google Tasks?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '¿Eliminar «$title» y todas sus tareas?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return '¿Dejar de compartir «$title» con esta cuenta?';
  }

  @override
  String get deleteEvent => 'Eliminar evento';

  @override
  String get title => 'Título';

  @override
  String get create => 'Crear';

  @override
  String get newTask => 'Nueva tarea';

  @override
  String get clearCompleted => 'Borrar completadas';

  @override
  String get refreshList => 'Actualizar lista';

  @override
  String get refreshAll => 'Actualizar todo';

  @override
  String get listRefreshed => 'Lista actualizada.';

  @override
  String get allTasksRefreshed => 'Todas las cuentas se actualizaron.';

  @override
  String exportedFile(String path) {
    return 'Exportado a $path';
  }

  @override
  String exportFailed(String error) {
    return 'Error al exportar: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Error al actualizar: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Selecciona o crea una lista de tareas para empezar.';

  @override
  String get signInToViewTasks => 'Inicia sesión para ver las tareas.';

  @override
  String get noTasks => 'No hay tareas.';

  @override
  String get noTasksYet => 'Aún no hay tareas';

  @override
  String get noTasksYetMessage =>
      'Crea una tarea o actualiza tus cuentas para empezar.';

  @override
  String get noTasksInList => 'No hay tareas en esta lista.';

  @override
  String get overdue => 'Vencidas';

  @override
  String get today => 'Hoy';

  @override
  String get tomorrow => 'Mañana';

  @override
  String get upcoming => 'Próximas';

  @override
  String get noDate => 'Sin fecha';

  @override
  String get completed => 'Completadas';

  @override
  String duePrefix(String date) {
    return 'Vence $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date, $time';
  }

  @override
  String get taskDetails => 'Detalles de la tarea';

  @override
  String get editTask => 'Editar tarea';

  @override
  String get noTaskSelected => 'No hay tarea seleccionada.';

  @override
  String get noTaskSelectedHelper =>
      'Selecciona una tarea para ver y editar sus detalles.';

  @override
  String get taskUnavailable => 'Tarea no disponible.';

  @override
  String get signInToEditTasks => 'Inicia sesión para editar tareas.';

  @override
  String get refreshTask => 'Actualizar tarea';

  @override
  String get primarySection => 'Principal';

  @override
  String get statusSection => 'Estado';

  @override
  String get openStatus => 'Abierta';

  @override
  String get doneStatus => 'Hecha';

  @override
  String get taskStatus => 'Estado';

  @override
  String get taskStatusNone => 'Sin estado';

  @override
  String get taskStatusNeedsAction => 'Necesita una acción';

  @override
  String get taskStatusInProcess => 'En curso';

  @override
  String get taskStatusCompleted => 'Completada';

  @override
  String get taskStatusCancelled => 'Cancelada';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% completada';
  }

  @override
  String get completionDate => 'Fecha de finalización';

  @override
  String get priority => 'Prioridad';

  @override
  String get priorityNone => 'Sin prioridad';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridad $priorityString · Alta';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridad $priorityString · Media';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridad $priorityString · Baja';
  }

  @override
  String get taskUrl => 'URL de la tarea';

  @override
  String get invalidTaskUrl =>
      'Introduce una URL absoluta, incluido su esquema.';

  @override
  String get classification => 'Clasificación';

  @override
  String get classificationPublic =>
      'Al compartirla, mostrar la tarea completa';

  @override
  String get classificationConfidential =>
      'Al compartirla, mostrar solo la disponibilidad';

  @override
  String get classificationPrivate => 'Al compartirla, ocultar esta tarea';

  @override
  String get pinTask => 'Fijar tarea';

  @override
  String get notes => 'Notas';

  @override
  String get dueDate => 'Fecha de vencimiento';

  @override
  String get clearDueDate => 'Borrar fecha de vencimiento';

  @override
  String get dueTime => 'Hora de vencimiento';

  @override
  String get startDate => 'Fecha de inicio';

  @override
  String get startTime => 'Hora de inicio';

  @override
  String get endDate => 'Fecha de fin';

  @override
  String get endTime => 'Hora de fin';

  @override
  String get reminderDate => 'Fecha del recordatorio';

  @override
  String get reminderTime => 'Hora del recordatorio';

  @override
  String get reminder => 'Recordatorio';

  @override
  String get addReminder => 'Añadir recordatorio';

  @override
  String get reminders => 'Recordatorios';

  @override
  String get noReminders => 'Sin recordatorios';

  @override
  String get editReminder => 'Editar recordatorio';

  @override
  String get beforeTaskStarts => 'Antes de que empiece la tarea';

  @override
  String get beforeTaskDue => 'Antes del vencimiento de la tarea';

  @override
  String get afterTaskStarts => 'Después de que empiece la tarea';

  @override
  String get afterTaskDue => 'Después del vencimiento de la tarea';

  @override
  String get relativeToTaskStart =>
      'En relación con la fecha de inicio de la tarea';

  @override
  String get relativeToTaskDue =>
      'En relación con la fecha de vencimiento de la tarea';

  @override
  String get reminderTimeOfDay => 'Hora del día';

  @override
  String get absoluteReminder => 'En una fecha y hora';

  @override
  String get reminderAmount => 'Cantidad';

  @override
  String get reminderUnit => 'Unidad';

  @override
  String get reminderUnitSeconds => 'Segundos';

  @override
  String get reminderUnitMinutes => 'Minutos';

  @override
  String get reminderUnitHours => 'Horas';

  @override
  String get reminderUnitDays => 'Días';

  @override
  String get reminderUnitWeeks => 'Semanas';

  @override
  String get reminderAtTaskStart => 'Al comenzar la tarea';

  @override
  String get reminderAtTaskDue => 'Al vencer la tarea';

  @override
  String get unsupportedReminder =>
      'Este tipo de recordatorio se conserva, pero no se puede editar su hora.';

  @override
  String get relatedRemindersTitle =>
      '¿Conservar los recordatorios relacionados?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Esta fecha tiene $countString recordatorios relacionados. ¿Quieres conservarlos en su fecha y hora actuales?';
  }

  @override
  String get discardRelatedReminders => 'Descartar recordatorios';

  @override
  String get keepRelatedReminders => 'Conservar recordatorios';

  @override
  String get addGuest => 'Añadir invitado';

  @override
  String get addGuestEmail => 'Añadir correo del invitado';

  @override
  String get removeReminder => 'Quitar recordatorio';

  @override
  String get off => 'Desactivado';

  @override
  String get repeat => 'Repetir';

  @override
  String get repeatNone => 'Ninguna';

  @override
  String get noneValue => 'Ninguno';

  @override
  String get repeatDaily => 'Diaria';

  @override
  String get repeatWeekly => 'Semanal';

  @override
  String get repeatMonthly => 'Mensual';

  @override
  String get repeatYearly => 'Anual';

  @override
  String get repeatEvery => 'Intervalo';

  @override
  String get repeatOn => 'Repetir en';

  @override
  String get repeatEnd => 'Finalizar repetición';

  @override
  String get repeatNever => 'Nunca';

  @override
  String get repeatUntil => 'En una fecha';

  @override
  String get repeatAfter => 'Después de un número de repeticiones';

  @override
  String get repeatCount => 'Repeticiones';

  @override
  String get repeatDayOfMonth => 'Días del mes';

  @override
  String get repeatMonths => 'Meses';

  @override
  String get repeatOrdinal => 'Posición del día de la semana';

  @override
  String get repeatSpecificDays => 'Días específicos';

  @override
  String get repeatFirst => 'Primero';

  @override
  String get repeatSecond => 'Segundo';

  @override
  String get repeatThird => 'Tercero';

  @override
  String get repeatFourth => 'Cuarto';

  @override
  String get repeatFifth => 'Quinto';

  @override
  String get repeatSecondToLast => 'Penúltimo';

  @override
  String get repeatLast => 'Último';

  @override
  String get repeatAnyDay => 'Día';

  @override
  String get repeatWeekday => 'Día laborable';

  @override
  String get repeatWeekendDay => 'Día de fin de semana';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'lunes',
      'TU': 'martes',
      'WE': 'miércoles',
      'TH': 'jueves',
      'FR': 'viernes',
      'SA': 'sábado',
      'SU': 'domingo',
      'day': 'día',
      'weekday': 'día laborable',
      'weekend': 'día de fin de semana',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Cada $countString días';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Cada $countString semanas';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Cada $countString meses';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Cada $countString años';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return 'los $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'el día $days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'el primer $days',
      'second': 'el segundo $days',
      'third': 'el tercer $days',
      'fourth': 'el cuarto $days',
      'fifth': 'el quinto $days',
      'secondToLast': 'el penúltimo $days',
      'last': 'el último $days',
      'other': 'en $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'en $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString veces',
      one: '$countString vez',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'hasta $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'Esta regla de repetición usa opciones que este editor no modifica.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'Esta lista no admite este patrón de repetición. Cambia el patrón o elige otra lista.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Añade una fecha de inicio o de vencimiento para usar este patrón, o desactiva la repetición.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Esta repetición no se puede usar con $provider.';
  }

  @override
  String get importance => 'Importancia';

  @override
  String get importanceLow => 'Baja';

  @override
  String get importanceNormal => 'Media';

  @override
  String get importanceHigh => 'Alta';

  @override
  String get categories => 'Categorías';

  @override
  String get scheduleSection => 'Programación';

  @override
  String get dueGroup => 'Vencimiento';

  @override
  String get startGroup => 'Inicio';

  @override
  String get reminderGroup => 'Recordatorio';

  @override
  String get organizationSection => 'Organización';

  @override
  String get actionsSection => 'Acciones';

  @override
  String get advancedSection => 'Avanzado';

  @override
  String get addCategory => 'Añadir categoría';

  @override
  String get list => 'Lista';

  @override
  String get microsoftMoveUnsupported =>
      'En esta versión, no se pueden mover tareas entre listas en cuentas de Microsoft To Do.';

  @override
  String get createSubtask => 'Crear subtarea';

  @override
  String get subtasks => 'Subtareas';

  @override
  String get duplicateTask => 'Duplicar tarea';

  @override
  String get taskDuplicated => 'Tarea duplicada.';

  @override
  String taskDuplicateFailed(String error) {
    return 'No se pudo duplicar la tarea: $error';
  }

  @override
  String get hideSubtasks => 'Ocultar subtareas';

  @override
  String get hideClosedSubtasks => 'Ocultar subtareas cerradas';

  @override
  String get moveToTop => 'Mover al principio';

  @override
  String get deleteTask => 'Eliminar tarea';

  @override
  String get newSubtask => 'Nueva subtarea';

  @override
  String deleteTaskConfirmation(String title) {
    return '¿Eliminar \"$title\"?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Esto también elimina la tarea original de Documentos de Google o los espacios de Chat.';

  @override
  String get metadata => 'Metadatos';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Actualizada';

  @override
  String get parent => 'Tarea principal';

  @override
  String get position => 'Posición';

  @override
  String get webLink => 'Enlace web';

  @override
  String get assignment => 'Asignación';

  @override
  String get localState => 'Estado local';

  @override
  String get pendingSync => 'Sincronización pendiente';

  @override
  String get synced => 'Sincronizada';

  @override
  String get account => 'Cuenta';

  @override
  String get sync => 'Sincronización';

  @override
  String get forceFullResync => 'Forzar una resincronización completa';

  @override
  String get forceFullResyncDescription =>
      'Vuelve a cargar por completo los datos de todas las cuentas conectadas. Esta opción solo debe usarse para solucionar problemas de sincronización.';

  @override
  String get runInBackgroundWhenClosed =>
      'Seguir ejecutándose al cerrar la ventana';

  @override
  String get showTrayIcon => 'Mostrar el icono en la bandeja del sistema';

  @override
  String get startMinimizedToTray =>
      'Iniciar minimizado en la bandeja del sistema';

  @override
  String get launchAtLogin => 'Iniciar al acceder';

  @override
  String get launchAtLoginDescription =>
      'Inicia BusyMax en segundo plano para que los recordatorios funcionen después de acceder.';

  @override
  String get launchAtLoginFailed =>
      'No se pudo actualizar el inicio al acceder.';

  @override
  String get requiresTrayIcon => 'Requiere el icono de la bandeja del sistema.';

  @override
  String get syncComplete => 'Sincronización completa.';

  @override
  String syncFailed(String error) {
    return 'Error de sincronización: $error';
  }

  @override
  String get notifySyncFailures =>
      'Notificaciones de errores de sincronización';

  @override
  String get notifyConflicts => 'Notificaciones de conflictos';

  @override
  String get notifyDueToday => 'Notificaciones de tareas que vencen hoy';

  @override
  String get eventReminders => 'Recordatorios de eventos';

  @override
  String get onState => 'Activado';

  @override
  String get taskReminders => 'Recordatorios de tareas';

  @override
  String get notificationDetailLevel =>
      'Nivel de detalle de las notificaciones';

  @override
  String get notificationDetailPrivate => 'Privado';

  @override
  String get notificationDetailNormal => 'Estándar';

  @override
  String get quietHours => 'Horario de silencio';

  @override
  String get quietHoursDescription =>
      'Pausar las notificaciones durante este período.';

  @override
  String get quietHoursStart => 'Inicio del horario de silencio';

  @override
  String get quietHoursEnd => 'Fin del horario de silencio';

  @override
  String get notifications => 'Notificaciones';

  @override
  String get windowsNotificationsUnavailable =>
      'Las notificaciones de Windows no están disponibles';

  @override
  String get windowsNotificationsUnpackaged =>
      'Esta ejecución de desarrollo sin empaquetar no puede usar las notificaciones de Windows. Instala el MSIX firmado para pruebas para comprobar los recordatorios.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax no pudo inicializar las notificaciones de Windows. Los recordatorios no aparecerán hasta que se resuelva este problema de instalación.';

  @override
  String get appearance => 'Apariencia';

  @override
  String get theme => 'Tema';

  @override
  String get themeSystem => 'Sistema';

  @override
  String get settingsSystem => 'Sistema';

  @override
  String get themeLight => 'Claro';

  @override
  String get themeDark => 'Oscuro';

  @override
  String get themeFamily => 'Familia de temas';

  @override
  String get themeFamilyYaru => 'Tema nativo de Ubuntu (Yaru)';

  @override
  String get localization => 'Localización';

  @override
  String get currentLocale => 'Configuración regional actual';

  @override
  String get privacy => 'Privacidad';

  @override
  String get redactTaskContentInDiagnostics =>
      'Ocultar contenido de tareas en diagnósticos';

  @override
  String get developerDiagnostics => 'Diagnósticos de desarrollo';

  @override
  String get diagnostics => 'Diagnósticos';

  @override
  String get apiInspectorDisabled => 'Mostrar inspector de API';

  @override
  String get googleTasksApi => 'API de Google Tasks';

  @override
  String discoveryRevision(String revision) {
    return 'Revisión de Discovery: $revision';
  }

  @override
  String get implementedMethods => 'Métodos implementados';

  @override
  String get supportsTasksScopes =>
      'Admite los alcances tasks y tasks.readonly';

  @override
  String get requiresTasksScope => 'Requiere el alcance tasks';

  @override
  String get blockedPendingOperations => 'Operaciones pendientes bloqueadas';

  @override
  String get signInToInspectPendingOperations =>
      'Inicia sesión para inspeccionar operaciones pendientes.';

  @override
  String get noBlockedPendingOperations =>
      'No hay operaciones pendientes bloqueadas.';

  @override
  String get operationActions => 'Acciones de la operación';

  @override
  String pendingOpListId(String id) {
    return 'lista=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'tarea=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'intentos=$countString';
  }

  @override
  String get retry => 'Reintentar';

  @override
  String get discard => 'Descartar';

  @override
  String get discardChangesAction => 'Descartar';

  @override
  String get discardChanges => '¿Descartar cambios?';

  @override
  String get discardChangesConfirmation =>
      'Esto descarta las ediciones no guardadas de esta tarea.';

  @override
  String get retryCompleted => 'Reintento completado.';

  @override
  String get discardPendingOperation => '¿Descartar operación pendiente?';

  @override
  String get discardPendingOperationConfirmation =>
      'Esto elimina la operación local bloqueada. En la próxima sincronización, se volverán a cargar los datos desde Google Tasks.';

  @override
  String get pendingOperationDiscarded => 'Operación pendiente descartada.';

  @override
  String get syncFailureNotificationTitle =>
      'Falló la sincronización de BusyMax';

  @override
  String syncFailureNotificationBody(String message) {
    return 'Falló la sincronización en segundo plano. $message';
  }

  @override
  String get conflictNotificationTitle =>
      'Conflicto de sincronización de BusyMax';

  @override
  String conflictNotificationBody(String summary) {
    return 'Se ha bloqueado un cambio local pendiente. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Tareas que vencen hoy';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString tareas vencen hoy.',
      one: 'Una tarea vence hoy.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Recordatorio de evento';

  @override
  String get taskReminderNotificationTitle => 'Recordatorio de tarea';

  @override
  String get eventReminderNotificationBody => 'El evento empieza pronto.';

  @override
  String get taskReminderNotificationBody => 'La tarea vence pronto.';

  @override
  String get notificationOpenAction => 'Abrir';

  @override
  String get notificationSnoozeAction => 'Posponer 10 minutos';

  @override
  String get notificationDismissAction => 'Cerrar';

  @override
  String get notificationDetailsHidden =>
      'Los detalles están ocultos por la configuración de privacidad.';

  @override
  String get previousMonth => 'Mes anterior';

  @override
  String get nextMonth => 'Mes siguiente';

  @override
  String get openMonthView => 'Abrir la vista mensual';

  @override
  String get previousYear => 'Año anterior';

  @override
  String get nextYear => 'Año siguiente';

  @override
  String get openYearView => 'Abrir la vista anual';

  @override
  String weekNumberTooltip(int number) {
    return 'Semana $number';
  }

  @override
  String get resizeAllDayPanel => 'Cambiar el tamaño del panel de todo el día';

  @override
  String scheduleItemCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count elementos',
      one: '1 elemento',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'Este calendario es de solo lectura.';

  @override
  String get selectTimeZone => 'Seleccionar zona horaria';

  @override
  String get searchLocations => 'Buscar ubicaciones';

  @override
  String get noLocationsFound => 'No se han encontrado ubicaciones';

  @override
  String get requiredField => 'Este campo es obligatorio.';

  @override
  String get providerConnectionDescription =>
      'Conecta calendarios y tareas de uno de estos proveedores.';

  @override
  String get appleICloudProvider => 'Calendario de Apple iCloud';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Tareas de Nextcloud';

  @override
  String get addAppleICloudAccount =>
      'Añadir cuenta del Calendario de Apple iCloud';

  @override
  String get addNextcloudAccount => 'Añadir cuenta de Nextcloud';

  @override
  String get waitingForAppleICloud => 'Conectando con Apple iCloud…';

  @override
  String get waitingForNextcloud => 'Esperando la autorización de Nextcloud…';

  @override
  String get connectAppleICloudTitle =>
      'Conectar el Calendario de Apple iCloud';

  @override
  String get appleAccountEmail => 'Correo de la cuenta de Apple';

  @override
  String get appleAppSpecificPassword => 'Contraseña específica de la app';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Crea una contraseña específica de la app después de activar la autenticación de dos factores en tu cuenta de Apple.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Restablecer la contraseña de tu cuenta de Apple revoca las contraseñas específicas de las apps.';

  @override
  String get connectNextcloudTitle => 'Conectar Nextcloud';

  @override
  String get nextcloudServerUrl => 'Servidor de Nextcloud o dirección CalDAV';

  @override
  String get nextcloudServerUrlHelp =>
      'Introduce la URL de tu servidor Nextcloud o pega la dirección CalDAV principal copiada de Nextcloud.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax abrirá el navegador. Aprueba allí el acceso y vuelve a BusyMax.';

  @override
  String get connectAccountAction => 'Conectar';

  @override
  String get cancelAccountConnection => 'Cancelar conexión';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'La cuenta se quitó localmente, pero no se pudo revocar la contraseña de app de Nextcloud.';

  @override
  String get davReauthenticationRequired =>
      'Vuelve a conectar esta cuenta para reanudar la sincronización.';

  @override
  String get davTemporarilyUnavailable =>
      'Esta cuenta no está disponible temporalmente.';

  @override
  String get davPermissionChanged =>
      'Han cambiado los permisos del servidor. Las ediciones pendientes están en pausa.';

  @override
  String get davUnsupportedServer =>
      'Este servidor o perfil de proveedor no es compatible.';

  @override
  String get collectionSettings => 'Calendarios y listas de tareas';

  @override
  String get calendarContent => 'Eventos del calendario';

  @override
  String get taskContent => 'Tareas';

  @override
  String get readOnlySharedCollection => 'Solo lectura';

  @override
  String get pendingLocally => 'Pendiente localmente';

  @override
  String get conflictBlocked => 'Bloqueado por un conflicto';

  @override
  String get authenticationBlocked => 'Bloqueado hasta volver a conectar';

  @override
  String get operationFailed => 'La operación ha fallado';

  @override
  String get keepServerVersion => 'Conservar la versión del servidor';

  @override
  String get reapplyLocalChange => 'Revisar y volver a aplicar el cambio local';

  @override
  String get duplicateLocalItem => 'Duplicar como elemento nuevo';

  @override
  String get davConnectionState => 'Estado de conexión';

  @override
  String get davConnected => 'Conectado';

  @override
  String get davConnecting => 'Conectando…';

  @override
  String get davSignedOut => 'Sesión cerrada';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Última sincronización correcta: $time';
  }

  @override
  String get davNeverSynced => 'Aún no se ha sincronizado';

  @override
  String get refreshCollections => 'Actualizar calendarios y listas de tareas';

  @override
  String nextcloudServerHost(String host) {
    return 'Servidor: $host';
  }

  @override
  String get collectionSupportsEvents => 'Calendario de eventos';

  @override
  String get collectionSupportsTasks => 'Lista de tareas';

  @override
  String get collectionSupportsEventsAndTasks => 'Eventos y tareas';

  @override
  String get writableCollection => 'Editable';

  @override
  String get sharedCollection => 'Compartido';

  @override
  String collectionLastSynced(String time) {
    return 'Última sincronización: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Problema de sincronización: $code';
  }

  @override
  String get syncConflicts => 'Conflictos de sincronización';

  @override
  String remoteChangedAt(String time) {
    return 'Cambio en el servidor: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Edición local: $summary';
  }

  @override
  String get conflictResolutionFailed => 'No se pudo resolver el conflicto.';

  @override
  String get recurringEventScope => 'Ámbito del evento recurrente';

  @override
  String get entireSeries => 'Serie completa';

  @override
  String get singleOccurrence => 'Este evento';

  @override
  String get thisAndFollowingEvents => 'Este evento y los siguientes';

  @override
  String get thisAndFutureUnavailable => 'No compatible con este proveedor.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'No se pueden mover de forma segura este evento y los siguientes. Elige este evento o toda la serie.';

  @override
  String get entireSeriesMoveUnavailable =>
      'La regla de repetición no está disponible localmente. Mueve solo este evento.';

  @override
  String get copyEventAndDeleteOriginal =>
      '¿Copiar el evento y eliminar el original?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax no puede mover este evento directamente de $source a $destination. Primero creará la copia y eliminará el original solo cuando la copia se complete correctamente. Los identificadores del evento cambiarán; los estados de respuesta de los asistentes pueden restablecerse y pueden enviarse invitaciones o cancelaciones; y es posible que no se conserven los enlaces de conferencia, los archivos adjuntos, los recordatorios, los campos específicos del proveedor ni las excepciones de repetición.';
  }

  @override
  String get copyAndDelete => 'Copiar y eliminar';

  @override
  String get chooseRecurringEventScope =>
      'Elige si este cambio se aplica a toda la serie, solo a este evento o a este y los siguientes eventos.';

  @override
  String get taskDueBeforeStart =>
      'El vencimiento no puede ser anterior al inicio.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Define una hora tanto para el inicio como para el vencimiento, o configura la tarea para todo el día.';

  @override
  String deleteCalendarConfirmation(String title) {
    return '¿Eliminar \"$title\"?';
  }

  @override
  String get setCustomCalendarName => 'Establecer nombre personalizado';

  @override
  String get setAction => 'Establecer';

  @override
  String get removeFromMyCalendars => 'Quitar de mis calendarios';

  @override
  String get removeAction => 'Quitar';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '¿Quitar \"$title\" de BusyMax? No se eliminarán el calendario ni los eventos de su propietario.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'Es posible que la carga se haya completado. Actualiza los adjuntos para comprobarlo antes de volver a subir el archivo.';

  @override
  String removeCalendarConfirmation(String title) {
    return '¿Quitar \"$title\" de tu lista de Google Calendar? No se eliminarán el calendario compartido ni sus eventos.';
  }

  @override
  String get calendarCannotRemove =>
      'Este calendario no se puede eliminar ni quitar de esta cuenta.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Espera a que terminen de sincronizarse los cambios pendientes de este calendario antes de eliminarlo o quitarlo.';

  @override
  String get calendarSubscriptions => 'Suscripciones de calendarios';

  @override
  String get calendarSubscriptionsDescription =>
      'Añade calendarios de solo lectura que se actualicen desde una URL WebCal segura.';

  @override
  String get addCalendarSubscription => 'Añadir suscripción de calendario';

  @override
  String get subscriptionName => 'Nombre local';

  @override
  String get subscriptionUrl => 'URL de la suscripción';

  @override
  String get subscriptionUrlHelp =>
      'Introduce una URL HTTPS o webcal. BusyMax guarda la URL completa en un almacenamiento seguro.';

  @override
  String get subscriptionUrlInvalid =>
      'Introduce una URL HTTPS o webcal válida sin información de usuario ni fragmento.';

  @override
  String get subscriptionColor => 'Color local';

  @override
  String get subscriptionColorHelp =>
      'Usa un color de seis dígitos, como #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Introduce un color hexadecimal de seis dígitos.';

  @override
  String get subscriptionRefreshMode => 'Frecuencia de actualización';

  @override
  String get subscriptionAutomatic => 'Automática';

  @override
  String get subscriptionHourly => 'Cada hora';

  @override
  String get subscriptionSixHours => 'Cada seis horas';

  @override
  String get subscriptionDaily => 'Diaria';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Origen: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Introduce una URL válida para previsualizar su origen seguro.';

  @override
  String get subscriptionReadOnly => 'Suscripción de solo lectura';

  @override
  String get subscriptionNeverRefreshed => 'Aún no se ha actualizado';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Última actualización correcta: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Próxima actualización: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Actualizada';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Problema de actualización: $code';
  }

  @override
  String get refreshNow => 'Actualizar ahora';

  @override
  String get unsubscribe => 'Cancelar suscripción';

  @override
  String unsubscribeCalendarTitle(String name) {
    return '¿Cancelar la suscripción a «$name»?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'Esto elimina la suscripción local y sus eventos almacenados en caché. El calendario publicado no cambia.';

  @override
  String get addSubscriptionAction => 'Añadir suscripción';

  @override
  String subscriptionOperationFailed(String error) {
    return 'La suscripción al calendario ha fallado: $error';
  }

  @override
  String get subscriptions => 'Suscripciones';

  @override
  String get calendarImport => 'Importación de calendario';

  @override
  String get calendarImportDescription =>
      'Selecciona un archivo, revisa sus eventos y elige el calendario editable que debe recibirlos.';

  @override
  String get importIcsFile => 'Importar archivo .ics';

  @override
  String get importIcsPreview => 'Importar eventos del calendario';

  @override
  String importEventsFound(int count) {
    return 'Conjuntos de eventos importables: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Eventos no válidos: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Omitidos intencionadamente: $fields';
  }

  @override
  String get noWritableCalendars =>
      'No hay ningún calendario de destino editable disponible.';

  @override
  String get importDestinationCalendar => 'Calendario de destino';

  @override
  String get importIcsConfirm => 'Importar eventos';

  @override
  String get importIcsComplete => 'Importación completada';

  @override
  String importQueued(int count) {
    return 'Importados o en cola: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Duplicados omitidos: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Conjuntos de repeticiones no compatibles: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'No se pudo importar el archivo de calendario: $error';
  }

  @override
  String get networkOffline => 'Sin conexión';

  @override
  String get networkOfflineDescription =>
      'Los cambios se sincronizarán cuando se restablezca la conexión.';

  @override
  String get networkOfflineTryAgain =>
      'No tienes conexión. Conéctate a Internet e inténtalo de nuevo.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'los días $days';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first y $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first y $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first y $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first y $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency el día $day de $month';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency los días $days de $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency el día $day de $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency los días $days de $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'el primer $days de $month',
      'second': 'el segundo $days de $month',
      'third': 'el tercer $days de $month',
      'fourth': 'el cuarto $days de $month',
      'fifth': 'el quinto $days de $month',
      'secondToLast': 'el penúltimo $days de $month',
      'last': 'el último $days de $month',
      'other': 'en $days de $month',
    });
    return '$frequency $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'el primer $days de $months',
      'second': 'el segundo $days de $months',
      'third': 'el tercer $days de $months',
      'fourth': 'el cuarto $days de $months',
      'fifth': 'el quinto $days de $months',
      'secondToLast': 'el penúltimo $days de $months',
      'last': 'el último $days de $months',
      'other': 'en $days de $months',
    });
    return '$frequency $_temp0';
  }

  @override
  String get searchFilters => 'Filtros de búsqueda';

  @override
  String get searchType => 'Tipo';

  @override
  String get searchDate => 'Fecha';

  @override
  String get searchAnyDate => 'Cualquier fecha (datos descargados)';

  @override
  String get eventLink => 'Enlace del evento';

  @override
  String get eventLinkOpenFailed => 'No se pudo abrir el enlace.';

  @override
  String get scheduleRangeIncomplete =>
      'No se pudieron comprobar algunos eventos. Se muestran los datos descargados.';

  @override
  String get searchThisWeek => 'Esta semana';

  @override
  String get searchCustomRange => 'Intervalo personalizado';

  @override
  String get searchTaskStatus => 'Estado de tareas';

  @override
  String get searchTaskDue => 'Vencimiento de tareas';

  @override
  String get searchAnyDueState => 'Cualquier vencimiento';

  @override
  String get searchNoDueDate => 'Sin fecha de vencimiento';

  @override
  String get searchPerson => 'Persona';

  @override
  String get searchSources => 'Fuentes';

  @override
  String get searchClearFilters => 'Restablecer filtros';

  @override
  String get searchFiltersAction => 'Filtros';

  @override
  String get searchNoSources => 'No hay fuentes de búsqueda seleccionadas';

  @override
  String get searchClearText => 'Borrar texto';

  @override
  String get openSharedCalendar => 'Abrir calendario compartido';

  @override
  String get manageCalendarSharing =>
      'Administrar uso compartido del calendario';

  @override
  String get shareRecipientEmail => 'Correo del destinatario';

  @override
  String get shareRole => 'Rol de acceso';

  @override
  String get addCalendarShare => 'Añadir acceso';

  @override
  String get sharingRefreshFailed =>
      'Se cambió el acceso, pero no se pudo actualizar la lista de permisos. Vuelve a cargarla antes de otro cambio.';

  @override
  String get sharingRateLimited =>
      'El uso compartido está limitado temporalmente. Inténtalo de nuevo cuando termine la espera.';

  @override
  String get attachmentUploadRateLimited =>
      'La carga de archivos adjuntos está limitada temporalmente. Inténtalo de nuevo cuando termine la espera.';

  @override
  String get sharingPermissionUnavailable =>
      'Los permisos para compartir no están disponibles para este calendario.';

  @override
  String get calendarShareFreeBusy => 'Solo libre/ocupado';

  @override
  String get calendarShareLimitedRead => 'Leer detalles limitados';

  @override
  String get calendarShareRead => 'Leer todos los detalles';

  @override
  String get calendarShareWrite => 'Editar eventos';

  @override
  String get calendarShareWriteWithoutPrivate => 'Editar sin detalles privados';

  @override
  String get calendarShareOwner => 'Propietario';

  @override
  String get eventLabel => 'Etiqueta del evento';

  @override
  String get loadOutlookCategories => 'Cargar categorías de Outlook';

  @override
  String get outlookCategoriesUnavailable =>
      'Las categorías de Outlook no están disponibles; se conservan las asignaciones actuales.';

  @override
  String get googleEventType => 'Tipo de evento';

  @override
  String get googleRegularEvent => 'Evento normal';

  @override
  String get googleFocusTime => 'Tiempo de concentración';

  @override
  String get googleOutOfOffice => 'Fuera de la oficina';

  @override
  String get googleWorkingLocation => 'Lugar de trabajo';

  @override
  String get googleDeclineInvitations => 'Rechazar invitaciones superpuestas';

  @override
  String get googleDeclineNone => 'No rechazar';

  @override
  String get googleDeclineNew => 'Rechazar invitaciones nuevas';

  @override
  String get googleDeclineAll => 'Rechazar todas las invitaciones en conflicto';

  @override
  String get googleDeclineMessage => 'Mensaje de rechazo';

  @override
  String get googleChatStatus => 'Estado del chat';

  @override
  String get googleChatAvailable => 'Disponible';

  @override
  String get googleChatDoNotDisturb => 'No molestar';

  @override
  String get googleWorkAtHome => 'Casa';

  @override
  String get googleWorkAtOffice => 'Oficina';

  @override
  String get googleWorkAtCustomLocation => 'Ubicación personalizada';

  @override
  String get googleWorkLocationLabel => 'Etiqueta de ubicación';

  @override
  String get googleStatusPrimaryOnly =>
      'Los eventos de estado de Google requieren tu calendario principal de Google.';

  @override
  String unknownEventLabel(String id) {
    return 'Etiqueta desconocida ($id)';
  }

  @override
  String get calendarOwnerEmail => 'Correo del propietario del calendario';

  @override
  String registrationSetupTitle(String provider) {
    return 'Configurar $provider';
  }

  @override
  String get registrationSetupGuide => 'Guía de configuración';

  @override
  String get registrationGoogleInstructions =>
      'Crea tu propio proyecto de Google Cloud, activa Calendar y Tasks e importa el JSON de un cliente OAuth de escritorio. Autoriza la cuenta deseada.';

  @override
  String get registrationMicrosoftInstructions =>
      'Usa un registro de aplicación pública en un inquilino de Entra que permita registros. Introduce el ID de cliente y los tipos de cuenta. No se necesita un secreto de cliente.';

  @override
  String get registrationImportGoogle => 'Seleccionar JSON OAuth de escritorio';

  @override
  String get registrationValidate => 'Validar registro';

  @override
  String get registrationAuthorize => 'Autorizar en el navegador';

  @override
  String get registrationClientId => 'ID de aplicación/cliente';

  @override
  String get registrationTenantId => 'ID de inquilino';

  @override
  String get registrationAudience => 'Cuentas compatibles';

  @override
  String get registrationBothAudience => 'Cuentas personales y organizativas';

  @override
  String get registrationOrganizationAudience => 'Cuentas organizativas';

  @override
  String get registrationPersonalAudience => 'Cuentas personales';

  @override
  String get registrationTenantAudience => 'Un inquilino organizativo';

  @override
  String registrationSummary(String clientId) {
    return 'Registro: $clientId';
  }

  @override
  String get registrationMigrate => 'Migrar ahora';

  @override
  String get registrationReplace => 'Reemplazar registro';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'Esta cuenta usa un registro original de $provider reservado para cuentas existentes. Para reemplazarlo, configura $setup y vuelve a conectar esta cuenta. Se conservarán tus calendarios, tareas y cambios locales.';
  }

  @override
  String get registrationContinue => 'Seguir usando esta cuenta';

  @override
  String get registrationGoogleProject => 'Proyecto de Google Cloud';

  @override
  String get registrationMicrosoftApp => 'Registro de aplicación de Microsoft';

  @override
  String get registrationUserOwned => 'Registro proporcionado por el usuario';

  @override
  String get registrationNativeGoogle =>
      'Registro nativo de Google para Android';

  @override
  String get registrationShared => 'Registro compartido (transición)';

  @override
  String get registrationUnresolved =>
      'No se ha identificado el origen del registro. Se conservan los datos de la cuenta.';

  @override
  String get registrationOfficialDocumentation => 'Documentación oficial';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Paquete: $packageName\nHash de firma: $signatureHash\nURI de redirección: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Comprueba el tipo de cliente, las cuentas admitidas, los permisos y la redirección del registro. Vuelve a seleccionar la configuración importada.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'No se pudo completar esta autorización. Iníciala de nuevo; se conserva la conexión existente.';

  @override
  String get oauthPermissionRefused =>
      'Se rechazó la autorización o faltan permisos necesarios. Reinténtalo y concede los permisos requeridos.';

  @override
  String get oauthProviderThrottled =>
      'El proveedor limita las solicitudes. Espera antes de reintentarlo; se conserva la conexión existente.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Un problema temporal del proveedor impide la autorización. Reinténtalo; se conserva la conexión existente.';

  @override
  String get oauthAuthorizationTimedOut =>
      'La autorización agotó el tiempo disponible. Reinténtalo y selecciona de nuevo la configuración importada.';

  @override
  String get oauthWrongAccount =>
      'Autoriza la cuenta seleccionada para reconectar. Se conserva la conexión existente.';

  @override
  String get oauthSecureStorageUnavailable =>
      'El almacenamiento seguro no está disponible. Restablece el acceso y reinténtalo.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'Se revocó la autorización remota, pero no se pudo completar la limpieza de la cuenta. Reinicia BusyMax para volver a intentar la recuperación local.';

  @override
  String get addAccount => 'Añadir cuenta';

  @override
  String get registrationConnect => 'Conectar';

  @override
  String get registrationBack => 'Volver';

  @override
  String get registrationReplaceGoogle => 'Reemplazar JSON OAuth de escritorio';

  @override
  String get registrationSelectedConfiguration => 'Configuración seleccionada';

  @override
  String get registrationDirectoryId => 'ID de directorio/inquilino';

  @override
  String get registrationInvalidId => 'Introduce un UUID válido.';

  @override
  String get registrationExpired =>
      'Esta configuración ha caducado. Impórtala de nuevo o edita los campos del registro antes de conectar.';

  @override
  String get registrationOwnProjectRequired =>
      'Elige un registro de tu propio proyecto o inquilino.';

  @override
  String get registrationSetupFailed =>
      'No se pudo completar la configuración. Inténtalo de nuevo.';

  @override
  String get registrationLinkFailed =>
      'No se pudo abrir el enlace. Revisa tu navegador e inténtalo de nuevo.';

  @override
  String get registrationPermissions => 'Permisos';

  @override
  String get registrationDesktopClient => 'Aplicación de escritorio';

  @override
  String get registrationOpenGoogleConsole => 'Abrir Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Requisitos de publicación y usuarios de prueba de Google';

  @override
  String get registrationDesktopHelp =>
      'Instrucciones de registro de aplicaciones de escritorio';

  @override
  String get registrationOpenEntra =>
      'Abrir el centro de administración de Microsoft Entra';

  @override
  String get registrationGuideGoogleProject =>
      'Abre Google Cloud Console. En el selector de proyectos de la parte superior, elige tu propio proyecto o selecciona New project, introduce un nombre y selecciona Create. Mantén ese proyecto seleccionado durante los pasos siguientes.';

  @override
  String get registrationGuideGoogleAudience =>
      'Ve a Google Auth Platform → Branding. Si aún no has iniciado la configuración, selecciona Get started. Introduce BusyMax en App name, elige tu propio User support email y selecciona Next. En Audience, elige External. Selecciona Next, introduce tu correo en Contact Information y selecciona Next. Acepta User Data Policy y selecciona Continue y Create. Si ya está configurado, revisa Branding y Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Abre Google Auth Platform → Data Access → Add or remove scopes. Selecciona los cinco ámbitos siguientes; usa Manually add scopes si hace falta. Para la entrada manual, pega los valores que faltan y selecciona Add to table. Selecciona Update y después Save. BusyMax necesita acceso al calendario y a las tareas.';

  @override
  String get registrationGuideGoogleClient =>
      'Abre Google Auth Platform → Clients → Create client. Elige Desktop app en Application type, introduce BusyMax en Name y selecciona Create. En el diálogo de creación, selecciona Download JSON y guarda el archivo. Selecciona Atrás para volver al formulario, elige ese archivo y revisa el proyecto y el ID de cliente. Selecciona Conectar y permite el acceso al calendario y a las tareas en el navegador.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Inicia sesión en Microsoft Entra admin center. Usa Settings para elegir un inquilino donde puedas registrar aplicaciones. Abre Entra ID → App registrations → New registration. Introduce BusyMax en Name y elige los tipos de cuenta en el siguiente paso. Si el registro está bloqueado, pide acceso al administrador del inquilino.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'En tu registro, abre Authentication → Add a platform → Mobile and desktop applications. Selecciona o introduce el URI de redirección siguiente y selecciona Configure para guardarlo. BusyMax usa el navegador del sistema. No se necesita un secreto de cliente.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Abre API permissions → Add a permission → Microsoft Graph → Delegated permissions. Busca y selecciona cada ámbito siguiente y luego Add permissions. Conserva User.Read si ya está presente. Si tu organización exige consentimiento administrativo, pide a un administrador que use Grant admin consent para el inquilino.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Selecciona Atrás para volver al formulario. Pega Application (client) ID y elige las mismas Cuentas compatibles que en el registro. Para Un inquilino organizativo, pega también Directory (tenant) ID. Selecciona Conectar e inicia sesión con la cuenta deseada en el navegador. BusyMax comprueba los campos localmente; Microsoft pide tu consentimiento durante el inicio de sesión en el navegador.';

  @override
  String get registrationGoogleImportFailed =>
      'No se pudo importar este archivo. Selecciona un JSON OAuth de escritorio válido. Se conserva cualquier selección válida anterior.';

  @override
  String get registrationGoogleSetupInstructions =>
      'Instrucciones de configuración de Google';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Instrucciones de configuración de Microsoft';

  @override
  String get registrationDesktopConfiguration =>
      'Configuración OAuth de escritorio';

  @override
  String get registrationNoFileSelected => 'Ningún archivo seleccionado';

  @override
  String get registrationChooseFile => 'Elegir archivo…';

  @override
  String get registrationReplaceFile => 'Reemplazar…';

  @override
  String get registrationGoogleIntroduction =>
      'Elige el JSON OAuth de escritorio de tu propio proyecto de Google Cloud.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Introduce los datos de tu propio registro de aplicación de Microsoft.';

  @override
  String get registrationSetupInstructions => 'Instrucciones de configuración';

  @override
  String get registrationInstructionsDescription =>
      'Crea la configuración necesaria para conectar tu cuenta.';

  @override
  String get registrationEnableApis => 'Habilitar Calendar y Tasks';

  @override
  String get registrationConsentScreen =>
      'Configurar la pantalla de consentimiento';

  @override
  String get registrationAppName => 'Nombre de la aplicación';

  @override
  String get registrationScopes => 'Ámbitos';

  @override
  String get registrationRedirectUri => 'URI de redirección';

  @override
  String get registrationOpenApiLibrary =>
      'Abrir la biblioteca de API de Google';

  @override
  String get registrationOpenBranding =>
      'Abrir Branding de Google Auth Platform';

  @override
  String get registrationOpenDataAccess =>
      'Abrir Data Access de Google Auth Platform';

  @override
  String get registrationOpenClients => 'Abrir Clients de Google Auth Platform';

  @override
  String get registrationOpenEntraAuthentication =>
      'Abrir registros de aplicaciones de Entra para Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'Abrir registros de aplicaciones de Entra para API permissions';

  @override
  String get registrationCopy => 'Copiar';

  @override
  String get registrationCopyAll => 'Copiar todo';

  @override
  String get registrationGuideGoogleApis =>
      'Ve a APIs & Services → Library. Busca Google Calendar API, abre su página y selecciona Enable. Vuelve a Library y repite el proceso para Google Tasks API.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'En Supported account types, elige Personal accounts only para una cuenta personal, Multiple Entra ID tenants para cuentas de organizaciones, Any Entra ID Tenant + Personal Microsoft accounts para ambas, o Single tenant only para este directorio. Selecciona Register. En Overview, copia Application (client) ID; para un solo inquilino, copia también Directory (tenant) ID. Usa la opción correspondiente de Cuentas compatibles en BusyMax.';

  @override
  String get registrationConnectBusyMax => 'Conectar con BusyMax';

  @override
  String get registrationRecommended => 'Recomendado';

  @override
  String get registrationOtherMethods => 'Otros métodos de conexión';

  @override
  String get registrationWorkspace => 'Organización de Google Workspace';

  @override
  String get registrationGoogleCustom => 'Cliente OAuth personalizado';

  @override
  String get registrationMicrosoftCustom =>
      'Registro de aplicación personalizado';

  @override
  String get registrationMethodsIntroduction =>
      'Elige cómo conectar tu cuenta.';

  @override
  String get registrationWorkspaceDescription =>
      'Usa una configuración administrada por tu organización.';

  @override
  String get registrationCustomDescription =>
      'Usa un registro que tú administras.';

  @override
  String get registrationSharedUnavailable =>
      'La conexión con BusyMax no está disponible en esta compilación. Puedes usar otro método de conexión a continuación.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Elige el JSON de OAuth de escritorio que proporciona o administra tu organización. El archivo no demuestra la propiedad de la organización, la audiencia ni la verificación.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Instrucciones de configuración de Google Workspace';

  @override
  String get registrationBusyMaxManaged => 'Registro administrado por BusyMax';

  @override
  String get registrationBranding => 'Configurar marca y dominios';

  @override
  String get registrationPublishing => 'Publicar para uso normal';

  @override
  String get registrationOpenAudience =>
      'Abrir Audience de Google Auth Platform';

  @override
  String get registrationGuideWorkspaceProject =>
      'Pide el JSON de OAuth de escritorio al administrador o abre Google Cloud Console y selecciona un proyecto de tu organización de Google Workspace. Para crearlo, abre Administrar recursos → Crear proyecto, introduce el Nombre del proyecto, elige tu organización o una de sus carpetas en Recurso principal y selecciona Crear. Selecciona ese proyecto para los pasos siguientes. Para crearlo necesitas Project Creator; para configurar OAuth, OAuth Config Editor; y para habilitar APIs, Service Usage Admin o permisos equivalentes. Si se bloquea una acción, pide ayuda al administrador.';

  @override
  String get registrationGuideGoogleBranding =>
      'En Branding → App domain, añade los dominios autorizados de tu proyecto antes de introducir sus URL de página principal, privacidad y condiciones de servicio, y pulsa Save. Las aplicaciones External en producción necesitan estos enlaces. Usa dominios propios y verifica su propiedad en Search Console cuando Google exija verificar la marca. El enlace de privacidad de BusyMax no demuestra que tu proyecto sea propietario de busystack.org.';

  @override
  String get registrationGuideGooglePublishing =>
      'En Audience, selecciona Publish app y confirma In production. No dejes el uso normal en Testing: estas autorizaciones de Calendar/Tasks y sus tokens de actualización caducan a los siete días. Publicar y verificar son procesos separados. El uso personal con menos de 100 usuarios puede estar exento de verificación, con avisos y un límite de usuarios; una distribución mayor puede necesitar aprobación de marca y ámbitos. Las autorizaciones de producción también pueden caducar o revocarse.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Revisa estos ámbitos con el administrador. Las aplicaciones Internal no necesitan listarlos en la pantalla de consentimiento. Si se solicita, abre Data Access → Add or remove scopes, añade estos valores y selecciona Update y Save. Los controles administrativos pueden restringir la autorización.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'Los permisos de calendarios compartidos y categorías se solicitan por separado al activar esas funciones opcionales; no los añadas a la configuración obligatoria anterior.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Ve a Google Auth Platform → Branding. Si aún no has iniciado la configuración, selecciona Get started. Introduce BusyMax en App name, elige tu propio User support email y selecciona Next. En Audience, elige Internal. Selecciona Next, introduce tu correo en Contact Information y selecciona Next. Acepta User Data Policy y selecciona Continue y Create. Si ya está configurado, revisa Branding y Audience.\n\nInternal solo admite cuentas de la organización matriz del proyecto, sujetas a los controles del administrador. No necesita lista de usuarios de prueba. BusyMax no puede verificar estos ajustes de la consola a partir del JSON.';

  @override
  String get contactsTitle => 'Contactos';

  @override
  String get contactsLinkedDescription =>
      'Usa los contactos almacenados de esta cuenta al añadir invitados a eventos.';

  @override
  String get contactsEnableSuggestions => 'Activar sugerencias de contactos';

  @override
  String get contactsReadPermissionDescription =>
      'Solicita acceso de solo lectura a los contactos';

  @override
  String get contactsEnableEditing => 'Activar edición de contactos';

  @override
  String get contactsWritePermissionDescription =>
      'Solicita acceso de lectura y escritura a los contactos';

  @override
  String get contactsSuggestionsEnabled => 'Sugerencias de contactos activadas';

  @override
  String get contactsNeedsAttention => 'Los contactos requieren atención';

  @override
  String get contactsReadWriteAccess => 'Acceso de lectura y escritura';

  @override
  String get contactsDisableForAccount =>
      'Desactivar contactos para esta cuenta';

  @override
  String get contactsOnlyDescription =>
      'Estas fuentes son independientes de las cuentas de calendarios y tareas.';

  @override
  String get contactsAddCardDav => 'Añadir contactos CardDAV';

  @override
  String get contactsAddNextcloud => 'Añadir contactos de Nextcloud';

  @override
  String get contactsUseForAttendees => 'Usar para sugerencias de asistentes';

  @override
  String get contactsServerUrlLabel => 'URL del servidor HTTPS';

  @override
  String get contactsUsernameLabel => 'Nombre de usuario';

  @override
  String get contactsPasswordLabel => 'Contraseña';
}
