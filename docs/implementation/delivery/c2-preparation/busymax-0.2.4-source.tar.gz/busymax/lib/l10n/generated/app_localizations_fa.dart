// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Persian (`fa`).
class AppLocalizationsFa extends AppLocalizations {
  AppLocalizationsFa([String locale = 'fa']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax از تنظیمات راه‌اندازی خودکار میزکار شما اجرا شده است. ورودی آن را در آنجا حذف کنید، سپس از BusyMax خارج شوید و دوباره آن را باز کنید تا بتوانید از این کلید استفاده کنید.';

  @override
  String get timeFormat => 'قالب زمان';

  @override
  String get firstDayOfWeek => 'روز اول هفته';

  @override
  String get systemDefault => 'پیش‌فرض سیستم';

  @override
  String systemDefaultResolved(String weekday) {
    return 'پیش‌فرض سیستم (⁨$weekday⁩)';
  }

  @override
  String get timeFormatTwelveHour => '۱۲ ساعته';

  @override
  String get timeFormatTwentyFourHour => '۲۴ ساعته';

  @override
  String get timeEndOfDay => 'پایان روز';

  @override
  String get timePeriod => 'بازهٔ روز';

  @override
  String get launchAtLoginReadFailed =>
      'وضعیت اجرای خودکار هنگام ورود مشخص نشد.';

  @override
  String get launchAtLoginUnavailable =>
      'اجرای خودکار هنگام ورود در این سیستم در دسترس نیست.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'اجرای خودکار توسط مدیر فعال شده و از اینجا قابل تغییر نیست.';

  @override
  String get settingsSaveFailed =>
      'تنظیمات ذخیره نشد. ممکن است تغییرات شما با راه‌اندازی دوبارهٔ BusyMax از بین برود.';

  @override
  String get nextcloudExportCollection => 'برون‌بری منابع مجموعه';

  @override
  String nextcloudImportItems(int count) {
    return '$count منبع رویداد/کار پیدا شد';
  }

  @override
  String get nextcloudSchedulingInbox => 'صندوق ورودی دعوت‌ها';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud این پیام‌ها را در تقویم‌ها پردازش می‌کند. تأیید دریافت فقط پیام را حذف می‌کند، نه رویداد را.';

  @override
  String get nextcloudInboxEmpty => 'پیام زمان‌بندی وجود ندارد.';

  @override
  String get nextcloudAcknowledge => 'تأیید دریافت پیام';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'این پیام از صندوق ورودی حذف شود؟ رویداد تقویم حفظ می‌شود.';

  @override
  String get nextcloudGuestAvailability => 'بررسی زمان آزاد مهمانان';

  @override
  String nextcloudTrashRetention(int days) {
    return 'مدت نگهداری در زباله‌دان سرور: $days روز';
  }

  @override
  String get nextcloudCancelMeeting => 'لغو جلسه';

  @override
  String get nextcloudDeclineAndRemove => 'رد و حذف دعوت';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'هنگام همگام‌سازی پاسخ رد ارسال می‌شود. جلسهٔ برگزارکننده لغو نمی‌شود.';

  @override
  String get nextcloudAvailabilityUnknown => 'وضعیت زمان آزاد نامشخص';

  @override
  String get nextcloudAvailabilityFree =>
      'برای این بازه زمان مشغولی گزارش نشده است';

  @override
  String get nextcloudAvailabilityBusy => 'بازه‌های مشغول';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud به‌روزرسانی جلسه را هنگام همگام‌سازی می‌فرستد. ذخیرهٔ محلی تأیید تحویل نیست.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'فقط برگزارکننده یا نمایندهٔ مجاز می‌تواند جزئیات جلسه را تغییر دهد. از جزئیات دعوت می‌توانید پاسخ دهید.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'این جلسه را نمی‌توان با کپی و حذف جابه‌جا کرد. از تقویمی با همان هویت زمان‌بندی استفاده کنید.';

  @override
  String get nextcloudSchedulingStatus => 'وضعیت زمان‌بندی سرور';

  @override
  String get nextcloudImportFollowUp =>
      'منابع واردشده محلی ذخیره شدند. تازه‌سازی یادآورها در انتظار است؛ دوباره وارد نکنید.';

  @override
  String get nextcloudNativeImport =>
      'رویدادها و کارها را کامل و بدون ارسال دعوت وارد کنید. UIDهای موجود رد می‌شوند مگر نسخه‌های جدید را انتخاب کنید. منابع پشتیبانی‌نشده جداگانه گزارش می‌شوند.';

  @override
  String get nextcloudImportMethod =>
      'این پرونده پیام زمان‌بندی دارد. درون‌ریزی محتوا را ذخیره و METHOD را حذف می‌کند؛ دعوت یا پاسخ را پردازش نمی‌کند.';

  @override
  String get nextcloudImportCopies =>
      'درون‌ریزی نسخه‌های جدید با هویت‌های جدید';

  @override
  String get nextcloudCollectionSettings => 'تنظیمات مجموعه';

  @override
  String get nextcloudSharing => 'اشتراک‌گذاری';

  @override
  String get nextcloudOwned => 'متعلق به شما';

  @override
  String get nextcloudShared => 'اشتراکی';

  @override
  String get nextcloudDelegated => 'واگذارشده';

  @override
  String get nextcloudSubscription => 'اشتراک';

  @override
  String get nextcloudDeleted => 'حذف‌شده';

  @override
  String get nextcloudMetadataEditable =>
      'محتوای تقویم فقط خواندنی است؛ ویژگی‌های مجموعه قابل تغییرند.';

  @override
  String get nextcloudServerOrder => 'ترتیب سرور (جدا از ترتیب نوار کناری)';

  @override
  String get nextcloudCalendarEnabled => 'فعال در سرور';

  @override
  String get nextcloudAvailability => 'لحاظ کردن این مجموعه در زمان آزاد';

  @override
  String get nextcloudCalendarTimezone => 'منطقهٔ زمانی تقویم (سند VTIMEZONE)';

  @override
  String get nextcloudRefreshPending =>
      'تغییر در Nextcloud ذخیره شد. تازه‌سازی در انتظار است؛ تغییر را تکرار نکنید.';

  @override
  String get nextcloudOutcomeUnknown =>
      'نتیجهٔ سرور تأیید نشد. پیش از تلاش دوباره تازه‌سازی کنید.';

  @override
  String get nextcloudRemoveShared => 'حذف تقویم/فهرست اشتراکی';

  @override
  String get nextcloudRemoveMixed =>
      'این مجموعه رویداد و کار دارد. حذف آن هر دو را حذف می‌کند.';

  @override
  String get nextcloudReadAccess => 'فقط خواندن';

  @override
  String get nextcloudWriteAccess => 'خواندن و نوشتن';

  @override
  String get nextcloudRecipientSearch => 'یافتن افراد یا گروه‌ها';

  @override
  String get nextcloudNoRecipients => 'فرد یا گروه مطابقی وجود ندارد.';

  @override
  String get nextcloudRevokeShare => 'لغو دسترسی';

  @override
  String get nextcloudPublish => 'انتشار پیوند';

  @override
  String get nextcloudUnpublish => 'توقف انتشار';

  @override
  String get nextcloudPublishWarning =>
      'هر کس پیوند منتشرشده را داشته باشد ممکن است بتواند این تقویم را بخواند. منتشر شود؟';

  @override
  String get nextcloudTrash => 'تقویم‌ها و کارهای حذف‌شده';

  @override
  String get nextcloudTrashEmpty => 'مورد حذف‌شده‌ای در تقویم نیست.';

  @override
  String get nextcloudRestore => 'بازیابی';

  @override
  String get nextcloudPermanentDelete => 'حذف همیشگی';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'این مورد برای همیشه حذف شود؟ دیگر از زباله‌دان تقویم Nextcloud بازیابی نمی‌شود.';

  @override
  String get nextcloudOperationDenied => 'Nextcloud این عملیات را مجاز ندانست.';

  @override
  String get nextcloudUnsupported => 'سرور از این عملیات پشتیبانی نمی‌کند.';

  @override
  String get nextcloudPendingChanges =>
      'پیش از بستن، تغییرات مجموعه را ذخیره یا دور بیندازید.';

  @override
  String get nextcloudServerUnavailable =>
      'دسترسی به Nextcloud ممکن نیست. موارد ذخیره‌شده و تغییرات در انتظار دست‌نخورده‌اند.';

  @override
  String get mapsShow => 'نمایش روی نقشه';

  @override
  String get openLink => 'باز کردن پیوند';

  @override
  String get externalLocationOpenFailed => 'مکان در برنامهٔ خارجی باز نشد.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '⁨$start⁩ – ⁨$end⁩';
  }

  @override
  String get scheduleRescheduleFailed =>
      'تغییر زمان رویداد ممکن نشد. زمان ذخیره‌شده تغییر نکرده است.';

  @override
  String get scheduleRescheduleStale =>
      'این رویداد هنگام کشیدن تغییر کرد. لطفاً دوباره تلاش کنید.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'زمان جدید ذخیره شد، اما یادآوری‌ها به‌روز نشدند.';

  @override
  String get moveUp => 'انتقال به بالا';

  @override
  String get moveDown => 'انتقال به پایین';

  @override
  String get windowsSupport => 'پشتیبانی';

  @override
  String get windowsThirdPartyLicenses => 'مجوزهای شخص ثالث';

  @override
  String get windowsSearch => 'جستجو';

  @override
  String get windowsStartupDisabledByUser =>
      'کاربر این گزینه را در تنظیمات Windows غیرفعال کرده است.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'با خط‌مشی Windows غیرفعال شده است.';

  @override
  String get windowsStartupUnavailable =>
      'پس از نصب BusyMax از بستهٔ MSIX در دسترس است.';

  @override
  String get windowsReminderExitNotice =>
      'با خروج کامل از BusyMax یادآورها متوقف می‌شوند. برای دریافت آن‌ها برنامه را در پس‌زمینه فعال نگه دارید.';

  @override
  String get windowsProductVersionLabel => 'نسخهٔ محصول';

  @override
  String get windowsPackageVersionLabel => 'نسخهٔ بستهٔ Windows';

  @override
  String get windowsUnpackaged => 'بدون بسته';

  @override
  String get windowsAgendaLoadMore => 'بارگیری موارد بیشتر دستور کار';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'دوشنبه',
      'TU': 'سه‌شنبه',
      'WE': 'چهارشنبه',
      'TH': 'پنجشنبه',
      'FR': 'جمعه',
      'SA': 'شنبه',
      'SU': 'یکشنبه',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'در روزهای $first و $second ماه';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency در روزهای $firstDay و $secondDay ماه $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency در روز $day ماه‌های $firstMonth و $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency در روزهای $firstDay و $secondDay ماه‌های $firstMonth و $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency در روزهای $days ماه‌های $firstMonth و $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'حساب‌های Google، Microsoft، Apple iCloud Calendar یا Nextcloud را متصل کنید.';

  @override
  String get googlePermissionsConsentNotice =>
      'در صفحهٔ مجوزهای Google، مجوزهای تقویم و کارها را هر دو انتخاب کنید.';

  @override
  String get googlePermissionsRequiredRetry =>
      'مجوزهای Google Calendar و Google Tasks لازم هستند. دوباره تلاش کنید و هر دو کادر را علامت بزنید.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'این سرویس پیکربندی نشده است.';

  @override
  String get waitingForGoogleSignIn => 'در انتظار ورود به Google...';

  @override
  String get waitingForMicrosoftSignIn => 'در انتظار ورود به Microsoft...';

  @override
  String get microsoftSignInNotConfigured =>
      'ورود به Microsoft پیکربندی نشده است. MICROSOFT_OAUTH_CLIENT_ID را تنظیم کنید.';

  @override
  String get cancel => 'لغو';

  @override
  String get close => 'بستن';

  @override
  String get windowMinimize => 'کوچک کردن';

  @override
  String get windowMaximize => 'بزرگ کردن';

  @override
  String get windowRestore => 'بازیابی';

  @override
  String get exit => 'خروج';

  @override
  String get options => 'گزینه‌ها';

  @override
  String get hide => 'پنهان کردن';

  @override
  String get show => 'نمایش';

  @override
  String get export => 'خروجی گرفتن';

  @override
  String get save => 'ذخیره';

  @override
  String get settings => 'تنظیمات';

  @override
  String get all => 'همه';

  @override
  String get calendarEvents => 'رویدادها';

  @override
  String get calendarTasks => 'کارها';

  @override
  String get calendar => 'تقویم';

  @override
  String get calendars => 'تقویم‌ها';

  @override
  String get newCalendar => 'تقویم جدید';

  @override
  String get calendarColor => 'رنگ تقویم';

  @override
  String calendarColorOption(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'رنگ $numberString';
  }

  @override
  String get calendarManagementUnsupported =>
      'این ارائه‌دهنده از مدیریت تقویم در BusyMax پشتیبانی نمی‌کند.';

  @override
  String get primaryCalendarCannotDelete => 'تقویم اصلی را نمی‌توان حذف کرد.';

  @override
  String calendarCreateFailed(String error) {
    return 'ایجاد تقویم ممکن نشد: ⁨$error⁩';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'تقویم ایجاد شد، اما BusyMax نتوانست حساب را تازه‌سازی کند. پس از همگام‌سازی بعدی نمایش داده می‌شود.';

  @override
  String calendarUpdateFailed(String error) {
    return 'به‌روزرسانی تقویم ممکن نشد: ⁨$error⁩';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'حذف تقویم ممکن نشد: ⁨$error⁩';
  }

  @override
  String get newEvent => 'رویداد جدید';

  @override
  String get refreshCalendar => 'تازه‌سازی تقویم';

  @override
  String get openInProvider => 'باز کردن در سرویس';

  @override
  String get linkedResources => 'منابع پیوندشده';

  @override
  String get noLinkedResources => 'منبع پیوندشده‌ای وجود ندارد';

  @override
  String get attachments => 'پیوست‌ها';

  @override
  String get attachmentsNotLoaded => 'پیوست‌ها بارگیری نشده‌اند';

  @override
  String get hideFromSchedule => 'پنهان کردن از برنامه';

  @override
  String get showInSchedule => 'نمایش در برنامه';

  @override
  String get noCalendarsSynced => 'هنوز هیچ تقویمی همگام نشده است.';

  @override
  String get allDay => 'تمام روز';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+⁨$countString⁩ مورد دیگر';
  }

  @override
  String get noEventsOrTasks => 'هیچ رویداد یا کاری وجود ندارد';

  @override
  String get scheduleLoading => 'در حال بارگیری برنامه...';

  @override
  String get scheduleUnavailable => 'برنامه در دسترس نیست';

  @override
  String get scheduleNoSources =>
      'هیچ تقویم یا فهرست کار قابل نمایشی وجود ندارد';

  @override
  String get scheduleNoSourcesDescription =>
      'در تنظیمات انتخاب کنید چه چیزهایی نمایش داده شوند، سپس برنامه را تازه‌سازی کنید.';

  @override
  String get scheduleNoSearchResults => 'هیچ رویداد یا کار منطبقی وجود ندارد';

  @override
  String get scheduleNoSearchResultsDescription =>
      'جست‌وجوی دیگری را امتحان کنید یا پالایه‌های فعلی را پاک کنید.';

  @override
  String get refresh => 'تازه‌سازی';

  @override
  String get trayOpenBusyMax => 'باز کردن BusyMax';

  @override
  String get trayShowBusyMax => 'نمایش BusyMax';

  @override
  String get trayNewEvent => 'رویداد جدید…';

  @override
  String get trayNewTask => 'کار جدید…';

  @override
  String get trayToday => 'امروز';

  @override
  String get trayAllDay => 'تمام‌روز';

  @override
  String get trayNow => 'اکنون';

  @override
  String get trayCalendarEvent => 'رویداد تقویم';

  @override
  String get trayUntitledEvent => 'رویداد بدون عنوان';

  @override
  String get trayNothingElseToday => 'امروز مورد دیگری نیست';

  @override
  String trayTasksDueToday(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString کار امروز سررسید دارند',
      one: '۱ کار امروز سررسید دارد',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'باز کردن برنامهٔ امروز';

  @override
  String get traySyncNow => 'همگام‌سازی اکنون';

  @override
  String get traySyncing => 'در حال همگام‌سازی…';

  @override
  String get trayNotConnected => 'متصل نیست';

  @override
  String get trayNotYetSynced => 'هنوز همگام نشده';

  @override
  String get trayLastSyncedJustNow => 'همین الان همگام شد';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString دقیقه پیش همگام شد',
      one: '۱ دقیقه پیش همگام شد',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString ساعت پیش همگام شد',
      one: '۱ ساعت پیش همگام شد',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString روز پیش همگام شد',
      one: '۱ روز پیش همگام شد',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'تنظیمات';

  @override
  String get trayQuitBusyMax => 'خروج از BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'بارگیری کارهای عقب‌افتادهٔ بیشتر';

  @override
  String get agendaLoadMoreNoDate => 'بارگیری کارهای بدون تاریخ بیشتر';

  @override
  String get viewDay => 'روز';

  @override
  String get viewWeek => 'هفته';

  @override
  String get viewMonth => 'ماه';

  @override
  String get viewYear => 'سال';

  @override
  String get viewAgenda => 'برنامه';

  @override
  String get scheduleSettings => 'برنامه';

  @override
  String get scheduleDisplaySettings => 'نمایش برنامه';

  @override
  String get newEventsAndTasks => 'رویدادها و کارهای جدید';

  @override
  String get defaultCalendar => 'تقویم پیش‌فرض';

  @override
  String get defaultTaskList => 'فهرست کارهای پیش‌فرض';

  @override
  String get lastUsed => 'آخرین استفاده';

  @override
  String get scheduleDisplayHoursDescription =>
      'نماهای روز و هفته ابتدا این بازهٔ زمانی را نشان می‌دهند. موارد زودتر یا دیرتر در صورت نیاز این بازه را گسترش می‌دهند.';

  @override
  String get scheduleDayStartsAt => 'شروع روز از';

  @override
  String get scheduleDayEndsAt => 'پایان روز در';

  @override
  String get sourceCalendar => 'تقویم';

  @override
  String get sourceTaskList => 'فهرست کار';

  @override
  String get createChoiceTitle => 'ایجاد';

  @override
  String get createEventAtTime => 'رویداد';

  @override
  String get createTaskAtDate => 'کار';

  @override
  String get editEvent => 'ویرایش رویداد';

  @override
  String get eventTitle => 'عنوان رویداد';

  @override
  String get location => 'مکان';

  @override
  String get timeSlot => 'بازهٔ زمانی';

  @override
  String get startDateTime => 'تاریخ/زمان شروع';

  @override
  String get endDateTime => 'تاریخ/زمان پایان';

  @override
  String get doesNotRepeat => 'تکرار نمی‌شود';

  @override
  String get defaultReminder => 'یادآور پیش‌فرض';

  @override
  String get guests => 'مهمانان';

  @override
  String get noGuests => 'فهرست مهمانان خالی است';

  @override
  String get attendeeRequired => 'ضروری';

  @override
  String get attendeeOptional => 'اختیاری';

  @override
  String get meetingSection => 'جلسه';

  @override
  String get addGoogleMeet => 'افزودن Google Meet';

  @override
  String get addTeamsMeeting => 'افزودن جلسهٔ Microsoft Teams';

  @override
  String get onlineMeetingAdded => 'جلسهٔ آنلاین افزوده شد';

  @override
  String get requestResponses => 'درخواست پاسخ';

  @override
  String get requestResponsesDescription =>
      'از مهمانان بخواهید به دعوت‌نامه پاسخ دهند.';

  @override
  String get hideGuestList => 'پنهان کردن فهرست مهمانان';

  @override
  String get hideGuestListDescription =>
      'مهمانان نمی‌توانند ببینند چه افراد دیگری دعوت شده‌اند.';

  @override
  String get allowNewTimeProposals => 'اجازهٔ پیشنهاد زمان‌های جدید';

  @override
  String get allowNewTimeProposalsDescription =>
      'مهمانان می‌توانند زمان دیگری برای جلسه پیشنهاد کنند.';

  @override
  String get notifyGuestsTitle => 'مهمانان اطلاع داده شوند؟';

  @override
  String get notifyGuestsSaveMessage =>
      'این جلسه مهمان دارد. هنگام ذخیره، دعوت‌نامه یا به‌روزرسانی رویداد برای آن‌ها ارسال شود؟';

  @override
  String get notifyGuestsDeleteMessage =>
      'این جلسه مهمان دارد. هنگام حذف، لغو جلسه ارسال شود؟';

  @override
  String get sendUpdates => 'ارسال به‌روزرسانی‌ها';

  @override
  String get sendCancellation => 'ارسال لغو';

  @override
  String get doNotSend => 'ارسال نکن';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'جلسه ذخیره شود؟';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft دعوت‌نامه یا به‌روزرسانی رویداد را برای مهمانان ارسال می‌کند.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'جلسه حذف شود؟';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft لغو جلسه را برای مهمانان ارسال می‌کند.';

  @override
  String get organizer => 'برگزارکننده';

  @override
  String get yourResponse => 'پاسخ شما';

  @override
  String get guestResponses => 'پاسخ مهمانان';

  @override
  String get respond => 'پاسخ دادن';

  @override
  String get acceptInvitation => 'پذیرفتن';

  @override
  String get tentativeInvitation => 'موقت';

  @override
  String get declineInvitation => 'رد کردن';

  @override
  String get joinMeeting => 'پیوستن به جلسه';

  @override
  String get responseAccepted => 'پذیرفته‌شده';

  @override
  String get responseTentative => 'موقت';

  @override
  String get responseDeclined => 'ردشده';

  @override
  String get responseNeedsAction => 'در انتظار پاسخ';

  @override
  String get responseNotResponded => 'بی‌پاسخ';

  @override
  String get responseOrganizer => 'برگزارکننده';

  @override
  String invitationResponseFailed(String error) {
    return 'ارسال پاسخ شما ممکن نیست: ⁨$error⁩';
  }

  @override
  String get joinMeetingFailed => 'باز کردن پیوند جلسه ممکن نیست.';

  @override
  String get description => 'توضیحات';

  @override
  String get availabilityShowAs => 'وضعیت دسترسی / نمایش به‌عنوان';

  @override
  String get busy => 'مشغول';

  @override
  String get visibility => 'قابلیت مشاهده';

  @override
  String get defaultVisibility => 'قابلیت مشاهدهٔ پیش‌فرض';

  @override
  String get conference => 'جلسه';

  @override
  String get noConference => 'بدون جلسه';

  @override
  String get providerCalendar => 'تقویم سرویس';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => 'پررنگ';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => 'مورب';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => 'زیرخط';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '⁨$minutesString⁩ دقیقه قبل',
      one: 'یک دقیقه قبل',
      zero: 'هنگام شروع',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'هنگام شروع';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '⁨$hoursString⁩ ساعت قبل',
      one: 'یک ساعت قبل',
      zero: 'هنگام شروع',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '⁨$daysString⁩ روز قبل',
      one: 'یک روز قبل',
      zero: 'همان روز',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'آزاد';

  @override
  String get availabilityTentative => 'احتمالی';

  @override
  String get availabilityOutOfOffice => 'خارج از دفتر';

  @override
  String get availabilityWorkingElsewhere => 'مشغول به کار در مکانی دیگر';

  @override
  String get visibilityDefault => 'پیش‌فرض';

  @override
  String get visibilityPublic => 'عمومی';

  @override
  String get visibilityPrivate => 'خصوصی';

  @override
  String get visibilityConfidential => 'محرمانه';

  @override
  String get sensitivityNormal => 'عادی';

  @override
  String get sensitivityPersonal => 'شخصی';

  @override
  String get tasks => 'کارها';

  @override
  String get allTasks => 'همهٔ کارها';

  @override
  String tasksInList(String title) {
    return 'کارهای ⁨⁨$title⁩⁩';
  }

  @override
  String get taskLists => 'فهرست‌های کار';

  @override
  String get navigation => 'پیمایش';

  @override
  String get mainMenu => 'منوی اصلی';

  @override
  String get keyboardShortcuts => 'میان‌برهای صفحه‌کلید';

  @override
  String get shortcutGroupGeneral => 'عمومی';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'نمایش این راهنمای میان‌برها';

  @override
  String get shortcutGroupNavigation => 'پیمایش';

  @override
  String get shortcutNextPeriod => 'بازهٔ بعدی';

  @override
  String get shortcutNextPeriodDescription =>
      'هفتهٔ بعد در نمای هفته، ماه بعد در نمای ماه و به همین ترتیب';

  @override
  String get shortcutPreviousPeriod => 'بازهٔ قبلی';

  @override
  String get shortcutPreviousPeriodDescription =>
      'هفتهٔ قبل در نمای هفته، ماه قبل در نمای ماه و به همین ترتیب';

  @override
  String get shortcutJumpToToday => 'رفتن به امروز';

  @override
  String get shortcutGroupView => 'نما';

  @override
  String get viewSelector => 'نما';

  @override
  String get shortcutDayView => 'نمای روز';

  @override
  String get shortcutWeekView => 'نمای هفته';

  @override
  String get shortcutMonthView => 'نمای ماه';

  @override
  String get shortcutYearView => 'نمای سال';

  @override
  String get shortcutAgendaView => 'نمای برنامه';

  @override
  String get shortcutGroupCreateAndEdit => 'ایجاد و ویرایش';

  @override
  String get shortcutSaveItem => 'ذخیرهٔ رویداد یا کار';

  @override
  String get shortcutDeleteItem => 'حذف رویداد یا کار';

  @override
  String get shortcutGroupTaskEditing => 'ویرایش کار';

  @override
  String get shortcutCancelEditing => 'لغو ویرایش';

  @override
  String get shortcutCancelEditingDescription => 'بستن ویرایش یا جزئیات کار';

  @override
  String get aboutBusyMax => 'دربارهٔ BusyMax';

  @override
  String get aboutBusyMaxDescription => 'تقویم و کارها';

  @override
  String get license => 'مجوز';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'وب‌سایت';

  @override
  String get sourceCode => 'کد منبع';

  @override
  String get reportAnIssue => 'گزارش مشکل';

  @override
  String get sendFeedback => 'ارسال بازخورد';

  @override
  String get feedbackSubmit => 'ارسال';

  @override
  String get feedbackCategory => 'دسته‌بندی';

  @override
  String get feedbackSelectCategory => 'یک دسته‌بندی انتخاب کنید';

  @override
  String get feedbackCategoryProblem => 'مشکل یا اشکال';

  @override
  String get feedbackCategoryFeature => 'درخواست قابلیت';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'نگرانی دربارهٔ حریم خصوصی یا امنیت';

  @override
  String get feedbackCategoryUsability => 'نگرانی دربارهٔ کاربردپذیری';

  @override
  String get feedbackCategoryOther => 'سایر';

  @override
  String get feedbackSubject => 'موضوع';

  @override
  String get feedbackDetailedMessage => 'پیام با جزئیات';

  @override
  String get feedbackReplyEmail => 'نشانی ایمیل برای پاسخ (اختیاری)';

  @override
  String get feedbackIncludeTechnicalDetails => 'افزودن جزئیات فنی';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'فقط نام و نسخهٔ سیستم‌عامل و تنظیمات منطقه‌ای برنامه افزوده می‌شود. هیچ گزارش، دادهٔ حساب، نام پرونده یا اطلاعات تشخیصی دیگری افزوده نمی‌شود.';

  @override
  String get feedbackCategoryRequired => 'یک دسته‌بندی انتخاب کنید.';

  @override
  String get feedbackSubjectLengthError =>
      'موضوع باید بین ۳ تا ۱۲۰ نویسه باشد.';

  @override
  String get feedbackMessageLengthError =>
      'پیام باید بین ۱۰ تا ۵٬۰۰۰ نویسه باشد.';

  @override
  String get feedbackInvalidEmail => 'یک نشانی ایمیل معتبر وارد کنید.';

  @override
  String get feedbackConnectionError =>
      'اتصال به BusyStack ممکن نشد. اتصال خود را بررسی و دوباره تلاش کنید.';

  @override
  String get feedbackTimeoutError =>
      'مهلت درخواست پایان یافت. بازخورد شما پاک نشده است؛ دوباره تلاش کنید.';

  @override
  String get feedbackRateLimitedError =>
      'بازخوردهای بیش از حدی از این شبکه ارسال شده است. کمی صبر کنید و دوباره تلاش کنید.';

  @override
  String get feedbackRejectedError =>
      'سرور ارسال را رد کرد. فیلدها را بررسی و دوباره تلاش کنید.';

  @override
  String get feedbackServerError =>
      'BusyStack اکنون نمی‌تواند بازخورد شما را بپذیرد. بازخورد شما پاک نشده است؛ دوباره تلاش کنید.';

  @override
  String feedbackSuccess(String id) {
    return 'بازخورد ارسال شد. شناسهٔ پیگیری: ⁨⁨$id⁩⁩';
  }

  @override
  String get toggleSidebar => 'نمایش یا پنهان کردن نوار کناری';

  @override
  String get showSidebar => 'نمایش پنل کناری';

  @override
  String get hideSidebar => 'پنهان کردن پنل کناری';

  @override
  String get accounts => 'حساب‌ها';

  @override
  String get currentAccount => 'حساب فعلی';

  @override
  String get switchAccount => 'تعویض حساب';

  @override
  String get addGoogleAccount => 'افزودن حساب Google';

  @override
  String get addMicrosoftAccount => 'افزودن حساب Microsoft';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'وارد شده';

  @override
  String get removeAccount => 'حذف حساب…';

  @override
  String get removingAccount => 'در حال حذف حساب…';

  @override
  String get removeAccountDescription =>
      'همگام‌سازی را متوقف و داده‌های این حساب را از این دستگاه حذف کنید.';

  @override
  String removeAccountTitle(String account) {
    return '⁨⁨$account⁩⁩ از BusyMax حذف شود؟';
  }

  @override
  String get removeAccountConfirmation =>
      'این کار، کارها، تقویم‌ها، رویدادها، یادآورها و تغییرات آفلاین در انتظار را که در این دستگاه ذخیره شده‌اند حذف می‌کند. تغییرات همگام‌نشده از بین می‌روند. نسخه‌های تقویم‌ها، رویدادها، فهرست‌های کار و کارها نزد ارائه‌دهنده حذف نمی‌شوند.';

  @override
  String get revokeGoogleAccess =>
      'دسترسی BusyMax به این حساب Google نیز لغو شود';

  @override
  String get revokeGoogleAccessDescription =>
      'پیش از اتصال دوباره باید دسترسی را دوباره اعطا کنید.';

  @override
  String get removeAccountAction => 'حذف حساب';

  @override
  String get removeAccountFailed => 'حذف حساب کامل نشد. دوباره تلاش کنید.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'حساب از این دستگاه حذف شد، اما BusyMax نتوانست دسترسی Google را لغو کند. می‌توانید آن را از حساب Google خود لغو کنید.';

  @override
  String get newTaskList => 'فهرست کار جدید';

  @override
  String taskListCreateFailed(String error) {
    return 'ایجاد فهرست کار ممکن نیست: ⁨$error⁩';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'تغییر نام فهرست کار ممکن نیست: ⁨$error⁩';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'حذف فهرست کار ممکن نیست: ⁨$error⁩';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'پیش از حذف یا برداشتن فهرست، حساب را همگام‌سازی کنید یا تغییرات مسدودشدهٔ این فهرست کار را در «عیب‌یابی» برطرف کنید.';

  @override
  String get signInToViewTaskLists => 'برای دیدن فهرست‌های کار وارد شوید.';

  @override
  String get noTaskListsSynced => 'هنوز هیچ فهرست کاری همگام نشده است.';

  @override
  String get listActions => 'عملیات فهرست';

  @override
  String get rename => 'تغییر نام';

  @override
  String get delete => 'حذف';

  @override
  String get renameList => 'تغییر نام فهرست';

  @override
  String get deleteList => 'حذف فهرست';

  @override
  String get unshare => 'لغو اشتراک‌گذاری';

  @override
  String get readOnlyTaskListCannotRename =>
      'این فهرست کار فقط‌خواندنی است و نمی‌توان نام آن را تغییر داد.';

  @override
  String get taskListCannotDelete =>
      'این فهرست کار با مجوزهای فعلی شما قابل حذف نیست.';

  @override
  String get builtInMicrosoftList => 'داخلی';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'فهرست‌های داخلی Microsoft To Do را نمی‌توان تغییر نام داد یا حذف کرد.';

  @override
  String deleteListConfirmation(String title) {
    return '‏«⁨⁨$title⁩⁩» از Google Tasks حذف شود؟';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return '‏«⁨$title⁩» و همهٔ کارهای آن حذف شوند؟';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'اشتراک‌گذاری «⁨$title⁩» از این حساب لغو شود؟';
  }

  @override
  String get deleteEvent => 'حذف رویداد';

  @override
  String get title => 'عنوان';

  @override
  String get create => 'ایجاد';

  @override
  String get newTask => 'کار جدید';

  @override
  String get clearCompleted => 'پاک کردن کارهای انجام‌شده';

  @override
  String get refreshList => 'تازه‌سازی فهرست';

  @override
  String get refreshAll => 'تازه‌سازی همه';

  @override
  String get listRefreshed => 'فهرست تازه‌سازی شد.';

  @override
  String get allTasksRefreshed => 'همهٔ حساب‌ها تازه‌سازی شدند.';

  @override
  String exportedFile(String path) {
    return 'در ⁨⁨$path⁩⁩ خروجی گرفته شد';
  }

  @override
  String exportFailed(String error) {
    return 'خروجی گرفتن ناموفق بود: ⁨⁨$error⁩⁩';
  }

  @override
  String refreshFailed(String error) {
    return 'تازه‌سازی ناموفق بود: ⁨⁨$error⁩⁩';
  }

  @override
  String get selectOrCreateTaskList =>
      'برای شروع، یک فهرست کار انتخاب یا ایجاد کنید.';

  @override
  String get signInToViewTasks => 'برای دیدن کارها وارد شوید.';

  @override
  String get noTasks => 'هیچ کاری وجود ندارد.';

  @override
  String get noTasksYet => 'هنوز کاری وجود ندارد';

  @override
  String get noTasksYetMessage =>
      'برای شروع یک کار ایجاد کنید یا حساب‌هایتان را تازه‌سازی کنید.';

  @override
  String get noTasksInList => 'هیچ کاری در این فهرست وجود ندارد.';

  @override
  String get overdue => 'گذشته از موعد';

  @override
  String get today => 'امروز';

  @override
  String get tomorrow => 'فردا';

  @override
  String get upcoming => 'پیش رو';

  @override
  String get noDate => 'بدون تاریخ';

  @override
  String get completed => 'انجام‌شده';

  @override
  String duePrefix(String date) {
    return 'سررسید: ⁨⁨$date⁩⁩';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '⁨⁨$date⁩⁩ · ⁨⁨$time⁩⁩';
  }

  @override
  String get taskDetails => 'جزئیات کار';

  @override
  String get editTask => 'ویرایش کار';

  @override
  String get noTaskSelected => 'هیچ کاری انتخاب نشده است.';

  @override
  String get noTaskSelectedHelper =>
      'برای دیدن و ویرایش جزئیات، کاری را انتخاب کنید.';

  @override
  String get taskUnavailable => 'کار در دسترس نیست.';

  @override
  String get signInToEditTasks => 'برای ویرایش کارها وارد شوید.';

  @override
  String get refreshTask => 'تازه‌سازی کار';

  @override
  String get primarySection => 'اصلی';

  @override
  String get statusSection => 'وضعیت';

  @override
  String get openStatus => 'باز';

  @override
  String get doneStatus => 'انجام‌شده';

  @override
  String get taskStatus => 'وضعیت';

  @override
  String get taskStatusNone => 'بدون وضعیت';

  @override
  String get taskStatusNeedsAction => 'نیازمند اقدام';

  @override
  String get taskStatusInProcess => 'در حال انجام';

  @override
  String get taskStatusCompleted => 'انجام‌شده';

  @override
  String get taskStatusCancelled => 'لغوشده';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString٪ تکمیل‌شده';
  }

  @override
  String get completionDate => 'تاریخ تکمیل';

  @override
  String get priority => 'اولویت';

  @override
  String get priorityNone => 'بدون اولویت';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'اولویت $priorityString · زیاد';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'اولویت $priorityString · متوسط';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'اولویت $priorityString · کم';
  }

  @override
  String get taskUrl => 'URL کار';

  @override
  String get invalidTaskUrl => 'یک URL مطلق شامل طرح آن وارد کنید.';

  @override
  String get classification => 'دسته‌بندی';

  @override
  String get classificationPublic => 'هنگام اشتراک‌گذاری، کل کار نشان داده شود';

  @override
  String get classificationConfidential =>
      'هنگام اشتراک‌گذاری، فقط مشغول بودن نشان داده شود';

  @override
  String get classificationPrivate => 'هنگام اشتراک‌گذاری، این کار پنهان شود';

  @override
  String get pinTask => 'سنجاق کردن کار';

  @override
  String get notes => 'یادداشت‌ها';

  @override
  String get dueDate => 'تاریخ سررسید';

  @override
  String get clearDueDate => 'پاک کردن تاریخ سررسید';

  @override
  String get dueTime => 'زمان سررسید';

  @override
  String get startDate => 'تاریخ شروع';

  @override
  String get startTime => 'زمان شروع';

  @override
  String get endDate => 'تاریخ پایان';

  @override
  String get endTime => 'زمان پایان';

  @override
  String get reminderDate => 'تاریخ یادآور';

  @override
  String get reminderTime => 'زمان یادآور';

  @override
  String get reminder => 'یادآور';

  @override
  String get addReminder => 'افزودن یادآور';

  @override
  String get reminders => 'یادآورها';

  @override
  String get noReminders => 'بدون یادآور';

  @override
  String get editReminder => 'ویرایش یادآور';

  @override
  String get beforeTaskStarts => 'پیش از شروع کار';

  @override
  String get beforeTaskDue => 'پیش از سررسید کار';

  @override
  String get afterTaskStarts => 'پس از شروع کار';

  @override
  String get afterTaskDue => 'پس از سررسید کار';

  @override
  String get relativeToTaskStart => 'نسبت به تاریخ شروع کار';

  @override
  String get relativeToTaskDue => 'نسبت به تاریخ سررسید کار';

  @override
  String get reminderTimeOfDay => 'زمان روز';

  @override
  String get absoluteReminder => 'در تاریخ و زمان مشخص';

  @override
  String get reminderAmount => 'مقدار';

  @override
  String get reminderUnit => 'واحد';

  @override
  String get reminderUnitSeconds => 'ثانیه';

  @override
  String get reminderUnitMinutes => 'دقیقه';

  @override
  String get reminderUnitHours => 'ساعت';

  @override
  String get reminderUnitDays => 'روز';

  @override
  String get reminderUnitWeeks => 'هفته';

  @override
  String get reminderAtTaskStart => 'هنگام شروع کار';

  @override
  String get reminderAtTaskDue => 'هنگام سررسید کار';

  @override
  String get unsupportedReminder =>
      'نوع این یادآور حفظ می‌شود، اما زمان آن قابل ویرایش نیست.';

  @override
  String get relatedRemindersTitle => 'یادآورهای مرتبط نگه داشته شوند؟';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'این تاریخ $countString یادآور مرتبط دارد. آن‌ها در تاریخ و زمان فعلی نگه داشته شوند؟';
  }

  @override
  String get discardRelatedReminders => 'دور انداختن یادآورها';

  @override
  String get keepRelatedReminders => 'نگه‌داشتن یادآورها';

  @override
  String get addGuest => 'افزودن مهمان';

  @override
  String get addGuestEmail => 'افزودن ایمیل مهمان';

  @override
  String get removeReminder => 'حذف یادآور';

  @override
  String get off => 'خاموش';

  @override
  String get repeat => 'تکرار';

  @override
  String get repeatNone => 'بدون تکرار';

  @override
  String get noneValue => 'هیچ‌کدام';

  @override
  String get repeatDaily => 'روزانه';

  @override
  String get repeatWeekly => 'هفتگی';

  @override
  String get repeatMonthly => 'ماهانه';

  @override
  String get repeatYearly => 'سالانه';

  @override
  String get repeatEvery => 'فاصلهٔ تکرار';

  @override
  String get repeatOn => 'تکرار در';

  @override
  String get repeatEnd => 'پایان تکرار';

  @override
  String get repeatNever => 'هرگز';

  @override
  String get repeatUntil => 'در تاریخ';

  @override
  String get repeatAfter => 'پس از تعداد مشخصی تکرار';

  @override
  String get repeatCount => 'تعداد تکرار';

  @override
  String get repeatDayOfMonth => 'روزهای ماه';

  @override
  String get repeatMonths => 'ماه‌ها';

  @override
  String get repeatOrdinal => 'جایگاه روز هفته';

  @override
  String get repeatSpecificDays => 'روزهای مشخص';

  @override
  String get repeatFirst => 'اول';

  @override
  String get repeatSecond => 'دوم';

  @override
  String get repeatThird => 'سوم';

  @override
  String get repeatFourth => 'چهارم';

  @override
  String get repeatFifth => 'پنجم';

  @override
  String get repeatSecondToLast => 'یکی مانده به آخر';

  @override
  String get repeatLast => 'آخر';

  @override
  String get repeatAnyDay => 'روز';

  @override
  String get repeatWeekday => 'روز هفته';

  @override
  String get repeatWeekendDay => 'روز آخر هفته';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'دوشنبه',
      'TU': 'سه‌شنبه',
      'WE': 'چهارشنبه',
      'TH': 'پنجشنبه',
      'FR': 'جمعه',
      'SA': 'شنبه',
      'SU': 'یکشنبه',
      'day': 'روز',
      'weekday': 'روز هفته',
      'weekend': 'روز آخر هفته',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'هر $countString روز';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'هر $countString هفته';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'هر $countString ماه';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'هر $countString سال';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return 'در $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'در روز $days ماه';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'در اولین $days',
      'second': 'در دومین $days',
      'third': 'در سومین $days',
      'fourth': 'در چهارمین $days',
      'fifth': 'در پنجمین $days',
      'secondToLast': 'در یکی‌مانده‌به‌آخرین $days',
      'last': 'در آخرین $days',
      'other': 'در $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'در $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString بار',
      one: '$countString بار',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'تا ⁨$date⁩';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'این قانون تکرار از گزینه‌هایی استفاده می‌کند که این ویرایشگر تغییر نمی‌دهد.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'این فهرست از این الگوی تکرار پشتیبانی نمی‌کند. الگو را تغییر دهید یا فهرست دیگری انتخاب کنید.';

  @override
  String get taskRecurrenceRequiresDate =>
      'برای استفاده از این الگوی تکرار، تاریخ شروع یا سررسید اضافه کنید یا تکرار را خاموش کنید.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'این تکرار را نمی‌توان با ⁨$provider⁩ استفاده کرد.';
  }

  @override
  String get importance => 'اهمیت';

  @override
  String get importanceLow => 'کم';

  @override
  String get importanceNormal => 'عادی';

  @override
  String get importanceHigh => 'زیاد';

  @override
  String get categories => 'دسته‌ها';

  @override
  String get scheduleSection => 'برنامه';

  @override
  String get dueGroup => 'سررسید';

  @override
  String get startGroup => 'شروع';

  @override
  String get reminderGroup => 'یادآور';

  @override
  String get organizationSection => 'سازمان‌دهی';

  @override
  String get actionsSection => 'عملیات';

  @override
  String get advancedSection => 'پیشرفته';

  @override
  String get addCategory => 'افزودن دسته';

  @override
  String get list => 'فهرست';

  @override
  String get microsoftMoveUnsupported =>
      'در این نسخه، جابه‌جایی کارها بین فهرست‌های حساب Microsoft To Do پشتیبانی نمی‌شود.';

  @override
  String get createSubtask => 'ایجاد زیرکار';

  @override
  String get subtasks => 'زیرکارها';

  @override
  String get duplicateTask => 'تکرار کار';

  @override
  String get taskDuplicated => 'کار تکرار شد.';

  @override
  String taskDuplicateFailed(String error) {
    return 'تکرار کار ممکن نیست: ⁨$error⁩';
  }

  @override
  String get hideSubtasks => 'پنهان کردن زیروظیفه‌ها';

  @override
  String get hideClosedSubtasks => 'پنهان کردن زیروظیفه‌های بسته‌شده';

  @override
  String get moveToTop => 'انتقال به بالاترین جایگاه';

  @override
  String get deleteTask => 'حذف کار';

  @override
  String get newSubtask => 'زیرکار جدید';

  @override
  String deleteTaskConfirmation(String title) {
    return '«⁨⁨$title⁩⁩» حذف شود؟';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'این کار، وظیفهٔ اصلی را نیز در Google Docs یا فضاهای Chat حذف می‌کند.';

  @override
  String get metadata => 'فراداده';

  @override
  String get id => 'شناسه';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'به‌روزشده';

  @override
  String get parent => 'کار والد';

  @override
  String get position => 'جایگاه';

  @override
  String get webLink => 'پیوند وب';

  @override
  String get assignment => 'واگذاری';

  @override
  String get localState => 'وضعیت محلی';

  @override
  String get pendingSync => 'در انتظار همگام‌سازی';

  @override
  String get synced => 'همگام‌شده';

  @override
  String get account => 'حساب';

  @override
  String get sync => 'همگام‌سازی';

  @override
  String get forceFullResync => 'اجبار به همگام‌سازی مجدد کامل';

  @override
  String get forceFullResyncDescription =>
      'همهٔ داده‌های هر حساب متصل را به‌طور کامل دوباره بارگیری می‌کند. فقط برای عیب‌یابی مشکلات همگام‌سازی از این گزینه استفاده کنید.';

  @override
  String get runInBackgroundWhenClosed => 'ادامهٔ اجرا پس از بسته شدن پنجره';

  @override
  String get showTrayIcon => 'نمایش نماد سینی سیستم';

  @override
  String get startMinimizedToTray => 'شروع به‌صورت کوچک‌شده در سینی سیستم';

  @override
  String get launchAtLogin => 'اجرا هنگام ورود';

  @override
  String get launchAtLoginDescription =>
      'BusyMax را در پس‌زمینه اجرا کنید تا یادآورها پس از ورود کار کنند.';

  @override
  String get launchAtLoginFailed => 'تنظیم اجرای هنگام ورود به‌روزرسانی نشد.';

  @override
  String get requiresTrayIcon => 'به نماد سینی سیستم نیاز دارد.';

  @override
  String get syncComplete => 'همگام‌سازی کامل شد.';

  @override
  String syncFailed(String error) {
    return 'همگام‌سازی ناموفق بود: ⁨⁨$error⁩⁩';
  }

  @override
  String get notifySyncFailures => 'اعلان هنگام شکست همگام‌سازی';

  @override
  String get notifyConflicts => 'اعلان هنگام تداخل';

  @override
  String get notifyDueToday => 'اعلان کارهای دارای سررسید امروز';

  @override
  String get eventReminders => 'یادآورهای رویداد';

  @override
  String get onState => 'روشن';

  @override
  String get taskReminders => 'یادآورهای کار';

  @override
  String get notificationDetailLevel => 'سطح جزئیات اعلان';

  @override
  String get notificationDetailPrivate => 'خصوصی';

  @override
  String get notificationDetailNormal => 'عادی';

  @override
  String get quietHours => 'ساعات سکوت';

  @override
  String get quietHoursDescription =>
      'اعلان‌ها را در این بازه موقتاً متوقف کنید.';

  @override
  String get quietHoursStart => 'شروع ساعات سکوت';

  @override
  String get quietHoursEnd => 'پایان ساعات سکوت';

  @override
  String get notifications => 'اعلان‌ها';

  @override
  String get windowsNotificationsUnavailable =>
      'اعلان‌های Windows در دسترس نیستند';

  @override
  String get windowsNotificationsUnpackaged =>
      'این اجرای توسعه‌ای بسته‌بندی‌نشده نمی‌تواند از اعلان‌های Windows استفاده کند. برای آزمایش یادآورها، MSIX امضاشدهٔ آزمایشی را نصب کنید.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax نتوانست اعلان‌های Windows را راه‌اندازی کند. تا برطرف شدن این مشکل نصب، یادآورها نمایش داده نمی‌شوند.';

  @override
  String get appearance => 'ظاهر';

  @override
  String get theme => 'پوسته';

  @override
  String get themeSystem => 'سیستم';

  @override
  String get settingsSystem => 'سیستم';

  @override
  String get themeLight => 'روشن';

  @override
  String get themeDark => 'تیره';

  @override
  String get themeFamily => 'خانوادهٔ پوسته';

  @override
  String get themeFamilyYaru => 'پوستهٔ بومی Ubuntu ‏(Yaru)';

  @override
  String get localization => 'زبان و منطقه';

  @override
  String get currentLocale => 'زبان و منطقهٔ فعلی';

  @override
  String get privacy => 'حریم خصوصی';

  @override
  String get redactTaskContentInDiagnostics =>
      'پنهان کردن محتوای کارها در اطلاعات تشخیصی';

  @override
  String get developerDiagnostics => 'تشخیص‌های توسعه‌دهنده';

  @override
  String get diagnostics => 'اطلاعات تشخیصی';

  @override
  String get apiInspectorDisabled => 'نمایش بازرس API';

  @override
  String get googleTasksApi => 'رابط Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'بازبینی Discovery: ⁨⁨$revision⁩⁩';
  }

  @override
  String get implementedMethods => 'روش‌های پیاده‌سازی‌شده';

  @override
  String get supportsTasksScopes =>
      'از محدوده‌های tasks و tasks.readonly پشتیبانی می‌کند';

  @override
  String get requiresTasksScope => 'به محدودهٔ tasks نیاز دارد';

  @override
  String get blockedPendingOperations => 'عملیات در انتظار مسدودشده';

  @override
  String get signInToInspectPendingOperations =>
      'برای بررسی عملیات در انتظار وارد شوید.';

  @override
  String get noBlockedPendingOperations =>
      'هیچ عملیات در انتظار مسدودشده‌ای وجود ندارد.';

  @override
  String get operationActions => 'اقدامات عملیات';

  @override
  String pendingOpListId(String id) {
    return 'فهرست=⁨⁨$id⁩⁩';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'کار=⁨⁨$id⁩⁩';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'تلاش‌ها=⁨$countString⁩';
  }

  @override
  String get retry => 'تلاش دوباره';

  @override
  String get discard => 'کنار گذاشتن';

  @override
  String get discardChangesAction => 'ذخیره نشود';

  @override
  String get discardChanges => 'تغییرات کنار گذاشته شوند؟';

  @override
  String get discardChangesConfirmation =>
      'با این کار ویرایش‌های ذخیره‌نشدهٔ این کار کنار گذاشته می‌شوند.';

  @override
  String get retryCompleted => 'تلاش دوباره کامل شد.';

  @override
  String get discardPendingOperation => 'عملیات در انتظار کنار گذاشته شود؟';

  @override
  String get discardPendingOperationConfirmation =>
      'با این کار عملیات محلی مسدودشده حذف می‌شود. در همگام‌سازی بعدی، داده‌ها از Google Tasks تازه‌سازی می‌شوند.';

  @override
  String get pendingOperationDiscarded => 'عملیات در انتظار کنار گذاشته شد.';

  @override
  String get syncFailureNotificationTitle => 'همگام‌سازی BusyMax ناموفق بود';

  @override
  String syncFailureNotificationBody(String message) {
    return 'همگام‌سازی پس‌زمینه ناموفق بود. ⁨⁨$message⁩⁩';
  }

  @override
  String get conflictNotificationTitle => 'تداخل همگام‌سازی BusyMax';

  @override
  String conflictNotificationBody(String summary) {
    return 'یک تغییر محلی در انتظار مسدود شد. ⁨⁨$summary⁩⁩';
  }

  @override
  String get dueTodayNotificationTitle => 'کارهای دارای سررسید امروز';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'امروز ⁨$countString⁩ کار سررسید دارند.',
      one: 'امروز یک کار سررسید دارد.',
      zero: 'امروز هیچ کاری سررسید ندارد.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'یادآور رویداد';

  @override
  String get taskReminderNotificationTitle => 'یادآور کار';

  @override
  String get eventReminderNotificationBody => 'رویداد به‌زودی شروع می‌شود.';

  @override
  String get taskReminderNotificationBody => 'سررسید کار نزدیک است.';

  @override
  String get notificationOpenAction => 'باز کردن';

  @override
  String get notificationSnoozeAction => 'تعویق ۱۰ دقیقه‌ای';

  @override
  String get notificationDismissAction => 'بستن';

  @override
  String get notificationDetailsHidden =>
      'جزئیات به‌دلیل تنظیمات حریم خصوصی پنهان شده‌اند.';

  @override
  String get previousMonth => 'ماه قبل';

  @override
  String get nextMonth => 'ماه بعد';

  @override
  String get openMonthView => 'باز کردن نمای ماه';

  @override
  String get previousYear => 'سال قبل';

  @override
  String get nextYear => 'سال بعد';

  @override
  String get openYearView => 'باز کردن نمای سال';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'هفتهٔ ⁨$numberString⁩';
  }

  @override
  String get resizeAllDayPanel => 'تغییر اندازهٔ پنل تمام‌روز';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '⁨$countString⁩ مورد',
      one: 'یک مورد',
      zero: 'هیچ موردی',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'این تقویم فقط‌خواندنی است.';

  @override
  String get selectTimeZone => 'انتخاب منطقهٔ زمانی';

  @override
  String get searchLocations => 'جست‌وجوی مکان‌ها';

  @override
  String get noLocationsFound => 'مکانی پیدا نشد';

  @override
  String get requiredField => 'این فیلد الزامی است.';

  @override
  String get providerConnectionDescription =>
      'تقویم‌ها و کارها را از یکی از این ارائه‌دهندگان متصل کنید.';

  @override
  String get appleICloudProvider => 'تقویم Apple iCloud';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'کارهای Nextcloud';

  @override
  String get addAppleICloudAccount => 'افزودن حساب تقویم Apple iCloud';

  @override
  String get addNextcloudAccount => 'افزودن حساب Nextcloud';

  @override
  String get waitingForAppleICloud => 'در حال اتصال به Apple iCloud…';

  @override
  String get waitingForNextcloud => 'در انتظار تأیید Nextcloud…';

  @override
  String get connectAppleICloudTitle => 'اتصال تقویم Apple iCloud';

  @override
  String get appleAccountEmail => 'ایمیل حساب Apple';

  @override
  String get appleAppSpecificPassword => 'گذرواژهٔ اختصاصی برنامه';

  @override
  String get appleAppSpecificPasswordHelp =>
      'پس از فعال کردن احراز هویت دومرحله‌ای برای حساب Apple، یک گذرواژهٔ اختصاصی برنامه بسازید.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'بازنشانی گذرواژهٔ حساب Apple، گذرواژه‌های اختصاصی برنامه را باطل می‌کند.';

  @override
  String get connectNextcloudTitle => 'اتصال Nextcloud';

  @override
  String get nextcloudServerUrl => 'سرور Nextcloud یا نشانی CalDAV';

  @override
  String get nextcloudServerUrlHelp =>
      'URL سرور Nextcloud خود را وارد کنید یا نشانی اصلی CalDAV را که از Nextcloud کپی کرده‌اید بچسبانید.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax مرورگر شما را باز می‌کند. آنجا دسترسی را تأیید کنید و سپس به BusyMax برگردید.';

  @override
  String get connectAccountAction => 'اتصال';

  @override
  String get cancelAccountConnection => 'لغو اتصال';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'حساب به‌صورت محلی حذف شد، اما ابطال گذرواژهٔ برنامهٔ Nextcloud ممکن نیست.';

  @override
  String get davReauthenticationRequired =>
      'برای ادامهٔ همگام‌سازی، این حساب را دوباره متصل کنید.';

  @override
  String get davTemporarilyUnavailable => 'این حساب موقتاً در دسترس نیست.';

  @override
  String get davPermissionChanged =>
      'مجوزهای سرور تغییر کرده‌اند. ویرایش‌های در انتظار متوقف شده‌اند.';

  @override
  String get davUnsupportedServer =>
      'این سرور یا نمایهٔ ارائه‌دهنده پشتیبانی نمی‌شود.';

  @override
  String get collectionSettings => 'تقویم‌ها و فهرست‌های کار';

  @override
  String get calendarContent => 'رویدادهای تقویم';

  @override
  String get taskContent => 'کارها';

  @override
  String get readOnlySharedCollection => 'فقط‌خواندنی';

  @override
  String get pendingLocally => 'در انتظار محلی';

  @override
  String get conflictBlocked => 'مسدودشده به‌دلیل تعارض';

  @override
  String get authenticationBlocked => 'تا اتصال دوباره مسدود است';

  @override
  String get operationFailed => 'عملیات ناموفق بود';

  @override
  String get keepServerVersion => 'نگه‌داشتن نسخهٔ سرور';

  @override
  String get reapplyLocalChange => 'بررسی و اعمال دوبارهٔ تغییر محلی';

  @override
  String get duplicateLocalItem => 'تکرار به‌عنوان مورد جدید';

  @override
  String get davConnectionState => 'وضعیت اتصال';

  @override
  String get davConnected => 'متصل';

  @override
  String get davConnecting => 'در حال اتصال…';

  @override
  String get davSignedOut => 'خارج‌شده';

  @override
  String davLastSuccessfulSync(String time) {
    return 'آخرین همگام‌سازی موفق: ⁨$time⁩';
  }

  @override
  String get davNeverSynced => 'هنوز همگام نشده';

  @override
  String get refreshCollections => 'تازه‌سازی تقویم‌ها و فهرست‌های کار';

  @override
  String nextcloudServerHost(String host) {
    return 'سرور: ⁨$host⁩';
  }

  @override
  String get collectionSupportsEvents => 'تقویم رویدادها';

  @override
  String get collectionSupportsTasks => 'فهرست کار';

  @override
  String get collectionSupportsEventsAndTasks => 'رویدادها و کارها';

  @override
  String get writableCollection => 'قابل نوشتن';

  @override
  String get sharedCollection => 'اشتراکی';

  @override
  String collectionLastSynced(String time) {
    return 'آخرین همگام‌سازی: ⁨$time⁩';
  }

  @override
  String collectionSyncError(String code) {
    return 'مشکل همگام‌سازی: ⁨$code⁩';
  }

  @override
  String get syncConflicts => 'تعارض‌های همگام‌سازی';

  @override
  String remoteChangedAt(String time) {
    return 'تغییر سرور: ⁨$time⁩';
  }

  @override
  String localPendingEdit(String summary) {
    return 'ویرایش محلی: ⁨$summary⁩';
  }

  @override
  String get conflictResolutionFailed => 'حل تعارض ممکن نیست.';

  @override
  String get recurringEventScope => 'دامنهٔ رویداد تکرارشونده';

  @override
  String get entireSeries => 'کل مجموعه';

  @override
  String get singleOccurrence => 'این رویداد';

  @override
  String get thisAndFollowingEvents => 'این رویداد و رویدادهای بعدی';

  @override
  String get thisAndFutureUnavailable =>
      'این ارائه‌دهنده از آن پشتیبانی نمی‌کند.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'انتقال امن این رویداد و رویدادهای بعدی ممکن نیست. این رویداد یا کل مجموعه را انتخاب کنید.';

  @override
  String get entireSeriesMoveUnavailable =>
      'قاعدهٔ تکرار به‌صورت محلی در دسترس نیست. به‌جای آن فقط این رویداد را منتقل کنید.';

  @override
  String get copyEventAndDeleteOriginal => 'رویداد کپی و نسخهٔ اصلی حذف شود؟';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax نمی‌تواند این رویداد را مستقیماً از ⁨$source⁩ به ⁨$destination⁩ منتقل کند. ابتدا کپی را ایجاد می‌کند و فقط پس از موفقیت کپی، نسخهٔ اصلی را حذف می‌کند. شناسه‌های رویداد تغییر می‌کنند؛ ممکن است وضعیت پاسخ شرکت‌کنندگان بازنشانی شود و دعوت‌نامه یا لغو ارسال شود؛ و شاید پیوندهای جلسه، پیوست‌ها، یادآورها، فیلدهای ویژهٔ ارائه‌دهنده و استثناهای تکرار منتقل نشوند.';
  }

  @override
  String get copyAndDelete => 'کپی و حذف';

  @override
  String get chooseRecurringEventScope =>
      'انتخاب کنید این تغییر برای کل مجموعه، فقط این رویداد، یا این رویداد و رویدادهای بعدی اعمال شود.';

  @override
  String get taskDueBeforeStart => 'زمان سررسید نباید پیش از زمان شروع باشد.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'برای شروع و سررسید هر دو زمان تعیین کنید، یا کار را تمام‌روز کنید.';

  @override
  String deleteCalendarConfirmation(String title) {
    return '«⁨⁨$title⁩⁩» حذف شود؟';
  }

  @override
  String get setCustomCalendarName => 'تنظیم نام سفارشی';

  @override
  String get setAction => 'تنظیم';

  @override
  String get removeFromMyCalendars => 'حذف از تقویم‌های من';

  @override
  String get removeAction => 'حذف';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return '«⁨$title⁩» از BusyMax حذف شود؟ تقویم و رویدادهای مالک حذف نخواهند شد.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'ممکن است بارگذاری کامل شده باشد. پیش از بارگذاری دوباره، پیوست‌ها را تازه‌سازی کنید تا نتیجه مشخص شود.';

  @override
  String removeCalendarConfirmation(String title) {
    return '«⁨$title⁩» از فهرست تقویم Google شما حذف شود؟ تقویم اشتراکی و رویدادهای آن حذف نخواهند شد.';
  }

  @override
  String get calendarCannotRemove =>
      'این تقویم را نمی‌توان از این حساب حذف یا جدا کرد.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'پیش از حذف یا جدا کردن این تقویم، صبر کنید تغییرات در انتظار آن همگام شوند.';

  @override
  String get calendarSubscriptions => 'اشتراک‌های تقویم';

  @override
  String get calendarSubscriptionsDescription =>
      'تقویم‌های فقط‌خواندنی را اضافه کنید که از یک URL امن WebCal تازه می‌شوند.';

  @override
  String get addCalendarSubscription => 'افزودن اشتراک تقویم';

  @override
  String get subscriptionName => 'نام محلی';

  @override
  String get subscriptionUrl => 'URL اشتراک';

  @override
  String get subscriptionUrlHelp =>
      'یک URL از نوع HTTPS یا webcal وارد کنید. BusyMax URL کامل را در فضای ذخیره‌سازی امن نگه می‌دارد.';

  @override
  String get subscriptionUrlInvalid =>
      'یک URL معتبر HTTPS یا webcal بدون اطلاعات کاربر یا قطعه وارد کنید.';

  @override
  String get subscriptionColor => 'رنگ محلی';

  @override
  String get subscriptionColorHelp => 'یک رنگ شش‌رقمی مانند #3584E4 وارد کنید.';

  @override
  String get subscriptionColorInvalid => 'یک رنگ هگزادسیمال شش‌رقمی وارد کنید.';

  @override
  String get subscriptionRefreshMode => 'دفعات تازه‌سازی';

  @override
  String get subscriptionAutomatic => 'خودکار';

  @override
  String get subscriptionHourly => 'ساعتی';

  @override
  String get subscriptionSixHours => 'هر شش ساعت';

  @override
  String get subscriptionDaily => 'روزانه';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'مبدأ: ⁨$origin⁩';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'برای پیش‌نمایش مبدأ امن، یک URL معتبر وارد کنید.';

  @override
  String get subscriptionReadOnly => 'اشتراک فقط‌خواندنی';

  @override
  String get subscriptionNeverRefreshed => 'هنوز تازه نشده';

  @override
  String subscriptionLastRefresh(String time) {
    return 'آخرین تازه‌سازی موفق: ⁨$time⁩';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'تازه‌سازی بعدی: ⁨$time⁩';
  }

  @override
  String get subscriptionStatusHealthy => 'به‌روز';

  @override
  String subscriptionStatusIssue(String code) {
    return 'مشکل تازه‌سازی: ⁨$code⁩';
  }

  @override
  String get refreshNow => 'تازه‌سازی اکنون';

  @override
  String get unsubscribe => 'لغو اشتراک';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'اشتراک «⁨$name⁩» لغو شود؟';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'این کار اشتراک محلی و رویدادهای ذخیره‌شدهٔ آن را حذف می‌کند. تقویم منتشرشده تغییر نمی‌کند.';

  @override
  String get addSubscriptionAction => 'افزودن اشتراک';

  @override
  String subscriptionOperationFailed(String error) {
    return 'اشتراک تقویم ناموفق بود: ⁨$error⁩';
  }

  @override
  String get subscriptions => 'اشتراک‌ها';

  @override
  String get calendarImport => 'درون‌ریزی تقویم';

  @override
  String get calendarImportDescription =>
      'یک فایل انتخاب کنید، رویدادهای آن را بررسی کنید و سپس تقویم قابل نوشتنی را که باید آن‌ها را دریافت کند انتخاب کنید.';

  @override
  String get importIcsFile => 'درون‌ریزی فایل .ics';

  @override
  String get importIcsPreview => 'درون‌ریزی رویدادهای تقویم';

  @override
  String importEventsFound(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'مجموعه رویدادهای قابل درون‌ریزی: $countString';
  }

  @override
  String importInvalidEvents(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'رویدادهای نامعتبر: $countString';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'عمداً حذف‌شده: ⁨$fields⁩';
  }

  @override
  String get noWritableCalendars => 'تقویم مقصد قابل نوشتنی موجود نیست.';

  @override
  String get importDestinationCalendar => 'تقویم مقصد';

  @override
  String get importIcsConfirm => 'درون‌ریزی رویدادها';

  @override
  String get importIcsComplete => 'درون‌ریزی کامل شد';

  @override
  String importQueued(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'درون‌ریزی‌شده یا در صف: $countString';
  }

  @override
  String importDuplicatesSkipped(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'تکراری‌ها رد شدند: $countString';
  }

  @override
  String importUnsupportedSets(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'مجموعه‌های تکرار پشتیبانی‌نشده: $countString';
  }

  @override
  String importIcsFailed(String error) {
    return 'درون‌ریزی فایل تقویم ممکن نیست: ⁨$error⁩';
  }

  @override
  String get networkOffline => 'آفلاین';

  @override
  String get networkOfflineDescription =>
      'تغییرات پس از برقراری دوبارهٔ اتصال همگام‌سازی می‌شوند.';

  @override
  String get networkOfflineTryAgain =>
      'آفلاین هستید. به اینترنت متصل شوید و دوباره تلاش کنید.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'در روزهای $days ماه';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first و $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first، $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first و $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first، $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first و $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first، $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first و $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first، $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency در روز $day ماه $month';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency در روزهای $days ماه $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency در روز $day ماه‌های $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency در روزهای $days ماه‌های $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'اولین',
      'second': 'دومین',
      'third': 'سومین',
      'fourth': 'چهارمین',
      'fifth': 'پنجمین',
      'secondToLast': 'یکی‌مانده‌به‌آخرین',
      'last': 'آخرین',
      'other': '',
    });
    return '$frequency در $_temp0 $days ماه $month';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'اولین',
      'second': 'دومین',
      'third': 'سومین',
      'fourth': 'چهارمین',
      'fifth': 'پنجمین',
      'secondToLast': 'یکی‌مانده‌به‌آخرین',
      'last': 'آخرین',
      'other': '',
    });
    return '$frequency در $_temp0 $days ماه‌های $months';
  }

  @override
  String get searchFilters => 'فیلترهای جستجو';

  @override
  String get searchType => 'نوع';

  @override
  String get searchDate => 'تاریخ';

  @override
  String get searchAnyDate => 'هر تاریخی (داده‌های بارگیری‌شده)';

  @override
  String get eventLink => 'پیوند رویداد';

  @override
  String get eventLinkOpenFailed => 'باز کردن پیوند ممکن نشد.';

  @override
  String get scheduleRangeIncomplete =>
      'بررسی برخی رویدادها ممکن نشد. داده‌های بارگیری‌شده نمایش داده می‌شوند.';

  @override
  String get searchThisWeek => 'این هفته';

  @override
  String get searchCustomRange => 'بازهٔ دلخواه';

  @override
  String get searchTaskStatus => 'وضعیت کار';

  @override
  String get searchTaskDue => 'سررسید کار';

  @override
  String get searchAnyDueState => 'هر وضعیت سررسید';

  @override
  String get searchNoDueDate => 'بدون تاریخ سررسید';

  @override
  String get searchPerson => 'شخص';

  @override
  String get searchSources => 'منابع';

  @override
  String get searchClearFilters => 'بازنشانی فیلترها';

  @override
  String get searchFiltersAction => 'فیلترها';

  @override
  String get searchNoSources => 'هیچ منبع جستجویی انتخاب نشده است';

  @override
  String get searchClearText => 'پاک کردن متن';

  @override
  String get openSharedCalendar => 'باز کردن تقویم اشتراکی';

  @override
  String get manageCalendarSharing => 'مدیریت اشتراک‌گذاری تقویم';

  @override
  String get shareRecipientEmail => 'ایمیل گیرنده';

  @override
  String get shareRole => 'نقش دسترسی';

  @override
  String get addCalendarShare => 'افزودن دسترسی';

  @override
  String get sharingRefreshFailed =>
      'تغییر اشتراک‌گذاری انجام شد، اما فهرست مجوزها به‌روز نشد. پیش از تغییر دیگر فهرست را دوباره بارگیری کنید.';

  @override
  String get sharingRateLimited =>
      'اشتراک‌گذاری موقتاً محدود شده است. پس از پایان زمان انتظار دوباره تلاش کنید.';

  @override
  String get attachmentUploadRateLimited =>
      'بارگذاری پیوست‌ها موقتاً محدود شده است. پس از پایان زمان انتظار دوباره تلاش کنید.';

  @override
  String get sharingPermissionUnavailable =>
      'مجوزهای اشتراک‌گذاری برای این تقویم در دسترس نیست.';

  @override
  String get calendarShareFreeBusy => 'فقط آزاد/مشغول';

  @override
  String get calendarShareLimitedRead => 'خواندن جزئیات محدود';

  @override
  String get calendarShareRead => 'خواندن همه جزئیات';

  @override
  String get calendarShareWrite => 'ویرایش رویدادها';

  @override
  String get calendarShareWriteWithoutPrivate => 'ویرایش بدون جزئیات خصوصی';

  @override
  String get calendarShareOwner => 'مالک';

  @override
  String get eventLabel => 'برچسب رویداد';

  @override
  String get loadOutlookCategories => 'بارگیری دسته‌های Outlook';

  @override
  String get outlookCategoriesUnavailable =>
      'دسته‌های Outlook در دسترس نیستند؛ انتساب‌های موجود حفظ می‌شوند.';

  @override
  String get googleEventType => 'نوع رویداد';

  @override
  String get googleRegularEvent => 'رویداد عادی';

  @override
  String get googleFocusTime => 'زمان تمرکز';

  @override
  String get googleOutOfOffice => 'خارج از دفتر';

  @override
  String get googleWorkingLocation => 'محل کار';

  @override
  String get googleDeclineInvitations => 'رد دعوت‌های هم‌زمان';

  @override
  String get googleDeclineNone => 'رد نکن';

  @override
  String get googleDeclineNew => 'رد دعوت‌های جدید';

  @override
  String get googleDeclineAll => 'رد همه دعوت‌های متداخل';

  @override
  String get googleDeclineMessage => 'پیام رد';

  @override
  String get googleChatStatus => 'وضعیت گفتگو';

  @override
  String get googleChatAvailable => 'در دسترس';

  @override
  String get googleChatDoNotDisturb => 'مزاحم نشوید';

  @override
  String get googleWorkAtHome => 'خانه';

  @override
  String get googleWorkAtOffice => 'دفتر';

  @override
  String get googleWorkAtCustomLocation => 'مکان سفارشی';

  @override
  String get googleWorkLocationLabel => 'عنوان مکان';

  @override
  String get googleStatusPrimaryOnly =>
      'رویدادهای وضعیت Google به تقویم اصلی Google نیاز دارند.';

  @override
  String unknownEventLabel(String id) {
    return 'برچسب ناشناخته (⁨$id⁩)';
  }

  @override
  String get calendarOwnerEmail => 'ایمیل مالک تقویم';

  @override
  String registrationSetupTitle(String provider) {
    return 'راه‌اندازی ⁨$provider⁩';
  }

  @override
  String get registrationSetupGuide => 'راهنمای راه‌اندازی';

  @override
  String get registrationGoogleInstructions =>
      'پروژهٔ Google Cloud خود را بسازید، APIهای Calendar و Tasks را فعال کنید و JSON کلاینت OAuth دسکتاپ را وارد کنید. به حساب موردنظر مجوز بدهید.';

  @override
  String get registrationMicrosoftInstructions =>
      'از ثبت برنامهٔ عمومی در مستأجر Entra که ثبت را مجاز می‌داند استفاده کنید. شناسهٔ کلاینت و نوع حساب‌ها را وارد کنید. رمز کلاینت لازم نیست.';

  @override
  String get registrationImportGoogle => 'انتخاب JSON کلاینت OAuth دسکتاپ';

  @override
  String get registrationValidate => 'اعتبارسنجی ثبت';

  @override
  String get registrationAuthorize => 'دادن مجوز در مرورگر';

  @override
  String get registrationClientId => 'شناسهٔ برنامه/کلاینت';

  @override
  String get registrationTenantId => 'شناسهٔ مستأجر';

  @override
  String get registrationAudience => 'حساب‌های پشتیبانی‌شده';

  @override
  String get registrationBothAudience => 'حساب‌های شخصی و سازمانی';

  @override
  String get registrationOrganizationAudience => 'حساب‌های سازمانی';

  @override
  String get registrationPersonalAudience => 'حساب‌های شخصی';

  @override
  String get registrationTenantAudience => 'یک مستأجر سازمانی';

  @override
  String registrationSummary(String clientId) {
    return 'ثبت: ⁨$clientId⁩';
  }

  @override
  String get registrationMigrate => 'انتقال اکنون';

  @override
  String get registrationReplace => 'جایگزینی ثبت';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'این حساب از ثبت اصلی ⁨$provider⁩ ویژهٔ حساب‌های موجود استفاده می‌کند. برای جایگزینی، ⁨$setup⁩ را تنظیم و این حساب را دوباره متصل کنید. تقویم‌ها، کارها و تغییرات محلی موجود حفظ می‌شوند.';
  }

  @override
  String get registrationContinue => 'ادامهٔ استفاده از این حساب';

  @override
  String get registrationGoogleProject => 'پروژهٔ Google Cloud';

  @override
  String get registrationMicrosoftApp => 'ثبت برنامهٔ Microsoft';

  @override
  String get registrationUserOwned => 'ثبت ارائه‌شده توسط کاربر';

  @override
  String get registrationNativeGoogle => 'ثبت بومی Google برای Android';

  @override
  String get registrationShared => 'ثبت مشترک (دورهٔ انتقال)';

  @override
  String get registrationUnresolved =>
      'منشأ ثبت مشخص نیست. داده‌های حساب حفظ شده‌اند.';

  @override
  String get registrationOfficialDocumentation => 'مستندات رسمی';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'بسته: ⁨$packageName⁩\nهش امضا: ⁨$signatureHash⁩\nنشانی هدایت: ⁨$redirectUri⁩';
  }

  @override
  String get oauthRegistrationRejected =>
      'نوع کارخواه، حساب‌های پشتیبانی‌شده، مجوزها و تغییر مسیر ثبت را بررسی کنید. پیکربندی واردشده را دوباره انتخاب کنید.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'این مجوزدهی کامل نشد. دوباره شروع کنید؛ اتصال فعلی حفظ شده است.';

  @override
  String get oauthPermissionRefused =>
      'مجوزدهی رد شد یا مجوزهای لازم داده نشد. دوباره تلاش کنید و مجوزهای لازم را بدهید.';

  @override
  String get oauthProviderThrottled =>
      'ارائه‌دهنده درخواست‌ها را محدود می‌کند. پیش از تلاش دوباره صبر کنید؛ اتصال فعلی حفظ شده است.';

  @override
  String get oauthProviderTemporaryFailure =>
      'مشکل موقت ارائه‌دهنده مانع تکمیل مجوزدهی شد. دوباره تلاش کنید؛ اتصال فعلی حفظ شده است.';

  @override
  String get oauthAuthorizationTimedOut =>
      'مهلت مجوزدهی تمام شد. دوباره تلاش کنید و پیکربندی واردشده را دوباره انتخاب کنید.';

  @override
  String get oauthWrongAccount =>
      'به حساب انتخاب‌شده برای اتصال مجدد مجوز بدهید. اتصال فعلی حفظ شده است.';

  @override
  String get oauthSecureStorageUnavailable =>
      'ذخیره‌سازی امن در دسترس نیست. دسترسی را بازیابی کنید و دوباره تلاش کنید.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'مجوز راه دور لغو شد، اما پاک‌سازی حساب کامل نشد. برای تلاش دوباره جهت بازیابی محلی، BusyMax را راه‌اندازی مجدد کنید.';

  @override
  String get addAccount => 'افزودن حساب';

  @override
  String get registrationConnect => 'اتصال';

  @override
  String get registrationBack => 'بازگشت';

  @override
  String get registrationReplaceGoogle => 'جایگزینی JSON OAuth دسکتاپ';

  @override
  String get registrationSelectedConfiguration => 'پیکربندی انتخاب‌شده';

  @override
  String get registrationDirectoryId => 'شناسهٔ دایرکتوری/مستأجر';

  @override
  String get registrationInvalidId => 'یک UUID معتبر وارد کنید.';

  @override
  String get registrationExpired =>
      'این پیکربندی منقضی شده است. پیش از اتصال دوباره وارد کنید یا فیلدهای ثبت را ویرایش کنید.';

  @override
  String get registrationOwnProjectRequired =>
      'ثبت مربوط به پروژه یا مستأجر خودتان را انتخاب کنید.';

  @override
  String get registrationSetupFailed =>
      'راه‌اندازی کامل نشد. دوباره تلاش کنید.';

  @override
  String get registrationLinkFailed =>
      'پیوند باز نشد. مرورگر را بررسی کنید و دوباره تلاش کنید.';

  @override
  String get registrationPermissions => 'مجوزها';

  @override
  String get registrationDesktopClient => 'برنامهٔ دسکتاپ';

  @override
  String get registrationOpenGoogleConsole => 'باز کردن کنسول Google Cloud';

  @override
  String get registrationGoogleAudienceHelp =>
      'الزامات انتشار و کاربران آزمایشی Google';

  @override
  String get registrationDesktopHelp => 'راهنمای ثبت برنامهٔ دسکتاپ';

  @override
  String get registrationOpenEntra => 'باز کردن مرکز مدیریت Microsoft Entra';

  @override
  String get registrationGuideGoogleProject =>
      'Google Cloud Console را باز کنید. از انتخابگر پروژه در بالا، پروژهٔ خود را انتخاب کنید یا New project را بزنید، نامی وارد کنید و Create را انتخاب کنید. در مراحل بعد همین پروژه را انتخاب‌شده نگه دارید.';

  @override
  String get registrationGuideGoogleAudience =>
      'به Google Auth Platform → Branding بروید. اگر راه‌اندازی شروع نشده، Get started را بزنید. در App name مقدار BusyMax را وارد کنید، User support email خود را انتخاب کنید و Next را بزنید. در Audience گزینهٔ External را انتخاب کنید. Next را بزنید، ایمیل خود را در Contact Information وارد کنید و Next را بزنید. User Data Policy را بپذیرید و Continue و Create را بزنید. اگر قبلاً تنظیم شده، Branding و Audience را بررسی کنید.';

  @override
  String get registrationGuideGooglePermissions =>
      'Google Auth Platform → Data Access → Add or remove scopes را باز کنید. پنج دامنهٔ زیر را انتخاب کنید؛ در صورت نیاز Manually add scopes را به کار ببرید. برای ورود دستی، مقادیر جاافتاده را جای‌گذاری کنید و Add to table را بزنید. Update و سپس Save را بزنید. BusyMax به دسترسی تقویم و کارها نیاز دارد.';

  @override
  String get registrationGuideGoogleClient =>
      'Google Auth Platform → Clients → Create client را باز کنید. Application type را روی Desktop app بگذارید، در Name مقدار BusyMax را وارد کنید و Create را بزنید. در پنجرهٔ ساخت، Download JSON را بزنید و فایل را ذخیره کنید. برای بازگشت به فرم، بازگشت را بزنید، فایل را انتخاب کنید و پروژه و شناسهٔ کلاینت را بررسی کنید. اتصال را بزنید و دسترسی تقویم و کارها را در مرورگر تأیید کنید.';

  @override
  String get registrationGuideMicrosoftApp =>
      'به مرکز مدیریت Microsoft Entra وارد شوید. با Settings مستأجری را انتخاب کنید که اجازهٔ ثبت برنامه دارید. Entra ID → App registrations → New registration را باز کنید. در Name مقدار BusyMax را وارد کنید و در مرحلهٔ بعد نوع حساب‌ها را انتخاب کنید. اگر ثبت مسدود است، از مدیر مستأجر دسترسی بخواهید.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'در ثبت برنامه، Authentication → Add a platform → Mobile and desktop applications را باز کنید. URI بازگشت زیر را انتخاب یا وارد کنید و با Configure ذخیره کنید. BusyMax از مرورگر سیستم استفاده می‌کند. رمز کلاینت لازم نیست.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'API permissions → Add a permission → Microsoft Graph → Delegated permissions را باز کنید. هر دامنهٔ زیر را جست‌وجو و انتخاب کنید و Add permissions را بزنید. اگر User.Read موجود است آن را نگه دارید. اگر سازمان رضایت مدیر می‌خواهد، از مدیر بخواهید Grant admin consent را برای مستأجر اجرا کند.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'برای بازگشت به فرم، بازگشت را بزنید. Application (client) ID را جای‌گذاری کنید و همان حساب‌های پشتیبانی‌شدهٔ ثبت برنامه را انتخاب کنید. برای یک مستأجر سازمانی، Directory (tenant) ID را هم جای‌گذاری کنید. اتصال را بزنید و در مرورگر به حساب مورد نظر وارد شوید. BusyMax فیلدها را محلی بررسی می‌کند؛ Microsoft هنگام ورود در مرورگر رضایت شما را درخواست می‌کند.';

  @override
  String get registrationGoogleImportFailed =>
      'این فایل وارد نشد. یک JSON OAuth دسکتاپ معتبر انتخاب کنید. انتخاب معتبر قبلی حفظ می‌شود.';

  @override
  String get registrationGoogleSetupInstructions => 'راهنمای راه‌اندازی Google';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'راهنمای راه‌اندازی Microsoft';

  @override
  String get registrationDesktopConfiguration => 'پیکربندی OAuth دسکتاپ';

  @override
  String get registrationNoFileSelected => 'فایلی انتخاب نشده است';

  @override
  String get registrationChooseFile => 'انتخاب فایل…';

  @override
  String get registrationReplaceFile => 'جایگزینی…';

  @override
  String get registrationGoogleIntroduction =>
      'فایل JSON مربوط به OAuth دسکتاپ را از پروژهٔ Google Cloud خود انتخاب کنید.';

  @override
  String get registrationMicrosoftIntroduction =>
      'اطلاعات ثبت برنامهٔ Microsoft خود را وارد کنید.';

  @override
  String get registrationSetupInstructions => 'راهنمای راه‌اندازی';

  @override
  String get registrationInstructionsDescription =>
      'پیکربندی لازم برای اتصال حساب را بسازید.';

  @override
  String get registrationEnableApis => 'فعال‌سازی Calendar و Tasks';

  @override
  String get registrationConsentScreen => 'تنظیم صفحهٔ رضایت';

  @override
  String get registrationAppName => 'نام برنامه';

  @override
  String get registrationScopes => 'دامنه‌های دسترسی';

  @override
  String get registrationRedirectUri => 'نشانی URI بازگشت';

  @override
  String get registrationOpenApiLibrary => 'باز کردن کتابخانهٔ Google API';

  @override
  String get registrationOpenBranding =>
      'باز کردن Branding در Google Auth Platform';

  @override
  String get registrationOpenDataAccess =>
      'باز کردن Data Access در Google Auth Platform';

  @override
  String get registrationOpenClients =>
      'باز کردن Clients در Google Auth Platform';

  @override
  String get registrationOpenEntraAuthentication =>
      'باز کردن ثبت برنامه‌های Entra برای تنظیم Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'باز کردن ثبت برنامه‌های Entra برای تنظیم API permissions';

  @override
  String get registrationCopy => 'کپی';

  @override
  String get registrationCopyAll => 'کپی همه';

  @override
  String get registrationGuideGoogleApis =>
      'به APIs & Services → Library بروید. Google Calendar API را جست‌وجو کنید، صفحه‌اش را باز کنید و Enable را بزنید. به Library برگردید و برای Google Tasks API تکرار کنید.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'در Supported account types برای حساب شخصی Personal accounts only، برای حساب‌های سازمانی Multiple Entra ID tenants، برای هر دو Any Entra ID Tenant + Personal Microsoft accounts و برای همین دایرکتوری Single tenant only را انتخاب کنید. Register را بزنید. از Overview مقدار Application (client) ID را کپی کنید؛ برای یک مستأجر Directory (tenant) ID را هم کپی کنید. گزینهٔ متناظر حساب‌های پشتیبانی‌شده را در BusyMax انتخاب کنید.';

  @override
  String get registrationConnectBusyMax => 'اتصال با BusyMax';

  @override
  String get registrationRecommended => 'پیشنهادشده';

  @override
  String get registrationOtherMethods => 'روش‌های دیگر اتصال';

  @override
  String get registrationWorkspace => 'سازمان Google Workspace';

  @override
  String get registrationGoogleCustom => 'کلاینت OAuth سفارشی';

  @override
  String get registrationMicrosoftCustom => 'ثبت برنامهٔ سفارشی';

  @override
  String get registrationMethodsIntroduction =>
      'روش اتصال حساب خود را انتخاب کنید.';

  @override
  String get registrationWorkspaceDescription =>
      'از تنظیمات تحت مدیریت سازمان خود استفاده کنید.';

  @override
  String get registrationCustomDescription =>
      'از ثبت برنامه‌ای که خودتان مدیریت می‌کنید استفاده کنید.';

  @override
  String get registrationSharedUnavailable =>
      'اتصال با BusyMax در این ساخت در دسترس نیست. می‌توانید از روش اتصال دیگری در زیر استفاده کنید.';

  @override
  String get registrationWorkspaceIntroduction =>
      'فایل JSON مربوط به Desktop OAuth را که سازمان شما ارائه یا مدیریت می‌کند انتخاب کنید. فایل، مالکیت سازمان، مخاطبان یا وضعیت تأیید را اثبات نمی‌کند.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'دستورالعمل‌های تنظیم Google Workspace';

  @override
  String get registrationBusyMaxManaged => 'ثبت تحت مدیریت BusyMax';

  @override
  String get registrationBranding => 'تنظیم برند و دامنه‌ها';

  @override
  String get registrationPublishing => 'انتشار برای استفادهٔ معمول';

  @override
  String get registrationOpenAudience =>
      'باز کردن Audience در Google Auth Platform';

  @override
  String get registrationGuideWorkspaceProject =>
      'فایل Desktop OAuth JSON را از مدیر بخواهید یا Google Cloud Console را باز کنید و پروژه‌ای متعلق به سازمان Google Workspace خود انتخاب کنید. برای ایجاد پروژه، مدیریت منابع ← ایجاد پروژه را باز کنید، نام پروژه را وارد کنید، سازمان یا یکی از پوشه‌های آن را در منبع والد انتخاب کنید و ایجاد را بزنید. همین پروژه را برای مراحل بعد انتخاب کنید. ایجاد به Project Creator، تنظیم OAuth به OAuth Config Editor و فعال‌سازی APIها به Service Usage Admin یا مجوزهای معادل نیاز دارد. اگر عملی مسدود است، از مدیر کمک بخواهید.';

  @override
  String get registrationGuideGoogleBranding =>
      'در Branding → App domain ابتدا دامنه‌های مجاز پروژه و سپس نشانی صفحهٔ اصلی، حریم خصوصی و شرایط خدمات را وارد کنید و Save را بزنید. برنامه‌های External در تولید به این پیوندها نیاز دارند. از دامنه‌های خود استفاده کنید و اگر Google تأیید برند خواست، مالکیت را در Search Console تأیید کنید. پیوند حریم خصوصی BusyMax مالکیت busystack.org را برای پروژهٔ شما اثبات نمی‌کند.';

  @override
  String get registrationGuideGooglePublishing =>
      'در Audience گزینهٔ Publish app را بزنید و In production را تأیید کنید. استفادهٔ معمول را در Testing نگذارید: مجوزهای Calendar/Tasks و توکن‌های تازه‌سازی آن‌ها پس از هفت روز منقضی می‌شوند. انتشار و تأیید جدا هستند. استفادهٔ شخصی با کمتر از 100 کاربر ممکن است با هشدار و سقف کاربران از تأیید معاف باشد؛ توزیع گسترده‌تر ممکن است به تأیید برند و محدوده‌ها نیاز داشته باشد. مجوزهای تولید هم می‌توانند منقضی یا لغو شوند.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'این محدوده‌ها را با مدیر بررسی کنید. برنامه‌های Internal به فهرست محدوده‌ها در صفحهٔ رضایت نیاز ندارند. اگر درخواست شد، Data Access → Add or remove scopes را باز کنید، مقادیر را اضافه کنید و Update و Save را بزنید. محدودیت‌های مدیر همچنان می‌توانند مجوز را محدود کنند.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'مجوزهای تقویم مشترک و دسته‌بندی جداگانه هنگام فعال کردن این ویژگی‌های اختیاری درخواست می‌شوند؛ آن‌ها را به تنظیمات الزامی بالا اضافه نکنید.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'به Google Auth Platform → Branding بروید. اگر راه‌اندازی شروع نشده، Get started را بزنید. در App name مقدار BusyMax را وارد کنید، User support email خود را انتخاب کنید و Next را بزنید. در Audience گزینهٔ Internal را انتخاب کنید. Next را بزنید، ایمیل خود را در Contact Information وارد کنید و Next را بزنید. User Data Policy را بپذیرید و Continue و Create را بزنید. اگر قبلاً تنظیم شده، Branding و Audience را بررسی کنید.\n\nInternal فقط حساب‌های سازمان مادر پروژه را با محدودیت‌های مدیر می‌پذیرد. فهرست کاربران آزمایشی لازم نیست. BusyMax نمی‌تواند این تنظیمات کنسول را از JSON دانلودشده تأیید کند.';

  @override
  String get contactsTitle => 'مخاطبان';

  @override
  String get contactsLinkedDescription =>
      'هنگام افزودن مهمانان رویداد از مخاطبان ذخیره‌شدهٔ این حساب استفاده شود.';

  @override
  String get contactsEnableSuggestions => 'فعال‌کردن پیشنهادهای مخاطبان';

  @override
  String get contactsReadPermissionDescription =>
      'درخواست دسترسی فقط‌خواندنی به مخاطبان';

  @override
  String get contactsEnableEditing => 'فعال‌کردن ویرایش مخاطبان';

  @override
  String get contactsWritePermissionDescription =>
      'درخواست دسترسی خواندن و نوشتن مخاطبان';

  @override
  String get contactsSuggestionsEnabled => 'پیشنهادهای مخاطبان فعال است';

  @override
  String get contactsNeedsAttention => 'مخاطبان نیاز به توجه دارند';

  @override
  String get contactsReadWriteAccess => 'دسترسی خواندن و نوشتن';

  @override
  String get contactsDisableForAccount => 'غیرفعال‌کردن مخاطبان برای این حساب';

  @override
  String get contactsOnlyDescription =>
      'این منابع از حساب‌های تقویم و وظایف مستقل هستند.';

  @override
  String get contactsAddCardDav => 'افزودن مخاطبان CardDAV';

  @override
  String get contactsAddNextcloud => 'افزودن مخاطبان Nextcloud';

  @override
  String get contactsUseForAttendees => 'استفاده برای پیشنهاد شرکت‌کنندگان';

  @override
  String get contactsServerUrlLabel => 'نشانی سرور HTTPS';

  @override
  String get contactsUsernameLabel => 'نام کاربری';

  @override
  String get contactsPasswordLabel => 'گذرواژه';
}
