// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: text_direction_code_point_in_literal, text_direction_code_point_in_comment

// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get launchAtLoginManagedExternally =>
      'BusyMax was launched by your desktop\'s startup settings. Remove its entry there, then quit and reopen BusyMax to use this switch.';

  @override
  String get timeFormat => 'Time format';

  @override
  String get firstDayOfWeek => 'First day of the week';

  @override
  String get systemDefault => 'System Default';

  @override
  String systemDefaultResolved(String weekday) {
    return 'System Default ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12-hour';

  @override
  String get timeFormatTwentyFourHour => '24-hour';

  @override
  String get timeEndOfDay => 'end of day';

  @override
  String get timePeriod => 'Day period';

  @override
  String get launchAtLoginReadFailed =>
      'Could not determine the launch-at-login state.';

  @override
  String get launchAtLoginUnavailable =>
      'Launch at login is unavailable on this system.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'Startup is enabled by your administrator and cannot be changed here.';

  @override
  String get settingsSaveFailed =>
      'Could not save settings. Your changes may be lost when BusyMax restarts.';

  @override
  String get nextcloudExportCollection => 'Export collection resources';

  @override
  String nextcloudImportItems(int count) {
    return '$count event/task resources found';
  }

  @override
  String get nextcloudSchedulingInbox => 'Scheduling inbox';

  @override
  String get nextcloudInboxExplanation =>
      'Nextcloud processes these messages into your calendars. Acknowledging a message removes only the inbox message, not the event.';

  @override
  String get nextcloudInboxEmpty => 'No scheduling messages.';

  @override
  String get nextcloudAcknowledge => 'Acknowledge message';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Remove this scheduling message from the inbox? The calendar event will be kept.';

  @override
  String get nextcloudGuestAvailability => 'Check guest availability';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Server trash retention: $days days';
  }

  @override
  String get nextcloudCancelMeeting => 'Cancel meeting';

  @override
  String get nextcloudDeclineAndRemove => 'Decline and remove invitation';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'Removing this invitation sends a decline when synchronized. It does not cancel the organizer’s meeting.';

  @override
  String get nextcloudAvailabilityUnknown => 'Availability unknown';

  @override
  String get nextcloudAvailabilityFree =>
      'No busy periods reported for this interval';

  @override
  String get nextcloudAvailabilityBusy => 'Busy periods';

  @override
  String get nextcloudSchedulingPending =>
      'Nextcloud will send meeting updates when this change synchronizes. Saving locally does not confirm delivery.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Only the organizer or an authorized delegate can change meeting details. You can respond to this invitation from its details.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'This meeting cannot be moved by copying and deleting it. Use a calendar under the same scheduling identity.';

  @override
  String get nextcloudSchedulingStatus => 'Server scheduling status';

  @override
  String get nextcloudImportFollowUp =>
      'The imported resources were saved locally. Reminder refresh is pending; do not import them again.';

  @override
  String get nextcloudNativeImport =>
      'Import complete event and task resources without sending invitations. Existing UIDs are skipped unless you choose new copies. Unsupported resources are reported individually.';

  @override
  String get nextcloudImportMethod =>
      'This file contains scheduling messages. Import stores their content and removes METHOD; it does not process an invitation or reply.';

  @override
  String get nextcloudImportCopies =>
      'Import as new copies with new identities';

  @override
  String get nextcloudCollectionSettings => 'Collection settings';

  @override
  String get nextcloudSharing => 'Sharing';

  @override
  String get nextcloudOwned => 'Owned';

  @override
  String get nextcloudShared => 'Shared';

  @override
  String get nextcloudDelegated => 'Delegated';

  @override
  String get nextcloudSubscription => 'Subscription';

  @override
  String get nextcloudDeleted => 'Deleted';

  @override
  String get nextcloudMetadataEditable =>
      'Calendar contents are read-only; collection properties can be changed.';

  @override
  String get nextcloudServerOrder =>
      'Server order (separate from sidebar order)';

  @override
  String get nextcloudCalendarEnabled => 'Enabled on the server';

  @override
  String get nextcloudAvailability => 'Include this collection in availability';

  @override
  String get nextcloudCalendarTimezone =>
      'Calendar timezone (VTIMEZONE document)';

  @override
  String get nextcloudRefreshPending =>
      'The change was saved on Nextcloud. Refresh is pending; do not repeat the change.';

  @override
  String get nextcloudOutcomeUnknown =>
      'The server outcome could not be confirmed. Refresh before trying again.';

  @override
  String get nextcloudRemoveShared => 'Remove shared calendar/list';

  @override
  String get nextcloudRemoveMixed =>
      'This collection contains events and tasks. Deleting it removes both its events and tasks.';

  @override
  String get nextcloudReadAccess => 'Read-only';

  @override
  String get nextcloudWriteAccess => 'Read and write';

  @override
  String get nextcloudRecipientSearch => 'Find people or groups';

  @override
  String get nextcloudNoRecipients => 'No matching people or groups.';

  @override
  String get nextcloudRevokeShare => 'Revoke access';

  @override
  String get nextcloudPublish => 'Publish link';

  @override
  String get nextcloudUnpublish => 'Stop publishing';

  @override
  String get nextcloudPublishWarning =>
      'Anyone with the published link may be able to read this calendar. Publish it?';

  @override
  String get nextcloudTrash => 'Deleted calendars and tasks';

  @override
  String get nextcloudTrashEmpty => 'No deleted calendar items.';

  @override
  String get nextcloudRestore => 'Restore';

  @override
  String get nextcloudPermanentDelete => 'Permanently delete';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Permanently delete this item? It cannot be restored from Nextcloud\'s calendar trash.';

  @override
  String get nextcloudOperationDenied =>
      'Nextcloud did not allow this operation.';

  @override
  String get nextcloudUnsupported =>
      'The server does not support this operation.';

  @override
  String get nextcloudPendingChanges =>
      'Save or discard collection changes before closing.';

  @override
  String get nextcloudServerUnavailable =>
      'Nextcloud could not be reached. Cached items and pending work are unchanged.';

  @override
  String get mapsShow => 'Show on map';

  @override
  String get openLink => 'Open link';

  @override
  String get externalLocationOpenFailed =>
      'The location could not be opened in an external application.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'The event could not be rescheduled. Its stored time has not been changed.';

  @override
  String get scheduleRescheduleStale =>
      'This event changed while you were dragging. Please try again.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'The new time was saved, but reminders could not be refreshed.';

  @override
  String get moveUp => 'Move up';

  @override
  String get moveDown => 'Move down';

  @override
  String get windowsSupport => 'Support';

  @override
  String get windowsThirdPartyLicenses => 'Third-party licenses';

  @override
  String get windowsSearch => 'Search';

  @override
  String get windowsStartupDisabledByUser =>
      'Disabled by the user in Windows Settings.';

  @override
  String get windowsStartupDisabledByPolicy => 'Disabled by Windows policy.';

  @override
  String get windowsStartupUnavailable =>
      'Available after BusyMax is installed from an MSIX package.';

  @override
  String get windowsReminderExitNotice =>
      'Reminders stop when BusyMax is fully quit. Keep it running in the background to receive them.';

  @override
  String get windowsProductVersionLabel => 'Product version';

  @override
  String get windowsPackageVersionLabel => 'Windows package version';

  @override
  String get windowsUnpackaged => 'Unpackaged';

  @override
  String get windowsAgendaLoadMore => 'Load more agenda items';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'Monday',
      'TU': 'Tuesday',
      'WE': 'Wednesday',
      'TH': 'Thursday',
      'FR': 'Friday',
      'SA': 'Saturday',
      'SU': 'Sunday',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'on days $first and $second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency on days $firstDay and $secondDay of $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency on day $day of $firstMonth and $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency on days $firstDay and $secondDay of $firstMonth and $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency on days $days of $firstMonth and $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Connect Google, Microsoft, Apple iCloud Calendar, or Nextcloud accounts.';

  @override
  String get googlePermissionsConsentNotice =>
      'On the Google permissions screen, select both Calendar and Tasks permissions.';

  @override
  String get googlePermissionsRequiredRetry =>
      'Google Calendar and Google Tasks permissions are required. Please try again and select both checkboxes.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'This provider is not configured.';

  @override
  String get waitingForGoogleSignIn => 'Waiting for Google sign-in...';

  @override
  String get waitingForMicrosoftSignIn => 'Waiting for Microsoft sign-in...';

  @override
  String get microsoftSignInNotConfigured =>
      'Microsoft sign-in is not configured. Set MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Cancel';

  @override
  String get close => 'Close';

  @override
  String get windowMinimize => 'Minimize';

  @override
  String get windowMaximize => 'Maximize';

  @override
  String get windowRestore => 'Restore';

  @override
  String get exit => 'Exit';

  @override
  String get options => 'Options';

  @override
  String get hide => 'Hide';

  @override
  String get show => 'Show';

  @override
  String get export => 'Export';

  @override
  String get save => 'Save';

  @override
  String get settings => 'Settings';

  @override
  String get all => 'All';

  @override
  String get calendarEvents => 'Events';

  @override
  String get calendarTasks => 'Tasks';

  @override
  String get calendar => 'Calendar';

  @override
  String get calendars => 'Calendars';

  @override
  String get newCalendar => 'New calendar';

  @override
  String get calendarColor => 'Calendar color';

  @override
  String calendarColorOption(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'Color $numberString';
  }

  @override
  String get calendarManagementUnsupported =>
      'This provider does not support calendar management in BusyMax.';

  @override
  String get primaryCalendarCannotDelete =>
      'The primary calendar cannot be deleted.';

  @override
  String calendarCreateFailed(String error) {
    return 'Could not create the calendar: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'The calendar was created, but BusyMax could not refresh the account. It will appear after the next sync.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Could not update the calendar: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Could not delete the calendar: $error';
  }

  @override
  String get newEvent => 'New event';

  @override
  String get refreshCalendar => 'Refresh calendar';

  @override
  String get openInProvider => 'Open in provider';

  @override
  String get linkedResources => 'Linked resources';

  @override
  String get noLinkedResources => 'No linked resources';

  @override
  String get attachments => 'Attachments';

  @override
  String get attachmentsNotLoaded => 'Attachments not loaded';

  @override
  String get hideFromSchedule => 'Hide from schedule';

  @override
  String get showInSchedule => 'Show in schedule';

  @override
  String get noCalendarsSynced => 'No calendars synced yet.';

  @override
  String get allDay => 'All day';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString more';
  }

  @override
  String get noEventsOrTasks => 'No events or tasks';

  @override
  String get scheduleLoading => 'Loading schedule...';

  @override
  String get scheduleUnavailable => 'Schedule unavailable';

  @override
  String get scheduleNoSources => 'No visible calendars or task lists';

  @override
  String get scheduleNoSourcesDescription =>
      'Choose what to show in Settings, then refresh.';

  @override
  String get scheduleNoSearchResults => 'No matching events or tasks';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Try a different search or clear the current filters.';

  @override
  String get refresh => 'Refresh';

  @override
  String get trayOpenBusyMax => 'Open BusyMax';

  @override
  String get trayShowBusyMax => 'Show BusyMax';

  @override
  String get trayNewEvent => 'New event…';

  @override
  String get trayNewTask => 'New task…';

  @override
  String get trayToday => 'Today';

  @override
  String get trayAllDay => 'All day';

  @override
  String get trayNow => 'Now';

  @override
  String get trayCalendarEvent => 'Calendar event';

  @override
  String get trayUntitledEvent => 'Untitled event';

  @override
  String get trayNothingElseToday => 'Nothing else today';

  @override
  String trayTasksDueToday(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString tasks due today',
      one: '1 task due today',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Open today’s agenda';

  @override
  String get traySyncNow => 'Sync now';

  @override
  String get traySyncing => 'Syncing…';

  @override
  String get trayNotConnected => 'Not connected';

  @override
  String get trayNotYetSynced => 'Not yet synced';

  @override
  String get trayLastSyncedJustNow => 'Last synced just now';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Last synced $countString minutes ago',
      one: 'Last synced 1 minute ago',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Last synced $countString hours ago',
      one: 'Last synced 1 hour ago',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Last synced $countString days ago',
      one: 'Last synced 1 day ago',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Settings';

  @override
  String get trayQuitBusyMax => 'Quit BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Load more overdue tasks';

  @override
  String get agendaLoadMoreNoDate => 'Load more no-date tasks';

  @override
  String get viewDay => 'Day';

  @override
  String get viewWeek => 'Week';

  @override
  String get viewMonth => 'Month';

  @override
  String get viewYear => 'Year';

  @override
  String get viewAgenda => 'Agenda';

  @override
  String get scheduleSettings => 'Schedule';

  @override
  String get scheduleDisplaySettings => 'Schedule display';

  @override
  String get newEventsAndTasks => 'New events and tasks';

  @override
  String get defaultCalendar => 'Default calendar';

  @override
  String get defaultTaskList => 'Default task list';

  @override
  String get lastUsed => 'Last used';

  @override
  String get scheduleDisplayHoursDescription =>
      'Day and Week views open within these hours. Early and late items expand the range when needed.';

  @override
  String get scheduleDayStartsAt => 'Day starts at';

  @override
  String get scheduleDayEndsAt => 'Day ends at';

  @override
  String get sourceCalendar => 'Calendar';

  @override
  String get sourceTaskList => 'Task list';

  @override
  String get createChoiceTitle => 'Create';

  @override
  String get createEventAtTime => 'Event';

  @override
  String get createTaskAtDate => 'Task';

  @override
  String get editEvent => 'Edit event';

  @override
  String get eventTitle => 'Event title';

  @override
  String get location => 'Location';

  @override
  String get timeSlot => 'Time slot';

  @override
  String get startDateTime => 'Start date/time';

  @override
  String get endDateTime => 'End date/time';

  @override
  String get doesNotRepeat => 'Does not repeat';

  @override
  String get defaultReminder => 'Default reminder';

  @override
  String get guests => 'Guests';

  @override
  String get noGuests => 'No guests';

  @override
  String get attendeeRequired => 'Required';

  @override
  String get attendeeOptional => 'Optional';

  @override
  String get meetingSection => 'Meeting';

  @override
  String get addGoogleMeet => 'Add Google Meet';

  @override
  String get addTeamsMeeting => 'Add Microsoft Teams meeting';

  @override
  String get onlineMeetingAdded => 'Online meeting added';

  @override
  String get requestResponses => 'Request responses';

  @override
  String get requestResponsesDescription =>
      'Ask guests to respond to the invitation.';

  @override
  String get hideGuestList => 'Hide guest list';

  @override
  String get hideGuestListDescription =>
      'Guests cannot see who else was invited.';

  @override
  String get allowNewTimeProposals => 'Allow new time proposals';

  @override
  String get allowNewTimeProposalsDescription =>
      'Guests can suggest a different meeting time.';

  @override
  String get notifyGuestsTitle => 'Notify guests?';

  @override
  String get notifyGuestsSaveMessage =>
      'This meeting has guests. Send invitations or event updates when it is saved?';

  @override
  String get notifyGuestsDeleteMessage =>
      'This meeting has guests. Send a cancellation when it is deleted?';

  @override
  String get sendUpdates => 'Send updates';

  @override
  String get sendCancellation => 'Send cancellation';

  @override
  String get doNotSend => 'Don’t send';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Save meeting?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'Microsoft will send invitations or event updates to guests.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Delete meeting?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'Microsoft will send a cancellation to guests.';

  @override
  String get organizer => 'Organizer';

  @override
  String get yourResponse => 'Your response';

  @override
  String get guestResponses => 'Guest responses';

  @override
  String get respond => 'Respond';

  @override
  String get acceptInvitation => 'Accept';

  @override
  String get tentativeInvitation => 'Tentative';

  @override
  String get declineInvitation => 'Decline';

  @override
  String get joinMeeting => 'Join meeting';

  @override
  String get responseAccepted => 'Accepted';

  @override
  String get responseTentative => 'Tentative';

  @override
  String get responseDeclined => 'Declined';

  @override
  String get responseNeedsAction => 'Awaiting response';

  @override
  String get responseNotResponded => 'Not responded';

  @override
  String get responseOrganizer => 'Organizer';

  @override
  String invitationResponseFailed(String error) {
    return 'Could not send your response: $error';
  }

  @override
  String get joinMeetingFailed => 'Could not open the meeting link.';

  @override
  String get description => 'Description';

  @override
  String get availabilityShowAs => 'Availability / Show as';

  @override
  String get busy => 'Busy';

  @override
  String get visibility => 'Visibility';

  @override
  String get defaultVisibility => 'Default visibility';

  @override
  String get conference => 'Conference';

  @override
  String get noConference => 'No conference';

  @override
  String get providerCalendar => 'Provider calendar';

  @override
  String get formatBoldShortLabel => 'B';

  @override
  String get formatBoldTooltip => 'Bold';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => 'Italic';

  @override
  String get formatUnderlineShortLabel => 'U';

  @override
  String get formatUnderlineTooltip => 'Underline';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString minutes before',
      one: '1 minute before',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'At start';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString hours before',
      one: '1 hour before',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString days before',
      one: '1 day before',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Free';

  @override
  String get availabilityTentative => 'Tentative';

  @override
  String get availabilityOutOfOffice => 'Out of office';

  @override
  String get availabilityWorkingElsewhere => 'Working elsewhere';

  @override
  String get visibilityDefault => 'Default';

  @override
  String get visibilityPublic => 'Public';

  @override
  String get visibilityPrivate => 'Private';

  @override
  String get visibilityConfidential => 'Confidential';

  @override
  String get sensitivityNormal => 'Normal';

  @override
  String get sensitivityPersonal => 'Personal';

  @override
  String get tasks => 'Tasks';

  @override
  String get allTasks => 'All tasks';

  @override
  String tasksInList(String title) {
    return 'Tasks in $title';
  }

  @override
  String get taskLists => 'Task lists';

  @override
  String get navigation => 'Navigation';

  @override
  String get mainMenu => 'Main Menu';

  @override
  String get keyboardShortcuts => 'Keyboard Shortcuts';

  @override
  String get shortcutGroupGeneral => 'General';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Show this shortcuts reference';

  @override
  String get shortcutGroupNavigation => 'Navigation';

  @override
  String get shortcutNextPeriod => 'Next period';

  @override
  String get shortcutNextPeriodDescription =>
      'Next week in week view, next month in month view, and so on';

  @override
  String get shortcutPreviousPeriod => 'Previous period';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Previous week in week view, previous month in month view, and so on';

  @override
  String get shortcutJumpToToday => 'Jump to today';

  @override
  String get shortcutGroupView => 'View';

  @override
  String get viewSelector => 'View';

  @override
  String get shortcutDayView => 'Day view';

  @override
  String get shortcutWeekView => 'Week view';

  @override
  String get shortcutMonthView => 'Month view';

  @override
  String get shortcutYearView => 'Year view';

  @override
  String get shortcutAgendaView => 'Agenda view';

  @override
  String get shortcutGroupCreateAndEdit => 'Create and Edit';

  @override
  String get shortcutSaveItem => 'Save event or task';

  @override
  String get shortcutDeleteItem => 'Delete event or task';

  @override
  String get shortcutGroupTaskEditing => 'Task editing';

  @override
  String get shortcutCancelEditing => 'Cancel editing';

  @override
  String get shortcutCancelEditingDescription =>
      'Close task editing or task details';

  @override
  String get aboutBusyMax => 'About BusyMax';

  @override
  String get aboutBusyMaxDescription => 'Calendar and tasks';

  @override
  String get license => 'License';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Website';

  @override
  String get sourceCode => 'Source code';

  @override
  String get reportAnIssue => 'Report an issue';

  @override
  String get sendFeedback => 'Send feedback';

  @override
  String get feedbackSubmit => 'Submit';

  @override
  String get feedbackCategory => 'Category';

  @override
  String get feedbackSelectCategory => 'Select a category';

  @override
  String get feedbackCategoryProblem => 'Problem or bug';

  @override
  String get feedbackCategoryFeature => 'Feature request';

  @override
  String get feedbackCategoryPrivacySecurity => 'Privacy or security concern';

  @override
  String get feedbackCategoryUsability => 'Usability concern';

  @override
  String get feedbackCategoryOther => 'Other';

  @override
  String get feedbackSubject => 'Subject';

  @override
  String get feedbackDetailedMessage => 'Detailed message';

  @override
  String get feedbackReplyEmail => 'Reply email (optional)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Include technical details';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Adds only your operating-system name and version and application locale. No logs, account data, file names, or other diagnostics are included.';

  @override
  String get feedbackCategoryRequired => 'Select a category.';

  @override
  String get feedbackSubjectLengthError =>
      'Subject must be between 3 and 120 characters.';

  @override
  String get feedbackMessageLengthError =>
      'Message must be between 10 and 5,000 characters.';

  @override
  String get feedbackInvalidEmail => 'Enter a valid email address.';

  @override
  String get feedbackConnectionError =>
      'Could not connect to BusyStack. Check your connection and try again.';

  @override
  String get feedbackTimeoutError =>
      'The request timed out. Your feedback has not been cleared; please try again.';

  @override
  String get feedbackRateLimitedError =>
      'Too many feedback submissions have been sent from this network. Please wait and try again.';

  @override
  String get feedbackRejectedError =>
      'The server rejected the submission. Review the fields and try again.';

  @override
  String get feedbackServerError =>
      'BusyStack could not accept your feedback right now. Your feedback has not been cleared; please try again.';

  @override
  String feedbackSuccess(String id) {
    return 'Feedback sent. Reference: $id';
  }

  @override
  String get toggleSidebar => 'Toggle Sidebar';

  @override
  String get showSidebar => 'Show sidebar panel';

  @override
  String get hideSidebar => 'Hide sidebar panel';

  @override
  String get accounts => 'Accounts';

  @override
  String get currentAccount => 'Current account';

  @override
  String get switchAccount => 'Switch account';

  @override
  String get addGoogleAccount => 'Add Google account';

  @override
  String get addMicrosoftAccount => 'Add Microsoft account';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Signed in';

  @override
  String get removeAccount => 'Remove account…';

  @override
  String get removingAccount => 'Removing account…';

  @override
  String get removeAccountDescription =>
      'Stop syncing and remove this account’s data from this device.';

  @override
  String removeAccountTitle(String account) {
    return 'Remove $account from BusyMax?';
  }

  @override
  String get removeAccountConfirmation =>
      'This deletes cached tasks, calendars, events, reminders, and pending offline changes from this device. Unsynced changes will be lost. Provider copies of calendars, events, task lists, and tasks are not deleted.';

  @override
  String get revokeGoogleAccess =>
      'Also revoke BusyMax’s access to this Google Account';

  @override
  String get revokeGoogleAccessDescription =>
      'You will need to grant access again before reconnecting.';

  @override
  String get removeAccountAction => 'Remove account';

  @override
  String get removeAccountFailed =>
      'Could not finish removing the account. Try again.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'The account was removed from this device, but BusyMax could not revoke Google access. You can revoke it from your Google Account.';

  @override
  String get newTaskList => 'New task list';

  @override
  String taskListCreateFailed(String error) {
    return 'Could not create the task list: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Could not rename the task list: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Could not delete the task list: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Synchronize the account, or resolve this task list’s blocked changes in Diagnostics, before deleting or removing the list.';

  @override
  String get signInToViewTaskLists => 'Sign in to view task lists.';

  @override
  String get noTaskListsSynced => 'No task lists synced yet.';

  @override
  String get listActions => 'List actions';

  @override
  String get rename => 'Rename';

  @override
  String get delete => 'Delete';

  @override
  String get renameList => 'Rename list';

  @override
  String get deleteList => 'Delete list';

  @override
  String get unshare => 'Unshare';

  @override
  String get readOnlyTaskListCannotRename =>
      'This task list is read-only and cannot be renamed.';

  @override
  String get taskListCannotDelete =>
      'This task list cannot be deleted with your current permissions.';

  @override
  String get builtInMicrosoftList => 'Built-in';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'Built-in Microsoft To Do lists cannot be renamed or deleted.';

  @override
  String deleteListConfirmation(String title) {
    return 'Delete \"$title\" from Google Tasks?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Delete \"$title\" and all of its tasks?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Unshare \"$title\" from this account?';
  }

  @override
  String get deleteEvent => 'Delete Event';

  @override
  String get title => 'Title';

  @override
  String get create => 'Create';

  @override
  String get newTask => 'New task';

  @override
  String get clearCompleted => 'Clear completed';

  @override
  String get refreshList => 'Refresh list';

  @override
  String get refreshAll => 'Refresh all';

  @override
  String get listRefreshed => 'List refreshed.';

  @override
  String get allTasksRefreshed => 'All accounts refreshed.';

  @override
  String exportedFile(String path) {
    return 'Exported to $path';
  }

  @override
  String exportFailed(String error) {
    return 'Export failed: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Refresh failed: $error';
  }

  @override
  String get selectOrCreateTaskList => 'Select or create a task list to begin.';

  @override
  String get signInToViewTasks => 'Sign in to view tasks.';

  @override
  String get noTasks => 'No tasks.';

  @override
  String get noTasksYet => 'No tasks yet';

  @override
  String get noTasksYetMessage =>
      'Create a task or refresh your accounts to get started.';

  @override
  String get noTasksInList => 'No tasks in this list.';

  @override
  String get overdue => 'Overdue';

  @override
  String get today => 'Today';

  @override
  String get tomorrow => 'Tomorrow';

  @override
  String get upcoming => 'Upcoming';

  @override
  String get noDate => 'No date';

  @override
  String get completed => 'Completed';

  @override
  String duePrefix(String date) {
    return 'Due $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date · $time';
  }

  @override
  String get taskDetails => 'Task details';

  @override
  String get editTask => 'Edit Task';

  @override
  String get noTaskSelected => 'No task selected.';

  @override
  String get noTaskSelectedHelper => 'Select a task to view and edit details.';

  @override
  String get taskUnavailable => 'Task unavailable.';

  @override
  String get signInToEditTasks => 'Sign in to edit tasks.';

  @override
  String get refreshTask => 'Refresh task';

  @override
  String get primarySection => 'Primary';

  @override
  String get statusSection => 'Status';

  @override
  String get openStatus => 'Open';

  @override
  String get doneStatus => 'Done';

  @override
  String get taskStatus => 'Status';

  @override
  String get taskStatusNone => 'No status';

  @override
  String get taskStatusNeedsAction => 'Needs action';

  @override
  String get taskStatusInProcess => 'In progress';

  @override
  String get taskStatusCompleted => 'Completed';

  @override
  String get taskStatusCancelled => 'Cancelled';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% completed';
  }

  @override
  String get completionDate => 'Completion date';

  @override
  String get priority => 'Priority';

  @override
  String get priorityNone => 'No priority';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priority $priorityString · High';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priority $priorityString · Medium';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Priority $priorityString · Low';
  }

  @override
  String get taskUrl => 'URL';

  @override
  String get invalidTaskUrl => 'Enter an absolute URL, including its scheme.';

  @override
  String get classification => 'Classification';

  @override
  String get classificationPublic => 'When shared, show the full task';

  @override
  String get classificationConfidential => 'When shared, show only busy';

  @override
  String get classificationPrivate => 'When shared, hide this task';

  @override
  String get pinTask => 'Pin task';

  @override
  String get notes => 'Notes';

  @override
  String get dueDate => 'Due date';

  @override
  String get clearDueDate => 'Clear due date';

  @override
  String get dueTime => 'Due time';

  @override
  String get startDate => 'Start date';

  @override
  String get startTime => 'Start time';

  @override
  String get endDate => 'End Date';

  @override
  String get endTime => 'End Time';

  @override
  String get reminderDate => 'Reminder date';

  @override
  String get reminderTime => 'Reminder time';

  @override
  String get reminder => 'Reminder';

  @override
  String get addReminder => 'Add Reminder';

  @override
  String get reminders => 'Reminders';

  @override
  String get noReminders => 'No reminders';

  @override
  String get editReminder => 'Edit reminder';

  @override
  String get beforeTaskStarts => 'Before the task starts';

  @override
  String get beforeTaskDue => 'Before the task is due';

  @override
  String get afterTaskStarts => 'After the task starts';

  @override
  String get afterTaskDue => 'After the task is due';

  @override
  String get relativeToTaskStart => 'Relative to the task start date';

  @override
  String get relativeToTaskDue => 'Relative to the task due date';

  @override
  String get reminderTimeOfDay => 'Time of day';

  @override
  String get absoluteReminder => 'At a date and time';

  @override
  String get reminderAmount => 'Amount';

  @override
  String get reminderUnit => 'Unit';

  @override
  String get reminderUnitSeconds => 'Seconds';

  @override
  String get reminderUnitMinutes => 'Minutes';

  @override
  String get reminderUnitHours => 'Hours';

  @override
  String get reminderUnitDays => 'Days';

  @override
  String get reminderUnitWeeks => 'Weeks';

  @override
  String get reminderAtTaskStart => 'At the task start';

  @override
  String get reminderAtTaskDue => 'At the task due time';

  @override
  String get unsupportedReminder =>
      'This reminder type is preserved but its time cannot be edited.';

  @override
  String get relatedRemindersTitle => 'Keep related reminders?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'This date has $countString related reminders. Keep them at their current date and time?';
  }

  @override
  String get discardRelatedReminders => 'Discard reminders';

  @override
  String get keepRelatedReminders => 'Keep reminders';

  @override
  String get addGuest => 'Add Guest';

  @override
  String get addGuestEmail => 'Add guest email';

  @override
  String get removeReminder => 'Remove reminder';

  @override
  String get off => 'Off';

  @override
  String get repeat => 'Repeat';

  @override
  String get repeatNone => 'None';

  @override
  String get noneValue => 'None';

  @override
  String get repeatDaily => 'Daily';

  @override
  String get repeatWeekly => 'Weekly';

  @override
  String get repeatMonthly => 'Monthly';

  @override
  String get repeatYearly => 'Yearly';

  @override
  String get repeatEvery => 'Interval';

  @override
  String get repeatOn => 'Repeat on';

  @override
  String get repeatEnd => 'End repeat';

  @override
  String get repeatNever => 'Never';

  @override
  String get repeatUntil => 'On date';

  @override
  String get repeatAfter => 'After a number of occurrences';

  @override
  String get repeatCount => 'Occurrences';

  @override
  String get repeatDayOfMonth => 'Days of month';

  @override
  String get repeatMonths => 'Months';

  @override
  String get repeatOrdinal => 'Weekday position';

  @override
  String get repeatSpecificDays => 'Specific days';

  @override
  String get repeatFirst => 'First';

  @override
  String get repeatSecond => 'Second';

  @override
  String get repeatThird => 'Third';

  @override
  String get repeatFourth => 'Fourth';

  @override
  String get repeatFifth => 'Fifth';

  @override
  String get repeatSecondToLast => 'Second to last';

  @override
  String get repeatLast => 'Last';

  @override
  String get repeatAnyDay => 'Day';

  @override
  String get repeatWeekday => 'Weekday';

  @override
  String get repeatWeekendDay => 'Weekend day';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'Monday',
      'TU': 'Tuesday',
      'WE': 'Wednesday',
      'TH': 'Thursday',
      'FR': 'Friday',
      'SA': 'Saturday',
      'SU': 'Sunday',
      'day': 'day',
      'weekday': 'weekday',
      'weekend': 'weekend day',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Every $countString days';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Every $countString weeks';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Every $countString months';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Every $countString years';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return 'on $days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'on day $days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'on the first $days',
      'second': 'on the second $days',
      'third': 'on the third $days',
      'fourth': 'on the fourth $days',
      'fifth': 'on the fifth $days',
      'secondToLast': 'on the second to last $days',
      'last': 'on the last $days',
      'other': 'on $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'in $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString times',
      one: '$countString time',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'until $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'This recurrence rule uses options that this editor does not change.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'This list cannot use this repeat pattern. Change the pattern or choose another list.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Add a start or due date to use this repeat pattern, or turn off repeat.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'This recurrence cannot be used with $provider.';
  }

  @override
  String get importance => 'Importance';

  @override
  String get importanceLow => 'Low';

  @override
  String get importanceNormal => 'Normal';

  @override
  String get importanceHigh => 'High';

  @override
  String get categories => 'Categories';

  @override
  String get scheduleSection => 'Schedule';

  @override
  String get dueGroup => 'Due';

  @override
  String get startGroup => 'Start';

  @override
  String get reminderGroup => 'Reminder';

  @override
  String get organizationSection => 'Organization';

  @override
  String get actionsSection => 'Actions';

  @override
  String get advancedSection => 'Advanced';

  @override
  String get addCategory => 'Add category';

  @override
  String get list => 'List';

  @override
  String get microsoftMoveUnsupported =>
      'Moving between lists is not supported for Microsoft To Do accounts in this version.';

  @override
  String get createSubtask => 'Create subtask';

  @override
  String get subtasks => 'Subtasks';

  @override
  String get duplicateTask => 'Duplicate task';

  @override
  String get taskDuplicated => 'Task duplicated.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Could not duplicate the task: $error';
  }

  @override
  String get hideSubtasks => 'Hide subtasks';

  @override
  String get hideClosedSubtasks => 'Hide closed subtasks';

  @override
  String get moveToTop => 'Move to top';

  @override
  String get deleteTask => 'Delete Task';

  @override
  String get newSubtask => 'New subtask';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Delete \"$title\"?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'This also deletes the original task in Google Docs or Chat Spaces.';

  @override
  String get metadata => 'Metadata';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Updated';

  @override
  String get parent => 'Parent';

  @override
  String get position => 'Position';

  @override
  String get webLink => 'Web link';

  @override
  String get assignment => 'Assignment';

  @override
  String get localState => 'Local state';

  @override
  String get pendingSync => 'Pending sync';

  @override
  String get synced => 'Synced';

  @override
  String get account => 'Account';

  @override
  String get sync => 'Sync';

  @override
  String get forceFullResync => 'Force full resync';

  @override
  String get forceFullResyncDescription =>
      'Completely reload data from every connected account. Use this only to troubleshoot synchronization problems.';

  @override
  String get runInBackgroundWhenClosed =>
      'Continue running when the window is closed';

  @override
  String get showTrayIcon => 'Show tray icon';

  @override
  String get startMinimizedToTray => 'Start minimized to the tray';

  @override
  String get launchAtLogin => 'Launch at login';

  @override
  String get launchAtLoginDescription =>
      'Start BusyMax in the background so reminders work after you sign in.';

  @override
  String get launchAtLoginFailed =>
      'Could not update the launch-at-login setting.';

  @override
  String get requiresTrayIcon => 'Requires the tray icon.';

  @override
  String get syncComplete => 'Sync complete.';

  @override
  String syncFailed(String error) {
    return 'Sync failed: $error';
  }

  @override
  String get notifySyncFailures => 'Notifications on sync failure';

  @override
  String get notifyConflicts => 'Notifications on conflicts';

  @override
  String get notifyDueToday => 'Due-today notifications';

  @override
  String get eventReminders => 'Event reminders';

  @override
  String get onState => 'On';

  @override
  String get taskReminders => 'Task reminders';

  @override
  String get notificationDetailLevel => 'Notification detail level';

  @override
  String get notificationDetailPrivate => 'Private';

  @override
  String get notificationDetailNormal => 'Normal';

  @override
  String get quietHours => 'Quiet hours';

  @override
  String get quietHoursDescription => 'Pause notifications during this period.';

  @override
  String get quietHoursStart => 'Quiet hours start';

  @override
  String get quietHoursEnd => 'Quiet hours end';

  @override
  String get notifications => 'Notifications';

  @override
  String get windowsNotificationsUnavailable =>
      'Windows notifications are unavailable';

  @override
  String get windowsNotificationsUnpackaged =>
      'This unpackaged development run cannot use Windows notifications. Install the test-signed MSIX to test reminders.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'BusyMax could not initialize Windows notifications. Reminders will not appear until this installation problem is resolved.';

  @override
  String get appearance => 'Appearance';

  @override
  String get theme => 'Theme';

  @override
  String get themeSystem => 'System';

  @override
  String get settingsSystem => 'System';

  @override
  String get themeLight => 'Light';

  @override
  String get themeDark => 'Dark';

  @override
  String get themeFamily => 'Theme family';

  @override
  String get themeFamilyYaru => 'Native Ubuntu (Yaru)';

  @override
  String get localization => 'Localization';

  @override
  String get currentLocale => 'Current locale';

  @override
  String get privacy => 'Privacy';

  @override
  String get redactTaskContentInDiagnostics =>
      'Redact task content in diagnostics';

  @override
  String get developerDiagnostics => 'Developer diagnostics';

  @override
  String get diagnostics => 'Diagnostics';

  @override
  String get apiInspectorDisabled => 'Show API inspector';

  @override
  String get googleTasksApi => 'Google Tasks API';

  @override
  String discoveryRevision(String revision) {
    return 'Discovery revision: $revision';
  }

  @override
  String get implementedMethods => 'Implemented methods';

  @override
  String get supportsTasksScopes => 'Supports tasks and tasks.readonly scopes';

  @override
  String get requiresTasksScope => 'Requires tasks scope';

  @override
  String get blockedPendingOperations => 'Blocked pending operations';

  @override
  String get signInToInspectPendingOperations =>
      'Sign in to inspect pending operations.';

  @override
  String get noBlockedPendingOperations => 'No blocked pending operations.';

  @override
  String get operationActions => 'Operation actions';

  @override
  String pendingOpListId(String id) {
    return 'list=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'task=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'attempts=$countString';
  }

  @override
  String get retry => 'Retry';

  @override
  String get discard => 'Discard';

  @override
  String get discardChangesAction => 'Discard';

  @override
  String get discardChanges => 'Discard changes?';

  @override
  String get discardChangesConfirmation =>
      'This discards unsaved edits to this task.';

  @override
  String get retryCompleted => 'Retry completed.';

  @override
  String get discardPendingOperation => 'Discard pending operation?';

  @override
  String get discardPendingOperationConfirmation =>
      'This removes the blocked local operation. The next sync will refresh from Google Tasks.';

  @override
  String get pendingOperationDiscarded => 'Pending operation discarded.';

  @override
  String get syncFailureNotificationTitle => 'BusyMax sync failed';

  @override
  String syncFailureNotificationBody(String message) {
    return 'Background sync failed. $message';
  }

  @override
  String get conflictNotificationTitle => 'BusyMax sync conflict';

  @override
  String conflictNotificationBody(String summary) {
    return 'A pending local change was blocked. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Tasks due today';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString tasks are due today.',
      one: 'One task is due today.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Event reminder';

  @override
  String get taskReminderNotificationTitle => 'Task reminder';

  @override
  String get eventReminderNotificationBody => 'Event starts soon.';

  @override
  String get taskReminderNotificationBody => 'Task is due soon.';

  @override
  String get notificationOpenAction => 'Open';

  @override
  String get notificationSnoozeAction => 'Snooze 10 minutes';

  @override
  String get notificationDismissAction => 'Dismiss';

  @override
  String get notificationDetailsHidden =>
      'Details are hidden by privacy settings.';

  @override
  String get previousMonth => 'Previous month';

  @override
  String get nextMonth => 'Next month';

  @override
  String get openMonthView => 'Open month view';

  @override
  String get previousYear => 'Previous year';

  @override
  String get nextYear => 'Next year';

  @override
  String get openYearView => 'Open year view';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'Week $numberString';
  }

  @override
  String get resizeAllDayPanel => 'Resize the all-day panel';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString items',
      one: '1 item',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'This calendar is read-only.';

  @override
  String get selectTimeZone => 'Select Timezone';

  @override
  String get searchLocations => 'Search locations';

  @override
  String get noLocationsFound => 'No locations found';

  @override
  String get requiredField => 'This field is required.';

  @override
  String get providerConnectionDescription =>
      'Connect calendars and tasks from one of these providers.';

  @override
  String get appleICloudProvider => 'Apple iCloud Calendar';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Nextcloud Tasks';

  @override
  String get addAppleICloudAccount => 'Add Apple iCloud Calendar account';

  @override
  String get addNextcloudAccount => 'Add Nextcloud account';

  @override
  String get waitingForAppleICloud => 'Connecting to Apple iCloud…';

  @override
  String get waitingForNextcloud => 'Waiting for Nextcloud authorization…';

  @override
  String get connectAppleICloudTitle => 'Connect Apple iCloud Calendar';

  @override
  String get appleAccountEmail => 'Apple Account email';

  @override
  String get appleAppSpecificPassword => 'App-specific password';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Create an app-specific password after enabling two-factor authentication for your Apple Account.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'Resetting your Apple Account password revokes app-specific passwords.';

  @override
  String get connectNextcloudTitle => 'Connect Nextcloud';

  @override
  String get nextcloudServerUrl => 'Nextcloud server or CalDAV address';

  @override
  String get nextcloudServerUrlHelp =>
      'Enter your Nextcloud server URL, or paste the primary CalDAV address copied from Nextcloud.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'BusyMax will open your browser. Approve access there, then return to BusyMax.';

  @override
  String get connectAccountAction => 'Connect';

  @override
  String get cancelAccountConnection => 'Cancel connection';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'The account was removed locally, but its Nextcloud app password could not be revoked.';

  @override
  String get davReauthenticationRequired =>
      'Reconnect this account to resume synchronization.';

  @override
  String get davTemporarilyUnavailable =>
      'This account is temporarily unavailable.';

  @override
  String get davPermissionChanged =>
      'Server permissions changed. Pending edits are paused.';

  @override
  String get davUnsupportedServer =>
      'This server or provider profile is not supported.';

  @override
  String get collectionSettings => 'Calendars and task lists';

  @override
  String get calendarContent => 'Calendar events';

  @override
  String get taskContent => 'Tasks';

  @override
  String get readOnlySharedCollection => 'Read-only';

  @override
  String get pendingLocally => 'Pending locally';

  @override
  String get conflictBlocked => 'Blocked by conflict';

  @override
  String get authenticationBlocked => 'Blocked until reconnect';

  @override
  String get operationFailed => 'Operation failed';

  @override
  String get keepServerVersion => 'Keep server version';

  @override
  String get reapplyLocalChange => 'Review and reapply local change';

  @override
  String get duplicateLocalItem => 'Duplicate as new item';

  @override
  String get davConnectionState => 'Connection state';

  @override
  String get davConnected => 'Connected';

  @override
  String get davConnecting => 'Connecting…';

  @override
  String get davSignedOut => 'Signed out';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Last successful sync: $time';
  }

  @override
  String get davNeverSynced => 'Not synchronized yet';

  @override
  String get refreshCollections => 'Refresh calendars and task lists';

  @override
  String nextcloudServerHost(String host) {
    return 'Server: $host';
  }

  @override
  String get collectionSupportsEvents => 'Event calendar';

  @override
  String get collectionSupportsTasks => 'Task list';

  @override
  String get collectionSupportsEventsAndTasks => 'Events and tasks';

  @override
  String get writableCollection => 'Writable';

  @override
  String get sharedCollection => 'Shared';

  @override
  String collectionLastSynced(String time) {
    return 'Last synchronized: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Sync issue: $code';
  }

  @override
  String get syncConflicts => 'Synchronization conflicts';

  @override
  String remoteChangedAt(String time) {
    return 'Server changed: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Local edit: $summary';
  }

  @override
  String get conflictResolutionFailed => 'The conflict could not be resolved.';

  @override
  String get recurringEventScope => 'Recurring event scope';

  @override
  String get entireSeries => 'Entire series';

  @override
  String get singleOccurrence => 'This event';

  @override
  String get thisAndFollowingEvents => 'This and following events';

  @override
  String get thisAndFutureUnavailable => 'Not supported by this provider.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'This and following events cannot be moved safely. Choose this event or the entire series.';

  @override
  String get entireSeriesMoveUnavailable =>
      'The recurrence rule is not available locally. Move this event instead.';

  @override
  String get copyEventAndDeleteOriginal => 'Copy event and delete original?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'BusyMax cannot move this event directly from $source to $destination. It will create the copy first and delete the original only after the copy succeeds. Event IDs will change; attendee response statuses may reset and invitations or cancellations may be sent; conference links, attachments, reminders, provider-specific fields, and recurrence exceptions may not carry over.';
  }

  @override
  String get copyAndDelete => 'Copy and delete';

  @override
  String get chooseRecurringEventScope =>
      'Choose whether this change applies to the entire series, only this occurrence, or this and following events.';

  @override
  String get taskDueBeforeStart => 'Due must not be before start.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Set times for both start and due, or make the task all day.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Delete \"$title\"?';
  }

  @override
  String get setCustomCalendarName => 'Set custom name';

  @override
  String get setAction => 'Set';

  @override
  String get removeFromMyCalendars => 'Remove from my calendars';

  @override
  String get removeAction => 'Remove';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Remove \"$title\" from BusyMax? The owner\'s calendar and events will not be deleted.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'The upload may have completed. Refresh attachments to resolve its outcome before uploading again.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Remove \"$title\" from your Google Calendar list? The shared calendar and its events will not be deleted.';
  }

  @override
  String get calendarCannotRemove =>
      'This calendar cannot be deleted or removed from this account.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Wait for this calendar’s pending changes to finish syncing before deleting or removing it.';

  @override
  String get calendarSubscriptions => 'Calendar subscriptions';

  @override
  String get calendarSubscriptionsDescription =>
      'Add read-only calendars that refresh from a secure WebCal URL.';

  @override
  String get addCalendarSubscription => 'Add calendar subscription';

  @override
  String get subscriptionName => 'Local name';

  @override
  String get subscriptionUrl => 'Subscription URL';

  @override
  String get subscriptionUrlHelp =>
      'Enter an HTTPS or webcal URL. BusyMax keeps the complete URL in secure storage.';

  @override
  String get subscriptionUrlInvalid =>
      'Enter a valid HTTPS or webcal URL without user information or a fragment.';

  @override
  String get subscriptionColor => 'Local color';

  @override
  String get subscriptionColorHelp => 'Use a six-digit color such as #3584E4.';

  @override
  String get subscriptionColorInvalid => 'Enter a six-digit hexadecimal color.';

  @override
  String get subscriptionRefreshMode => 'Refresh frequency';

  @override
  String get subscriptionAutomatic => 'Automatic';

  @override
  String get subscriptionHourly => 'Hourly';

  @override
  String get subscriptionSixHours => 'Every six hours';

  @override
  String get subscriptionDaily => 'Daily';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Source: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Enter a valid URL to preview its safe origin.';

  @override
  String get subscriptionReadOnly => 'Read-only subscription';

  @override
  String get subscriptionNeverRefreshed => 'Not refreshed yet';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Last successful refresh: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Next refresh: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Up to date';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Refresh issue: $code';
  }

  @override
  String get refreshNow => 'Refresh now';

  @override
  String get unsubscribe => 'Unsubscribe';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Unsubscribe from “$name”?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'This removes the local subscription and its cached events. The published calendar is not changed.';

  @override
  String get addSubscriptionAction => 'Add subscription';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Calendar subscription failed: $error';
  }

  @override
  String get subscriptions => 'Subscriptions';

  @override
  String get calendarImport => 'Calendar import';

  @override
  String get calendarImportDescription =>
      'Select a file, review its events, then choose the writable calendar that should receive them.';

  @override
  String get importIcsFile => 'Import .ics file';

  @override
  String get importIcsPreview => 'Import calendar events';

  @override
  String importEventsFound(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Importable event sets: $countString';
  }

  @override
  String importInvalidEvents(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Invalid events: $countString';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Intentionally omitted: $fields';
  }

  @override
  String get noWritableCalendars =>
      'No writable destination calendar is available.';

  @override
  String get importDestinationCalendar => 'Destination calendar';

  @override
  String get importIcsConfirm => 'Import events';

  @override
  String get importIcsComplete => 'Import complete';

  @override
  String importQueued(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Imported or queued: $countString';
  }

  @override
  String importDuplicatesSkipped(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Duplicates skipped: $countString';
  }

  @override
  String importUnsupportedSets(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Unsupported recurrence sets: $countString';
  }

  @override
  String importIcsFailed(String error) {
    return 'Could not import the calendar file: $error';
  }

  @override
  String get networkOffline => 'Offline';

  @override
  String get networkOfflineDescription =>
      'Changes will sync when the connection is restored.';

  @override
  String get networkOfflineTryAgain =>
      'You’re offline. Connect to the internet and try again.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'on days $days';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first and $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first and $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first and $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first and $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency on $month $day';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency on days $days of $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency on day $day of $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency on days $days of $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'on the first $days of $month',
      'second': 'on the second $days of $month',
      'third': 'on the third $days of $month',
      'fourth': 'on the fourth $days of $month',
      'fifth': 'on the fifth $days of $month',
      'secondToLast': 'on the second to last $days of $month',
      'last': 'on the last $days of $month',
      'other': 'on $days of $month',
    });
    return '$frequency $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'on the first $days of $months',
      'second': 'on the second $days of $months',
      'third': 'on the third $days of $months',
      'fourth': 'on the fourth $days of $months',
      'fifth': 'on the fifth $days of $months',
      'secondToLast': 'on the second to last $days of $months',
      'last': 'on the last $days of $months',
      'other': 'on $days of $months',
    });
    return '$frequency $_temp0';
  }

  @override
  String get searchFilters => 'Search filters';

  @override
  String get searchType => 'Type';

  @override
  String get searchDate => 'Date';

  @override
  String get searchAnyDate => 'Any date (downloaded data)';

  @override
  String get eventLink => 'Event link';

  @override
  String get eventLinkOpenFailed => 'Could not open the link.';

  @override
  String get scheduleRangeIncomplete =>
      'Some events could not be checked. Showing downloaded data.';

  @override
  String get searchThisWeek => 'This week';

  @override
  String get searchCustomRange => 'Custom range';

  @override
  String get searchTaskStatus => 'Task status';

  @override
  String get searchTaskDue => 'Task due';

  @override
  String get searchAnyDueState => 'Any due state';

  @override
  String get searchNoDueDate => 'No due date';

  @override
  String get searchPerson => 'Person';

  @override
  String get searchSources => 'Sources';

  @override
  String get searchClearFilters => 'Clear filters';

  @override
  String get searchFiltersAction => 'Filters';

  @override
  String get searchNoSources => 'No search sources selected';

  @override
  String get searchClearText => 'Clear text';

  @override
  String get openSharedCalendar => 'Open shared calendar';

  @override
  String get manageCalendarSharing => 'Manage calendar sharing';

  @override
  String get shareRecipientEmail => 'Recipient email';

  @override
  String get shareRole => 'Access role';

  @override
  String get addCalendarShare => 'Add access';

  @override
  String get sharingRefreshFailed =>
      'The sharing change succeeded, but the permission list could not be refreshed. Retry the list before making another change.';

  @override
  String get sharingRateLimited =>
      'Sharing is temporarily rate-limited. Try again when the wait ends.';

  @override
  String get attachmentUploadRateLimited =>
      'Attachment upload is temporarily rate-limited. Try again when the wait ends.';

  @override
  String get sharingPermissionUnavailable =>
      'Sharing permissions are unavailable for this calendar.';

  @override
  String get calendarShareFreeBusy => 'Free/busy only';

  @override
  String get calendarShareLimitedRead => 'Read limited details';

  @override
  String get calendarShareRead => 'Read all details';

  @override
  String get calendarShareWrite => 'Edit events';

  @override
  String get calendarShareWriteWithoutPrivate => 'Edit without private details';

  @override
  String get calendarShareOwner => 'Owner';

  @override
  String get eventLabel => 'Event label';

  @override
  String get loadOutlookCategories => 'Load Outlook categories';

  @override
  String get outlookCategoriesUnavailable =>
      'Outlook categories are unavailable; existing assignments are preserved.';

  @override
  String get googleEventType => 'Event type';

  @override
  String get googleRegularEvent => 'Regular event';

  @override
  String get googleFocusTime => 'Focus time';

  @override
  String get googleOutOfOffice => 'Out of office';

  @override
  String get googleWorkingLocation => 'Working location';

  @override
  String get googleDeclineInvitations => 'Decline overlapping invitations';

  @override
  String get googleDeclineNone => 'Do not decline';

  @override
  String get googleDeclineNew => 'Decline new invitations';

  @override
  String get googleDeclineAll => 'Decline all conflicting invitations';

  @override
  String get googleDeclineMessage => 'Decline message';

  @override
  String get googleChatStatus => 'Chat status';

  @override
  String get googleChatAvailable => 'Available';

  @override
  String get googleChatDoNotDisturb => 'Do not disturb';

  @override
  String get googleWorkAtHome => 'Home';

  @override
  String get googleWorkAtOffice => 'Office';

  @override
  String get googleWorkAtCustomLocation => 'Custom location';

  @override
  String get googleWorkLocationLabel => 'Location label';

  @override
  String get googleStatusPrimaryOnly =>
      'Google status events require your primary Google calendar.';

  @override
  String unknownEventLabel(String id) {
    return 'Unknown label ($id)';
  }

  @override
  String get calendarOwnerEmail => 'Calendar owner email';

  @override
  String registrationSetupTitle(String provider) {
    return 'Set up $provider';
  }

  @override
  String get registrationSetupGuide => 'Setup guide';

  @override
  String get registrationGoogleInstructions =>
      'Create your own Google Cloud project, enable both Calendar and Tasks APIs, and download a Desktop OAuth client JSON. Import the configuration, then authorize the intended account.';

  @override
  String get registrationMicrosoftInstructions =>
      'Use a public app registration in an Entra tenant that permits registration. Enter its Application/client ID and supported account audience. No client secret is required.';

  @override
  String get registrationImportGoogle => 'Select Desktop OAuth JSON';

  @override
  String get registrationValidate => 'Validate registration';

  @override
  String get registrationAuthorize => 'Authorize in browser';

  @override
  String get registrationClientId => 'Application (client) ID';

  @override
  String get registrationTenantId => 'Tenant ID';

  @override
  String get registrationAudience => 'Supported accounts';

  @override
  String get registrationBothAudience => 'Personal and organizational accounts';

  @override
  String get registrationOrganizationAudience => 'Organizational accounts';

  @override
  String get registrationPersonalAudience => 'Personal accounts';

  @override
  String get registrationTenantAudience => 'One organizational tenant';

  @override
  String registrationSummary(String clientId) {
    return 'Registration: $clientId';
  }

  @override
  String get registrationMigrate => 'Migrate now';

  @override
  String get registrationReplace => 'Replace registration';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'This account uses an original $provider registration reserved for existing accounts. To replace it, set up $setup and reconnect this account. Your existing calendars, tasks, and local changes will be preserved.';
  }

  @override
  String get registrationContinue => 'Continue using this account';

  @override
  String get registrationGoogleProject => 'Google Cloud project';

  @override
  String get registrationMicrosoftApp => 'Microsoft app registration';

  @override
  String get registrationUserOwned => 'User-provided registration';

  @override
  String get registrationNativeGoogle => 'Native Google Android registration';

  @override
  String get registrationShared => 'Shared registration (transition)';

  @override
  String get registrationUnresolved =>
      'Registration provenance is unresolved. Account data is preserved.';

  @override
  String get registrationOfficialDocumentation => 'Official documentation';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Package: $packageName\nSignature hash: $signatureHash\nRedirect URI: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Check the client type, supported accounts, permissions, and redirect in your registration. Select the configuration again if it was imported.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'This authorization attempt could not be completed. Start authorization again; your existing connection is preserved.';

  @override
  String get oauthPermissionRefused =>
      'Authorization was refused or required permissions were not granted. Try again and grant the required permissions.';

  @override
  String get oauthProviderThrottled =>
      'The provider is limiting requests. Wait before trying again; your existing connection is preserved.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Authorization could not complete because of a temporary provider problem. Try again; your existing connection is preserved.';

  @override
  String get oauthAuthorizationTimedOut =>
      'Authorization timed out. Try again; select a fresh configuration if it was imported.';

  @override
  String get oauthWrongAccount =>
      'Authorize the account selected for reconnection. Your existing connection is preserved.';

  @override
  String get oauthSecureStorageUnavailable =>
      'Secure storage is unavailable. Restore access to secure storage and try again.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'Remote authorization was revoked, but account cleanup could not finish. Restart BusyMax to retry local recovery.';

  @override
  String get addAccount => 'Add account';

  @override
  String get registrationConnect => 'Connect';

  @override
  String get registrationBack => 'Back';

  @override
  String get registrationReplaceGoogle => 'Replace Desktop OAuth JSON';

  @override
  String get registrationSelectedConfiguration => 'Selected configuration';

  @override
  String get registrationDirectoryId => 'Directory (tenant) ID';

  @override
  String get registrationInvalidId => 'Enter a valid UUID.';

  @override
  String get registrationExpired =>
      'This configuration expired. Import it again or edit the registration fields before connecting.';

  @override
  String get registrationOwnProjectRequired =>
      'Choose a registration from your own project or tenant.';

  @override
  String get registrationSetupFailed => 'Setup could not complete. Try again.';

  @override
  String get registrationLinkFailed =>
      'Could not open the link. Check your browser and try again.';

  @override
  String get registrationPermissions => 'Permissions';

  @override
  String get registrationDesktopClient => 'Desktop application';

  @override
  String get registrationOpenGoogleConsole => 'Open Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Google publishing and test-user requirements';

  @override
  String get registrationDesktopHelp => 'Desktop app registration instructions';

  @override
  String get registrationOpenEntra => 'Open Microsoft Entra admin center';

  @override
  String get registrationGuideGoogleProject =>
      'Open Google Cloud Console. Use the project selector at the top to select your own project, or choose New project, enter a name and select Create. Keep that project selected for the remaining steps.';

  @override
  String get registrationGuideGoogleAudience =>
      'Go to Google Auth Platform → Branding. If setup has not started, select Get started. Enter BusyMax as the App name, choose your own User support email and select Next. In Audience, choose External. Select Next, enter your email under Contact Information and select Next. Accept the User Data Policy, then select Continue and Create. If already configured, review Branding and Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Open Google Auth Platform → Data Access → Add or remove scopes. Select the five scopes below; use Manually add scopes if needed. For manual entry, paste the missing values and select Add to table. Select Update, then Save. BusyMax needs both calendar and task access.';

  @override
  String get registrationGuideGoogleClient =>
      'Open Google Auth Platform → Clients → Create client. Set Application type to Desktop app, enter BusyMax as the Name and select Create. In the creation dialog, select Download JSON and save the file. Select Back to return to the form, choose that file and review its project and client ID. Select Connect and approve calendar and task access in your browser.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Sign in to Microsoft Entra admin center. Use Settings to select a tenant where you can register applications. Open Entra ID → App registrations → New registration. Enter BusyMax as the Name, then choose the supported account types in the next step. If registration is blocked, ask your tenant administrator for access.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'In your registration, open Authentication → Add a platform → Mobile and desktop applications. Select or enter the redirect URI below, then select Configure to save it. BusyMax uses your system browser. No client secret is required.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Open API permissions → Add a permission → Microsoft Graph → Delegated permissions. Search for and select each scope below, then select Add permissions. Keep User.Read if it is already present. If your organization requires administrator consent, ask an administrator to use Grant admin consent for your tenant.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Select Back to return to the form. Paste Application (client) ID and select the same Supported accounts as the registration. For One organizational tenant, also paste Directory (tenant) ID. Select Connect and sign in to the intended account in your browser. BusyMax checks the fields locally; Microsoft requests your permission during browser sign-in.';

  @override
  String get registrationGoogleImportFailed =>
      'Could not import this file. Select a valid Desktop OAuth JSON. Any previous valid selection is kept.';

  @override
  String get registrationGoogleSetupInstructions => 'Google setup instructions';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Microsoft setup instructions';

  @override
  String get registrationDesktopConfiguration => 'Desktop OAuth configuration';

  @override
  String get registrationNoFileSelected => 'No file selected';

  @override
  String get registrationChooseFile => 'Choose file…';

  @override
  String get registrationReplaceFile => 'Replace…';

  @override
  String get registrationGoogleIntroduction =>
      'Choose the Desktop OAuth JSON from your own Google Cloud project.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Enter the details of your own Microsoft app registration.';

  @override
  String get registrationSetupInstructions => 'Setup instructions';

  @override
  String get registrationInstructionsDescription =>
      'Create the configuration needed to connect your account.';

  @override
  String get registrationEnableApis => 'Enable Calendar and Tasks';

  @override
  String get registrationConsentScreen => 'Configure the consent screen';

  @override
  String get registrationAppName => 'App name';

  @override
  String get registrationScopes => 'Scopes';

  @override
  String get registrationRedirectUri => 'Redirect URI';

  @override
  String get registrationOpenApiLibrary => 'Open Google API Library';

  @override
  String get registrationOpenBranding => 'Open Google Auth Platform Branding';

  @override
  String get registrationOpenDataAccess =>
      'Open Google Auth Platform Data Access';

  @override
  String get registrationOpenClients => 'Open Google Auth Platform Clients';

  @override
  String get registrationOpenEntraAuthentication =>
      'Open Entra app registrations for Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'Open Entra app registrations for API permissions';

  @override
  String get registrationCopy => 'Copy';

  @override
  String get registrationCopyAll => 'Copy all';

  @override
  String get registrationGuideGoogleApis =>
      'Go to APIs & Services → Library. Search for Google Calendar API, open its page and select Enable. Return to Library and repeat for Google Tasks API.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Under Supported account types, choose Personal accounts only for a personal account, Multiple Entra ID tenants for organizational accounts, Any Entra ID Tenant + Personal Microsoft accounts for both, or Single tenant only for this directory. Select Register. In Overview, copy Application (client) ID; for one tenant, also copy Directory (tenant) ID. Use the matching Supported accounts choice in BusyMax.';

  @override
  String get registrationConnectBusyMax => 'Connect with BusyMax';

  @override
  String get registrationRecommended => 'Recommended';

  @override
  String get registrationOtherMethods => 'Other connection methods';

  @override
  String get registrationWorkspace => 'Google Workspace organization';

  @override
  String get registrationGoogleCustom => 'Custom OAuth client';

  @override
  String get registrationMicrosoftCustom => 'Custom app registration';

  @override
  String get registrationMethodsIntroduction =>
      'Choose how to connect your account.';

  @override
  String get registrationWorkspaceDescription =>
      'Use a configuration managed by your organization.';

  @override
  String get registrationCustomDescription =>
      'Use a registration that you manage.';

  @override
  String get registrationSharedUnavailable =>
      'BusyMax connection is unavailable in this build. You can use another connection method below.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Choose the Desktop OAuth JSON supplied or managed by your organization. The file does not prove organization ownership, audience, or verification status.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Google Workspace setup instructions';

  @override
  String get registrationBusyMaxManaged => 'BusyMax-managed registration';

  @override
  String get registrationBranding => 'Configure branding and domains';

  @override
  String get registrationPublishing => 'Publish for normal use';

  @override
  String get registrationOpenAudience => 'Open Google Auth Platform Audience';

  @override
  String get registrationGuideWorkspaceProject =>
      'Ask your administrator for the Desktop OAuth JSON, or open Google Cloud Console and select a project owned by your Google Workspace organization. To create one, open Manage resources → Create project, enter Project name, choose your organization or one of its folders in Parent resource and select Create. Select that project for the remaining steps. Creation needs Project Creator access; configuring OAuth needs OAuth Config Editor, and enabling APIs needs Service Usage Admin or equivalent permissions. Ask the administrator if blocked.';

  @override
  String get registrationGuideGoogleBranding =>
      'In Branding → App domain, add your project’s authorized domains before entering its homepage, privacy-policy and terms-of-service URLs, then Save. External production apps need these links. Use domains you own; complete Search Console ownership verification when Google requires brand verification. BusyMax’s product privacy link below does not establish ownership of busystack.org for your project.';

  @override
  String get registrationGuideGooglePublishing =>
      'In Audience, select Publish app and confirm In production. Do not leave normal use in Testing: these Calendar/Tasks authorizations and refresh tokens expire after seven days. Publishing and verification are separate. Personal use with fewer than 100 users can be exempt from verification, with unverified-app warnings and a user cap; broader distribution may require brand and scope approval. Production authorizations can still expire or be revoked.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Review the scopes below with your administrator. Internal apps do not need a consent-screen scope listing. If your administrator requests one, open Data Access → Add or remove scopes, add these values, then Update and Save. Administrator controls can still restrict authorization.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'Shared-calendar and category permissions are requested separately when those optional features are enabled; do not add them to the required setup above.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Go to Google Auth Platform → Branding. If setup has not started, select Get started. Enter BusyMax as the App name, choose your own User support email and select Next. In Audience, choose Internal. Select Next, enter your email under Contact Information and select Next. Accept the User Data Policy, then select Continue and Create. If already configured, review Branding and Audience.\n\nInternal allows only accounts in the project’s parent organization, subject to administrator controls. No test-user list is needed. BusyMax cannot verify these console settings from the downloaded JSON.';

  @override
  String get contactsTitle => 'Contacts';

  @override
  String get contactsLinkedDescription =>
      'Use cached contacts from this account when adding event guests.';

  @override
  String get contactsEnableSuggestions => 'Enable contact suggestions';

  @override
  String get contactsReadPermissionDescription =>
      'Requests read-only contact access';

  @override
  String get contactsEnableEditing => 'Enable contact editing';

  @override
  String get contactsWritePermissionDescription =>
      'Requests contact read and write access';

  @override
  String get contactsSuggestionsEnabled => 'Contact suggestions enabled';

  @override
  String get contactsNeedsAttention => 'Contacts need attention';

  @override
  String get contactsReadWriteAccess => 'Read and write access';

  @override
  String get contactsDisableForAccount => 'Disable contacts for this account';

  @override
  String get contactsOnlyDescription =>
      'These sources are independent of calendar and task accounts.';

  @override
  String get contactsAddCardDav => 'Add CardDAV contacts';

  @override
  String get contactsAddNextcloud => 'Add Nextcloud contacts';

  @override
  String get contactsUseForAttendees => 'Use for attendee suggestions';

  @override
  String get contactsServerUrlLabel => 'HTTPS server URL';

  @override
  String get contactsUsernameLabel => 'Username';

  @override
  String get contactsPasswordLabel => 'Password';
}

/// The translations for Portuguese, as used in Portugal (`pt_PT`).
class AppLocalizationsPtPt extends AppLocalizationsPt {
  AppLocalizationsPtPt() : super('pt_PT');

  @override
  String get launchAtLoginManagedExternally =>
      'O BusyMax foi iniciado pelas definições de arranque do ambiente de trabalho. Remova a respetiva entrada, depois saia do BusyMax e volte a abri-lo para utilizar este interruptor.';

  @override
  String get timeFormat => 'Formato da hora';

  @override
  String get firstDayOfWeek => 'Primeiro dia da semana';

  @override
  String get systemDefault => 'Predefinição do sistema';

  @override
  String systemDefaultResolved(String weekday) {
    return 'Predefinição do sistema ($weekday)';
  }

  @override
  String get timeFormatTwelveHour => '12 horas';

  @override
  String get timeFormatTwentyFourHour => '24 horas';

  @override
  String get timeEndOfDay => 'fim do dia';

  @override
  String get timePeriod => 'Período do dia';

  @override
  String get launchAtLoginReadFailed =>
      'Não foi possível determinar o estado do arranque ao iniciar sessão.';

  @override
  String get launchAtLoginUnavailable =>
      'O arranque ao iniciar sessão não está disponível neste sistema.';

  @override
  String get windowsStartupEnabledByPolicy =>
      'O arranque automático foi ativado pelo administrador e não pode ser alterado aqui.';

  @override
  String get settingsSaveFailed =>
      'Não foi possível guardar as definições. As alterações poderão perder-se ao reiniciar o BusyMax.';

  @override
  String get nextcloudExportCollection => 'Exportar recursos da coleção';

  @override
  String nextcloudImportItems(int count) {
    return '$count recursos de eventos/tarefas encontrados';
  }

  @override
  String get nextcloudSchedulingInbox => 'Caixa de entrada de convites';

  @override
  String get nextcloudInboxExplanation =>
      'O Nextcloud processa estas mensagens nos seus calendários. Confirmar remove apenas a mensagem, não o evento.';

  @override
  String get nextcloudInboxEmpty => 'Nenhuma mensagem de agendamento.';

  @override
  String get nextcloudAcknowledge => 'Confirmar receção';

  @override
  String get nextcloudAcknowledgeConfirm =>
      'Remover esta mensagem da caixa de entrada? O evento será mantido.';

  @override
  String get nextcloudGuestAvailability =>
      'Verificar disponibilidade dos convidados';

  @override
  String nextcloudTrashRetention(int days) {
    return 'Retenção na reciclagem do servidor: $days dias';
  }

  @override
  String get nextcloudCancelMeeting => 'Cancelar reunião';

  @override
  String get nextcloudDeclineAndRemove => 'Recusar e remover convite';

  @override
  String get nextcloudDeclineRemovalWarning =>
      'A remoção enviará uma recusa na sincronização. Não cancela a reunião do organizador.';

  @override
  String get nextcloudAvailabilityUnknown => 'Disponibilidade desconhecida';

  @override
  String get nextcloudAvailabilityFree =>
      'Nenhum período ocupado informado para este intervalo';

  @override
  String get nextcloudAvailabilityBusy => 'Períodos ocupados';

  @override
  String get nextcloudSchedulingPending =>
      'O Nextcloud enviará as atualizações ao sincronizar. Guardar localmente não confirma a entrega.';

  @override
  String get nextcloudAttendeeRestrictions =>
      'Só o organizador ou um representante autorizado pode alterar os detalhes. Pode responder ao convite nos detalhes.';

  @override
  String get nextcloudMeetingMoveUnsupported =>
      'Esta reunião não pode ser movida por cópia e eliminação. Use um calendário com a mesma identidade de agendamento.';

  @override
  String get nextcloudSchedulingStatus => 'Estado de agendamento do servidor';

  @override
  String get nextcloudImportFollowUp =>
      'Os recursos importados foram guardados localmente. A atualização dos lembretes está pendente; não importe novamente.';

  @override
  String get nextcloudNativeImport =>
      'Importar eventos e tarefas completos sem enviar convites. UIDs existentes são ignorados, salvo se escolher novas cópias. Recursos incompatíveis são informados individualmente.';

  @override
  String get nextcloudImportMethod =>
      'Este ficheiro contém mensagens de agendamento. A importação guardada o conteúdo e remove METHOD; não processa convites nem respostas.';

  @override
  String get nextcloudImportCopies =>
      'Importar novas cópias com novas identidades';

  @override
  String get nextcloudCollectionSettings => 'Definições da coleção';

  @override
  String get nextcloudSharing => 'Partilha';

  @override
  String get nextcloudOwned => 'Própria';

  @override
  String get nextcloudShared => 'Partilhada';

  @override
  String get nextcloudDelegated => 'Delegada';

  @override
  String get nextcloudSubscription => 'Subscrição';

  @override
  String get nextcloudDeleted => 'Eliminada';

  @override
  String get nextcloudMetadataEditable =>
      'O conteúdo é apenas leitura; as propriedades da coleção podem ser alteradas.';

  @override
  String get nextcloudServerOrder =>
      'Ordem no servidor (independente da barra lateral)';

  @override
  String get nextcloudCalendarEnabled => 'Ativada no servidor';

  @override
  String get nextcloudAvailability => 'Incluir esta coleção na disponibilidade';

  @override
  String get nextcloudCalendarTimezone =>
      'Fuso horário do calendário (documento VTIMEZONE)';

  @override
  String get nextcloudRefreshPending =>
      'A alteração foi guardada no Nextcloud. A atualização está pendente; não repita a alteração.';

  @override
  String get nextcloudOutcomeUnknown =>
      'Não foi possível confirmar o resultado no servidor. Atualize antes de tentar novamente.';

  @override
  String get nextcloudRemoveShared => 'Remover calendário/lista partilhada';

  @override
  String get nextcloudRemoveMixed =>
      'Esta coleção contém eventos e tarefas. A eliminação remove ambos.';

  @override
  String get nextcloudReadAccess => 'Apenas leitura';

  @override
  String get nextcloudWriteAccess => 'Leitura e escrita';

  @override
  String get nextcloudRecipientSearch => 'Procurar pessoas ou grupos';

  @override
  String get nextcloudNoRecipients => 'Nenhuma pessoa ou grupo correspondente.';

  @override
  String get nextcloudRevokeShare => 'Revogar acesso';

  @override
  String get nextcloudPublish => 'Publicar ligação';

  @override
  String get nextcloudUnpublish => 'Parar publicação';

  @override
  String get nextcloudPublishWarning =>
      'Qualquer pessoa com o ligação publicado poderá ler este calendário. Publicar?';

  @override
  String get nextcloudTrash => 'Calendários e tarefas eliminados';

  @override
  String get nextcloudTrashEmpty => 'Nenhum item de calendário eliminado.';

  @override
  String get nextcloudRestore => 'Restaurar';

  @override
  String get nextcloudPermanentDelete => 'Eliminar permanentemente';

  @override
  String get nextcloudPermanentDeleteWarning =>
      'Eliminar este item permanentemente? Ele não poderá ser restaurado da reciclagem de calendários do Nextcloud.';

  @override
  String get nextcloudOperationDenied =>
      'O Nextcloud não permitiu esta operação.';

  @override
  String get nextcloudUnsupported =>
      'O servidor não oferece suporte a esta operação.';

  @override
  String get nextcloudPendingChanges =>
      'Guarde ou descarte as alterações da coleção antes de fechar.';

  @override
  String get nextcloudServerUnavailable =>
      'Não foi possível aceder a o Nextcloud. O conteúdo em cache e as alterações pendentes permanecem intactos.';

  @override
  String get mapsShow => 'Mostrar no mapa';

  @override
  String get openLink => 'Abrir ligação';

  @override
  String get externalLocationOpenFailed =>
      'Não foi possível abrir a localização numa aplicação externa.';

  @override
  String scheduleProposedRange(String start, String end) {
    return '$start – $end';
  }

  @override
  String get scheduleRescheduleFailed =>
      'Não foi possível reagendar o evento. O horário guardado não foi alterado.';

  @override
  String get scheduleRescheduleStale =>
      'Este evento foi alterado durante o arrastamento. Tente novamente.';

  @override
  String get scheduleRescheduleNotificationsFailed =>
      'O novo horário foi guardado, mas não foi possível atualizar os lembretes.';

  @override
  String get moveUp => 'Mover para cima';

  @override
  String get moveDown => 'Mover para baixo';

  @override
  String get windowsSupport => 'Suporte';

  @override
  String get windowsThirdPartyLicenses => 'Licenças de terceiros';

  @override
  String get windowsSearch => 'Pesquisar';

  @override
  String get windowsStartupDisabledByUser =>
      'Desativado pelo utilizador nas Definições do Windows.';

  @override
  String get windowsStartupDisabledByPolicy =>
      'Desativado por uma política do Windows.';

  @override
  String get windowsStartupUnavailable =>
      'Disponível após a instalação do BusyMax a partir de um pacote MSIX.';

  @override
  String get windowsReminderExitNotice =>
      'Os lembretes param quando o BusyMax é totalmente encerrado. Mantenha-o em execução em segundo plano para os receber.';

  @override
  String get windowsProductVersionLabel => 'Versão do produto';

  @override
  String get windowsPackageVersionLabel => 'Versão do pacote do Windows';

  @override
  String get windowsUnpackaged => 'Sem pacote';

  @override
  String get windowsAgendaLoadMore => 'Carregar mais itens da agenda';

  @override
  String repeatWeeklyDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'à segunda-feira',
      'TU': 'à terça-feira',
      'WE': 'à quarta-feira',
      'TH': 'à quinta-feira',
      'FR': 'à sexta-feira',
      'SA': 'ao sábado',
      'SU': 'ao domingo',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatOnTwoMonthDaysSummary(String first, String second) {
    return 'nos dias $first e $second';
  }

  @override
  String repeatYearlyOnTwoMonthDaysSummary(
    String frequency,
    String month,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency nos dias $firstDay e $secondDay de $month';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaySummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String day,
  ) {
    return '$frequency no dia $day de $firstMonth e $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnTwoMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String firstDay,
    String secondDay,
  ) {
    return '$frequency nos dias $firstDay e $secondDay de $firstMonth e $secondMonth';
  }

  @override
  String repeatYearlyInTwoMonthsOnMonthDaysSummary(
    String frequency,
    String firstMonth,
    String secondMonth,
    String days,
  ) {
    return '$frequency nos dias $days de $firstMonth e $secondMonth';
  }

  @override
  String get appTitle => 'BusyMax';

  @override
  String get connectGoogleAccount =>
      'Ligue as contas Google, Microsoft, Calendário Apple iCloud ou Nextcloud.';

  @override
  String get googlePermissionsConsentNotice =>
      'No ecrã de autorizações da Google, selecione as autorizações do Calendário e das Tarefas.';

  @override
  String get googlePermissionsRequiredRetry =>
      'As autorizações do Calendário Google e do Google Tasks são necessárias. Tente novamente e selecione ambas as caixas.';

  @override
  String get googleTasksProvider => 'Google Tasks';

  @override
  String get microsoftTodoProvider => 'Microsoft To Do';

  @override
  String get providerNotConfigured => 'Este fornecedor não está configurado.';

  @override
  String get waitingForGoogleSignIn =>
      'A aguardar o início de sessão da Google...';

  @override
  String get waitingForMicrosoftSignIn =>
      'A aguardar o início de sessão da Microsoft...';

  @override
  String get microsoftSignInNotConfigured =>
      'O início de sessão da Microsoft não está configurado. Defina MICROSOFT_OAUTH_CLIENT_ID.';

  @override
  String get cancel => 'Cancelar';

  @override
  String get close => 'Fechar';

  @override
  String get windowMinimize => 'Minimizar';

  @override
  String get windowMaximize => 'Maximizar';

  @override
  String get windowRestore => 'Restaurar';

  @override
  String get exit => 'Sair';

  @override
  String get options => 'Opções';

  @override
  String get hide => 'Ocultar';

  @override
  String get show => 'Mostrar';

  @override
  String get export => 'Exportar';

  @override
  String get save => 'Guardar';

  @override
  String get settings => 'Definições';

  @override
  String get all => 'Tudo';

  @override
  String get calendarEvents => 'Eventos';

  @override
  String get calendarTasks => 'Tarefas';

  @override
  String get calendar => 'Calendário';

  @override
  String get calendars => 'Calendários';

  @override
  String get newCalendar => 'Novo calendário';

  @override
  String get calendarColor => 'Cor do calendário';

  @override
  String calendarColorOption(int number) {
    return 'Cor $number';
  }

  @override
  String get calendarManagementUnsupported =>
      'Este fornecedor não suporta a gestão de calendários no BusyMax.';

  @override
  String get primaryCalendarCannotDelete =>
      'O calendário principal não pode ser eliminado.';

  @override
  String calendarCreateFailed(String error) {
    return 'Não foi possível criar o calendário: $error';
  }

  @override
  String get calendarCreatedRefreshPending =>
      'O calendário foi criado, mas o BusyMax não conseguiu atualizar a conta. Será apresentado após a próxima sincronização.';

  @override
  String calendarUpdateFailed(String error) {
    return 'Não foi possível atualizar o calendário: $error';
  }

  @override
  String calendarDeleteFailed(String error) {
    return 'Não foi possível eliminar o calendário: $error';
  }

  @override
  String get newEvent => 'Novo evento';

  @override
  String get refreshCalendar => 'Atualizar calendário';

  @override
  String get openInProvider => 'Abrir no serviço';

  @override
  String get linkedResources => 'Recursos ligados';

  @override
  String get noLinkedResources => 'Sem recursos ligados';

  @override
  String get attachments => 'Anexos';

  @override
  String get attachmentsNotLoaded => 'Anexos não carregados';

  @override
  String get hideFromSchedule => 'Ocultar da agenda';

  @override
  String get showInSchedule => 'Mostrar na agenda';

  @override
  String get noCalendarsSynced => 'Ainda não há calendários sincronizados.';

  @override
  String get allDay => 'Todo o dia';

  @override
  String moreItems(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return '+$countString mais';
  }

  @override
  String get noEventsOrTasks => 'Sem eventos ou tarefas';

  @override
  String get scheduleLoading => 'A carregar agenda...';

  @override
  String get scheduleUnavailable => 'Agenda indisponível';

  @override
  String get scheduleNoSources =>
      'Sem calendários ou listas de tarefas visíveis';

  @override
  String get scheduleNoSourcesDescription =>
      'Escolha o que pretende mostrar nas Definições e atualize a agenda.';

  @override
  String get scheduleNoSearchResults =>
      'Nenhum evento ou tarefa correspondente';

  @override
  String get scheduleNoSearchResultsDescription =>
      'Experimente outra pesquisa ou limpe os filtros atuais.';

  @override
  String get refresh => 'Atualizar';

  @override
  String get trayOpenBusyMax => 'Abrir o BusyMax';

  @override
  String get trayShowBusyMax => 'Mostrar o BusyMax';

  @override
  String get trayNewEvent => 'Novo evento…';

  @override
  String get trayNewTask => 'Nova tarefa…';

  @override
  String get trayToday => 'Hoje';

  @override
  String get trayAllDay => 'Todo o dia';

  @override
  String get trayNow => 'Agora';

  @override
  String get trayCalendarEvent => 'Evento do calendário';

  @override
  String get trayUntitledEvent => 'Evento sem título';

  @override
  String get trayNothingElseToday => 'Nada mais hoje';

  @override
  String trayTasksDueToday(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count tarefas terminam hoje',
      one: '1 tarefa termina hoje',
    );
    return '$_temp0';
  }

  @override
  String get trayOpenTodayAgenda => 'Abrir a agenda de hoje';

  @override
  String get traySyncNow => 'Sincronizar agora';

  @override
  String get traySyncing => 'A sincronizar…';

  @override
  String get trayNotConnected => 'Não ligado';

  @override
  String get trayNotYetSynced => 'Ainda não sincronizado';

  @override
  String get trayLastSyncedJustNow => 'Sincronizado agora mesmo';

  @override
  String trayLastSyncedMinutesAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado há $count minutos',
      one: 'Sincronizado há 1 minuto',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedHoursAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado há $count horas',
      one: 'Sincronizado há 1 hora',
    );
    return '$_temp0';
  }

  @override
  String trayLastSyncedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Sincronizado há $count dias',
      one: 'Sincronizado há 1 dia',
    );
    return '$_temp0';
  }

  @override
  String get traySettings => 'Definições';

  @override
  String get trayQuitBusyMax => 'Sair do BusyMax';

  @override
  String get agendaLoadMoreOverdue => 'Carregar mais tarefas em atraso';

  @override
  String get agendaLoadMoreNoDate => 'Carregar mais tarefas sem data';

  @override
  String get viewDay => 'Dia';

  @override
  String get viewWeek => 'Semana';

  @override
  String get viewMonth => 'Mês';

  @override
  String get viewYear => 'Ano';

  @override
  String get viewAgenda => 'Vista de agenda';

  @override
  String get scheduleSettings => 'Agenda';

  @override
  String get scheduleDisplaySettings => 'Apresentação da agenda';

  @override
  String get newEventsAndTasks => 'Novos eventos e tarefas';

  @override
  String get defaultCalendar => 'Calendário predefinido';

  @override
  String get defaultTaskList => 'Lista de tarefas predefinida';

  @override
  String get lastUsed => 'Utilizado recentemente';

  @override
  String get scheduleDisplayHoursDescription =>
      'As vistas de dia e semana mostram inicialmente este intervalo horário. Os itens anteriores ou posteriores alargam-no quando necessário.';

  @override
  String get scheduleDayStartsAt => 'O dia começa às';

  @override
  String get scheduleDayEndsAt => 'O dia termina às';

  @override
  String get sourceCalendar => 'Calendário';

  @override
  String get sourceTaskList => 'Lista de tarefas';

  @override
  String get createChoiceTitle => 'Criar';

  @override
  String get createEventAtTime => 'Evento';

  @override
  String get createTaskAtDate => 'Tarefa';

  @override
  String get editEvent => 'Editar evento';

  @override
  String get eventTitle => 'Título do evento';

  @override
  String get location => 'Local';

  @override
  String get timeSlot => 'Intervalo de tempo';

  @override
  String get startDateTime => 'Data e hora de início';

  @override
  String get endDateTime => 'Data e hora de fim';

  @override
  String get doesNotRepeat => 'Não se repete';

  @override
  String get defaultReminder => 'Lembrete predefinido';

  @override
  String get guests => 'Convidados';

  @override
  String get noGuests => 'Sem convidados';

  @override
  String get attendeeRequired => 'Obrigatório';

  @override
  String get attendeeOptional => 'Opcional';

  @override
  String get meetingSection => 'Reunião';

  @override
  String get addGoogleMeet => 'Adicionar o Google Meet';

  @override
  String get addTeamsMeeting => 'Adicionar reunião do Microsoft Teams';

  @override
  String get onlineMeetingAdded => 'Reunião online adicionada';

  @override
  String get requestResponses => 'Pedir respostas';

  @override
  String get requestResponsesDescription =>
      'Peça aos convidados que respondam ao convite.';

  @override
  String get hideGuestList => 'Ocultar lista de convidados';

  @override
  String get hideGuestListDescription =>
      'Os convidados não podem ver quem mais foi convidado.';

  @override
  String get allowNewTimeProposals => 'Permitir novas propostas de horário';

  @override
  String get allowNewTimeProposalsDescription =>
      'Os convidados podem sugerir uma hora diferente para a reunião.';

  @override
  String get notifyGuestsTitle => 'Notificar convidados?';

  @override
  String get notifyGuestsSaveMessage =>
      'Esta reunião tem convidados. Enviar convites ou atualizações do evento ao guardá-la?';

  @override
  String get notifyGuestsDeleteMessage =>
      'Esta reunião tem convidados. Enviar um cancelamento ao eliminá-la?';

  @override
  String get sendUpdates => 'Enviar atualizações';

  @override
  String get sendCancellation => 'Enviar cancelamento';

  @override
  String get doNotSend => 'Não enviar';

  @override
  String get microsoftNotifyGuestsSaveTitle => 'Guardar reunião?';

  @override
  String get microsoftNotifyGuestsSaveMessage =>
      'A Microsoft enviará convites ou atualizações do evento aos convidados.';

  @override
  String get microsoftNotifyGuestsDeleteTitle => 'Eliminar reunião?';

  @override
  String get microsoftNotifyGuestsDeleteMessage =>
      'A Microsoft enviará um cancelamento aos convidados.';

  @override
  String get organizer => 'Organizador';

  @override
  String get yourResponse => 'A sua resposta';

  @override
  String get guestResponses => 'Respostas dos convidados';

  @override
  String get respond => 'Responder';

  @override
  String get acceptInvitation => 'Aceitar';

  @override
  String get tentativeInvitation => 'Provisório';

  @override
  String get declineInvitation => 'Recusar';

  @override
  String get joinMeeting => 'Participar na reunião';

  @override
  String get responseAccepted => 'Aceite';

  @override
  String get responseTentative => 'Provisório';

  @override
  String get responseDeclined => 'Recusado';

  @override
  String get responseNeedsAction => 'A aguardar resposta';

  @override
  String get responseNotResponded => 'Sem resposta';

  @override
  String get responseOrganizer => 'Organizador';

  @override
  String invitationResponseFailed(String error) {
    return 'Não foi possível enviar a sua resposta: $error';
  }

  @override
  String get joinMeetingFailed =>
      'Não foi possível abrir a ligação da reunião.';

  @override
  String get description => 'Descrição';

  @override
  String get availabilityShowAs => 'Disponibilidade / Mostrar como';

  @override
  String get busy => 'Ocupado';

  @override
  String get visibility => 'Visibilidade';

  @override
  String get defaultVisibility => 'Visibilidade predefinida';

  @override
  String get conference => 'Conferência';

  @override
  String get noConference => 'Sem conferência';

  @override
  String get providerCalendar => 'Calendário do fornecedor';

  @override
  String get formatBoldShortLabel => 'N';

  @override
  String get formatBoldTooltip => 'Negrito';

  @override
  String get formatItalicShortLabel => 'I';

  @override
  String get formatItalicTooltip => 'Itálico';

  @override
  String get formatUnderlineShortLabel => 'S';

  @override
  String get formatUnderlineTooltip => 'Sublinhado';

  @override
  String reminderMinutesBefore(int minutes) {
    final intl.NumberFormat minutesNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String minutesString = minutesNumberFormat.format(minutes);

    String _temp0 = intl.Intl.pluralLogic(
      minutes,
      locale: localeName,
      other: '$minutesString minutos antes',
      one: '1 minuto antes',
    );
    return '$_temp0';
  }

  @override
  String get reminderAtStart => 'À hora de início';

  @override
  String reminderHoursBefore(int hours) {
    final intl.NumberFormat hoursNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String hoursString = hoursNumberFormat.format(hours);

    String _temp0 = intl.Intl.pluralLogic(
      hours,
      locale: localeName,
      other: '$hoursString horas antes',
      one: '1 hora antes',
    );
    return '$_temp0';
  }

  @override
  String reminderDaysBefore(int days) {
    final intl.NumberFormat daysNumberFormat = intl.NumberFormat.decimalPattern(
      localeName,
    );
    final String daysString = daysNumberFormat.format(days);

    String _temp0 = intl.Intl.pluralLogic(
      days,
      locale: localeName,
      other: '$daysString dias antes',
      one: '1 dia antes',
    );
    return '$_temp0';
  }

  @override
  String get availabilityFree => 'Livre';

  @override
  String get availabilityTentative => 'Provisório';

  @override
  String get availabilityOutOfOffice => 'Fora do escritório';

  @override
  String get availabilityWorkingElsewhere => 'A trabalhar noutro local';

  @override
  String get visibilityDefault => 'Predefinida';

  @override
  String get visibilityPublic => 'Pública';

  @override
  String get visibilityPrivate => 'Privada';

  @override
  String get visibilityConfidential => 'Confidencial';

  @override
  String get sensitivityNormal => 'Normal';

  @override
  String get sensitivityPersonal => 'Pessoal';

  @override
  String get tasks => 'Tarefas';

  @override
  String get allTasks => 'Todas as tarefas';

  @override
  String tasksInList(String title) {
    return 'Tarefas em $title';
  }

  @override
  String get taskLists => 'Listas de tarefas';

  @override
  String get navigation => 'Navegação';

  @override
  String get mainMenu => 'Menu principal';

  @override
  String get keyboardShortcuts => 'Atalhos de teclado';

  @override
  String get shortcutGroupGeneral => 'Geral';

  @override
  String get shortcutKeyboardShortcutsDescription =>
      'Mostrar esta referência de atalhos';

  @override
  String get shortcutGroupNavigation => 'Navegação';

  @override
  String get shortcutNextPeriod => 'Período seguinte';

  @override
  String get shortcutNextPeriodDescription =>
      'Semana seguinte na vista semanal, mês seguinte na vista mensal e assim por diante';

  @override
  String get shortcutPreviousPeriod => 'Período anterior';

  @override
  String get shortcutPreviousPeriodDescription =>
      'Semana anterior na vista semanal, mês anterior na vista mensal e assim por diante';

  @override
  String get shortcutJumpToToday => 'Ir para hoje';

  @override
  String get shortcutGroupView => 'Vista';

  @override
  String get viewSelector => 'Vista';

  @override
  String get shortcutDayView => 'Vista diária';

  @override
  String get shortcutWeekView => 'Vista semanal';

  @override
  String get shortcutMonthView => 'Vista mensal';

  @override
  String get shortcutYearView => 'Vista anual';

  @override
  String get shortcutAgendaView => 'Vista de agenda';

  @override
  String get shortcutGroupCreateAndEdit => 'Criar e editar';

  @override
  String get shortcutSaveItem => 'Guardar evento ou tarefa';

  @override
  String get shortcutDeleteItem => 'Eliminar evento ou tarefa';

  @override
  String get shortcutGroupTaskEditing => 'Edição de tarefas';

  @override
  String get shortcutCancelEditing => 'Cancelar edição';

  @override
  String get shortcutCancelEditingDescription =>
      'Fechar a edição ou os detalhes da tarefa';

  @override
  String get aboutBusyMax => 'Acerca do BusyMax';

  @override
  String get aboutBusyMaxDescription => 'Calendário e tarefas';

  @override
  String get license => 'Licença';

  @override
  String get apacheLicenseName => 'Apache License 2.0';

  @override
  String get website => 'Site';

  @override
  String get sourceCode => 'Código-fonte';

  @override
  String get reportAnIssue => 'Comunicar um problema';

  @override
  String get sendFeedback => 'Enviar comentários';

  @override
  String get feedbackSubmit => 'Enviar';

  @override
  String get feedbackCategory => 'Categoria';

  @override
  String get feedbackSelectCategory => 'Selecione uma categoria';

  @override
  String get feedbackCategoryProblem => 'Problema ou erro';

  @override
  String get feedbackCategoryFeature => 'Pedido de funcionalidade';

  @override
  String get feedbackCategoryPrivacySecurity =>
      'Questão de privacidade ou segurança';

  @override
  String get feedbackCategoryUsability => 'Problema de utilização';

  @override
  String get feedbackCategoryOther => 'Outro';

  @override
  String get feedbackSubject => 'Assunto';

  @override
  String get feedbackDetailedMessage => 'Mensagem detalhada';

  @override
  String get feedbackReplyEmail =>
      'Endereço de e-mail para resposta (opcional)';

  @override
  String get feedbackIncludeTechnicalDetails => 'Incluir detalhes técnicos';

  @override
  String get feedbackTechnicalDetailsDisclosure =>
      'Adiciona apenas o nome e a versão do sistema operativo e a configuração regional da aplicação. Não são incluídos registos, dados de contas, nomes de ficheiros nem outros diagnósticos.';

  @override
  String get feedbackCategoryRequired => 'Selecione uma categoria.';

  @override
  String get feedbackSubjectLengthError =>
      'O assunto deve ter entre 3 e 120 carateres.';

  @override
  String get feedbackMessageLengthError =>
      'A mensagem deve ter entre 10 e 5 000 carateres.';

  @override
  String get feedbackInvalidEmail => 'Introduza um endereço de e-mail válido.';

  @override
  String get feedbackConnectionError =>
      'Não foi possível ligar ao BusyStack. Verifique a ligação e tente novamente.';

  @override
  String get feedbackTimeoutError =>
      'O pedido excedeu o tempo limite. Os seus comentários não foram apagados; tente novamente.';

  @override
  String get feedbackRateLimitedError =>
      'Foram enviados demasiados comentários a partir desta rede. Aguarde e tente novamente.';

  @override
  String get feedbackRejectedError =>
      'O servidor rejeitou o envio. Reveja os campos e tente novamente.';

  @override
  String get feedbackServerError =>
      'O BusyStack não pode aceitar os seus comentários neste momento. Os seus comentários não foram apagados; tente novamente.';

  @override
  String feedbackSuccess(String id) {
    return 'Comentários enviados. Referência: $id';
  }

  @override
  String get toggleSidebar => 'Mostrar ou ocultar a barra lateral';

  @override
  String get showSidebar => 'Mostrar painel lateral';

  @override
  String get hideSidebar => 'Ocultar painel lateral';

  @override
  String get accounts => 'Contas';

  @override
  String get currentAccount => 'Conta atual';

  @override
  String get switchAccount => 'Mudar de conta';

  @override
  String get addGoogleAccount => 'Adicionar conta Google';

  @override
  String get addMicrosoftAccount => 'Adicionar conta Microsoft';

  @override
  String get googleProvider => 'Google';

  @override
  String get microsoftProvider => 'Microsoft';

  @override
  String get signedInAccount => 'Sessão iniciada';

  @override
  String get removeAccount => 'Remover conta…';

  @override
  String get removingAccount => 'A remover conta…';

  @override
  String get removeAccountDescription =>
      'Parar a sincronização e remover os dados desta conta deste dispositivo.';

  @override
  String removeAccountTitle(String account) {
    return 'Remover $account do BusyMax?';
  }

  @override
  String get removeAccountConfirmation =>
      'Esta ação elimina deste dispositivo as tarefas, calendários, eventos, lembretes e alterações offline pendentes colocados em cache. As alterações não sincronizadas serão perdidas. As cópias dos calendários, eventos, listas de tarefas e tarefas no fornecedor não são eliminadas.';

  @override
  String get revokeGoogleAccess =>
      'Revogar também o acesso do BusyMax a esta conta Google';

  @override
  String get revokeGoogleAccessDescription =>
      'Terá de conceder acesso novamente antes de voltar a ligar a conta.';

  @override
  String get removeAccountAction => 'Remover conta';

  @override
  String get removeAccountFailed =>
      'Não foi possível concluir a remoção da conta. Tente novamente.';

  @override
  String get accountRemovedGoogleRevokeFailed =>
      'A conta foi removida deste dispositivo, mas não foi possível revogar o acesso do BusyMax à sua conta Google. Pode revogar esse acesso na sua conta Google.';

  @override
  String get newTaskList => 'Nova lista de tarefas';

  @override
  String taskListCreateFailed(String error) {
    return 'Não foi possível criar a lista de tarefas: $error';
  }

  @override
  String taskListRenameFailed(String error) {
    return 'Não foi possível mudar o nome da lista de tarefas: $error';
  }

  @override
  String taskListDeleteFailed(String error) {
    return 'Não foi possível eliminar a lista de tarefas: $error';
  }

  @override
  String get taskListPendingChangesPreventRemoval =>
      'Sincronize a conta ou resolva as alterações bloqueadas desta lista de tarefas em Diagnóstico antes de eliminar ou remover a lista.';

  @override
  String get signInToViewTaskLists =>
      'Inicie sessão para ver as listas de tarefas.';

  @override
  String get noTaskListsSynced =>
      'Ainda não há listas de tarefas sincronizadas.';

  @override
  String get listActions => 'Ações da lista';

  @override
  String get rename => 'Mudar o nome';

  @override
  String get delete => 'Eliminar';

  @override
  String get renameList => 'Mudar o nome da lista';

  @override
  String get deleteList => 'Eliminar lista';

  @override
  String get unshare => 'Cancelar partilha';

  @override
  String get readOnlyTaskListCannotRename =>
      'Esta lista de tarefas é só de leitura e não pode ter o nome alterado.';

  @override
  String get taskListCannotDelete =>
      'Esta lista de tarefas não pode ser eliminada com as permissões atuais.';

  @override
  String get builtInMicrosoftList => 'Incorporada';

  @override
  String get builtInMicrosoftListCannotRenameDelete =>
      'As listas incorporadas do Microsoft To Do não podem ser renomeadas nem eliminadas.';

  @override
  String deleteListConfirmation(String title) {
    return 'Eliminar “$title” do Google Tasks?';
  }

  @override
  String deleteTaskListConfirmation(String title) {
    return 'Eliminar “$title” e todas as suas tarefas?';
  }

  @override
  String unshareTaskListConfirmation(String title) {
    return 'Cancelar a partilha de “$title” desta conta?';
  }

  @override
  String get deleteEvent => 'Eliminar evento';

  @override
  String get title => 'Título';

  @override
  String get create => 'Criar';

  @override
  String get newTask => 'Nova tarefa';

  @override
  String get clearCompleted => 'Limpar tarefas concluídas';

  @override
  String get refreshList => 'Atualizar lista';

  @override
  String get refreshAll => 'Atualizar tudo';

  @override
  String get listRefreshed => 'Lista atualizada.';

  @override
  String get allTasksRefreshed => 'Todas as contas foram atualizadas.';

  @override
  String exportedFile(String path) {
    return 'Exportado para $path';
  }

  @override
  String exportFailed(String error) {
    return 'Falha ao exportar: $error';
  }

  @override
  String refreshFailed(String error) {
    return 'Falha ao atualizar: $error';
  }

  @override
  String get selectOrCreateTaskList =>
      'Selecione ou crie uma lista de tarefas para começar.';

  @override
  String get signInToViewTasks => 'Inicie sessão para ver as tarefas.';

  @override
  String get noTasks => 'Sem tarefas.';

  @override
  String get noTasksYet => 'Ainda não há tarefas';

  @override
  String get noTasksYetMessage =>
      'Crie uma tarefa ou atualize as suas contas para começar.';

  @override
  String get noTasksInList => 'Não há tarefas nesta lista.';

  @override
  String get overdue => 'Em atraso';

  @override
  String get today => 'Hoje';

  @override
  String get tomorrow => 'Amanhã';

  @override
  String get upcoming => 'Próximas';

  @override
  String get noDate => 'Sem data';

  @override
  String get completed => 'Concluídas';

  @override
  String duePrefix(String date) {
    return 'Prazo: $date';
  }

  @override
  String dateTimeDisplay(String date, String time) {
    return '$date, $time';
  }

  @override
  String get taskDetails => 'Detalhes da tarefa';

  @override
  String get editTask => 'Editar tarefa';

  @override
  String get noTaskSelected => 'Nenhuma tarefa selecionada.';

  @override
  String get noTaskSelectedHelper =>
      'Selecione uma tarefa para ver e editar os detalhes.';

  @override
  String get taskUnavailable => 'Tarefa indisponível.';

  @override
  String get signInToEditTasks => 'Inicie sessão para editar tarefas.';

  @override
  String get refreshTask => 'Atualizar tarefa';

  @override
  String get primarySection => 'Principal';

  @override
  String get statusSection => 'Estado';

  @override
  String get openStatus => 'Aberta';

  @override
  String get doneStatus => 'Concluída';

  @override
  String get taskStatus => 'Estado';

  @override
  String get taskStatusNone => 'Sem estado';

  @override
  String get taskStatusNeedsAction => 'Requer ação';

  @override
  String get taskStatusInProcess => 'Em curso';

  @override
  String get taskStatusCompleted => 'Concluída';

  @override
  String get taskStatusCancelled => 'Cancelada';

  @override
  String completionPercent(int percent) {
    final intl.NumberFormat percentNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String percentString = percentNumberFormat.format(percent);

    return '$percentString% concluída';
  }

  @override
  String get completionDate => 'Data de conclusão';

  @override
  String get priority => 'Prioridade';

  @override
  String get priorityNone => 'Sem prioridade';

  @override
  String priorityHighValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridade $priorityString · Alta';
  }

  @override
  String priorityMediumValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridade $priorityString · Média';
  }

  @override
  String priorityLowValue(int priority) {
    final intl.NumberFormat priorityNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String priorityString = priorityNumberFormat.format(priority);

    return 'Prioridade $priorityString · Baixa';
  }

  @override
  String get taskUrl => 'URL da tarefa';

  @override
  String get invalidTaskUrl =>
      'Introduza um URL absoluto, incluindo o esquema.';

  @override
  String get classification => 'Classificação';

  @override
  String get classificationPublic =>
      'Quando partilhada, mostrar a tarefa completa';

  @override
  String get classificationConfidential =>
      'Quando partilhada, mostrar apenas ocupado';

  @override
  String get classificationPrivate => 'Quando partilhada, ocultar esta tarefa';

  @override
  String get pinTask => 'Afixar tarefa';

  @override
  String get notes => 'Notas';

  @override
  String get dueDate => 'Data limite';

  @override
  String get clearDueDate => 'Limpar data limite';

  @override
  String get dueTime => 'Hora limite';

  @override
  String get startDate => 'Data de início';

  @override
  String get startTime => 'Hora de início';

  @override
  String get endDate => 'Data de fim';

  @override
  String get endTime => 'Hora de fim';

  @override
  String get reminderDate => 'Data do lembrete';

  @override
  String get reminderTime => 'Hora do lembrete';

  @override
  String get reminder => 'Lembrete';

  @override
  String get addReminder => 'Adicionar lembrete';

  @override
  String get reminders => 'Lembretes';

  @override
  String get noReminders => 'Sem lembretes';

  @override
  String get editReminder => 'Editar lembrete';

  @override
  String get beforeTaskStarts => 'Antes do início da tarefa';

  @override
  String get beforeTaskDue => 'Antes do prazo da tarefa';

  @override
  String get afterTaskStarts => 'Depois do início da tarefa';

  @override
  String get afterTaskDue => 'Depois do prazo da tarefa';

  @override
  String get relativeToTaskStart => 'Relativo à data de início da tarefa';

  @override
  String get relativeToTaskDue => 'Relativo à data limite da tarefa';

  @override
  String get reminderTimeOfDay => 'Hora do dia';

  @override
  String get absoluteReminder => 'Numa data e hora';

  @override
  String get reminderAmount => 'Quantidade';

  @override
  String get reminderUnit => 'Unidade';

  @override
  String get reminderUnitSeconds => 'Segundos';

  @override
  String get reminderUnitMinutes => 'Minutos';

  @override
  String get reminderUnitHours => 'Horas';

  @override
  String get reminderUnitDays => 'Dias';

  @override
  String get reminderUnitWeeks => 'Semanas';

  @override
  String get reminderAtTaskStart => 'No início da tarefa';

  @override
  String get reminderAtTaskDue => 'No prazo da tarefa';

  @override
  String get unsupportedReminder =>
      'Este tipo de lembrete é preservado, mas a hora não pode ser editada.';

  @override
  String get relatedRemindersTitle => 'Manter lembretes relacionados?';

  @override
  String relatedRemindersDescription(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'Esta data tem $countString lembretes relacionados. Mantê-los na data e hora atuais?';
  }

  @override
  String get discardRelatedReminders => 'Eliminar lembretes';

  @override
  String get keepRelatedReminders => 'Manter lembretes';

  @override
  String get addGuest => 'Adicionar convidado';

  @override
  String get addGuestEmail => 'Adicionar e-mail do convidado';

  @override
  String get removeReminder => 'Remover lembrete';

  @override
  String get off => 'Desativado';

  @override
  String get repeat => 'Repetição';

  @override
  String get repeatNone => 'Não repetir';

  @override
  String get noneValue => 'Nenhum';

  @override
  String get repeatDaily => 'Diariamente';

  @override
  String get repeatWeekly => 'Semanalmente';

  @override
  String get repeatMonthly => 'Mensalmente';

  @override
  String get repeatYearly => 'Anualmente';

  @override
  String get repeatEvery => 'Intervalo';

  @override
  String get repeatOn => 'Repetir em';

  @override
  String get repeatEnd => 'Terminar repetição';

  @override
  String get repeatNever => 'Nunca';

  @override
  String get repeatUntil => 'Numa data';

  @override
  String get repeatAfter => 'Depois de um número de ocorrências';

  @override
  String get repeatCount => 'Ocorrências';

  @override
  String get repeatDayOfMonth => 'Dias do mês';

  @override
  String get repeatMonths => 'Meses';

  @override
  String get repeatOrdinal => 'Posição do dia da semana';

  @override
  String get repeatSpecificDays => 'Dias específicos';

  @override
  String get repeatFirst => 'Primeiro';

  @override
  String get repeatSecond => 'Segundo';

  @override
  String get repeatThird => 'Terceiro';

  @override
  String get repeatFourth => 'Quarto';

  @override
  String get repeatFifth => 'Quinto';

  @override
  String get repeatSecondToLast => 'Penúltimo';

  @override
  String get repeatLast => 'Último';

  @override
  String get repeatAnyDay => 'Dia';

  @override
  String get repeatWeekday => 'Dia útil';

  @override
  String get repeatWeekendDay => 'Dia do fim de semana';

  @override
  String repeatOrdinalDaySummary(String dayKey, String day) {
    String _temp0 = intl.Intl.selectLogic(dayKey, {
      'MO': 'segunda-feira',
      'TU': 'terça-feira',
      'WE': 'quarta-feira',
      'TH': 'quinta-feira',
      'FR': 'sexta-feira',
      'SA': 'sábado',
      'SU': 'domingo',
      'day': 'dia',
      'weekday': 'dia útil',
      'weekend': 'dia do fim de semana',
      'other': '$day',
    });
    return '$_temp0';
  }

  @override
  String repeatEveryDays(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'A cada $countString dias';
  }

  @override
  String repeatEveryWeeks(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'A cada $countString semanas';
  }

  @override
  String repeatEveryMonths(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'A cada $countString meses';
  }

  @override
  String repeatEveryYears(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'A cada $countString anos';
  }

  @override
  String repeatOnDaysSummary(String days) {
    return '$days';
  }

  @override
  String repeatOnMonthDaysSummary(String days) {
    return 'no dia $days';
  }

  @override
  String repeatOnOrdinalSummary(String position, String days) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'na primeira ocorrência de $days',
      'second': 'na segunda ocorrência de $days',
      'third': 'na terceira ocorrência de $days',
      'fourth': 'na quarta ocorrência de $days',
      'fifth': 'na quinta ocorrência de $days',
      'secondToLast': 'na penúltima ocorrência de $days',
      'last': 'na última ocorrência de $days',
      'other': 'em $days',
    });
    return '$_temp0';
  }

  @override
  String repeatInMonthsSummary(String months) {
    return 'em $months';
  }

  @override
  String repeatTimesSummary(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString vezes',
      one: '$countString vez',
    );
    return '$_temp0';
  }

  @override
  String repeatUntilSummary(String date) {
    return 'até $date';
  }

  @override
  String get unsupportedRecurrencePreserved =>
      'Esta regra de recorrência utiliza opções que este editor não altera.';

  @override
  String get taskRecurrenceDestinationUnsupported =>
      'Esta lista não suporta este padrão de repetição. Altere o padrão ou escolha outra lista.';

  @override
  String get taskRecurrenceRequiresDate =>
      'Adicione uma data de início ou de conclusão para usar este padrão, ou desative a repetição.';

  @override
  String recurrenceUnsupportedByProvider(String provider) {
    return 'Esta recorrência não pode ser usada com $provider.';
  }

  @override
  String get importance => 'Importância';

  @override
  String get importanceLow => 'Baixa';

  @override
  String get importanceNormal => 'Média';

  @override
  String get importanceHigh => 'Alta';

  @override
  String get categories => 'Categorias';

  @override
  String get scheduleSection => 'Agenda';

  @override
  String get dueGroup => 'Prazo';

  @override
  String get startGroup => 'Início';

  @override
  String get reminderGroup => 'Lembrete';

  @override
  String get organizationSection => 'Organização';

  @override
  String get actionsSection => 'Ações';

  @override
  String get advancedSection => 'Avançado';

  @override
  String get addCategory => 'Adicionar categoria';

  @override
  String get list => 'Lista';

  @override
  String get microsoftMoveUnsupported =>
      'Nesta versão, não é possível mover tarefas entre listas em contas Microsoft To Do.';

  @override
  String get createSubtask => 'Criar subtarefa';

  @override
  String get subtasks => 'Subtarefas';

  @override
  String get duplicateTask => 'Duplicar tarefa';

  @override
  String get taskDuplicated => 'Tarefa duplicada.';

  @override
  String taskDuplicateFailed(String error) {
    return 'Não foi possível duplicar a tarefa: $error';
  }

  @override
  String get hideSubtasks => 'Ocultar subtarefas';

  @override
  String get hideClosedSubtasks => 'Ocultar subtarefas concluídas';

  @override
  String get moveToTop => 'Mover para o início';

  @override
  String get deleteTask => 'Eliminar tarefa';

  @override
  String get newSubtask => 'Nova subtarefa';

  @override
  String deleteTaskConfirmation(String title) {
    return 'Eliminar «$title»?';
  }

  @override
  String get deleteAssignedTaskWarning =>
      'Isto também elimina a tarefa original no Google Docs ou nos espaços do Chat.';

  @override
  String get metadata => 'Metadados';

  @override
  String get id => 'ID';

  @override
  String get etag => 'ETag';

  @override
  String get updated => 'Atualizado';

  @override
  String get parent => 'Tarefa principal';

  @override
  String get position => 'Posição';

  @override
  String get webLink => 'Ligação Web';

  @override
  String get assignment => 'Atribuição';

  @override
  String get localState => 'Estado local';

  @override
  String get pendingSync => 'Sincronização pendente';

  @override
  String get synced => 'Sincronizado';

  @override
  String get account => 'Conta';

  @override
  String get sync => 'Sincronização';

  @override
  String get forceFullResync => 'Forçar nova sincronização completa';

  @override
  String get forceFullResyncDescription =>
      'Recarrega completamente os dados de todas as contas ligadas. Utilize esta opção apenas para resolver problemas de sincronização.';

  @override
  String get runInBackgroundWhenClosed =>
      'Continuar em execução quando a janela for fechada';

  @override
  String get showTrayIcon => 'Mostrar ícone na área de notificação';

  @override
  String get startMinimizedToTray =>
      'Iniciar minimizado na área de notificação';

  @override
  String get launchAtLogin => 'Iniciar ao entrar';

  @override
  String get launchAtLoginDescription =>
      'Inicie o BusyMax em segundo plano para que os lembretes funcionem após entrar.';

  @override
  String get launchAtLoginFailed =>
      'Não foi possível atualizar o início de sessão.';

  @override
  String get requiresTrayIcon => 'Requer o ícone da área de notificação.';

  @override
  String get syncComplete => 'Sincronização concluída.';

  @override
  String syncFailed(String error) {
    return 'Falha na sincronização: $error';
  }

  @override
  String get notifySyncFailures => 'Notificações de falhas de sincronização';

  @override
  String get notifyConflicts => 'Notificações de conflitos';

  @override
  String get notifyDueToday => 'Notificações de tarefas com prazo para hoje';

  @override
  String get eventReminders => 'Lembretes de eventos';

  @override
  String get onState => 'Ativado';

  @override
  String get taskReminders => 'Lembretes de tarefas';

  @override
  String get notificationDetailLevel => 'Nível de detalhe das notificações';

  @override
  String get notificationDetailPrivate => 'Privado';

  @override
  String get notificationDetailNormal => 'Predefinido';

  @override
  String get quietHours => 'Período de silêncio';

  @override
  String get quietHoursDescription =>
      'Pausar as notificações durante este período.';

  @override
  String get quietHoursStart => 'Início do período de silêncio';

  @override
  String get quietHoursEnd => 'Fim do período de silêncio';

  @override
  String get notifications => 'Notificações';

  @override
  String get windowsNotificationsUnavailable =>
      'As notificações do Windows não estão disponíveis';

  @override
  String get windowsNotificationsUnpackaged =>
      'Esta execução de desenvolvimento sem pacote não pode usar as notificações do Windows. Instale o MSIX assinado para teste para verificar os lembretes.';

  @override
  String get windowsNotificationsInstalledFailure =>
      'O BusyMax não conseguiu inicializar as notificações do Windows. Os lembretes não serão apresentados até este problema de instalação ser resolvido.';

  @override
  String get appearance => 'Aspeto';

  @override
  String get theme => 'Tema';

  @override
  String get themeSystem => 'Sistema';

  @override
  String get settingsSystem => 'Sistema';

  @override
  String get themeLight => 'Claro';

  @override
  String get themeDark => 'Escuro';

  @override
  String get themeFamily => 'Família de temas';

  @override
  String get themeFamilyYaru => 'Tema nativo do Ubuntu (Yaru)';

  @override
  String get localization => 'Localização';

  @override
  String get currentLocale => 'Configuração regional atual';

  @override
  String get privacy => 'Privacidade';

  @override
  String get redactTaskContentInDiagnostics =>
      'Ocultar o conteúdo das tarefas nos diagnósticos';

  @override
  String get developerDiagnostics => 'Diagnósticos de programador';

  @override
  String get diagnostics => 'Diagnósticos';

  @override
  String get apiInspectorDisabled => 'Mostrar inspetor da API';

  @override
  String get googleTasksApi => 'API do Google Tasks';

  @override
  String discoveryRevision(String revision) {
    return 'Revisão de descoberta: $revision';
  }

  @override
  String get implementedMethods => 'Métodos implementados';

  @override
  String get supportsTasksScopes =>
      'Suporta os âmbitos de autorização tasks e tasks.readonly';

  @override
  String get requiresTasksScope => 'Requer o âmbito de autorização tasks';

  @override
  String get blockedPendingOperations => 'Operações pendentes bloqueadas';

  @override
  String get signInToInspectPendingOperations =>
      'Inicie sessão para inspecionar as operações pendentes.';

  @override
  String get noBlockedPendingOperations =>
      'Não há operações pendentes bloqueadas.';

  @override
  String get operationActions => 'Ações da operação';

  @override
  String pendingOpListId(String id) {
    return 'lista=$id';
  }

  @override
  String pendingOpTaskId(String id) {
    return 'tarefa=$id';
  }

  @override
  String pendingOpAttempts(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    return 'tentativas=$countString';
  }

  @override
  String get retry => 'Tentar novamente';

  @override
  String get discard => 'Descartar';

  @override
  String get discardChangesAction => 'Descartar';

  @override
  String get discardChanges => 'Descartar alterações?';

  @override
  String get discardChangesConfirmation =>
      'Esta ação descarta as alterações não guardadas nesta tarefa.';

  @override
  String get retryCompleted => 'Nova tentativa concluída.';

  @override
  String get discardPendingOperation => 'Descartar operação pendente?';

  @override
  String get discardPendingOperationConfirmation =>
      'Esta ação remove a operação local bloqueada. Na próxima sincronização, os dados serão novamente carregados do Google Tasks.';

  @override
  String get pendingOperationDiscarded => 'Operação pendente descartada.';

  @override
  String get syncFailureNotificationTitle =>
      'Falha na sincronização do BusyMax';

  @override
  String syncFailureNotificationBody(String message) {
    return 'A sincronização em segundo plano falhou. $message';
  }

  @override
  String get conflictNotificationTitle =>
      'Conflito de sincronização do BusyMax';

  @override
  String conflictNotificationBody(String summary) {
    return 'Uma alteração local pendente foi bloqueada. $summary';
  }

  @override
  String get dueTodayNotificationTitle => 'Tarefas com prazo para hoje';

  @override
  String dueTodayNotificationBody(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Há $countString tarefas com prazo para hoje.',
      one: 'Há uma tarefa com prazo para hoje.',
    );
    return '$_temp0';
  }

  @override
  String get eventReminderNotificationTitle => 'Lembrete de evento';

  @override
  String get taskReminderNotificationTitle => 'Lembrete de tarefa';

  @override
  String get eventReminderNotificationBody => 'O evento começa em breve.';

  @override
  String get taskReminderNotificationBody => 'O prazo da tarefa aproxima-se.';

  @override
  String get notificationOpenAction => 'Abrir';

  @override
  String get notificationSnoozeAction => 'Adiar 10 minutos';

  @override
  String get notificationDismissAction => 'Fechar';

  @override
  String get notificationDetailsHidden =>
      'Os detalhes estão ocultos pelas definições de privacidade.';

  @override
  String get previousMonth => 'Mês anterior';

  @override
  String get nextMonth => 'Mês seguinte';

  @override
  String get openMonthView => 'Abrir vista mensal';

  @override
  String get previousYear => 'Ano anterior';

  @override
  String get nextYear => 'Ano seguinte';

  @override
  String get openYearView => 'Abrir vista anual';

  @override
  String weekNumberTooltip(int number) {
    final intl.NumberFormat numberNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String numberString = numberNumberFormat.format(number);

    return 'Semana $numberString';
  }

  @override
  String get resizeAllDayPanel => 'Redimensionar o painel de dia inteiro';

  @override
  String scheduleItemCount(int count) {
    final intl.NumberFormat countNumberFormat =
        intl.NumberFormat.decimalPattern(localeName);
    final String countString = countNumberFormat.format(count);

    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$countString itens',
      one: '1 item',
    );
    return '$_temp0';
  }

  @override
  String get readOnlyCalendar => 'Este calendário é só de leitura.';

  @override
  String get selectTimeZone => 'Selecionar fuso horário';

  @override
  String get searchLocations => 'Pesquisar locais';

  @override
  String get noLocationsFound => 'Não foram encontrados locais';

  @override
  String get requiredField => 'Este campo é obrigatório.';

  @override
  String get providerConnectionDescription =>
      'Ligue calendários e tarefas a um destes fornecedores.';

  @override
  String get appleICloudProvider => 'Calendário Apple iCloud';

  @override
  String get nextcloudProvider => 'Nextcloud';

  @override
  String get appleICloudTasksProvider => 'Apple iCloud';

  @override
  String get nextcloudTasksProvider => 'Tarefas do Nextcloud';

  @override
  String get addAppleICloudAccount =>
      'Adicionar conta do Calendário Apple iCloud';

  @override
  String get addNextcloudAccount => 'Adicionar conta Nextcloud';

  @override
  String get waitingForAppleICloud => 'A ligar ao Apple iCloud…';

  @override
  String get waitingForNextcloud => 'A aguardar autorização do Nextcloud…';

  @override
  String get connectAppleICloudTitle => 'Ligar o Calendário Apple iCloud';

  @override
  String get appleAccountEmail => 'E-mail da conta Apple';

  @override
  String get appleAppSpecificPassword =>
      'Palavra-passe específica da aplicação';

  @override
  String get appleAppSpecificPasswordHelp =>
      'Crie uma palavra-passe específica da aplicação depois de ativar a autenticação de dois fatores na sua conta Apple.';

  @override
  String get appleAppSpecificPasswordResetWarning =>
      'A reposição da palavra-passe da conta Apple revoga as palavras-passe específicas de aplicações.';

  @override
  String get connectNextcloudTitle => 'Ligar ao Nextcloud';

  @override
  String get nextcloudServerUrl => 'Servidor Nextcloud ou endereço CalDAV';

  @override
  String get nextcloudServerUrlHelp =>
      'Introduza o URL do servidor Nextcloud ou cole o endereço CalDAV principal copiado do Nextcloud.';

  @override
  String get nextcloudBrowserAuthorizationHelp =>
      'O BusyMax abrirá o navegador. Aprove o acesso aí e volte ao BusyMax.';

  @override
  String get connectAccountAction => 'Ligar';

  @override
  String get cancelAccountConnection => 'Cancelar ligação';

  @override
  String get nextcloudAccountRemovedRevokeFailed =>
      'A conta foi removida localmente, mas não foi possível revogar a palavra-passe da aplicação Nextcloud.';

  @override
  String get davReauthenticationRequired =>
      'Volte a ligar esta conta para retomar a sincronização.';

  @override
  String get davTemporarilyUnavailable =>
      'Esta conta está temporariamente indisponível.';

  @override
  String get davPermissionChanged =>
      'As permissões do servidor foram alteradas. As edições pendentes estão em pausa.';

  @override
  String get davUnsupportedServer =>
      'Este servidor ou perfil do fornecedor não é suportado.';

  @override
  String get collectionSettings => 'Calendários e listas de tarefas';

  @override
  String get calendarContent => 'Eventos do calendário';

  @override
  String get taskContent => 'Tarefas';

  @override
  String get readOnlySharedCollection => 'Só de leitura';

  @override
  String get pendingLocally => 'Pendente localmente';

  @override
  String get conflictBlocked => 'Bloqueado por conflito';

  @override
  String get authenticationBlocked => 'Bloqueado até voltar a ligar';

  @override
  String get operationFailed => 'Operação falhou';

  @override
  String get keepServerVersion => 'Manter versão do servidor';

  @override
  String get reapplyLocalChange => 'Rever e reaplicar alteração local';

  @override
  String get duplicateLocalItem => 'Duplicar como novo item';

  @override
  String get davConnectionState => 'Estado da ligação';

  @override
  String get davConnected => 'Ligado';

  @override
  String get davConnecting => 'A ligar…';

  @override
  String get davSignedOut => 'Sessão terminada';

  @override
  String davLastSuccessfulSync(String time) {
    return 'Última sincronização bem-sucedida: $time';
  }

  @override
  String get davNeverSynced => 'Ainda não sincronizado';

  @override
  String get refreshCollections => 'Atualizar calendários e listas de tarefas';

  @override
  String nextcloudServerHost(String host) {
    return 'Servidor: $host';
  }

  @override
  String get collectionSupportsEvents => 'Calendário de eventos';

  @override
  String get collectionSupportsTasks => 'Lista de tarefas';

  @override
  String get collectionSupportsEventsAndTasks => 'Eventos e tarefas';

  @override
  String get writableCollection => 'Editável';

  @override
  String get sharedCollection => 'Partilhado';

  @override
  String collectionLastSynced(String time) {
    return 'Última sincronização: $time';
  }

  @override
  String collectionSyncError(String code) {
    return 'Problema de sincronização: $code';
  }

  @override
  String get syncConflicts => 'Conflitos de sincronização';

  @override
  String remoteChangedAt(String time) {
    return 'Alteração no servidor: $time';
  }

  @override
  String localPendingEdit(String summary) {
    return 'Edição local: $summary';
  }

  @override
  String get conflictResolutionFailed =>
      'Não foi possível resolver o conflito.';

  @override
  String get recurringEventScope => 'Âmbito do evento recorrente';

  @override
  String get entireSeries => 'Série inteira';

  @override
  String get singleOccurrence => 'Este evento';

  @override
  String get thisAndFollowingEvents => 'Este evento e os seguintes';

  @override
  String get thisAndFutureUnavailable => 'Não suportado por este fornecedor.';

  @override
  String get thisAndFutureMoveUnavailable =>
      'Este evento e os seguintes não podem ser movidos com segurança. Escolha este evento ou a série inteira.';

  @override
  String get entireSeriesMoveUnavailable =>
      'A regra de recorrência não está disponível localmente. Mova apenas este evento.';

  @override
  String get copyEventAndDeleteOriginal =>
      'Copiar o evento e eliminar o original?';

  @override
  String copyEventMoveWarning(String source, String destination) {
    return 'O BusyMax não pode mover este evento diretamente de $source para $destination. Criará primeiro a cópia e eliminará o original apenas depois de a cópia ser criada com êxito. Os IDs do evento mudarão; os estados das respostas dos participantes poderão ser repostos e poderão ser enviados convites ou cancelamentos; as ligações de reuniões, os anexos, os lembretes, os campos específicos do fornecedor e as exceções de recorrência poderão não ser transferidos.';
  }

  @override
  String get copyAndDelete => 'Copiar e eliminar';

  @override
  String get chooseRecurringEventScope =>
      'Escolha se esta alteração se aplica à série inteira, apenas a este evento ou a este e aos eventos seguintes.';

  @override
  String get taskDueBeforeStart => 'O prazo não pode ser anterior ao início.';

  @override
  String get taskStartDueTimeModeMismatch =>
      'Defina horários para o início e o prazo, ou torne a tarefa de dia inteiro.';

  @override
  String deleteCalendarConfirmation(String title) {
    return 'Eliminar «$title»?';
  }

  @override
  String get setCustomCalendarName => 'Definir nome personalizado';

  @override
  String get setAction => 'Definir';

  @override
  String get removeFromMyCalendars => 'Remover dos meus calendários';

  @override
  String get removeAction => 'Remover';

  @override
  String removeOpenedSharedCalendarConfirmation(String title) {
    return 'Remover \"$title\" do BusyMax? O calendário e os eventos do proprietário não serão eliminados.';
  }

  @override
  String get attachmentUploadUnresolved =>
      'O carregamento pode ter sido concluído. Atualize os anexos para confirmar antes de carregar novamente.';

  @override
  String removeCalendarConfirmation(String title) {
    return 'Remover \"$title\" da sua lista do Google Calendar? O calendário partilhado e os respetivos eventos não serão eliminados.';
  }

  @override
  String get calendarCannotRemove =>
      'Não é possível eliminar nem remover este calendário desta conta.';

  @override
  String get calendarPendingChangesPreventRemoval =>
      'Aguarde que as alterações pendentes deste calendário terminem de sincronizar antes de o eliminar ou remover.';

  @override
  String get calendarSubscriptions => 'Subscrições de calendários';

  @override
  String get calendarSubscriptionsDescription =>
      'Adicione calendários só de leitura que sejam atualizados a partir de um URL WebCal seguro.';

  @override
  String get addCalendarSubscription => 'Adicionar subscrição de calendário';

  @override
  String get subscriptionName => 'Nome local';

  @override
  String get subscriptionUrl => 'URL da subscrição';

  @override
  String get subscriptionUrlHelp =>
      'Introduza um URL HTTPS ou webcal. O BusyMax mantém o URL completo num armazenamento seguro.';

  @override
  String get subscriptionUrlInvalid =>
      'Introduza um URL HTTPS ou webcal válido sem informações de utilizador ou fragmento.';

  @override
  String get subscriptionColor => 'Cor local';

  @override
  String get subscriptionColorHelp =>
      'Utilize uma cor de seis dígitos, como #3584E4.';

  @override
  String get subscriptionColorInvalid =>
      'Introduza uma cor hexadecimal de seis dígitos.';

  @override
  String get subscriptionRefreshMode => 'Frequência de atualização';

  @override
  String get subscriptionAutomatic => 'Automática';

  @override
  String get subscriptionHourly => 'De hora a hora';

  @override
  String get subscriptionSixHours => 'A cada seis horas';

  @override
  String get subscriptionDaily => 'Diária';

  @override
  String subscriptionSafeOrigin(String origin) {
    return 'Origem: $origin';
  }

  @override
  String get subscriptionSafeOriginUnavailable =>
      'Introduza um URL válido para pré-visualizar a origem segura.';

  @override
  String get subscriptionReadOnly => 'Subscrição só de leitura';

  @override
  String get subscriptionNeverRefreshed => 'Ainda não atualizada';

  @override
  String subscriptionLastRefresh(String time) {
    return 'Última atualização bem-sucedida: $time';
  }

  @override
  String subscriptionNextRefresh(String time) {
    return 'Próxima atualização: $time';
  }

  @override
  String get subscriptionStatusHealthy => 'Atualizada';

  @override
  String subscriptionStatusIssue(String code) {
    return 'Problema de atualização: $code';
  }

  @override
  String get refreshNow => 'Atualizar agora';

  @override
  String get unsubscribe => 'Cancelar subscrição';

  @override
  String unsubscribeCalendarTitle(String name) {
    return 'Cancelar subscrição de “$name”?';
  }

  @override
  String get unsubscribeCalendarConfirmation =>
      'Isto remove a subscrição local e os eventos colocados em cache. O calendário publicado não é alterado.';

  @override
  String get addSubscriptionAction => 'Adicionar subscrição';

  @override
  String subscriptionOperationFailed(String error) {
    return 'Falha na subscrição do calendário: $error';
  }

  @override
  String get subscriptions => 'Subscrições';

  @override
  String get calendarImport => 'Importação de calendário';

  @override
  String get calendarImportDescription =>
      'Selecione um ficheiro, reveja os eventos e escolha o calendário editável que os deve receber.';

  @override
  String get importIcsFile => 'Importar ficheiro .ics';

  @override
  String get importIcsPreview => 'Importar eventos do calendário';

  @override
  String importEventsFound(int count) {
    return 'Conjuntos de eventos importáveis: $count';
  }

  @override
  String importInvalidEvents(int count) {
    return 'Eventos inválidos: $count';
  }

  @override
  String importFieldsOmitted(String fields) {
    return 'Omitidos intencionalmente: $fields';
  }

  @override
  String get noWritableCalendars =>
      'Não está disponível nenhum calendário de destino editável.';

  @override
  String get importDestinationCalendar => 'Calendário de destino';

  @override
  String get importIcsConfirm => 'Importar eventos';

  @override
  String get importIcsComplete => 'Importação concluída';

  @override
  String importQueued(int count) {
    return 'Importados ou em fila: $count';
  }

  @override
  String importDuplicatesSkipped(int count) {
    return 'Duplicados ignorados: $count';
  }

  @override
  String importUnsupportedSets(int count) {
    return 'Conjuntos de recorrência não suportados: $count';
  }

  @override
  String importIcsFailed(String error) {
    return 'Não foi possível importar o ficheiro de calendário: $error';
  }

  @override
  String get networkOffline => 'Sem ligação';

  @override
  String get networkOfflineDescription =>
      'As alterações serão sincronizadas quando a ligação for restabelecida.';

  @override
  String get networkOfflineTryAgain =>
      'Está offline. Ligue-se à Internet e tente novamente.';

  @override
  String repeatOnMonthDaysSummaryMultiple(String days) {
    return 'nos dias $days';
  }

  @override
  String get repeatSummarySeparator => ' ';

  @override
  String repeatMonthDayValue(String day) {
    return '$day';
  }

  @override
  String repeatWeekdayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatWeekdayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatMonthDayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthValue(String month, String monthKey) {
    String _temp0 = intl.Intl.selectLogic(monthKey, {'other': '$month'});
    return '$_temp0';
  }

  @override
  String repeatYearlyMonthDayListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatYearlyMonthDayListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyMonthListPair(String first, String second) {
    return '$first e $second';
  }

  @override
  String repeatYearlyMonthListStart(String first, String rest) {
    return '$first, $rest';
  }

  @override
  String repeatYearlyOnMonthDaySummary(
    String frequency,
    String month,
    String day,
  ) {
    return '$frequency no dia $day de $month';
  }

  @override
  String repeatYearlyOnMonthDaysSummary(
    String frequency,
    String month,
    String days,
  ) {
    return '$frequency nos dias $days de $month';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaySummary(
    String frequency,
    String months,
    String day,
  ) {
    return '$frequency no dia $day de $months';
  }

  @override
  String repeatYearlyInMonthsOnMonthDaysSummary(
    String frequency,
    String months,
    String days,
  ) {
    return '$frequency nos dias $days de $months';
  }

  @override
  String repeatYearlyOnOrdinalSummary(
    String frequency,
    String month,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'na primeira ocorrência de $days de $month',
      'second': 'na segunda ocorrência de $days de $month',
      'third': 'na terceira ocorrência de $days de $month',
      'fourth': 'na quarta ocorrência de $days de $month',
      'fifth': 'na quinta ocorrência de $days de $month',
      'secondToLast': 'na penúltima ocorrência de $days de $month',
      'last': 'na última ocorrência de $days de $month',
      'other': 'em $days de $month',
    });
    return '$frequency $_temp0';
  }

  @override
  String repeatYearlyInMonthsOnOrdinalSummary(
    String frequency,
    String months,
    String position,
    String days,
  ) {
    String _temp0 = intl.Intl.selectLogic(position, {
      'first': 'na primeira ocorrência de $days de $months',
      'second': 'na segunda ocorrência de $days de $months',
      'third': 'na terceira ocorrência de $days de $months',
      'fourth': 'na quarta ocorrência de $days de $months',
      'fifth': 'na quinta ocorrência de $days de $months',
      'secondToLast': 'na penúltima ocorrência de $days de $months',
      'last': 'na última ocorrência de $days de $months',
      'other': 'em $days de $months',
    });
    return '$frequency $_temp0';
  }

  @override
  String get searchFilters => 'Filtros de pesquisa';

  @override
  String get searchType => 'Tipo';

  @override
  String get searchDate => 'Data';

  @override
  String get searchAnyDate => 'Qualquer data (dados transferidos)';

  @override
  String get eventLink => 'Ligação do evento';

  @override
  String get eventLinkOpenFailed => 'Não foi possível abrir a ligação.';

  @override
  String get scheduleRangeIncomplete =>
      'Não foi possível verificar alguns eventos. São apresentados os dados transferidos.';

  @override
  String get searchThisWeek => 'Esta semana';

  @override
  String get searchCustomRange => 'Intervalo personalizado';

  @override
  String get searchTaskStatus => 'Estado das tarefas';

  @override
  String get searchTaskDue => 'Prazo das tarefas';

  @override
  String get searchAnyDueState => 'Qualquer prazo';

  @override
  String get searchNoDueDate => 'Sem data de conclusão';

  @override
  String get searchPerson => 'Pessoa';

  @override
  String get searchSources => 'Origens';

  @override
  String get searchClearFilters => 'Repor filtros';

  @override
  String get searchFiltersAction => 'Filtros';

  @override
  String get searchNoSources => 'Nenhuma origem de pesquisa selecionada';

  @override
  String get searchClearText => 'Limpar texto';

  @override
  String get openSharedCalendar => 'Abrir calendário partilhado';

  @override
  String get manageCalendarSharing => 'Gerir partilha do calendário';

  @override
  String get shareRecipientEmail => 'E-mail do destinatário';

  @override
  String get shareRole => 'Papel de acesso';

  @override
  String get addCalendarShare => 'Adicionar acesso';

  @override
  String get sharingRefreshFailed =>
      'A partilha foi alterada, mas a lista de permissões não foi atualizada. Recarregue-a antes de fazer outra alteração.';

  @override
  String get sharingRateLimited =>
      'A partilha está temporariamente limitada. Volte a tentar quando terminar o tempo de espera.';

  @override
  String get attachmentUploadRateLimited =>
      'O carregamento de anexos está temporariamente limitado. Volte a tentar quando terminar o tempo de espera.';

  @override
  String get sharingPermissionUnavailable =>
      'As permissões de partilha não estão disponíveis para este calendário.';

  @override
  String get calendarShareFreeBusy => 'Apenas livre/ocupado';

  @override
  String get calendarShareLimitedRead => 'Ler detalhes limitados';

  @override
  String get calendarShareRead => 'Ler todos os detalhes';

  @override
  String get calendarShareWrite => 'Editar eventos';

  @override
  String get calendarShareWriteWithoutPrivate => 'Editar sem detalhes privados';

  @override
  String get calendarShareOwner => 'Proprietário';

  @override
  String get eventLabel => 'Etiqueta do evento';

  @override
  String get loadOutlookCategories => 'Carregar categorias do Outlook';

  @override
  String get outlookCategoriesUnavailable =>
      'As categorias do Outlook não estão disponíveis; as atribuições existentes são mantidas.';

  @override
  String get googleEventType => 'Tipo de evento';

  @override
  String get googleRegularEvent => 'Evento normal';

  @override
  String get googleFocusTime => 'Tempo de concentração';

  @override
  String get googleOutOfOffice => 'Fora do escritório';

  @override
  String get googleWorkingLocation => 'Local de trabalho';

  @override
  String get googleDeclineInvitations => 'Recusar convites sobrepostos';

  @override
  String get googleDeclineNone => 'Não recusar';

  @override
  String get googleDeclineNew => 'Recusar novos convites';

  @override
  String get googleDeclineAll => 'Recusar todos os convites em conflito';

  @override
  String get googleDeclineMessage => 'Mensagem de recusa';

  @override
  String get googleChatStatus => 'Estado da conversa';

  @override
  String get googleChatAvailable => 'Disponível';

  @override
  String get googleChatDoNotDisturb => 'Não incomodar';

  @override
  String get googleWorkAtHome => 'Casa';

  @override
  String get googleWorkAtOffice => 'Escritório';

  @override
  String get googleWorkAtCustomLocation => 'Local personalizado';

  @override
  String get googleWorkLocationLabel => 'Nome do local';

  @override
  String get googleStatusPrimaryOnly =>
      'Os eventos de estado do Google exigem o calendário principal do Google.';

  @override
  String unknownEventLabel(String id) {
    return 'Etiqueta desconhecida ($id)';
  }

  @override
  String get calendarOwnerEmail => 'E-mail do proprietário do calendário';

  @override
  String registrationSetupTitle(String provider) {
    return 'Configurar $provider';
  }

  @override
  String get registrationSetupGuide => 'Guia de configuração';

  @override
  String get registrationGoogleInstructions =>
      'Crie o o seu próprio projeto Google Cloud, ative Calendar e Tasks e importe o JSON de um cliente OAuth para computador. Autorize a conta desejada.';

  @override
  String get registrationMicrosoftInstructions =>
      'Use um registro de aplicativo público em um locatário Entra que permita registros. Informe o ID do cliente e os tipos de conta. Não é necessário segredo de cliente.';

  @override
  String get registrationImportGoogle =>
      'Selecionar JSON OAuth para computador';

  @override
  String get registrationValidate => 'Validar registro';

  @override
  String get registrationAuthorize => 'Autorizar no navegador';

  @override
  String get registrationClientId => 'ID do aplicativo/cliente';

  @override
  String get registrationTenantId => 'ID do locatário';

  @override
  String get registrationAudience => 'Contas compatíveis';

  @override
  String get registrationBothAudience => 'Contas pessoais e organizacionais';

  @override
  String get registrationOrganizationAudience => 'Contas organizacionais';

  @override
  String get registrationPersonalAudience => 'Contas pessoais';

  @override
  String get registrationTenantAudience => 'Um locatário organizacional';

  @override
  String registrationSummary(String clientId) {
    return 'Registro: $clientId';
  }

  @override
  String get registrationMigrate => 'Migrar agora';

  @override
  String get registrationReplace => 'Substituir registro';

  @override
  String registrationRetirementNotice(String provider, String setup) {
    return 'Esta conta usa um registo original de $provider reservado às contas existentes. Para o substituir, configure $setup e volte a ligar esta conta. Os calendários, tarefas e alterações locais serão preservados.';
  }

  @override
  String get registrationContinue => 'Continuar usando esta conta';

  @override
  String get registrationGoogleProject => 'Projeto do Google Cloud';

  @override
  String get registrationMicrosoftApp => 'Registro de aplicativo Microsoft';

  @override
  String get registrationUserOwned => 'Registro fornecido pelo usuário';

  @override
  String get registrationNativeGoogle =>
      'Registro nativo do Google para Android';

  @override
  String get registrationShared => 'Registro compartilhado (transição)';

  @override
  String get registrationUnresolved =>
      'A origem do registro não foi identificada. Os dados da conta são preservados.';

  @override
  String get registrationOfficialDocumentation => 'Documentação oficial';

  @override
  String registrationAndroidIdentity(
    String packageName,
    String signatureHash,
    String redirectUri,
  ) {
    return 'Pacote: $packageName\nHash da assinatura: $signatureHash\nURI de redirecionamento: $redirectUri';
  }

  @override
  String get oauthRegistrationRejected =>
      'Verifique o tipo de cliente, as contas suportadas, as permissões e o redirecionamento do registo. Selecione novamente a configuração importada.';

  @override
  String get oauthAuthorizationCodeUnusable =>
      'Não foi possível concluir esta autorização. Inicie novamente; a ligação existente é preservada.';

  @override
  String get oauthPermissionRefused =>
      'A autorização foi recusada ou faltam permissões necessárias. Tente novamente e conceda as permissões exigidas.';

  @override
  String get oauthProviderThrottled =>
      'O fornecedor está a limitar pedidos. Aguarde antes de tentar novamente; a ligação existente é preservada.';

  @override
  String get oauthProviderTemporaryFailure =>
      'Um problema temporário do fornecedor impediu a autorização. Tente novamente; a ligação existente é preservada.';

  @override
  String get oauthAuthorizationTimedOut =>
      'O tempo de autorização expirou. Tente novamente e selecione uma nova configuração, se foi importada.';

  @override
  String get oauthWrongAccount =>
      'Autorize a conta selecionada para voltar a ligar. A ligação existente é preservada.';

  @override
  String get oauthSecureStorageUnavailable =>
      'O armazenamento seguro está indisponível. Restabeleça o acesso e tente novamente.';

  @override
  String get oauthRevokedRemovalIncomplete =>
      'A autorização remota foi revogada, mas a limpeza da conta não pôde ser concluída. Reinicie o BusyMax para tentar novamente a recuperação local.';

  @override
  String get addAccount => 'Adicionar conta';

  @override
  String get registrationConnect => 'Ligar';

  @override
  String get registrationBack => 'Voltar';

  @override
  String get registrationReplaceGoogle => 'Substituir JSON OAuth de computador';

  @override
  String get registrationSelectedConfiguration => 'Configuração selecionada';

  @override
  String get registrationDirectoryId => 'ID do diretório/inquilino';

  @override
  String get registrationInvalidId => 'Introduza um UUID válido.';

  @override
  String get registrationExpired =>
      'Esta configuração expirou. Importe-a novamente ou edite os campos antes de ligar.';

  @override
  String get registrationOwnProjectRequired =>
      'Escolha um registo do seu próprio projeto ou inquilino.';

  @override
  String get registrationSetupFailed =>
      'Não foi possível concluir a configuração. Tente novamente.';

  @override
  String get registrationLinkFailed =>
      'Não foi possível abrir a ligação. Verifique o navegador e tente novamente.';

  @override
  String get registrationPermissions => 'Permissões';

  @override
  String get registrationDesktopClient => 'Aplicação de computador';

  @override
  String get registrationOpenGoogleConsole => 'Abrir a Google Cloud Console';

  @override
  String get registrationGoogleAudienceHelp =>
      'Requisitos Google de publicação e utilizadores de teste';

  @override
  String get registrationDesktopHelp =>
      'Instruções de registo de aplicações de computador';

  @override
  String get registrationOpenEntra =>
      'Abrir o centro de administração do Microsoft Entra';

  @override
  String get registrationGuideGoogleProject =>
      'Abra a Google Cloud Console. Use o seletor de projetos no topo para selecionar o seu projeto, ou escolha New project, introduza um nome e selecione Create. Mantenha esse projeto selecionado nos passos seguintes.';

  @override
  String get registrationGuideGoogleAudience =>
      'Aceda a Google Auth Platform → Branding. Se a configuração ainda não começou, selecione Get started. Introduza BusyMax em App name, escolha o seu User support email e selecione Next. Em Audience, escolha External. Selecione Next, introduza o seu email em Contact Information e selecione Next. Aceite User Data Policy e selecione Continue e Create. Se já estiver configurado, reveja Branding e Audience.';

  @override
  String get registrationGuideGooglePermissions =>
      'Abra Google Auth Platform → Data Access → Add or remove scopes. Selecione os cinco âmbitos abaixo; use Manually add scopes se necessário. Para a introdução manual, cole os valores em falta e selecione Add to table. Selecione Update e depois Save. O BusyMax precisa de acesso ao calendário e às tarefas.';

  @override
  String get registrationGuideGoogleClient =>
      'Abra Google Auth Platform → Clients → Create client. Defina Application type como Desktop app, introduza BusyMax em Name e selecione Create. Na janela de criação, selecione Download JSON e guarde o ficheiro. Selecione Voltar para voltar ao formulário, escolha esse ficheiro e reveja o projeto e o ID de cliente. Selecione Ligar e autorize o acesso ao calendário e às tarefas no navegador.';

  @override
  String get registrationGuideMicrosoftApp =>
      'Inicie sessão no centro de administração Microsoft Entra. Use Settings para escolher um inquilino onde possa registar aplicações. Abra Entra ID → App registrations → New registration. Introduza BusyMax em Name e escolha os tipos de conta no passo seguinte. Se o registo estiver bloqueado, peça acesso ao administrador do inquilino.';

  @override
  String get registrationGuideMicrosoftRedirect =>
      'No registo, abra Authentication → Add a platform → Mobile and desktop applications. Selecione ou introduza o URI de redirecionamento abaixo e selecione Configure para o guardar. O BusyMax usa o navegador do sistema. Não é necessário um segredo de cliente.';

  @override
  String get registrationGuideMicrosoftPermissions =>
      'Abra API permissions → Add a permission → Microsoft Graph → Delegated permissions. Procure e selecione cada âmbito abaixo e selecione Add permissions. Mantenha User.Read se já existir. Se a organização exigir consentimento administrativo, peça a um administrador que use Grant admin consent para o inquilino.';

  @override
  String get registrationGuideMicrosoftConnect =>
      'Selecione Voltar para voltar ao formulário. Cole Application (client) ID e escolha as mesmas Contas suportadas do registo. Para Um inquilino organizacional, cole também Directory (tenant) ID. Selecione Ligar e inicie sessão na conta pretendida no navegador. O BusyMax verifica os campos localmente; a Microsoft pede o seu consentimento durante o início de sessão no navegador.';

  @override
  String get registrationGoogleImportFailed =>
      'Não foi possível importar este ficheiro. Selecione um JSON OAuth de computador válido. Qualquer seleção válida anterior é mantida.';

  @override
  String get registrationGoogleSetupInstructions =>
      'Instruções de configuração do Google';

  @override
  String get registrationMicrosoftSetupInstructions =>
      'Instruções de configuração da Microsoft';

  @override
  String get registrationDesktopConfiguration =>
      'Configuração OAuth para computador';

  @override
  String get registrationNoFileSelected => 'Nenhum ficheiro selecionado';

  @override
  String get registrationChooseFile => 'Escolher ficheiro…';

  @override
  String get registrationReplaceFile => 'Substituir…';

  @override
  String get registrationGoogleIntroduction =>
      'Escolha o JSON OAuth para computador do seu próprio projeto Google Cloud.';

  @override
  String get registrationMicrosoftIntroduction =>
      'Introduza os dados do seu próprio registo de aplicação Microsoft.';

  @override
  String get registrationSetupInstructions => 'Instruções de configuração';

  @override
  String get registrationInstructionsDescription =>
      'Crie a configuração necessária para ligar a sua conta.';

  @override
  String get registrationEnableApis => 'Ativar Calendar e Tasks';

  @override
  String get registrationConsentScreen => 'Configurar o ecrã de consentimento';

  @override
  String get registrationAppName => 'Nome da aplicação';

  @override
  String get registrationScopes => 'Âmbitos';

  @override
  String get registrationRedirectUri => 'URI de redirecionamento';

  @override
  String get registrationOpenApiLibrary =>
      'Abrir a biblioteca de API da Google';

  @override
  String get registrationOpenBranding =>
      'Abrir Branding na Google Auth Platform';

  @override
  String get registrationOpenDataAccess =>
      'Abrir Data Access na Google Auth Platform';

  @override
  String get registrationOpenClients => 'Abrir Clients na Google Auth Platform';

  @override
  String get registrationOpenEntraAuthentication =>
      'Abrir registos Entra para Authentication';

  @override
  String get registrationOpenEntraPermissions =>
      'Abrir registos Entra para API permissions';

  @override
  String get registrationCopy => 'Copiar';

  @override
  String get registrationCopyAll => 'Copiar tudo';

  @override
  String get registrationGuideGoogleApis =>
      'Aceda a APIs & Services → Library. Procure Google Calendar API, abra a página e selecione Enable. Volte a Library e repita para Google Tasks API.';

  @override
  String get registrationGuideMicrosoftAudience =>
      'Em Supported account types, escolha Personal accounts only para uma conta pessoal, Multiple Entra ID tenants para contas organizacionais, Any Entra ID Tenant + Personal Microsoft accounts para ambas, ou Single tenant only para este diretório. Selecione Register. Em Overview, copie Application (client) ID; para um só inquilino, copie também Directory (tenant) ID. Use a opção correspondente de Contas suportadas no BusyMax.';

  @override
  String get registrationConnectBusyMax => 'Ligar com BusyMax';

  @override
  String get registrationRecommended => 'Recomendado';

  @override
  String get registrationOtherMethods => 'Outros métodos de ligação';

  @override
  String get registrationWorkspace => 'Organização Google Workspace';

  @override
  String get registrationGoogleCustom => 'Cliente OAuth personalizado';

  @override
  String get registrationMicrosoftCustom =>
      'Registo de aplicação personalizado';

  @override
  String get registrationMethodsIntroduction =>
      'Escolha como ligar a sua conta.';

  @override
  String get registrationWorkspaceDescription =>
      'Use uma configuração gerida pela sua organização.';

  @override
  String get registrationCustomDescription => 'Use um registo que gere.';

  @override
  String get registrationSharedUnavailable =>
      'A ligação com BusyMax não está disponível nesta compilação. Pode usar outro método de ligação abaixo.';

  @override
  String get registrationWorkspaceIntroduction =>
      'Escolha o JSON de OAuth para computador fornecido ou gerido pela sua organização. O ficheiro não comprova a propriedade da organização, o público ou a verificação.';

  @override
  String get registrationWorkspaceSetupInstructions =>
      'Instruções de configuração do Google Workspace';

  @override
  String get registrationBusyMaxManaged => 'Registo gerido pelo BusyMax';

  @override
  String get registrationBranding => 'Configurar marca e domínios';

  @override
  String get registrationPublishing => 'Publicar para utilização normal';

  @override
  String get registrationOpenAudience =>
      'Abrir Audience do Google Auth Platform';

  @override
  String get registrationGuideWorkspaceProject =>
      'Peça o JSON OAuth para computador ao administrador ou abra a Google Cloud Console e selecione um projeto da sua organização Google Workspace. Para o criar, abra Gerir recursos → Criar projeto, introduza o Nome do projeto, escolha a organização ou uma das suas pastas em Recurso superior e selecione Criar. Selecione esse projeto para os passos seguintes. A criação requer Project Creator, a configuração OAuth requer OAuth Config Editor e a ativação de APIs requer Service Usage Admin ou permissões equivalentes. Se houver um bloqueio, contacte o administrador.';

  @override
  String get registrationGuideGoogleBranding =>
      'Em Branding → App domain, adicione os domínios autorizados do projeto antes dos URL da página inicial, privacidade e termos de serviço, e selecione Save. As aplicações External em produção precisam destas ligações. Use domínios seus e confirme a propriedade em Search Console quando a Google exigir verificação da marca. A ligação de privacidade do BusyMax não comprova que o seu projeto é proprietário de busystack.org.';

  @override
  String get registrationGuideGooglePublishing =>
      'Em Audience, selecione Publish app e confirme In production. Não mantenha a utilização normal em Testing: estas autorizações Calendar/Tasks e tokens de atualização expiram após sete dias. Publicação e verificação são processos separados. O uso pessoal com menos de 100 utilizadores pode estar isento de verificação, com avisos e um limite de utilizadores; uma distribuição maior pode exigir aprovação da marca e dos âmbitos. As autorizações de produção podem ainda expirar ou ser revogadas.';

  @override
  String get registrationGuideWorkspacePermissions =>
      'Reveja estes âmbitos com o administrador. As aplicações Internal não precisam de os listar no ecrã de consentimento. Se solicitado, abra Data Access → Add or remove scopes, adicione os valores, depois Update e Save. Os controlos administrativos podem restringir a autorização.';

  @override
  String get registrationGuideMicrosoftOptionalPermissions =>
      'As permissões de calendários partilhados e categorias são pedidas separadamente ao ativar essas funções opcionais; não as adicione à configuração obrigatória acima.';

  @override
  String get registrationGuideWorkspaceAudience =>
      'Aceda a Google Auth Platform → Branding. Se a configuração ainda não começou, selecione Get started. Introduza BusyMax em App name, escolha o seu User support email e selecione Next. Em Audience, escolha Internal. Selecione Next, introduza o seu email em Contact Information e selecione Next. Aceite User Data Policy e selecione Continue e Create. Se já estiver configurado, reveja Branding e Audience.\n\nInternal permite apenas contas da organização principal do projeto, sujeitas aos controlos administrativos. Não é necessária uma lista de utilizadores de teste. O BusyMax não verifica estas definições a partir do JSON.';

  @override
  String get contactsTitle => 'Contactos';

  @override
  String get contactsLinkedDescription =>
      'Utilize os contactos em cache desta conta ao adicionar convidados a eventos.';

  @override
  String get contactsEnableSuggestions => 'Ativar sugestões de contactos';

  @override
  String get contactsReadPermissionDescription =>
      'Pede acesso só de leitura aos contactos';

  @override
  String get contactsEnableEditing => 'Ativar edição de contactos';

  @override
  String get contactsWritePermissionDescription =>
      'Pede acesso de leitura e escrita aos contactos';

  @override
  String get contactsSuggestionsEnabled => 'Sugestões de contactos ativadas';

  @override
  String get contactsNeedsAttention => 'Os contactos precisam de atenção';

  @override
  String get contactsReadWriteAccess => 'Acesso de leitura e escrita';

  @override
  String get contactsDisableForAccount => 'Desativar contactos para esta conta';

  @override
  String get contactsOnlyDescription =>
      'Estas fontes são independentes das contas de calendário e tarefas.';

  @override
  String get contactsAddCardDav => 'Adicionar contactos CardDAV';

  @override
  String get contactsAddNextcloud => 'Adicionar contactos Nextcloud';

  @override
  String get contactsUseForAttendees =>
      'Utilizar para sugestões de participantes';

  @override
  String get contactsServerUrlLabel => 'URL do servidor HTTPS';

  @override
  String get contactsUsernameLabel => 'Nome de utilizador';

  @override
  String get contactsPasswordLabel => 'Palavra-passe';
}
