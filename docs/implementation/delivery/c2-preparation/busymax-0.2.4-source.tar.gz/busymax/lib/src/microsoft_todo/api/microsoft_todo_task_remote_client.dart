import '../../features/tasks/domain/task_remote_client.dart';
import '../../features/tasks/domain/task_remote_error.dart';
import '../../features/tasks/domain/task_remote_models.dart';
import 'microsoft_todo_api_client.dart';
import 'microsoft_todo_api_error.dart';
import 'microsoft_todo_api_models.dart';

class MicrosoftTodoTaskRemoteClient
    implements
        TaskRemoteClient,
        TaskChecklistRemoteClient,
        TaskConflictSnapshotNormalizer,
        RevisionlessTaskListConflictClient {
  MicrosoftTodoTaskRemoteClient({
    required MicrosoftTodoApiClient client,
    required String defaultTimeZone,
    DateTime Function()? nowUtc,
  }) : _client = client,
       _defaultTimeZone = defaultTimeZone,
       _nowUtc = nowUtc ?? (() => DateTime.now().toUtc());

  final MicrosoftTodoApiClient _client;
  final String _defaultTimeZone;
  final DateTime Function() _nowUtc;

  @override
  Map<String, Object?> normalizeTaskConflictSnapshot(
    Map<String, Object?> snapshot,
  ) {
    final normalized = Map<String, Object?>.from(snapshot);
    if (!normalized.containsKey('notes') && snapshot.containsKey('body')) {
      final body = snapshot['body'];
      final content = body is Map ? body['content']?.toString() ?? '' : '';
      final contentType = body is Map ? body['contentType']?.toString() : null;
      normalized['notes'] = _microsoftBodyToPlainText(content, contentType);
    }
    _putMicrosoftDateTimeAliases(
      normalized,
      snapshot,
      graphField: 'dueDateTime',
      dateTimeField: 'microsoftDueDateTime',
      timeZoneField: 'microsoftDueTimeZone',
    );
    if (!normalized.containsKey('due') && snapshot.containsKey('dueDateTime')) {
      final dueDateTime = _dateTimePart(snapshot['dueDateTime']);
      normalized['due'] = dueDateTime == null || dueDateTime.length < 10
          ? dueDateTime
          : dueDateTime.substring(0, 10);
    }
    _putMicrosoftDateTimeAliases(
      normalized,
      snapshot,
      graphField: 'startDateTime',
      dateTimeField: 'microsoftStartDateTime',
      timeZoneField: 'microsoftStartTimeZone',
    );
    _putMicrosoftDateTimeAliases(
      normalized,
      snapshot,
      graphField: 'reminderDateTime',
      dateTimeField: 'microsoftReminderDateTime',
      timeZoneField: 'microsoftReminderTimeZone',
    );
    _putMicrosoftDateTimeAliases(
      normalized,
      snapshot,
      graphField: 'completedDateTime',
      dateTimeField: 'microsoftCompletedDateTime',
      timeZoneField: 'microsoftCompletedTimeZone',
    );
    if (!normalized.containsKey('microsoftIsReminderOn') &&
        snapshot.containsKey('isReminderOn')) {
      normalized['microsoftIsReminderOn'] = snapshot['isReminderOn'];
    }
    return normalized;
  }

  @override
  Map<String, Object?> normalizeTaskListConflictSnapshot(
    Map<String, Object?> snapshot,
  ) {
    final normalized = Map<String, Object?>.from(snapshot);
    if (!normalized.containsKey('title') &&
        snapshot.containsKey('displayName')) {
      normalized['title'] = snapshot['displayName'];
    }
    return normalized;
  }

  @override
  Future<TaskListDto> createTaskList({required String title}) async {
    final dto = await _translateMicrosoftErrors(
      () => _client.createTaskList(displayName: title),
    );
    return _taskListDto(dto);
  }

  @override
  Future<void> deleteTaskList(String taskListId) {
    return _translateMicrosoftErrors(() => _client.deleteTaskList(taskListId));
  }

  @override
  Future<TaskListDto> getTaskList(String taskListId) async {
    var nextLink = null as String?;
    do {
      final page = await _translateMicrosoftErrors(
        () => _client.listTaskListsPage(nextLink: nextLink),
      );
      for (final item in page.items) {
        if (item.id == taskListId) {
          return _taskListDto(item);
        }
      }
      nextLink = page.nextLink;
    } while (nextLink != null && nextLink.isNotEmpty);

    throw const TaskRemoteError(
      statusCode: 404,
      code: 'not_found',
      message: 'Microsoft To Do task list was not found.',
    );
  }

  @override
  Future<TaskListsPageDto> listTaskListsPage({
    int maxResults = 1000,
    String? pageToken,
  }) async {
    final page = await _translateMicrosoftErrors(
      () => _client.listTaskListsPage(nextLink: pageToken),
    );
    return TaskListsPageDto(
      items: page.items.map(_taskListDto).toList(),
      nextPageToken: page.nextLink,
      rawJson: page.rawJson,
    );
  }

  @override
  Future<TaskListDto> patchTaskList(String taskListId, TaskListPatch patch) {
    return _updateTaskList(taskListId, patch.fields);
  }

  @override
  Future<TaskListDto> updateTaskList(
    String taskListId,
    TaskListPut replacement,
  ) {
    return _updateTaskList(taskListId, replacement.fields);
  }

  Future<TaskListDto> _updateTaskList(
    String taskListId,
    Map<String, Object?> fields,
  ) async {
    final dto = await _translateMicrosoftErrors(
      () => _client.updateTaskList(
        taskListId: taskListId,
        patch: {
          if (fields.containsKey('title')) 'displayName': fields['title'],
          if (fields.containsKey('displayName'))
            'displayName': fields['displayName'],
        },
      ),
    );
    return _taskListDto(dto);
  }

  @override
  Future<void> clearCompletedTasks(String taskListId) {
    throw const TaskRemoteError(
      statusCode: 400,
      code: 'unsupported_provider_operation',
      message: 'Clear completed is not supported for Microsoft To Do accounts.',
    );
  }

  @override
  Future<TaskChecklistItemsPageDto> listChecklistItemsPage({
    required String taskListId,
    required String taskId,
    String? pageToken,
  }) async {
    final page = await _translateMicrosoftErrors(
      () => _checklistClient.listChecklistItemsPage(
        taskListId: taskListId,
        taskId: taskId,
        nextLink: pageToken,
      ),
    );
    return TaskChecklistItemsPageDto(
      items: page.items.map(_checklistItemDto).toList(),
      nextPageToken: page.nextLink,
      rawJson: page.rawJson,
    );
  }

  @override
  Future<TaskChecklistItemDto> createChecklistItem({
    required String taskListId,
    required String taskId,
    required String title,
    bool completed = false,
  }) async {
    final item = await _translateMicrosoftErrors(
      () => _checklistClient.createChecklistItem(
        taskListId: taskListId,
        taskId: taskId,
        body: {'displayName': title, 'isChecked': completed},
      ),
    );
    return _checklistItemDto(item);
  }

  @override
  Future<TaskChecklistItemDto> updateChecklistItem({
    required String taskListId,
    required String taskId,
    required String checklistItemId,
    String? title,
    bool? completed,
  }) async {
    final item = await _translateMicrosoftErrors(
      () => _checklistClient.updateChecklistItem(
        taskListId: taskListId,
        taskId: taskId,
        checklistItemId: checklistItemId,
        patch: {'displayName': ?title, 'isChecked': ?completed},
      ),
    );
    return _checklistItemDto(item);
  }

  @override
  Future<void> deleteChecklistItem({
    required String taskListId,
    required String taskId,
    required String checklistItemId,
  }) {
    return _translateMicrosoftErrors(
      () => _checklistClient.deleteChecklistItem(
        taskListId: taskListId,
        taskId: taskId,
        checklistItemId: checklistItemId,
      ),
    );
  }

  @override
  Future<TaskDto> createTask({
    required String taskListId,
    String? parentTaskId,
    String? previousSiblingTaskId,
    required TaskCreate create,
  }) async {
    if (parentTaskId != null || previousSiblingTaskId != null) {
      throw const TaskRemoteError(
        statusCode: 400,
        code: 'unsupported_provider_operation',
        message:
            'Nested tasks are not supported by Microsoft To Do sync in this version.',
      );
    }
    final dto = await _translateMicrosoftErrors(
      () => _client.createTask(
        taskListId: taskListId,
        body: _microsoftTaskPatch(create.fields),
      ),
    );
    return _taskDto(dto);
  }

  @override
  Future<void> deleteTask({
    required String taskListId,
    required String taskId,
  }) {
    return _translateMicrosoftErrors(
      () => _client.deleteTask(taskListId: taskListId, taskId: taskId),
    );
  }

  @override
  Future<TaskDto> getTask({
    required String taskListId,
    required String taskId,
  }) async {
    final dto = await _translateMicrosoftErrors(
      () => _client.getTask(taskListId: taskListId, taskId: taskId),
    );
    return _taskDto(dto);
  }

  @override
  Future<TasksPageDto> listTasksPage({
    required String taskListId,
    DateTime? completedMax,
    DateTime? completedMin,
    DateTime? dueMax,
    DateTime? dueMin,
    int maxResults = 100,
    String? pageToken,
    bool showCompleted = true,
    bool showDeleted = false,
    bool showHidden = false,
    DateTime? updatedMin,
    bool showAssigned = false,
  }) async {
    final page = await _translateMicrosoftErrors(
      () => _client.listTasksPage(taskListId: taskListId, nextLink: pageToken),
    );
    return TasksPageDto(
      items: page.items.map(_taskDto).toList(),
      nextPageToken: page.nextLink,
      rawJson: page.rawJson,
    );
  }

  @override
  Future<TaskDto> moveTask({
    required String sourceTaskListId,
    required String taskId,
    String? parentTaskId,
    String? previousSiblingTaskId,
    String? destinationTaskListId,
  }) {
    throw const TaskRemoteError(
      statusCode: 400,
      code: 'unsupported_provider_operation',
      message:
          'Moving Microsoft To Do tasks between lists is not supported in this version.',
    );
  }

  @override
  Future<TaskDto> patchTask({
    required String taskListId,
    required String taskId,
    required TaskPatch patch,
  }) {
    return _updateTask(taskListId, taskId, patch.fields);
  }

  @override
  Future<TaskDto> updateTask({
    required String taskListId,
    required String taskId,
    required TaskPut replacement,
  }) {
    return _updateTask(taskListId, taskId, replacement.fields);
  }

  Future<TaskDto> _updateTask(
    String taskListId,
    String taskId,
    Map<String, Object?> fields,
  ) async {
    final patch = _microsoftTaskPatch(fields);
    return _translateMicrosoftErrors(() async {
      try {
        final dto = await _client.updateTask(
          taskListId: taskListId,
          taskId: taskId,
          patch: patch,
        );
        return _taskDto(dto);
      } on MicrosoftTodoApiError catch (error) {
        if (error.statusCode == 400 &&
            patch['completedDateTime'] == null &&
            patch.containsKey('completedDateTime')) {
          final retryPatch = Map<String, Object?>.from(patch)
            ..remove('completedDateTime');
          final dto = await _client.updateTask(
            taskListId: taskListId,
            taskId: taskId,
            patch: retryPatch,
          );
          return _taskDto(dto);
        }
        rethrow;
      }
    });
  }

  Future<T> _translateMicrosoftErrors<T>(Future<T> Function() request) async {
    try {
      return await request();
    } on MicrosoftTodoApiError catch (error) {
      throw TaskRemoteError(
        statusCode: error.statusCode,
        code: error.code ?? 'microsoft_todo_error',
        message: error.message,
        providerDetails: error.rawJson,
        retryAfter: error.retryAfter,
        retryable: error.statusCode == 429 || error.statusCode >= 500,
      );
    }
  }

  MicrosoftTodoChecklistApiClient get _checklistClient {
    final client = _client;
    if (client is MicrosoftTodoChecklistApiClient) {
      return client as MicrosoftTodoChecklistApiClient;
    }
    throw const TaskRemoteError(
      statusCode: 400,
      code: 'unsupported_provider_operation',
      message: 'Microsoft To Do checklist operations are unavailable.',
    );
  }

  Map<String, Object?> _microsoftTaskPatch(Map<String, Object?> fields) {
    final patch = <String, Object?>{};
    if (fields.containsKey('title')) {
      patch['title'] = fields['title'];
    }
    if (fields.containsKey('notes')) {
      patch['body'] = {
        'content': _plainTextToHtml(fields['notes']?.toString() ?? ''),
        'contentType': 'html',
      };
    }
    if (fields.containsKey('status')) {
      final status = fields['status']?.toString();
      if (status == 'completed') {
        patch['status'] = 'completed';
        patch['completedDateTime'] =
            fields['microsoftCompletedDateTime'] ??
            _completedFieldDateTime(fields['completed']) ??
            _dateTimeTimeZone(_localNowDateTime());
      } else {
        patch['status'] = 'notStarted';
        patch['completedDateTime'] = null;
      }
    }
    if (fields.containsKey('due')) {
      final due = fields['due'];
      patch['dueDateTime'] = due == null ? null : _dateOnlyToDateTime(due);
    }
    if (fields.containsKey('microsoftDueDateTime')) {
      patch['dueDateTime'] = fields['microsoftDueDateTime'];
    }
    if (fields.containsKey('microsoftStartDateTime')) {
      patch['startDateTime'] = fields['microsoftStartDateTime'];
    }
    if (fields.containsKey('microsoftReminderDateTime')) {
      patch['reminderDateTime'] = fields['microsoftReminderDateTime'];
    }
    if (fields.containsKey('microsoftCompletedDateTime')) {
      patch['completedDateTime'] = fields['microsoftCompletedDateTime'];
    }
    if (fields.containsKey('microsoftIsReminderOn')) {
      patch['isReminderOn'] = fields['microsoftIsReminderOn'];
    }
    if (fields.containsKey('recurrence')) {
      patch['recurrence'] = fields['recurrence'];
    }
    if (fields.containsKey('importance')) {
      patch['importance'] = fields['importance'];
    }
    if (fields.containsKey('categories')) {
      patch['categories'] = fields['categories'];
    }
    return patch;
  }

  Map<String, Object?> _dateOnlyToDateTime(Object value) {
    final text = value.toString();
    final date = text.length >= 10 ? text.substring(0, 10) : text;
    return {'dateTime': date, 'timeZone': _defaultTimeZone};
  }

  Map<String, Object?> _dateTimeTimeZone(String value) {
    return {'dateTime': value, 'timeZone': _defaultTimeZone};
  }

  Map<String, Object?>? _completedFieldDateTime(Object? value) {
    if (value == null) {
      return null;
    }
    return _dateTimeTimeZone(value.toString());
  }

  String _localNowDateTime() {
    final now = _nowUtc().toLocal();
    final date =
        '${now.year.toString().padLeft(4, '0')}-'
        '${now.month.toString().padLeft(2, '0')}-'
        '${now.day.toString().padLeft(2, '0')}';
    final time =
        '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}:'
        '${now.second.toString().padLeft(2, '0')}';
    return '${date}T$time';
  }
}

TaskListDto _taskListDto(MicrosoftTodoTaskListDto dto) {
  return TaskListDto(
    id: dto.id,
    title: dto.displayName ?? '',
    rawJson: dto.rawJson,
    kind: '#microsoft.graph.todoTaskList',
  );
}

TaskDto _taskDto(MicrosoftTodoTaskDto dto) {
  return TaskDto(
    id: dto.id,
    etag: dto.etag,
    title: dto.title ?? '',
    updated: _parseUtc(dto.lastModifiedDateTime),
    notes: _microsoftBodyToPlainText(
      dto.body?.content ?? '',
      dto.body?.contentType,
    ),
    status: dto.status == 'completed' ? 'completed' : 'needsAction',
    completed: null,
    due: null,
    deleted: dto.removed ? true : null,
    hidden: false,
    rawJson: dto.rawJson,
    kind: '#microsoft.graph.todoTask',
  );
}

TaskChecklistItemDto _checklistItemDto(MicrosoftTodoChecklistItemDto dto) {
  return TaskChecklistItemDto(
    id: dto.id,
    title: dto.displayName ?? '',
    completed: dto.isChecked ?? false,
    createdAtUtc: _parseUtc(dto.createdDateTime),
    completedAtUtc: _parseUtc(dto.checkedDateTime),
    rawJson: dto.rawJson,
  );
}

DateTime? _parseUtc(String? value) {
  if (value == null || value.isEmpty) {
    return null;
  }
  return DateTime.tryParse(value)?.toUtc();
}

String _plainTextToHtml(String value) {
  return _htmlEscape(value).replaceAll('\n', '<br>');
}

String _htmlToPlainText(String value) {
  return value
      .replaceAll(RegExp(r'<\s*br\s*/?\s*>', caseSensitive: false), '\n')
      .replaceAll(RegExp(r'</\s*p\s*>', caseSensitive: false), '\n')
      .replaceAll(RegExp(r'<[^>]+>'), '')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&amp;', '&')
      .trim();
}

String _microsoftBodyToPlainText(String content, String? contentType) {
  return contentType?.toLowerCase() == 'html'
      ? _htmlToPlainText(content)
      : content;
}

String _htmlEscape(String text) {
  return text
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
}

void _putMicrosoftDateTimeAliases(
  Map<String, Object?> normalized,
  Map<String, Object?> snapshot, {
  required String graphField,
  required String dateTimeField,
  required String timeZoneField,
}) {
  if (!snapshot.containsKey(graphField)) return;
  final value = snapshot[graphField];
  if (!normalized.containsKey(dateTimeField)) {
    normalized[dateTimeField] = value;
  }
  if (!normalized.containsKey(timeZoneField)) {
    normalized[timeZoneField] = value is Map
        ? value['timeZone']?.toString()
        : null;
  }
}

String? _dateTimePart(Object? value) {
  if (value is Map) {
    return value['dateTime']?.toString();
  }
  return value?.toString();
}
