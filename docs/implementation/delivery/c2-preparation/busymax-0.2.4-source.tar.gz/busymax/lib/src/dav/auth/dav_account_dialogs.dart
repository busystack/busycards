import 'package:flutter/material.dart';
import 'package:yaru/yaru.dart';

import '../../app/busymax_design.dart';
import '../../app/busymax_dialogs.dart';
import '../../l10n/l10n.dart';
import '../../providers/busy_provider.dart';

final class AppleICloudCredentialInput {
  AppleICloudCredentialInput({required this.email, required this.password});

  final String email;
  final String password;

  @override
  String toString() =>
      'AppleICloudCredentialInput(email: [REDACTED], password: [REDACTED])';
}

Future<AppleICloudCredentialInput?> showAppleICloudCredentialDialog(
  BuildContext context, {
  String? fixedEmail,
}) {
  return showBusyMaxModalDialog<AppleICloudCredentialInput>(
    context,
    barrierDismissible: false,
    builder: (context) => _AppleCredentialDialog(fixedEmail: fixedEmail),
  );
}

Future<String?> showNextcloudServerDialog(
  BuildContext context, {
  String? initialServer,
}) {
  return showBusyMaxModalDialog<String>(
    context,
    barrierDismissible: false,
    builder: (context) => _NextcloudServerDialog(initialServer: initialServer),
  );
}

final class _AppleCredentialDialog extends StatefulWidget {
  const _AppleCredentialDialog({required this.fixedEmail});

  final String? fixedEmail;

  @override
  State<_AppleCredentialDialog> createState() => _AppleCredentialDialogState();
}

final class _AppleCredentialDialogState extends State<_AppleCredentialDialog> {
  late final TextEditingController _email = TextEditingController(
    text: widget.fixedEmail ?? '',
  );
  final TextEditingController _password = TextEditingController();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();
  var _submitted = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    final emailMissing = _submitted && _email.text.trim().isEmpty;
    final passwordMissing = _submitted && _password.text.trim().isEmpty;
    return BusyMaxDialogShell(
      title: l10n.connectAppleICloudTitle,
      maxWidth: 520,
      actions: [
        BusyMaxPushButton.standard(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.cancel),
        ),
        BusyMaxPushButton.suggested(
          onPressed: _submit,
          child: Text(l10n.connectAccountAction),
        ),
      ],
      children: [
        Text(l10n.appleAppSpecificPasswordHelp),
        BusyMaxGroupedList(
          filled: true,
          children: [
            YaruListTile.square(
              title: TextField(
                key: const Key('apple-account-email-field'),
                controller: _email,
                focusNode: _emailFocus,
                autofocus: widget.fixedEmail == null,
                readOnly: widget.fixedEmail != null,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [
                  AutofillHints.username,
                  AutofillHints.email,
                ],
                textInputAction: TextInputAction.next,
                onSubmitted: (_) => _passwordFocus.requestFocus(),
                onChanged: (_) => setState(() {}),
                decoration: busyMaxGroupedTextFieldDecoration(
                  context,
                  labelText: l10n.appleAccountEmail,
                  errorText: emailMissing ? l10n.requiredField : null,
                ),
              ),
            ),
            YaruListTile.square(
              title: Semantics(
                textField: true,
                label: l10n.appleAppSpecificPassword,
                child: TextField(
                  key: const Key('apple-app-specific-password-field'),
                  controller: _password,
                  focusNode: _passwordFocus,
                  autofocus: widget.fixedEmail != null,
                  obscureText: true,
                  enableSuggestions: false,
                  autocorrect: false,
                  autofillHints: const [AutofillHints.password],
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _submit(),
                  onChanged: (_) => setState(() {}),
                  decoration: busyMaxGroupedTextFieldDecoration(
                    context,
                    labelText: l10n.appleAppSpecificPassword,
                    errorText: passwordMissing ? l10n.requiredField : null,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: BusyMaxSpacing.md),
        Text(
          l10n.appleAppSpecificPasswordResetWarning,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  void _submit() {
    setState(() => _submitted = true);
    final email = _email.text.trim();
    final password = _password.text.trim();
    if (email.isEmpty || password.isEmpty) return;
    Navigator.of(
      context,
    ).pop(AppleICloudCredentialInput(email: email, password: password));
  }
}

final class _NextcloudServerDialog extends StatefulWidget {
  const _NextcloudServerDialog({required this.initialServer});

  final String? initialServer;

  @override
  State<_NextcloudServerDialog> createState() => _NextcloudServerDialogState();
}

final class _NextcloudServerDialogState extends State<_NextcloudServerDialog> {
  late final TextEditingController _server = TextEditingController(
    text: widget.initialServer ?? '',
  );
  var _submitted = false;

  @override
  void dispose() {
    _server.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    final title = l10n.registrationSetupTitle(
      BusyProvider.nextcloud.displayName,
    );
    return BusyMaxDialogShell(
      title: title,
      maxWidth: 560,
      header: Padding(
        padding: const EdgeInsets.all(BusyMaxSpacing.headerInset),
        child: Row(
          children: [
            const SizedBox(width: BusyMaxSizes.headerIconButton),
            Expanded(
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            SizedBox(
              width: BusyMaxSizes.headerIconButton,
              child: Center(
                child: YaruWindowControl(
                  type: YaruWindowControlType.close,
                  semanticLabel: l10n.close,
                  onTap: () => Navigator.pop(context),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        BusyMaxPushButton.standard(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.cancel),
        ),
        BusyMaxPushButton.suggested(
          onPressed: _submit,
          child: Text(l10n.connectAccountAction),
        ),
      ],
      children: [
        BusyMaxGroupedList(
          filled: true,
          children: [
            YaruListTile.square(
              title: TextField(
                key: const Key('nextcloud-server-field'),
                controller: _server,
                autofocus: true,
                keyboardType: TextInputType.url,
                autofillHints: const [AutofillHints.url],
                textInputAction: TextInputAction.done,
                onChanged: (_) => setState(() {}),
                onSubmitted: (_) => _submit(),
                decoration:
                    busyMaxGroupedTextFieldDecoration(
                      context,
                      labelText: l10n.nextcloudServerUrl,
                      errorText: _submitted && _server.text.trim().isEmpty
                          ? l10n.requiredField
                          : null,
                    ).copyWith(
                      hintText: 'https://cloud.example.com/remote.php/dav',
                    ),
              ),
            ),
          ],
        ),
        const SizedBox(height: BusyMaxSpacing.sm),
        Text(l10n.nextcloudServerUrlHelp),
        const SizedBox(height: BusyMaxSpacing.md),
        Text(l10n.nextcloudBrowserAuthorizationHelp),
      ],
    );
  }

  void _submit() {
    setState(() => _submitted = true);
    final server = _server.text.trim();
    if (server.isEmpty) return;
    Navigator.of(context).pop(server);
  }
}
