import '../core/http/request_dispatch_exception.dart';
import '../features/sync/domain_sync_schedule.dart';
import '../core/auth/authorization_persistence.dart';
import '../core/auth/registration_staging.dart';
import '../core/auth/oauth_registration.dart';

import 'dart:async';
import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:busystack_contacts/busystack_contacts.dart';
import 'package:uuid/uuid.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:busymax/src/core/secrets/secret_store.dart';
import 'package:busymax/src/providers/busy_provider.dart';
import 'package:busymax/src/features/tasks/domain/task_capabilities.dart';

import '../core/time/provider_date_time.dart';
import '../contacts/busymax_contacts_controller.dart';
import '../contacts/busymax_contacts_store.dart';
import '../core/auth/account_token_broker.dart';
import '../core/http/native_terminating_http_client.dart';
import '../core/time/stored_temporal_projection.dart';
import '../dav/nextcloud/nextcloud_native_export.dart';
import '../config/build_config.dart';
import '../calendar_providers/cloud_calendar_client.dart';
import '../db/app_database.dart';
import '../dav/auth/dav_account_onboarding_service.dart';
import '../dav/auth/nextcloud_app_password_revoker.dart';
import '../dav/auth/nextcloud_login_flow_v2.dart';
import '../dav/dav_provider_profile.dart';
import '../dav/discovery/dav_discovery_service.dart';
import '../dav/http/dav_http_transport.dart';
import '../dav/mutation/dav_conflict_repository.dart';
import '../dav/mutation/dav_calendar_collection_mutation_service.dart';
import '../dav/mutation/dav_pending_operations.dart';
import '../dav/mutation/dav_task_list_mutation_service.dart';
import '../dav/sync/dav_account_sync_engine.dart';
import '../dav/storage/dav_projection_coverage_service.dart';
import '../dav/storage/dav_settings_repository.dart';
import '../dav/nextcloud/nextcloud_collection_service.dart';
import '../dav/nextcloud/nextcloud_sharing_service.dart';
import '../dav/nextcloud/nextcloud_trash_service.dart';
import '../dav/nextcloud/nextcloud_scheduling_service.dart';
import '../features/calendar/data/calendar_repository.dart';
import '../features/calendar/data/microsoft_shared_calendar_service.dart';
import '../features/schedule/presentation/attachment_upload_coordinator.dart';
import '../features/sync/cloud_calendar_range_coverage_service.dart';
import '../features/calendar/data/calendar_collection_creation_service.dart';
import '../ical/ical_import_service.dart';
import '../features/accounts/data/accounts_repository.dart';
import '../features/auth/data/auth_repository.dart';
import '../features/connectivity/network_connectivity_service.dart';
import '../features/feedback/data/feedback_api_client.dart';
import '../features/notifications/desktop_notification_service.dart';
import '../features/notifications/notification_cancellation_queue.dart';
import '../features/notifications/due_today_notification_scheduler.dart';
import '../features/notifications/notification_schedule_service.dart';
import '../features/notifications/notification_scheduler.dart';
import '../features/notifications/notification_reconciler.dart';
import '../features/sync/account_sync_operations.dart';
import '../features/sync/all_accounts_sync_scheduler.dart';
import '../features/sync/calendar_sync_engine.dart';
import '../features/sync/pending_mutation_sync_requester.dart';
import '../features/sync/pending_op_resolution_service.dart';
import '../features/sync/sync_engine.dart';
import '../features/sync/sync_failure_notification_policy.dart';
import '../features/task_lists/data/task_lists_repository.dart';
import '../features/tasks/data/tasks_repository.dart';
import '../features/tasks/domain/task_remote_client.dart';
import '../features/tray/data/tray_presentation_service.dart';
import '../google_tasks/api/google_tasks_api_client.dart';
import '../google_tasks/http/authenticated_http_client.dart';
import '../google_tasks/http/retrying_http_client.dart';
import '../google_tasks/oauth/oauth_loopback_flow.dart';
import '../google_tasks/oauth/oauth_service.dart';
import '../google_calendar/google_calendar_api_client.dart';
import '../google_calendar/google_calendar_models.dart';
import '../microsoft_calendar/microsoft_calendar_api_client.dart';
import '../microsoft_calendar/microsoft_calendar_models.dart';
import '../microsoft_calendar/microsoft_event_attachment.dart';
import '../microsoft_todo/api/microsoft_todo_api_models.dart';
import '../microsoft_todo/api/microsoft_todo_api_client.dart';
import '../features/tasks/domain/task_source_links.dart';
import '../microsoft_todo/api/microsoft_todo_task_remote_client.dart';
import '../microsoft_todo/oauth/microsoft_oauth_service.dart';
import '../platform/common/desktop_services.dart';
import '../schedule/schedule_commands.dart';
import '../schedule/schedule_repository.dart';
import '../schedule/schedule_sidebar_order.dart';
import '../webcal/webcal_http_client.dart';
import '../webcal/webcal_subscription_service.dart';
import 'app_settings.dart';
import '../features/maps/data/location_resolution_repository.dart';

export '../app/app_settings.dart';

final buildConfigProvider = Provider<BuildConfig>(
  (ref) => BuildConfig.fromEnvironment(),
);

final locationResolutionRepositoryProvider =
    Provider<LocationResolutionRepository>(
      (ref) => LocationResolutionRepository(ref.watch(databaseProvider)),
    );
final databaseProvider = Provider<AppDatabase>((ref) {
  final database = AppDatabase.open();
  ref.onDispose(database.close);
  return database;
});

final secureStorageProvider = Provider<FlutterSecureStorage>(
  (ref) => const FlutterSecureStorage(),
);

final networkConnectivityMonitorProvider = Provider<NetworkConnectivityMonitor>(
  (ref) {
    final monitor = NetworkConnectivityMonitor();
    ref.onDispose(() => unawaited(monitor.dispose()));
    return monitor;
  },
);

final networkAvailabilityProvider = StreamProvider<NetworkAvailability>((ref) {
  return ref.watch(networkConnectivityMonitorProvider).watch();
});

final networkReconnectSyncCoordinatorProvider =
    Provider<NetworkReconnectSyncCoordinator>((ref) {
      final coordinator = NetworkReconnectSyncCoordinator(
        monitor: ref.watch(networkConnectivityMonitorProvider),
        synchronize: () => ref.read(syncSchedulerProvider).runNow(),
      );
      coordinator.start();
      ref.onDispose(() => unawaited(coordinator.dispose()));
      return coordinator;
    });

final baseHttpClientProvider = Provider<http.Client>((ref) {
  final client = ConnectivityAwareHttpClient(
    inner: NativeTerminatingHttpClient(),
    requireNetwork: ref
        .watch(networkConnectivityMonitorProvider)
        .requireNetwork,
  );
  ref.onDispose(client.close);
  return client;
});

final nextcloudLoginFlowV2Provider = Provider<NextcloudLoginFlowV2>((ref) {
  return NextcloudLoginFlowV2(client: ref.watch(baseHttpClientProvider));
});

final davAccountOnboardingServiceProvider =
    Provider<DavAccountOnboardingService>((ref) {
      final client = ref.watch(baseHttpClientProvider);
      return DavAccountOnboardingService(
        database: ref.watch(databaseProvider),
        secretStore: ref.watch(secretStoreProvider),
        accountsRepository: ref.watch(accountsRepositoryProvider),
        nextcloudLoginFlow: ref.watch(nextcloudLoginFlowV2Provider),
        discover:
            ({
              required accountId,
              required provider,
              required accountAuthority,
              required credential,
              cancellationToken,
            }) {
              final profile = davProviderProfile(
                provider,
                nextcloudServer: provider == BusyProvider.nextcloud
                    ? accountAuthority
                    : null,
              );
              final transport = DavHttpTransport(
                client: client,
                profile: profile,
                accountAuthority: accountAuthority,
              );
              return DavDiscoveryService(
                transport: transport,
                profile: profile,
                accountAuthority: accountAuthority,
                accountId: accountId,
                credential: credential,
              ).discover(
                correlationId: const Uuid().v4(),
                cancellationToken: cancellationToken,
              );
            },
        nextcloudCredentialRevoker:
            ({required accountId, required credential}) {
              final profile = davProviderProfile(
                BusyProvider.nextcloud,
                nextcloudServer: credential.canonicalServer,
              );
              return NextcloudAppPasswordRevoker(
                transport: DavHttpTransport(
                  client: client,
                  profile: profile,
                  accountAuthority: credential.canonicalServer,
                ),
              ).revoke(
                accountId: accountId,
                credential: credential,
                correlationId: const Uuid().v4(),
              );
            },
      );
    });

final retryingHttpClientProvider = Provider<http.Client>((ref) {
  return RetryingHttpClient(inner: ref.watch(baseHttpClientProvider));
});

final feedbackSubmissionServiceProvider = Provider<FeedbackSubmissionService>((
  ref,
) {
  final config = ref.watch(buildConfigProvider);
  return FeedbackApiClient(
    httpClient: ref.watch(baseHttpClientProvider),
    endpoint: Uri.parse(config.feedbackEndpoint),
  );
});

final secretStoreProvider = Provider<SecretStore>((ref) {
  return SecureSecretStore(ref.watch(secureStorageProvider));
});

final registrationSummariesProvider =
    StreamProvider<Map<String, RegistrationSummary>>((ref) async* {
      final persistence = ref.watch(authorizationPersistenceProvider);
      await persistence.recover();
      final existing = await persistence.database
          .select(persistence.database.oAuthTransitionAccounts)
          .get();
      for (final row in existing) {
        final account = await (persistence.database.select(
          persistence.database.accounts,
        )..where((r) => r.id.equals(row.accountId))).getSingleOrNull();
        if (account == null) continue;
        final provider = BusyProviderCodec.requireStorageValue(
          account.provider,
        );
        final gateway = provider == BusyProvider.google
            ? ref.read(applicationOAuthGatewayProvider)
            : ref.read(applicationMicrosoftOAuthServiceProvider);
        if (gateway is RegistrationBindingResolver) {
          try {
            await gateway.establishExistingBinding(row.accountId, provider);
          } on Object {
            /* Unresolved records stay intact and have no retirement label. */
          }
        }
      }
      await for (final rows
          in persistence.database
              .select(persistence.database.accountAuthorizations)
              .watch()) {
        final summaries = <String, RegistrationSummary>{};
        for (final row in rows) {
          try {
            final record = await persistence.readCurrentCredential(
              row.accountId,
            );
            if (record is BoundOAuthSecretRecord &&
                record.generation == row.generation) {
              summaries[row.accountId] = record.registration.summary(
                transitionEligible: record.transitionEligible,
              );
            } else if (record is NativeOAuthCredential &&
                record.generation == row.generation) {
              summaries[row.accountId] = record.summary;
            }
          } on Object {
            /* Missing/corrupt credentials have unresolved provenance. */
          }
        }
        yield summaries;
      }
    });

final registrationStagingProvider = Provider<RegistrationStaging>((ref) {
  final staging = RegistrationStaging(ref.watch(buildConfigProvider));
  ref.onDispose(staging.dispose);
  return staging;
});
final authorizationPersistenceProvider = Provider<AuthorizationPersistence>(
  (ref) => AuthorizationPersistence(
    database: ref.watch(databaseProvider),
    secrets: ref.watch(secretStoreProvider),
    gate: ref.watch(crossEngineAccountGateProvider),
  ),
);

final authorizationGenerationReaderProvider =
    Provider<Future<int> Function(String)>(
      (ref) => ref.watch(authorizationPersistenceProvider).generation,
    );

final applicationOAuthServiceProvider = Provider<OAuthService>((ref) {
  return OAuthService(
    config: ref.watch(buildConfigProvider),
    httpClient: ref.watch(baseHttpClientProvider),
    tokenStore: ref.watch(secretStoreProvider),
    loopbackFlow: OAuthLoopbackFlow(),
    registrations: ref.watch(registrationStagingProvider),
    persistence: ref.watch(authorizationPersistenceProvider),
  );
});

final oAuthServiceProvider = applicationOAuthServiceProvider;

final applicationOAuthGatewayProvider = Provider<OAuthGateway>(
  (ref) => ref.watch(applicationOAuthServiceProvider),
);

final microsoftOAuthServiceProvider = Provider<MicrosoftOAuthService>((ref) {
  return MicrosoftOAuthService(
    config: ref.watch(buildConfigProvider),
    httpClient: ref.watch(baseHttpClientProvider),
    tokenStore: ref.watch(secretStoreProvider),
    loopbackFlow: OAuthLoopbackFlow(),
    registrations: ref.watch(registrationStagingProvider),
    persistence: ref.watch(authorizationPersistenceProvider),
  );
});

final applicationMicrosoftOAuthServiceProvider =
    Provider<MicrosoftOAuthGateway?>(
      (ref) => ref.watch(microsoftOAuthServiceProvider),
    );

final accountTokenBrokerProvider = Provider<AccountTokenBroker>((ref) {
  return DesktopAccountTokenBroker(
    google: ref.watch(applicationOAuthServiceProvider),
    microsoft: ref.watch(microsoftOAuthServiceProvider),
  );
});

final busyMaxContactsStoreProvider = Provider<BusyMaxContactsStore>((ref) {
  return BusyMaxContactsStore(ref.watch(databaseProvider));
});

final busyMaxContactsControllerProvider = Provider<BusyMaxContactsController>((
  ref,
) {
  final broker = ref.watch(accountTokenBrokerProvider);
  if (broker is! ContactsAuthorizationBroker) {
    throw StateError('Contacts authorization is unavailable.');
  }
  final storage = ref.watch(secureStorageProvider);
  String key(String accountId) =>
      'busymax.contacts.dav.${base64UrlEncode(utf8.encode(accountId))}';
  final controller = BusyMaxContactsController(
    store: ref.watch(busyMaxContactsStoreProvider),
    accounts: ref.watch(accountsRepositoryProvider),
    authorization: broker as ContactsAuthorizationBroker,
    readAuthorizationGeneration: ref.watch(
      authorizationGenerationReaderProvider,
    ),
    httpClient: ref.watch(baseHttpClientProvider),
    readDavSecret: (accountId) => storage.read(key: key(accountId)),
    writeDavSecret: (accountId, value) =>
        storage.write(key: key(accountId), value: value),
    deleteDavSecret: (accountId) => storage.delete(key: key(accountId)),
    readLinkedDavCredential: (accountId) async {
      final credential = await ref
          .read(secretStoreProvider)
          .readCredential(accountId);
      return credential is NextcloudSecretRecord
          ? BusyMaxLinkedDavCredential(
              server: credential.canonicalServer,
              username: credential.loginName,
              password: credential.appPassword,
            )
          : null;
    },
    launchBrowser: (uri) =>
        launchUrl(uri, mode: LaunchMode.externalApplication),
  );
  controller.startInBackground();
  ref.onDispose(() => unawaited(controller.close()));
  return controller;
});

final authenticatedHttpClientProvider = Provider<http.Client>((ref) {
  return AuthenticatedHttpClient(
    inner: ref.watch(retryingHttpClientProvider),
    oAuthService: ref.watch(applicationOAuthServiceProvider),
  );
});

final desktopNotificationBackendProvider = Provider<DesktopNotificationBackend>(
  (ref) => const DisabledDesktopNotificationBackend(),
);

final desktopNotificationReadinessProvider =
    StateProvider<DesktopNotificationReadiness>(
      (ref) => const DesktopNotificationReadiness.initializing(),
    );

// Survives scheduler invalidation, settings changes and backend replacement.
final notificationCancellationQueueProvider =
    Provider<NotificationCancellationQueue>(
      (ref) => NotificationCancellationQueue(),
    );

final desktopNotificationServiceProvider = Provider<DesktopNotificationService>(
  (ref) {
    final settings = ref.watch(appSettingsControllerProvider);
    return DesktopNotificationService(
      backend: ref.watch(desktopNotificationBackendProvider),
      cancellationQueue: ref.watch(notificationCancellationQueueProvider),
      settings: settings,
      locale: settings.locale,
      onDestinationActivated: (destination) async {
        await ref.read(desktopWindowServiceProvider).showWindow();
        ref.read(desktopNavigationServiceProvider).open(destination);
      },
    );
  },
);

final operationalNotificationReporterProvider =
    Provider<OperationalNotificationReporter>((ref) {
      final desktop = ref.watch(desktopNotificationServiceProvider);
      return CallbackOperationalNotificationReporter(
        onSyncFailure: desktop.notifySyncFailure,
        onConflict: desktop.notifyConflict,
      );
    });

Stream<T> _contactsConfigurationStream<T>(
  BusyMaxContactsController controller,
  Future<T> Function() read,
) => Stream<T>.multi((output) {
  var disposed = false;
  var generation = 0;
  void reload() {
    final captured = ++generation;
    unawaited(
      Future<T>.sync(read).then<void>(
        (value) {
          if (!disposed && captured == generation) output.add(value);
        },
        onError: (Object error, StackTrace stack) {
          if (!disposed && captured == generation) {
            output.addError(error, stack);
          }
        },
      ),
    );
  }

  final subscription = controller.changes.listen(
    (_) => reload(),
    onError: output.addError,
  );
  output.onCancel = () {
    disposed = true;
    generation++;
    return subscription.cancel();
  };
  reload();
});

final busyMaxContactAccountsProvider = StreamProvider<List<ContactAccount>>((
  ref,
) {
  final controller = ref.watch(busyMaxContactsControllerProvider);
  return _contactsConfigurationStream(
    controller,
    () => controller.store.read((tx) => tx.accounts()),
  );
});

final busyMaxContactSourceSettingsProvider =
    StreamProvider<List<BusyMaxContactSourceSetting>>((ref) {
      final controller = ref.watch(busyMaxContactsControllerProvider);
      return _contactsConfigurationStream(
        controller,
        controller.sourceSettings,
      );
    });

final desktopWindowServiceProvider = Provider<DesktopWindowService>(
  (ref) => const NoOpDesktopWindowService(),
);

/// Sanitized platform adapter health only; never contains menu labels or user
/// content.
final desktopTrayDiagnosticProvider = StateProvider<String?>((ref) => null);

final linuxWindowServiceProvider = desktopWindowServiceProvider;

final desktopActivationServiceProvider = Provider<DesktopActivationService>(
  (ref) => const NoOpDesktopActivationService(),
);

final externalCalendarOpenServiceProvider = desktopActivationServiceProvider;

final desktopAutostartServiceProvider = Provider<DesktopAutostartService>(
  (ref) => const UnavailableDesktopAutostartService(),
);

final linuxAutostartServiceProvider = desktopAutostartServiceProvider;

final launchAtLoginStateProvider = FutureProvider<DesktopAutostartState>(
  (ref) => ref.watch(desktopAutostartServiceProvider).state(),
);

final launchAtLoginEnabledProvider = FutureProvider<bool>(
  (ref) async => (await ref.watch(launchAtLoginStateProvider.future)).isEnabled,
);

final launchAtLoginControllerProvider =
    StateNotifierProvider<LaunchAtLoginController, bool>(
      (ref) => LaunchAtLoginController(ref),
    );

/// Serializes changes across Settings instances, including the state readback.
class LaunchAtLoginController extends StateNotifier<bool> {
  LaunchAtLoginController(this._ref) : super(false);

  final Ref _ref;

  Future<void> setEnabled(bool enabled) async {
    if (state) return;
    state = true;
    try {
      await _ref.read(desktopAutostartServiceProvider).setEnabled(enabled);
    } finally {
      if (mounted) {
        _ref.invalidate(launchAtLoginStateProvider);
        try {
          await _ref.read(launchAtLoginStateProvider.future);
        } on Object {
          // The read provider exposes this failure separately from write errors.
        } finally {
          if (mounted) state = false;
        }
      }
    }
  }
}

final desktopNavigationServiceProvider = Provider<DesktopNavigationService>((
  ref,
) {
  final service = QueuedDesktopNavigationService();
  ref.onDispose(() => unawaited(service.dispose()));
  return service;
});

final systemAppearanceSourceProvider = Provider<SystemAppearanceSource>((ref) {
  throw StateError('A platform SystemAppearanceSource was not configured.');
});

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository(
    oAuth: ref.watch(applicationOAuthGatewayProvider),
    authorizationPersistence: ref.watch(authorizationPersistenceProvider),
    database: ref.watch(databaseProvider),
    accountsRepository: ref.watch(accountsRepositoryProvider),
    microsoftOAuth: ref.watch(applicationMicrosoftOAuthServiceProvider),
    onAccountRemovalStarting: (accountId) => ref
        .read(busyMaxContactsControllerProvider)
        .beginLinkedAccountRemoval(accountId),
    onAccountRemoving: (accountId) => ref
        .read(busyMaxContactsControllerProvider)
        .prepareLinkedAccountRemoval(accountId),
    persistLinkedAccountRemoval: (accountId) => ref
        .read(busyMaxContactsControllerProvider)
        .persistLinkedAccountRemoval(accountId),
    onAccountRemovalFailed: (accountId) => ref
        .read(busyMaxContactsControllerProvider)
        .restoreLinkedAccountAfterFailedRemoval(accountId),
    onAccountRemoved: () => ref
        .read(busyMaxContactsControllerProvider)
        .linkedAccountRemovalCommitted(),
    onAccountRemovalFinished: (accountId) => ref
        .read(busyMaxContactsControllerProvider)
        .finishLinkedAccountRemoval(accountId),
  );
});

final accountsRepositoryProvider = Provider<AccountsRepository>((ref) {
  return AccountsRepository(database: ref.watch(databaseProvider));
});

final accountsStreamProvider = StreamProvider<List<AccountEntity>>((ref) {
  return ref.watch(accountsRepositoryProvider).watchAccounts();
});

final accountManagementStreamProvider = StreamProvider<List<AccountEntity>>((
  ref,
) {
  return ref.watch(accountsRepositoryProvider).watchVisibleAccounts();
});

final davSettingsRepositoryProvider = Provider<DavSettingsRepository>((ref) {
  return DavSettingsRepository(
    database: ref.watch(databaseProvider),
    onVisibilityChanged: (_) =>
        ref.read(notificationReconcilerProvider).reconcile(),
  );
});

final davCollectionsStreamProvider =
    StreamProvider<List<DavCollectionSettingsEntity>>((ref) {
      return ref.watch(davSettingsRepositoryProvider).watchCollections();
    });

final davConflictRepositoryProvider = Provider<DavConflictRepository>((ref) {
  return DavConflictRepository(database: ref.watch(databaseProvider));
});

final davConflictsStreamProvider = StreamProvider<List<DavConflictEntity>>((
  ref,
) {
  return ref.watch(davConflictRepositoryProvider).watchUnresolved();
});

final davConflictResolutionServiceProvider =
    Provider<DavConflictResolutionService>((ref) {
      final database = ref.watch(databaseProvider);
      return DavConflictResolutionService(
        database: database,
        pendingQueue: DavPendingOperationQueue(database: database),
        rebuildNotifications: (accountId, _) async {
          await NotificationScheduleService(database: database)
              .rebuildUpcomingNotifications(accountId);
        },
      );
    });

final davTaskCollectionCapabilitiesProvider =
    StreamProvider.family<
      TaskCollectionCapabilities?,
      ({String accountId, String taskListId})
    >((ref, key) {
      return ref
          .watch(davSettingsRepositoryProvider)
          .watchCollectionByTaskListId(key.accountId, key.taskListId)
          .map((collection) => collection?.taskCapabilities);
    });

final selectedAccountIdProvider = StateProvider<String?>((ref) => null);

final selectedAccountProvider = Provider<AccountEntity?>((ref) {
  final accounts = (ref.watch(accountsStreamProvider).valueOrNull ?? const [])
      .where((account) => account.isTaskCapable)
      .toList(growable: false);
  final selectedId = ref.watch(selectedAccountIdProvider);
  if (selectedId != null) {
    for (final account in accounts) {
      if (account.id == selectedId) {
        return account;
      }
    }
  }
  if (accounts.isNotEmpty) {
    return accounts.first;
  }
  return null;
});

final selectedAccountCapabilitiesProvider =
    Provider<TaskCollectionCapabilities>((ref) {
      final account = ref.watch(selectedAccountProvider);
      return account == null
          ? noTaskCollectionCapabilities
          : adapterDefaultTaskCapabilities(account.provider);
    });

final localTimeZoneSourceProvider = Provider<LocalTimeZoneSource>(
  (ref) => const FixedLocalTimeZoneSource('Etc/UTC'),
);

final androidLocalTimeZoneStateProvider = StateProvider<String>(
  (ref) => 'Etc/UTC',
);
final androidSystemUses24HourProvider = StateProvider<bool>((ref) => false);

final localTimeZoneProvider = Provider<String>(
  (ref) => ref.watch(androidLocalTimeZoneStateProvider),
);

final googleTasksApiClientForAccountProvider =
    Provider.family<TaskRemoteClient, String>((ref, accountId) {
      final config = ref.watch(buildConfigProvider);
      return GoogleTasksRestApiClient(
        httpClient: ref.watch(retryingHttpClientProvider),
        baseUri: Uri.parse(config.googleApiBaseUrl),
        authorizationHeaderProvider: () => ref
            .read(accountTokenBrokerProvider)
            .authorizationHeader(BusyProvider.google, accountId),
        unauthorizedRefreshProvider: () => ref
            .read(accountTokenBrokerProvider)
            .recoverUnauthorized(BusyProvider.google, accountId),
      );
    });

final googleCalendarApiClientForAccountProvider =
    Provider.family<GoogleCalendarApiClient, String>((ref, accountId) {
      final config = ref.watch(buildConfigProvider);
      return GoogleCalendarApiClient(
        httpClient: ref.watch(retryingHttpClientProvider),
        baseUri: Uri.parse(config.googleApiBaseUrl),
        authorizationHeaderProvider: () => ref
            .read(accountTokenBrokerProvider)
            .authorizationHeader(BusyProvider.google, accountId),
        unauthorizedRefreshProvider: () => ref
            .read(accountTokenBrokerProvider)
            .recoverUnauthorized(BusyProvider.google, accountId),
      );
    });

final googleEventLabelsForCalendarProvider =
    FutureProvider.family<
      List<GoogleEventLabel>,
      ({String accountId, String calendarId})
    >(
      (ref, key) async => ref
          .watch(googleCalendarApiClientForAccountProvider(key.accountId))
          .getEventLabels(key.calendarId),
    );

final microsoftTodoApiClientForAccountProvider =
    Provider.family<MicrosoftTodoApiClient, String>((ref, accountId) {
      final config = ref.watch(buildConfigProvider);
      final broker = ref.watch(accountTokenBrokerProvider);
      return MicrosoftTodoRestApiClient(
        httpClient: ref.watch(baseHttpClientProvider),
        baseUri: Uri.parse(config.microsoftGraphBaseUrl),
        authorizationHeaderWithClaimsProvider: (claims) =>
            broker is MicrosoftGraphAuthorizationBroker
            ? (broker as MicrosoftGraphAuthorizationBroker)
                  .microsoftGraphAuthorizationHeader(
                    accountId,
                    MicrosoftGraphAuthorizationKind.ordinary,
                    claims: claims,
                  )
            : claims == null
            ? broker.authorizationHeader(BusyProvider.microsoft, accountId)
            : throw StateError('Claims authorization is unavailable.'),
        unauthorizedRefreshProvider: () => ref
            .read(accountTokenBrokerProvider)
            .recoverUnauthorized(BusyProvider.microsoft, accountId),
      );
    });

final microsoftTaskLinkedResourcesProvider =
    FutureProvider.family<
      List<TaskSourceLink>,
      ({String accountId, String taskListId, String taskId})
    >((ref, key) async {
      final client = ref.read(
        microsoftTodoApiClientForAccountProvider(key.accountId),
      );
      if (client is! MicrosoftTodoLinkedResourcesApiClient) {
        throw StateError('Microsoft task linked resources are unavailable.');
      }
      final links = <TaskSourceLink>[];
      final seenUrls = <String>{};
      final seenPages = <String>{};
      String? nextLink;
      do {
        final page = await (client as MicrosoftTodoLinkedResourcesApiClient)
            .listLinkedResourcesPage(
              taskListId: key.taskListId,
              taskId: key.taskId,
              nextLink: nextLink,
            );
        for (final resource in page.resources) {
          final uri = Uri.tryParse(resource.webUrl?.trim() ?? '');
          if (uri == null ||
              (uri.scheme != 'https' && uri.scheme != 'http') ||
              uri.host.isEmpty ||
              uri.userInfo.isNotEmpty ||
              !seenUrls.add(uri.toString())) {
            continue;
          }
          final displayName = resource.displayName?.trim();
          final applicationName = resource.applicationName?.trim();
          links.add(
            TaskSourceLink(
              url: uri.toString(),
              label: [
                if (displayName != null && displayName.isNotEmpty) displayName,
                if (applicationName != null &&
                    applicationName.isNotEmpty &&
                    applicationName != displayName)
                  applicationName,
              ].join(' · '),
            ),
          );
        }
        nextLink = page.nextLink;
        if (nextLink != null && !seenPages.add(nextLink)) {
          throw StateError('Microsoft linked resource pagination repeated.');
        }
      } while (nextLink != null);
      return List.unmodifiable(links);
    });

final attachmentUploadCoordinatorProvider =
    ChangeNotifierProvider<AttachmentUploadCoordinator>(
      (ref) => AttachmentUploadCoordinator(),
    );

final microsoftEventAttachmentsProvider =
    FutureProvider.family<
      List<MicrosoftEventAttachment>,
      ({String accountId, String calendarId, String eventId})
    >(
      (ref, key) => ref
          .read(microsoftCalendarApiClientForAccountProvider(key.accountId))
          .listEventAttachments(
            calendarId: key.calendarId,
            eventId: key.eventId,
          ),
    );

final microsoftTaskAttachmentsProvider =
    FutureProvider.family<
      List<MicrosoftTodoAttachmentDto>,
      ({String accountId, String taskListId, String taskId})
    >((ref, key) async {
      final client = ref.read(
        microsoftTodoApiClientForAccountProvider(key.accountId),
      );
      if (client is! MicrosoftTodoAttachmentsApiClient) {
        throw StateError('Microsoft task attachments are unavailable.');
      }
      final items = <MicrosoftTodoAttachmentDto>[];
      final seenPages = <String>{};
      String? nextLink;
      do {
        final page = await (client as MicrosoftTodoAttachmentsApiClient)
            .listTaskAttachmentsPage(
              taskListId: key.taskListId,
              taskId: key.taskId,
              nextLink: nextLink,
            );
        items.addAll(page.attachments);
        nextLink = page.nextLink;
        if (nextLink != null && !seenPages.add(nextLink)) {
          throw const FormatException('Attachment pagination loop.');
        }
      } while (nextLink != null);
      return items;
    });

final microsoftCalendarApiClientForAccountProvider =
    Provider.family<MicrosoftCalendarApiClient, String>((ref, accountId) {
      final config = ref.watch(buildConfigProvider);
      final account = ref
          .watch(accountsStreamProvider)
          .valueOrNull
          ?.where((candidate) => candidate.id == accountId)
          .firstOrNull;
      final broker = ref.watch(accountTokenBrokerProvider);
      Future<String> authorization(
        MicrosoftGraphAuthorizationKind kind,
        String? claims,
      ) => broker is MicrosoftGraphAuthorizationBroker
          ? (broker as MicrosoftGraphAuthorizationBroker)
                .microsoftGraphAuthorizationHeader(
                  accountId,
                  kind,
                  claims: claims,
                )
          : claims == null
          ? switch (kind) {
              MicrosoftGraphAuthorizationKind.ordinary =>
                broker.authorizationHeader(BusyProvider.microsoft, accountId),
              MicrosoftGraphAuthorizationKind.sharedCalendar =>
                broker.microsoftSharedCalendarAuthorizationHeader(accountId),
              MicrosoftGraphAuthorizationKind.category =>
                broker.microsoftCategoryAuthorizationHeader(accountId),
            }
          : throw StateError('Claims authorization is unavailable.');
      return MicrosoftCalendarApiClient(
        httpClient: ref.watch(baseHttpClientProvider),
        baseUri: Uri.parse(config.microsoftGraphBaseUrl),
        responseTimeZone: ref.watch(localTimeZoneProvider),
        accountTenantId: account?.tenantId,
        authorizationHeaderWithClaimsProvider: (claims) =>
            authorization(MicrosoftGraphAuthorizationKind.ordinary, claims),
        sharedCalendarAuthorizationHeaderWithClaimsProvider: (claims) =>
            authorization(
              MicrosoftGraphAuthorizationKind.sharedCalendar,
              claims,
            ),
        categoryAuthorizationHeaderWithClaimsProvider: (claims) =>
            authorization(MicrosoftGraphAuthorizationKind.category, claims),
        unauthorizedRefreshProvider: () => ref
            .read(accountTokenBrokerProvider)
            .recoverUnauthorized(BusyProvider.microsoft, accountId),
      );
    });

final microsoftMasterCategoriesProvider =
    FutureProvider.family<List<MicrosoftMasterCategory>, String>(
      (ref, accountId) => ref
          .watch(microsoftCalendarApiClientForAccountProvider(accountId))
          .listMasterCategories(),
    );

final microsoftCategoryAuthorizationProvider =
    Provider<MicrosoftCategoryAuthorization?>((ref) {
      final gateway = ref.watch(applicationMicrosoftOAuthServiceProvider);
      return gateway is MicrosoftCategoryAuthorization
          ? gateway as MicrosoftCategoryAuthorization
          : null;
    });

final microsoftTodoTaskRemoteClientForAccountProvider =
    Provider.family<TaskRemoteClient, String>((ref, accountId) {
      return MicrosoftTodoTaskRemoteClient(
        client: ref.watch(microsoftTodoApiClientForAccountProvider(accountId)),
        defaultTimeZone: ref.watch(localTimeZoneProvider),
      );
    });

final taskRemoteApiClientForAccountProvider =
    Provider.family<TaskRemoteClient?, String>((ref, accountId) {
      final accounts = ref.watch(accountsStreamProvider).valueOrNull;
      AccountEntity? account;
      for (final candidate in accounts ?? const <AccountEntity>[]) {
        if (candidate.id == accountId) {
          account = candidate;
          break;
        }
      }
      if (account == null) {
        return null;
      }
      return switch (account.provider) {
        BusyProvider.microsoft => ref.watch(
          microsoftTodoTaskRemoteClientForAccountProvider(accountId),
        ),
        BusyProvider.google => ref.watch(
          googleTasksApiClientForAccountProvider(accountId),
        ),
        BusyProvider.appleICloud ||
        BusyProvider.nextcloud ||
        BusyProvider.webCal => null,
      };
    });

final calendarRemoteApiClientForAccountProvider =
    Provider.family<CloudCalendarClient?, String>((ref, accountId) {
      final accounts = ref.watch(accountsStreamProvider).valueOrNull;
      AccountEntity? account;
      for (final candidate in accounts ?? const <AccountEntity>[]) {
        if (candidate.id == accountId) {
          account = candidate;
          break;
        }
      }
      if (account == null) return null;
      return switch (account.provider) {
        BusyProvider.google => ref.watch(
          googleCalendarApiClientForAccountProvider(accountId),
        ),
        BusyProvider.microsoft => ref.watch(
          microsoftCalendarApiClientForAccountProvider(accountId),
        ),
        BusyProvider.appleICloud ||
        BusyProvider.nextcloud ||
        BusyProvider.webCal => null,
      };
    });

typedef SyncEngineForAccountFactory = SyncEngine Function(
  String accountId,
  BusyProvider provider,
);

final syncEngineForAccountFactoryProvider =
    Provider<SyncEngineForAccountFactory>((ref) {
      return (accountId, provider) {
        final apiClient = switch (provider) {
          BusyProvider.microsoft => ref.read(
            microsoftTodoTaskRemoteClientForAccountProvider(accountId),
          ),
          BusyProvider.google => ref.read(
            googleTasksApiClientForAccountProvider(accountId),
          ),
          BusyProvider.appleICloud ||
          BusyProvider.nextcloud => throw StateError(
            'DAV task accounts must use DavSynchronizationEngine.',
          ),
          BusyProvider.webCal => throw StateError(
            'WebCal subscriptions do not have a task client.',
          ),
        };

        return SyncEngine(
          database: ref.read(databaseProvider),
          apiClient: apiClient,
          accountId: accountId,
          fullRefreshOnly: provider == BusyProvider.microsoft,
          onTaskListIdReplaced: (oldId, newId) => ref
              .read(appSettingsControllerProvider.notifier)
              .replaceSidebarId(
                SidebarOrderSection.taskLists,
                oldId,
                newId,
                accountId: accountId,
              ),
          onConflictBlocked: ref
              .read(operationalNotificationReporterProvider)
              .notifyConflict,
        );
      };
    });

typedef CalendarSyncEngineForAccountFactory = CalendarSyncEngine Function(
  String accountId,
  BusyProvider provider,
);

final calendarSyncEngineForAccountFactoryProvider =
    Provider<CalendarSyncEngineForAccountFactory>((ref) {
      return (accountId, provider) {
        final CloudCalendarClient client = switch (provider) {
          BusyProvider.microsoft => ref.read(
            microsoftCalendarApiClientForAccountProvider(accountId),
          ),
          BusyProvider.google => ref.read(
            googleCalendarApiClientForAccountProvider(accountId),
          ),
          BusyProvider.appleICloud ||
          BusyProvider.nextcloud => throw StateError(
            'DAV calendar accounts must use DavSynchronizationEngine.',
          ),
          BusyProvider.webCal => throw StateError(
            'WebCal subscriptions use WebCalSubscriptionService.',
          ),
        };
        return CalendarSyncEngine(
          database: ref.read(databaseProvider),
          client: client,
          accountId: accountId,
          onCalendarSourceIdReplaced: (oldId, newId) => ref
              .read(appSettingsControllerProvider.notifier)
              .replaceSidebarId(
                SidebarOrderSection.calendars,
                oldId,
                newId,
                accountId: accountId,
              ),
          onConflictBlocked: ref
              .read(operationalNotificationReporterProvider)
              .notifyConflict,
          onNotificationScheduleChanged: () =>
              ref.read(notificationReconcilerProvider).reconcile(),
        );
      };
    });

typedef DavAccountSyncEngineFactory = DavAccountSyncEngine Function(
  String accountId,
);

final davAccountSyncEngineFactoryProvider =
    Provider<DavAccountSyncEngineFactory>((ref) {
      return (accountId) => DavAccountSyncEngine(
        database: ref.read(databaseProvider),
        secretStore: ref.read(secretStoreProvider),
        httpClient: ref.read(baseHttpClientProvider),
        accountId: accountId,
        rebuildNotifications: (accountId, _) async {
          await NotificationScheduleService(
            database: ref.read(databaseProvider),
          ).rebuildUpcomingNotifications(accountId);
          await ref.read(notificationReconcilerProvider).reconcile();
        },
        reportPendingMutationFailure: (accountId, error) => ref
            .read(operationalNotificationReporterProvider)
            .notifySyncFailure(error),
      );
    });

final accountSyncCoordinatorProvider = Provider<AccountSyncCoordinator>((ref) {
  final accountsRepository = ref.watch(accountsRepositoryProvider);
  final coordinator = AccountSyncCoordinator(
    restoreIncompleteTaskImports:
        accountsRepository.incompleteTaskImportAccountIds,
    persistTaskImportIncomplete: accountsRepository.setTaskImportIncomplete,
  );
  ref.onDispose(() => unawaited(coordinator.dispose()));
  return coordinator;
});

final crossEngineAccountGateProvider = Provider<CrossEngineAccountGate>(
  (ref) => const InProcessAccountGate(),
);

/// Range snapshots share the account locks used by baseline sync and writes.
final calendarMonthRetrieverProvider = Provider<CalendarMonthRetriever>((ref) {
  final gate = ref.watch(crossEngineAccountGateProvider);
  final coordinator = ref.watch(accountSyncCoordinatorProvider);
  final connectivity = ref.watch(networkConnectivityMonitorProvider);
  final engineForAccount = ref.watch(
    calendarSyncEngineForAccountFactoryProvider,
  );
  return (accountId, provider, month, {required sourceIds}) => gate.run(
    accountId,
    () => coordinator.run(accountId, () async {
      await connectivity.requireNetwork();
      await engineForAccount(
        accountId,
        provider,
      ).retrieveMonth(month, sourceIds: sourceIds);
    }),
  );
});

final accountSyncOperationsProvider = Provider<AccountSyncOperations>((ref) {
  final accountsRepository = ref.watch(accountsRepositoryProvider);
  final connectivity = ref.watch(networkConnectivityMonitorProvider);
  final syncCoordinator = ref.watch(accountSyncCoordinatorProvider);

  Future<BusyProvider> providerForAccount(String accountId) async {
    final account = await accountsRepository.accountById(accountId);
    if (account == null) {
      throw StateError('Account $accountId is unavailable.');
    }
    return account.provider;
  }

  final routing = RoutingAccountSyncOperations(
    providerForAccount: providerForAccount,
    syncDav: (accountId, {required full}) => syncCoordinator.trackTaskImport(
      accountId,
      () => ref
          .read(davAccountSyncEngineFactoryProvider)(accountId)
          .synchronize(full: full),
    ),
    syncWebCal: (accountId, {required full}) => ref
        .read(webCalSubscriptionServiceProvider)
        .refreshAccount(accountId, force: full),
    syncTasksRest: (accountId, {required full}) async {
      final provider = await providerForAccount(accountId);
      final engine = ref.read(syncEngineForAccountFactoryProvider)(
        accountId,
        provider,
      );
      await DomainSyncPolicy(ref.read(databaseProvider)).run(
        accountId,
        SyncDomain.tasks,
        full: full,
        deferred: engine.dispatchPendingWrites,
        maintainCached: engine.maintainCachedReminders,
        pull: () => syncCoordinator.trackTaskImport(accountId, () async {
          if (full) {
            await engine.fullSync();
          } else {
            await engine.incrementalSync();
          }
        }, changedOnFailure: () => engine.remoteImportWroteData),
      );
    },
    syncCalendarRest: (accountId, {required full}) async {
      final provider = await providerForAccount(accountId);
      final engine = ref.read(calendarSyncEngineForAccountFactoryProvider)(
        accountId,
        provider,
      );
      await DomainSyncPolicy(ref.read(databaseProvider)).run(
        accountId,
        SyncDomain.calendar,
        full: full,
        deferred: engine.dispatchPendingWrites,
        maintainCached: engine.maintainCachedReminders,
        pull: () async {
          if (full) {
            await engine.fullSync();
          } else {
            await engine.incrementalSync();
          }
        },
      );
    },
  );
  return CrossEngineCoordinatedAccountSyncOperations(
    gate: ref.watch(crossEngineAccountGateProvider),
    inner: CoordinatedAccountSyncOperations(
      coordinator: syncCoordinator,
      inner: ConnectivityAwareAccountSyncOperations(
        inner: routing,
        requireNetwork: connectivity.requireNetwork,
      ),
    ),
  );
});

typedef SignedInSyncRunner = Future<void> Function(
  String accountId,
  bool initial,
);

final signedInSyncRunnerProvider = Provider<SignedInSyncRunner>((ref) {
  return (accountId, initial) async {
    try {
      await _runAccountSyncIfEligible(
        ref,
        accountId,
        (operations) => withSyncTrigger(
          initial ? SyncTrigger.manual : SyncTrigger.foreground,
          () => operations.syncAccount(accountId, full: initial),
        ),
      );
    } on Object catch (error) {
      await _markAccountReconnectRequiredForSyncError(ref, accountId, error);
      rethrow;
    }
  };
});

typedef AllAccountsSyncRunner = Future<void> Function();

final allAccountsSyncRunnerProvider = Provider<AllAccountsSyncRunner>((ref) {
  Future<void> syncAccount(String accountId) async {
    await _runAccountSyncIfEligible(
      ref,
      accountId,
      (operations) => operations.syncAccount(accountId, full: false),
    );
  }

  return () async {
    await ref.read(networkConnectivityMonitorProvider).requireNetwork();
    await runAllSyncEligibleAccountSync(
      listSyncEligibleAccounts: ref
          .read(accountsRepositoryProvider)
          .listSyncEligibleAccounts,
      syncAccount: syncAccount,
      rethrowFirstFailure: true,
      onSyncFailure: ref
          .read(operationalNotificationReporterProvider)
          .notifySyncFailure,
      onAccountSyncFailure: (accountId, error) =>
          _markAccountReconnectRequiredForSyncError(ref, accountId, error),
    );
  };
});

final StateNotifierProvider<AuthSessionController, AuthSessionState>
authSessionControllerProvider =
    StateNotifierProvider<AuthSessionController, AuthSessionState>((ref) {
      final config = ref.watch(buildConfigProvider);
      return AuthSessionController(
        repository: ref.watch(authRepositoryProvider),
        isConfigured: config.hasAnyProviderConfigured,
        onSignedIn: ref.read(signedInSyncRunnerProvider),
      );
    });

final calendarRepositoryProvider = Provider<CalendarRepository>((ref) {
  return CalendarRepository(
    database: ref.watch(databaseProvider),
    localTimeZone: ref.watch(localTimeZoneProvider),
    nextcloudCollections: (accountId) =>
        ref.read(nextcloudCollectionServiceProvider(accountId)),
    onNotificationScheduleChanged: () =>
        ref.read(notificationReconcilerProvider).reconcile(),
  );
});

final microsoftSharedCalendarServiceProvider =
    Provider<MicrosoftSharedCalendarService>((ref) {
      final gateway = ref.read(applicationMicrosoftOAuthServiceProvider);
      if (gateway is! MicrosoftSharedCalendarAuthorization) {
        throw StateError(
          'Microsoft shared-calendar authorization is unavailable.',
        );
      }
      return MicrosoftSharedCalendarService(
        authorization: gateway as MicrosoftSharedCalendarAuthorization,
        clientForAccount: (accountId) =>
            ref.read(microsoftCalendarApiClientForAccountProvider(accountId)),
        repository: ref.read(calendarRepositoryProvider),
        retrieveMonth: ref.watch(calendarMonthRetrieverProvider),
        now: DateTime.now,
      );
    });

final calendarSourcesStreamProvider =
    StreamProvider<List<CalendarSourceEntity>>((ref) {
      final accounts =
          ref.watch(accountManagementStreamProvider).valueOrNull ?? const [];
      return ref.watch(calendarRepositoryProvider).watchSourcesForAccounts([
        for (final account in accounts)
          if (account.calendarsEnabled) account.id,
      ]);
    });

final webCalHttpTransportProvider = Provider<WebCalHttpTransport>(
  (ref) => IoWebCalHttpTransport(),
);

final webCalSubscriptionServiceProvider = Provider<WebCalSubscriptionService>((
  ref,
) {
  return WebCalSubscriptionService(
    database: ref.watch(databaseProvider),
    secretStore: ref.watch(secretStoreProvider),
    httpTransport: ref.watch(webCalHttpTransportProvider),
    onNotificationScheduleChanged: () =>
        ref.read(notificationReconcilerProvider).reconcile(),
  );
});

final webCalSubscriptionsProvider =
    StreamProvider<List<WebCalSubscriptionEntity>>((ref) {
      return ref.watch(webCalSubscriptionServiceProvider).watchSubscriptions();
    });

final icalImportServiceProvider = Provider<IcalImportService>((ref) {
  return IcalImportService(
    database: ref.watch(databaseProvider),
    calendarRepository: ref.watch(calendarRepositoryProvider),
    onNativeImported: (accountId) async {
      try {
        await NotificationScheduleService(database: ref.read(databaseProvider))
            .rebuildUpcomingNotifications(accountId);
        await ref.read(notificationReconcilerProvider).reconcile();
      } finally {
        ref
            .read(
              pendingCalendarMutationSyncRequesterForAccountProvider(accountId),
            )
            .request();
      }
    },
  );
});

final davProjectionCoverageServiceProvider =
    Provider<DavProjectionCoverageService>((ref) {
      return DavProjectionCoverageService(
        database: ref.watch(databaseProvider),
      );
    });

/// One invalidation source for all presentations, including background sync.
final scheduleDataRevisionProvider = StreamProvider<int>((ref) async* {
  final changes = ref.watch(scheduleRepositoryProvider).watchChanges();
  var revision = 0;
  yield revision;
  await for (final _ in changes) {
    yield ++revision;
  }
});

final scheduleTaskListsProvider = FutureProvider<List<TaskListEntity>>((
  ref,
) async {
  ref.watch(scheduleDataRevisionProvider);
  final accounts = await ref.watch(accountsStreamProvider.future);
  final groups = await Future.wait([
    for (final account in accounts.where((account) => account.isTaskCapable))
      ref
          .watch(taskListsRepositoryForAccountProvider(account.id))
          .listTaskLists(),
  ]);
  return [for (final group in groups) ...group];
});

final scheduleRepositoryProvider = Provider<ScheduleRepository>((ref) {
  return ScheduleRepository(
    ref.watch(databaseProvider),
    ensureCloudCoverage: (range, filters) => ref
        .read(cloudCalendarRangeCoverageServiceProvider)
        .ensureRange(
          range.start.toUtc(),
          range.end.toUtc(),
          accountIds: filters.accountIds,
          sourceIds: filters.sourceIds,
          sourceFilterActive: filters.sourceFilterActive,
        ),
    ensureProjectionCoverage: (range) async {
      final start = range.start.toUtc();
      final end = range.end.toUtc();
      await Future.wait([
        ref
            .read(webCalSubscriptionServiceProvider)
            .ensureProjectionCoverage(rangeStartUtc: start, rangeEndUtc: end),
        ref
            .read(davProjectionCoverageServiceProvider)
            .ensureProjectionCoverage(rangeStartUtc: start, rangeEndUtc: end),
      ]);
    },
  );
});

final cloudCalendarRangeCoverageServiceProvider =
    Provider<CloudCalendarRangeCoverageService>((ref) {
      return CloudCalendarRangeCoverageService(
        database: ref.watch(databaseProvider),
        retrieveMonth: ref.watch(calendarMonthRetrieverProvider),
      );
    });

final Provider<String?> activeAccountProvider = Provider<String?>((ref) {
  final selectedAccount = ref.watch(selectedAccountProvider);
  if (selectedAccount != null) {
    return selectedAccount.id;
  }
  final session = ref.watch(authSessionControllerProvider);
  return session.isSignedIn ? session.accountId : null;
});

final googleTasksApiClientProvider = Provider<TaskRemoteClient?>((ref) {
  final accountId = ref.watch(activeAccountProvider);
  if (accountId == null) {
    return null;
  }
  return ref.watch(taskRemoteApiClientForAccountProvider(accountId));
});

final davTaskListMutationClientForAccountProvider =
    Provider.family<DavTaskListMutationClient, String>((ref, accountId) {
      return DavTaskListMutationService(
        database: ref.watch(databaseProvider),
        secretStore: ref.watch(secretStoreProvider),
        httpClient: ref.watch(baseHttpClientProvider),
        accountId: accountId,
        refreshAfterMutation: () =>
            ref.read(signedInSyncRunnerProvider)(accountId, true),
        requireNetwork: ref
            .watch(networkConnectivityMonitorProvider)
            .requireNetwork,
      );
    });

final nextcloudCollectionServiceProvider =
    Provider.family<NextcloudCollectionService, String>(
      (ref, accountId) => NextcloudCollectionService(
        database: ref.watch(databaseProvider),
        secrets: ref.watch(secretStoreProvider),
        client: ref.watch(baseHttpClientProvider),
        accountId: accountId,
        requireNetwork: ref
            .watch(networkConnectivityMonitorProvider)
            .requireNetwork,
        refresh: () => ref.read(signedInSyncRunnerProvider)(accountId, true),
      ),
    );
final nextcloudNativeExportServiceProvider =
    Provider<NextcloudNativeExportService>(
      (ref) => NextcloudNativeExportService(ref.watch(databaseProvider)),
    );
final nextcloudSharingServiceProvider =
    Provider.family<NextcloudSharingService, String>(
      (ref, accountId) => NextcloudSharingService(
        ref.watch(nextcloudCollectionServiceProvider(accountId)),
      ),
    );
final nextcloudTrashServiceProvider =
    Provider.family<NextcloudTrashService, String>(
      (ref, accountId) => NextcloudTrashService(
        ref.watch(nextcloudCollectionServiceProvider(accountId)),
      ),
    );

final nextcloudSchedulingServiceProvider =
    Provider.family<NextcloudSchedulingService, String>(
      (ref, accountId) => NextcloudSchedulingService(
        ref.watch(nextcloudCollectionServiceProvider(accountId)),
      ),
    );

final davCalendarCollectionMutationClientForAccountProvider =
    Provider.family<DavCalendarCollectionMutationClient, String>((
      ref,
      accountId,
    ) {
      return DavCalendarCollectionMutationService(
        database: ref.watch(databaseProvider),
        secretStore: ref.watch(secretStoreProvider),
        httpClient: ref.watch(baseHttpClientProvider),
        accountId: accountId,
        refreshAfterMutation: () =>
            ref.read(signedInSyncRunnerProvider)(accountId, true),
        requireNetwork: ref
            .watch(networkConnectivityMonitorProvider)
            .requireNetwork,
      );
    });

final calendarCollectionCreationServiceProvider =
    Provider<CalendarCollectionCreator>((ref) {
      return CalendarCollectionCreationService(
        accountsRepository: ref.watch(accountsRepositoryProvider),
        calendarRepository: ref.watch(calendarRepositoryProvider),
        davClientForAccount: (accountId) => ref.read(
          davCalendarCollectionMutationClientForAccountProvider(accountId),
        ),
        requestCloudSynchronization: (accountId) => ref
            .read(
              pendingCalendarMutationSyncRequesterForAccountProvider(accountId),
            )
            .request(),
      );
    });

final taskListsRepositoryProvider = Provider<TaskListsRepository?>((ref) {
  final accountId = ref.watch(activeAccountProvider);
  if (accountId == null) {
    return null;
  }
  return TaskListsRepository(
    database: ref.watch(databaseProvider),
    accountId: accountId,
    apiClient: ref.watch(googleTasksApiClientProvider),
    davMutationClient: ref.watch(
      davTaskListMutationClientForAccountProvider(accountId),
    ),
    onMutationQueued: ref.watch(pendingMutationSyncRequesterProvider)?.request,
    onNotificationScheduleChanged: () =>
        ref.read(notificationReconcilerProvider).reconcile(),
  );
});

final taskListsRepositoryForAccountProvider =
    Provider.family<TaskListsRepository, String>((ref, accountId) {
      return TaskListsRepository(
        database: ref.watch(databaseProvider),
        accountId: accountId,
        apiClient: ref.watch(taskRemoteApiClientForAccountProvider(accountId)),
        davMutationClient: ref.watch(
          davTaskListMutationClientForAccountProvider(accountId),
        ),
        onMutationQueued: ref
            .watch(pendingMutationSyncRequesterForAccountProvider(accountId))
            .request,
        onNotificationScheduleChanged: () =>
            ref.read(notificationReconcilerProvider).reconcile(),
      );
    });

final tasksRepositoryProvider = Provider<TasksRepository?>((ref) {
  final accountId = ref.watch(activeAccountProvider);
  if (accountId == null) {
    return null;
  }
  return TasksRepository(
    database: ref.watch(databaseProvider),
    accountId: accountId,
    apiClient: ref.watch(googleTasksApiClientProvider),
    onMutationQueued: ref.watch(pendingMutationSyncRequesterProvider)?.request,
    onNotificationScheduleChanged: () =>
        ref.read(notificationReconcilerProvider).reconcile(),
  );
});

final tasksRepositoryForAccountProvider =
    Provider.family<TasksRepository, String>((ref, accountId) {
      return TasksRepository(
        database: ref.watch(databaseProvider),
        accountId: accountId,
        apiClient: ref.watch(taskRemoteApiClientForAccountProvider(accountId)),
        onMutationQueued: ref
            .watch(pendingMutationSyncRequesterForAccountProvider(accountId))
            .request,
        onNotificationScheduleChanged: () =>
            ref.read(notificationReconcilerProvider).reconcile(),
      );
    });

final pendingMutationSyncRequesterProvider =
    Provider<PendingMutationSyncRequester?>((ref) {
      final accountId = ref.watch(activeAccountProvider);
      if (accountId == null) {
        return null;
      }

      final requester = PendingMutationSyncRequester(
        sync: () => _runAccountSyncIfEligible(
          ref,
          accountId,
          (operations) => operations.syncTasks(accountId, full: false),
        ),
        onSyncFailure: ref
            .watch(operationalNotificationReporterProvider)
            .notifySyncFailure,
        onSyncError: (error) =>
            _markAccountReconnectRequiredForSyncError(ref, accountId, error),
        canSync: ref.watch(networkConnectivityMonitorProvider).canUseNetwork,
      );
      ref.onDispose(requester.dispose);
      return requester;
    });

final pendingMutationSyncRequesterForAccountProvider =
    Provider.family<PendingMutationSyncRequester, String>((ref, accountId) {
      final requester = PendingMutationSyncRequester(
        sync: () => _runAccountSyncIfEligible(
          ref,
          accountId,
          (operations) => operations.syncTasks(accountId, full: false),
        ),
        onSyncFailure: ref
            .watch(operationalNotificationReporterProvider)
            .notifySyncFailure,
        onSyncError: (error) =>
            _markAccountReconnectRequiredForSyncError(ref, accountId, error),
        canSync: ref.watch(networkConnectivityMonitorProvider).canUseNetwork,
      );
      ref.onDispose(requester.dispose);
      return requester;
    });

final pendingCalendarMutationSyncRequesterForAccountProvider =
    Provider.family<PendingMutationSyncRequester, String>((ref, accountId) {
      final requester = PendingMutationSyncRequester(
        sync: () => _runAccountSyncIfEligible(
          ref,
          accountId,
          (operations) => operations.syncCalendar(accountId, full: false),
        ),
        onSyncFailure: ref
            .watch(operationalNotificationReporterProvider)
            .notifySyncFailure,
        onSyncError: (error) =>
            _markAccountReconnectRequiredForSyncError(ref, accountId, error),
        canSync: ref.watch(networkConnectivityMonitorProvider).canUseNetwork,
      );
      ref.onDispose(requester.dispose);
      return requester;
    });

final pendingOpResolutionServiceForAccountProvider =
    Provider.family<PendingOpResolutionService, String>((ref, accountId) {
      return PendingOpResolutionService(
        database: ref.watch(databaseProvider),
        apiClient: ref.watch(taskRemoteApiClientForAccountProvider(accountId)),
        calendarClient: ref.watch(
          calendarRemoteApiClientForAccountProvider(accountId),
        ),
        accountId: accountId,
        syncTasks: () => _runAccountSyncIfEligible(
          ref,
          accountId,
          (operations) => operations.syncTasks(accountId, full: false),
        ),
        syncCalendar: () => _runAccountSyncIfEligible(
          ref,
          accountId,
          (operations) => operations.syncCalendar(accountId, full: false),
        ),
        onNotificationScheduleChanged: () =>
            ref.read(notificationReconcilerProvider).reconcile(),
      );
    });

final pendingOpResolutionServiceProvider =
    Provider<PendingOpResolutionService?>((ref) {
      final accountId = ref.watch(activeAccountProvider);
      if (accountId == null) {
        return null;
      }
      return ref.watch(pendingOpResolutionServiceForAccountProvider(accountId));
    });

final syncSchedulerProvider = Provider<AllAccountsSyncScheduler>((ref) {
  Future<void> syncAccount(String accountId) async {
    await _runAccountSyncIfEligible(
      ref,
      accountId,
      (operations) => withSyncTrigger(
        SyncTrigger.background,
        () => operations.syncAccount(accountId, full: false),
      ),
    );
  }

  final scheduler = AllAccountsSyncScheduler(
    listSyncEligibleAccounts: ref
        .read(accountsRepositoryProvider)
        .listSyncEligibleAccounts,
    syncAccount: syncAccount,
    onSyncFailure: ref
        .watch(operationalNotificationReporterProvider)
        .notifySyncFailure,
    onAccountSyncFailure: (accountId, error) =>
        _markAccountReconnectRequiredForSyncError(ref, accountId, error),
    canSync: ref.watch(networkConnectivityMonitorProvider).canUseNetwork,
  );
  scheduler.start();
  ref.onDispose(() => unawaited(scheduler.dispose()));
  return scheduler;
});

final syncSchedulerRunningProvider = StreamProvider<bool>((ref) {
  return ref.watch(syncSchedulerProvider).watchRunning();
});

final trayPresentationServiceProvider =
    Provider<BusyMaxTrayPresentationService>((ref) {
      return BusyMaxTrayPresentationService(
        accountsRepository: ref.watch(accountsRepositoryProvider),
        calendarRepository: ref.watch(calendarRepositoryProvider),
        scheduleRepository: ref.watch(scheduleRepositoryProvider),
        listTaskLists: (account) => ref
            .read(taskListsRepositoryForAccountProvider(account.id))
            .listTaskLists(),
        canCreateTask: (account, taskList) async {
          if (account.provider == BusyProvider.google ||
              account.provider == BusyProvider.microsoft) {
            return adapterDefaultTaskCapabilities(account.provider)
                .canCreateTasks;
          }
          if (account.provider != BusyProvider.nextcloud) return false;
          final capabilities = await ref.read(
            davTaskCollectionCapabilitiesProvider((
              accountId: account.id,
              taskListId: taskList.id,
            )).future,
          );
          return capabilities?.canCreateTasks == true;
        },
        settings: () => ref.read(appSettingsControllerProvider),
        connectivity: () =>
            ref.read(networkConnectivityMonitorProvider).availability,
        synchronizationRunning: () => ref.read(syncSchedulerProvider).isRunning,
      );
    });

Future<void> _markAccountReconnectRequiredForSyncError(
  Ref ref,
  String accountId,
  Object error,
) async {
  final account = await ref
      .read(accountsRepositoryProvider)
      .accountById(accountId);
  if (account?.isAuthenticationAccount != true) return;
  if (syncFailureNotificationDisposition(error) !=
      SyncFailureNotificationDisposition.reconnectRequired) {
    return;
  }
  try {
    await ref
        .read(authRepositoryProvider)
        .markReconnectRequired(
          accountId,
          authorizationGeneration: failureAuthorizationGeneration(
            error,
            accountId,
          ),
        );
  } on Object {
    // Keep the original sync failure as the reported error.
  }
}

Future<void> _runAccountSyncIfEligible(
  Ref ref,
  String accountId,
  Future<void> Function(AccountSyncOperations operations) synchronize,
) async {
  final account = await ref
      .read(accountsRepositoryProvider)
      .accountById(accountId);
  if (account?.isSyncEligible != true) {
    return;
  }
  final generation = await ref
      .read(authorizationPersistenceProvider)
      .generation(accountId);
  try {
    await synchronize(ref.read(accountSyncOperationsProvider));
  } on Object catch (error) {
    throw AuthorizationScopedFailure(
      accountId: accountId,
      generation: generation,
      cause: error,
    );
  }
}

// This handler outlives individual schedulers, so a visible Linux notification
// can route to the current scheduler even after an explicit invalidation.
final _reminderActionHandlerProvider = Provider<ScheduledReminderActionHandler>(
  (ref) =>
      (row, action) => ref
          .read(notificationSchedulerProvider)
          .handleReminderAction(row, action),
);

final Provider<NotificationScheduler> notificationSchedulerProvider =
    Provider<NotificationScheduler>((ref) {
      final scheduler = NotificationScheduler(
        database: ref.watch(databaseProvider),
        notifications: ref.read(desktopNotificationServiceProvider),
        // Read the independent router without making it a dependency of the
        // scheduler it resolves when an action arrives.
        onReminderAction: ref.read(_reminderActionHandlerProvider),
        onNotificationActivated: (row) => _openNotificationSource(ref, row),
      );
      ref.listen(desktopNotificationServiceProvider, (_, notifications) {
        scheduler.updateNotifications(notifications);
      });
      scheduler.start();
      ref.onDispose(scheduler.stop);
      return scheduler;
    });

final notificationReconcilerProvider = Provider<NotificationReconciler>(
  (ref) => CallbackNotificationReconciler(
    ref.watch(notificationSchedulerProvider).checkNow,
  ),
);

final _notificationOpenSequenceProvider = StateProvider<int>((ref) => 0);

Future<void> _openNotificationSource(
  Ref ref,
  NotificationScheduleData row,
) async {
  return switch (row.sourceType) {
    'event' => _openEventNotification(ref, row),
    'task' => _openTaskNotification(ref, row),
    _ => ref.read(desktopWindowServiceProvider).showWindow(),
  };
}

Future<void> _openEventNotification(
  Ref ref,
  NotificationScheduleData row,
) async {
  final database = ref.read(databaseProvider);
  final event =
      await (database.select(database.calendarEvents)..where(
            (table) =>
                table.accountId.equals(row.accountId) &
                table.id.equals(row.sourceId) &
                table.isDeleted.equals(false) &
                table.isCancelled.equals(false),
          ))
          .getSingleOrNull();
  if (event == null) {
    await ref.read(desktopWindowServiceProvider).showWindow();
    return;
  }

  await _openScheduleItemFromNotification(
    ref,
    kind: ScheduleWorkspaceCommandKind.openCalendarEvent,
    date: calendarEventStartAsLocal(event),
    accountId: event.accountId,
    sourceId: event.calendarSourceId,
    itemId: event.id,
  );
}

Future<void> _openTaskNotification(
  Ref ref,
  NotificationScheduleData row,
) async {
  final database = ref.read(databaseProvider);
  final task =
      await (database.select(database.tasks)
            ..where(
              (table) =>
                  table.accountId.equals(row.accountId) &
                  table.id.equals(row.sourceId) &
                  table.pendingDelete.equals(false),
            )
            ..limit(1))
          .getSingleOrNull();
  if (task == null) {
    await ref.read(desktopWindowServiceProvider).showWindow();
    return;
  }

  await _openScheduleItemFromNotification(
    ref,
    kind: ScheduleWorkspaceCommandKind.openTask,
    date: _taskCommandDate(task),
    accountId: task.accountId,
    sourceId: task.taskListId,
    itemId: task.id,
  );
}

Future<void> _openScheduleItemFromNotification(
  Ref ref, {
  required ScheduleWorkspaceCommandKind kind,
  required DateTime? date,
  required String accountId,
  required String sourceId,
  required String itemId,
}) async {
  await ref.read(desktopWindowServiceProvider).showWindow();
  final sequenceController = ref.read(
    _notificationOpenSequenceProvider.notifier,
  );
  final sequence = sequenceController.state + 1;
  sequenceController.state = sequence;
  ref
      .read(scheduleWorkspaceCommandProvider.notifier)
      .state = ScheduleWorkspaceCommand(
    kind,
    sequence,
    date: date,
    accountId: accountId,
    sourceId: sourceId,
    itemId: itemId,
  );
  ref
      .read(desktopNavigationServiceProvider)
      .open(DesktopNavigationDestination.schedule);
}

DateTime? _taskCommandDate(Task task) {
  return providerDateTimeAsLocal(
        task.microsoftDueDateTime,
        task.microsoftDueTimeZone,
      ) ??
      providerDateTimeAsLocal(
        task.microsoftReminderDateTime,
        task.microsoftReminderTimeZone,
      ) ??
      taskDueAsLocal(task);
}

final dueTodayNotificationProvider = Provider<DueTodayNotificationScheduler>((
  ref,
) {
  final scheduler = DueTodayNotificationScheduler(
    database: ref.watch(databaseProvider),
    settings: () => ref.read(appSettingsControllerProvider),
    activeAccountId: () => ref.read(activeAccountProvider),
    notifications: () => ref.read(desktopNotificationServiceProvider),
    markNotified: (date) => ref
        .read(appSettingsControllerProvider.notifier)
        .markDueTodayNotified(date),
    syncBlocksDelivery: ref.read(accountSyncCoordinatorProvider).blocksDueToday,
    accountSyncChanges: ref.read(accountSyncCoordinatorProvider).runningChanges,
  );
  ref.listen(
    appSettingsControllerProvider,
    (_, _) => scheduler.inputsChanged(),
  );
  ref.listen(activeAccountProvider, (_, _) => scheduler.inputsChanged());
  scheduler.start();
  ref.onDispose(scheduler.stop);
  return scheduler;
});
