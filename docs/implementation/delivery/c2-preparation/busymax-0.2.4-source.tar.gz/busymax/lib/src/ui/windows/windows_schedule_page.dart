import 'package:busymax/src/l10n/time_format_scope.dart';
import 'package:busymax/src/l10n/week_preferences_scope.dart';
import 'dart:async';
import '../../providers/busy_provider.dart';
import 'dart:math' as math;

import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../../../l10n/generated/app_localizations.dart';
import '../../app/app_bootstrap.dart';
import '../../app/busymax_shortcuts.dart';
import '../../app/common/busymax_design_values.dart';
import '../../app/common/busymax_motion_widgets.dart';
import '../../app/common/busymax_mutation_list.dart';
import '../../calendar_providers/calendar_mutation.dart';
import '../../features/accounts/data/accounts_repository.dart';
import '../../features/calendar/data/calendar_repository.dart';
import '../../features/calendar/presentation/event_editor_draft.dart';
import '../../features/calendar/presentation/google_status_event_labels.dart';
import '../../features/schedule/presentation/schedule_item_exporter.dart';
import '../../features/schedule/presentation/cloud_calendar_series_export.dart';
import '../../features/task_lists/data/task_lists_repository.dart';
import '../../features/tasks/domain/task_capabilities.dart';
import '../../schedule/schedule_filters.dart';
import '../../schedule/schedule_commands.dart';
import '../../schedule/schedule_projection.dart';
import '../../schedule/schedule_item.dart';
import '../../features/maps/application/external_location_launcher.dart';
import '../../features/schedule/application/saved_schedule_location.dart';
import '../../schedule/schedule_event_rescheduling.dart';
import '../../features/calendar/domain/event_timing_policy.dart';
import '../../features/tasks/data/tasks_repository.dart';
import '../../features/tasks/domain/task_mutation_result.dart';
import '../common/schedule/schedule_interactions.dart';
import '../common/schedule/schedule_preview_label.dart';
import 'windows_schedule_day_week_view.dart';
import 'windows_event_attachments_dialog.dart';
import '../../schedule/schedule_range.dart';
import '../../schedule/schedule_navigation_intent.dart';
import '../../schedule/schedule_source_visibility.dart';
import '../../schedule/schedule_view_mode.dart';
import '../../schedule/task_list_mutation_intent.dart';
import '../common/busymax_glyph.dart';
import 'windows_busymax_glyphs.dart';
import 'windows_calendar_activation_flows.dart';
import 'windows_event_editor_dialog.dart';
import 'windows_guest_update_dialog.dart';
import 'windows_schedule_source_pane.dart';
import 'windows_schedule_search_pane.dart';
import '../../schedule/schedule_search_criteria.dart';
import '../../features/schedule/presentation/schedule_search_result_text.dart';
import '../../features/schedule/presentation/schedule_event_details_format.dart';
import 'windows_task_details_dialog.dart';
import 'windows_task_editor_dialog.dart';

class WindowsSchedulePage extends ConsumerStatefulWidget {
  const WindowsSchedulePage({super.key, this.externalLocationLauncher});

  final ExternalLocationLauncher? externalLocationLauncher;

  @override
  ConsumerState<WindowsSchedulePage> createState() =>
      _WindowsSchedulePageState();
}

class _WindowsSchedulePageState extends ConsumerState<WindowsSchedulePage> {
  final _searchController = TextEditingController();
  final _searchFocusNode = FocusNode();
  var _selectedDate = DateTime.now();
  var _query = '';
  bool _searchActive = false;
  bool? _sourcePaneBeforeSearch;
  ScheduleSearchCriteria? _searchCriteria;
  ScheduleSearchCriteria? _initialSearchCriteria;
  var _firstWeekday = DateTime.monday;
  ScheduleSourceVisibility? _latestVisibility;
  late ScheduleViewMode _mode;
  var _agendaDays = 30;
  var _agendaTaskLimit = 100;
  var _refreshRevision = 0;
  String? _taskListsKey;
  Future<List<TaskListEntity>>? _taskListsFuture;
  Object? _normalItemsKey;
  Future<List<ScheduleItem>>? _normalItemsFuture;
  Object? _searchItemsKey;
  Future<List<ScheduleItem>>? _searchItemsFuture;
  var _sourcePaneCollapsed = false;
  var _accountInventoryResolved = false;
  var _sourcePaneTransitionGeneration = 0;
  Timer? _searchDebounce;
  ScheduleWorkspaceCommand? _pendingCommand;
  bool _resolvingCommand = false;
  bool _commandRefreshPending = false;
  CalendarSourceEntity? _creationCalendar;
  ScheduleTaskListKey? _creationTaskList;
  var _navigationGeneration = 0;
  ScheduleNavigationIntent? _navigationIntent;
  var _taskMutationGeneration = 0;
  TaskListMutationIntent? _taskMutationIntent;

  @override
  void initState() {
    super.initState();
    _mode = ref.read(appSettingsControllerProvider).scheduleViewMode;
    _searchFocusNode.addListener(_searchFocusChanged);
    ref.listenManual(scheduleDataRevisionProvider, (previous, next) {
      if (!next.hasValue || !mounted) return;
      _reload();
      unawaited(_revealPendingCommand());
    });
    ref.listenManual(scheduleWorkspaceCommandProvider, (previous, command) {
      if (command == null) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || ref.read(scheduleWorkspaceCommandProvider) != command) {
          return;
        }
        ref.read(scheduleWorkspaceCommandProvider.notifier).state = null;
        _pendingCommand = null;
        switch (command.kind) {
          case ScheduleWorkspaceCommandKind.today:
            _openDay(DateTime.now());
          case ScheduleWorkspaceCommandKind.agenda:
            _selectDate(command.date ?? DateTime.now());
            _setMode(ScheduleViewMode.agenda);
          case ScheduleWorkspaceCommandKind.newEvent:
            unawaited(_createEvent(start: command.date));
          case ScheduleWorkspaceCommandKind.newTask:
            unawaited(_createTask());
          case ScheduleWorkspaceCommandKind.openDate:
            _openDay(command.date ?? DateTime.now());
          case ScheduleWorkspaceCommandKind.openCalendarEvent:
          case ScheduleWorkspaceCommandKind.openTask:
            _searchDebounce?.cancel();
            _searchController.clear();
            _query = '';
            _searchActive = false;
            _searchCriteria = null;
            _initialSearchCriteria = null;
            _searchFocusNode.unfocus();
            _openDay(command.date ?? DateTime.now());
            _pendingCommand = command;
            unawaited(_revealPendingCommand());
        }
      });
    }, fireImmediately: true);
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _searchController.dispose();
    _searchFocusNode.removeListener(_searchFocusChanged);
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final firstWeekday = BusyMaxWeekPreferencesScope.firstWeekdayOf(context);
    if (_firstWeekday == firstWeekday) return;
    _firstWeekday = firstWeekday;
    _searchCriteria = _searchCriteria?.copyWith(firstWeekday: firstWeekday);
    _initialSearchCriteria = _initialSearchCriteria?.copyWith(
      firstWeekday: firstWeekday,
    );
    _normalItemsKey = null;
    _searchItemsKey = null;
  }

  Future<void> _revealPendingCommand() async {
    final command = _pendingCommand;
    if (command == null) return;
    if (_resolvingCommand) {
      _commandRefreshPending = true;
      return;
    }
    _commandRefreshPending = false;
    _resolvingCommand = true;
    try {
      final repository = ref.read(scheduleRepositoryProvider);
      final filters = ScheduleFilters(
        accountIds: {if (command.accountId != null) command.accountId!},
        taskCompletion: ScheduleTaskCompletion.all,
        showNoDateTasks: true,
      );
      final items = command.kind == ScheduleWorkspaceCommandKind.openTask
          ? await repository.listAllTasks(filters: filters)
          : await repository.listItems(
              range: ScheduleRange.day(command.date ?? DateTime.now()),
              filters: filters,
            );
      if (!mounted || _pendingCommand != command) return;
      final item = items.where(command.matchesItem).firstOrNull;
      if (item == null) return; // Keep pending while initial sync supplies it.
      _pendingCommand = null;
      await _showItemDetails(item);
    } on Object catch (_) {
      if (mounted) {
        unawaited(
          displayInfoBar(
            context,
            builder: (context, close) => InfoBar(
              title: Text(AppLocalizations.of(context).scheduleUnavailable),
              severity: InfoBarSeverity.error,
              action: Button(
                onPressed: () => unawaited(_revealPendingCommand()),
                child: Text(AppLocalizations.of(context).retry),
              ),
            ),
          ),
        );
      }
    } finally {
      _resolvingCommand = false;
      if (mounted &&
          _pendingCommand != null &&
          (_pendingCommand != command || _commandRefreshPending)) {
        unawaited(_revealPendingCommand());
      }
    }
  }

  void _reload() {
    setState(() {
      _refreshRevision += 1;
      _taskListsKey = null;
      _taskListsFuture = null;
      _normalItemsKey = null;
      _normalItemsFuture = null;
      _searchItemsKey = null;
      _searchItemsFuture = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final accountsState = ref.watch(accountsStreamProvider);
    _accountInventoryResolved =
        !accountsState.isLoading && !accountsState.hasError;
    if (accountsState.isLoading && accountsState.valueOrNull == null) {
      return const ScaffoldPage(content: Center(child: ProgressRing()));
    }
    if (accountsState.hasError && accountsState.valueOrNull == null) {
      return ScaffoldPage(
        content: Center(
          child: InfoBar(
            title: Text(AppLocalizations.of(context).scheduleUnavailable),
            severity: InfoBarSeverity.error,
          ),
        ),
      );
    }
    final accounts = accountsState.valueOrNull ?? const <AccountEntity>[];
    final accountIds = [for (final account in accounts) account.id];
    return StreamBuilder<List<CalendarSourceEntity>>(
      stream: ref
          .watch(calendarRepositoryProvider)
          .watchSourcesForAccounts(accountIds),
      builder: (context, sourcesSnapshot) {
        if (sourcesSnapshot.connectionState == ConnectionState.waiting &&
            !sourcesSnapshot.hasData) {
          return const ScaffoldPage(content: Center(child: ProgressRing()));
        }
        if (sourcesSnapshot.hasError && !sourcesSnapshot.hasData) {
          return ScaffoldPage(
            content: Center(
              child: InfoBar(
                title: Text(AppLocalizations.of(context).scheduleUnavailable),
                severity: InfoBarSeverity.error,
              ),
            ),
          );
        }
        final sources = sourcesSnapshot.data ?? const <CalendarSourceEntity>[];
        return FutureBuilder<List<TaskListEntity>>(
          future: _taskListsFor(accounts),
          builder: (context, listsSnapshot) {
            if (listsSnapshot.connectionState != ConnectionState.done &&
                !listsSnapshot.hasData) {
              return const ScaffoldPage(content: Center(child: ProgressRing()));
            }
            final taskLists = listsSnapshot.data ?? const <TaskListEntity>[];
            final settings = ref.watch(appSettingsControllerProvider);
            final visibility = ScheduleSourceVisibility.fromSources(
              calendarSources: sources,
              taskLists: taskLists,
              settings: settings,
            );
            return _buildPage(
              context,
              accounts: accounts,
              sources: sources,
              taskLists: taskLists,
              visibility: visibility,
            );
          },
        );
      },
    );
  }

  Widget _buildPage(
    BuildContext context, {
    required List<AccountEntity> accounts,
    required List<CalendarSourceEntity> sources,
    required List<TaskListEntity> taskLists,
    required ScheduleSourceVisibility visibility,
  }) {
    _latestVisibility = visibility;
    if (_searchActive && _searchCriteria == null) _initializeSearch();
    final settings = ref.read(appSettingsControllerProvider);
    final allCalendars = writableCalendarSources(sources);
    final visibleCalendars = allCalendars
        .where(
          (source) => visibility.visibleCalendarSourceIds.contains(source.id),
        )
        .toList();
    _creationCalendar =
        preferredCreationDestination(
          allCalendars,
          selected: settings.defaultCalendar,
          lastUsed: settings.lastUsedCalendar,
          destinationOf: (source) =>
              CreationDestination(accountId: source.accountId, id: source.id),
        ) ??
        visibleCalendars.firstOrNull ??
        allCalendars.firstOrNull;
    final accountsById = {for (final account in accounts) account.id: account};
    final eligibleTaskLists = taskLists.where((list) {
      if (list.pendingDelete) return false;
      final account = accountsById[list.accountId];
      if (account == null || !account.isTaskCapable) return false;
      if (account.provider == BusyProvider.nextcloud) {
        return ref
                .watch(
                  davTaskCollectionCapabilitiesProvider((
                    accountId: account.id,
                    taskListId: list.id,
                  )),
                )
                .valueOrNull
                ?.canCreateTasks ==
            true;
      }
      return adapterDefaultTaskCapabilities(account.provider).canCreateTasks;
    }).toList();
    final creationTaskList =
        preferredCreationDestination(
          eligibleTaskLists,
          selected: settings.defaultTaskList,
          lastUsed: settings.lastUsedTaskList,
          destinationOf: (list) =>
              CreationDestination(accountId: list.accountId, id: list.id),
        ) ??
        eligibleTaskLists
            .where(
              (list) => visibility.visibleTaskListKeys.contains(
                ScheduleTaskListKey(
                  accountId: list.accountId,
                  taskListId: list.id,
                ),
              ),
            )
            .firstOrNull ??
        eligibleTaskLists.firstOrNull;
    _creationTaskList = creationTaskList == null
        ? null
        : ScheduleTaskListKey(
            accountId: creationTaskList.accountId,
            taskListId: creationTaskList.id,
          );
    final l10n = AppLocalizations.of(context);
    final locale = Localizations.localeOf(context).toLanguageTag();
    final range = _rangeForMode();
    final presentationMode = _mode;
    final presentationDate = _selectedDate;
    final presentationFirstWeekday = _firstWeekday;
    final presentationNavigationIntent = _navigationIntent;
    final presentationMutationIntent = _taskMutationIntent;
    final searchCriteria = _searchCriteria;
    final searchQuery = _query;
    final presentation = _searchActive && searchCriteria != null
        ? _buildSearchPresentation(
            future: _searchItemsFor(
              range: range,
              accounts: accounts,
              criteria: searchCriteria,
              query: searchQuery,
            ),
            criteria: searchCriteria,
            query: searchQuery,
            locale: locale,
            mutationIntent: presentationMutationIntent,
          )
        : _buildNormalPresentation(
            future: _normalItemsFor(
              range: range,
              accounts: accounts,
              visibility: visibility,
              mode: presentationMode,
              agendaTaskLimit: _agendaTaskLimit,
            ),
            mode: presentationMode,
            selectedDate: presentationDate,
            firstWeekday: presentationFirstWeekday,
            range: range,
            locale: locale,
            sources: sources,
            coverageFilters: ScheduleFilters(
              accountIds: {for (final account in accounts) account.id},
              sourceIds: visibility.visibleCalendarSourceIds,
              sourceFilterActive: true,
            ),
            navigationIntent: presentationNavigationIntent,
            mutationIntent: presentationMutationIntent,
          );
    return LayoutBuilder(
      builder: (context, constraints) {
        final canShowSourcePane = BusyMaxBreakpoints.showsSourcePane(
          constraints.maxWidth,
        );
        final showSourcePane = canShowSourcePane && !_sourcePaneCollapsed;
        final sourcePane = _searchActive && _searchCriteria != null
            ? _searchPane(accounts, sources, taskLists)
            : WindowsScheduleSourcePane(
                firstWeekday: _firstWeekday,
                selectedDate: _selectedDate,
                accounts: accounts,
                accountInventoryResolved: _accountInventoryResolved,
                calendarSources: sources,
                taskLists: taskLists,
                visibleCalendarSourceIds: visibility.visibleCalendarSourceIds,
                visibleTaskListKeys: visibility.visibleTaskListKeys,
                onDateSelected: _openDay,
                onCalendarVisibilityChanged: _setCalendarVisible,
                onTaskListVisibilityChanged: _setTaskListVisible,
                onAddAccount: () =>
                    unawaited(context.push<void>('/settings?page=accounts')),
                onSourcesChanged: _reload,
              );
        return CallbackShortcuts(
          bindings: {
            BusyMaxShortcutActivators.search: _focusSearch,
            BusyMaxShortcutActivators.sidebar: () {
              if (canShowSourcePane) {
                setState(() {
                  _sourcePaneCollapsed = !showSourcePane;
                  _sourcePaneTransitionGeneration += 1;
                });
              } else {
                unawaited(
                  _showSourcesDialog(
                    accounts: accounts,
                    sources: sources,
                    taskLists: taskLists,
                    visibility: visibility,
                  ),
                );
              }
            },
            BusyMaxShortcutActivators.dismiss: _dismissSearch,
            const SingleActivator(
              LogicalKeyboardKey.arrowLeft,
              shift: true,
            ): () =>
                _invokeUnmodifiedShortcut(() => _movePeriod(-1)),
            const SingleActivator(
              LogicalKeyboardKey.arrowRight,
              shift: true,
            ): () =>
                _invokeUnmodifiedShortcut(() => _movePeriod(1)),
            const SingleActivator(LogicalKeyboardKey.keyE): () =>
                _invokeUnmodifiedShortcut(() => unawaited(_createEvent())),
            const SingleActivator(LogicalKeyboardKey.keyT): () =>
                _invokeUnmodifiedShortcut(() => unawaited(_createTask())),
            const SingleActivator(LogicalKeyboardKey.keyT, shift: true): () =>
                _invokeUnmodifiedShortcut(() => _selectDate(DateTime.now())),
            const SingleActivator(LogicalKeyboardKey.digit1): () =>
                _invokeUnmodifiedShortcut(() => _setMode(ScheduleViewMode.day)),
            const SingleActivator(LogicalKeyboardKey.numpad1): () =>
                _invokeUnmodifiedShortcut(() => _setMode(ScheduleViewMode.day)),
            const SingleActivator(LogicalKeyboardKey.digit2): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.week),
                ),
            const SingleActivator(LogicalKeyboardKey.numpad2): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.week),
                ),
            const SingleActivator(LogicalKeyboardKey.digit3): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.month),
                ),
            const SingleActivator(LogicalKeyboardKey.numpad3): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.month),
                ),
            const SingleActivator(LogicalKeyboardKey.digit4): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.year),
                ),
            const SingleActivator(LogicalKeyboardKey.numpad4): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.year),
                ),
            const SingleActivator(LogicalKeyboardKey.digit5): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.agenda),
                ),
            const SingleActivator(LogicalKeyboardKey.numpad5): () =>
                _invokeUnmodifiedShortcut(
                  () => _setMode(ScheduleViewMode.agenda),
                ),
          },
          child: Focus(
            autofocus: true,
            child: ScaffoldPage(
              header: PageHeader(
                title: Text(_periodTitle(l10n, locale, range)),
                commandBar: CommandBar(
                  compactBreakpointWidth: BusyMaxBreakpoints.compact,
                  primaryItems: [
                    if (!showSourcePane)
                      CommandBarButton(
                        icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.more)),
                        label: Text(
                          _searchActive
                              ? l10n.searchFiltersAction
                              : l10n.showSidebar,
                        ),
                        onPressed: () {
                          if (canShowSourcePane) {
                            setState(() {
                              _sourcePaneCollapsed = false;
                              _sourcePaneTransitionGeneration += 1;
                            });
                          } else {
                            unawaited(
                              _showSourcesDialog(
                                accounts: accounts,
                                sources: sources,
                                taskLists: taskLists,
                                visibility: visibility,
                              ),
                            );
                          }
                        },
                      ),
                    if (!_searchActive)
                      CommandBarButton(
                        icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.today)),
                        label: Text(l10n.today),
                        onPressed: () => _selectDate(DateTime.now()),
                      ),
                    if (!_searchActive && _mode != ScheduleViewMode.agenda) ...[
                      CommandBarButton(
                        icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.previous)),
                        tooltip: l10n.shortcutPreviousPeriodDescription,
                        onPressed: () => _movePeriod(-1),
                      ),
                      CommandBarButton(
                        icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.next)),
                        tooltip: l10n.shortcutNextPeriodDescription,
                        onPressed: () => _movePeriod(1),
                      ),
                    ],
                    CommandBarButton(
                      icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                      label: Text(l10n.newEvent),
                      key: const ValueKey('windows-new-event'),
                      onPressed: _creationCalendar == null
                          ? null
                          : () => unawaited(_createEvent()),
                    ),
                  ],
                  secondaryItems: [
                    CommandBarButton(
                      icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.task)),
                      label: Text(l10n.newTask),
                      onPressed: _creationTaskList == null
                          ? null
                          : () => unawaited(_createTask()),
                    ),
                    CommandBarButton(
                      icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.refresh)),
                      label: Text(l10n.refresh),
                      onPressed: _reload,
                    ),
                    CommandBarButton(
                      icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.calendar)),
                      label: Text(l10n.importIcsFile),
                      onPressed: () => unawaited(
                        showWindowsIcsImportFlow(
                          context,
                          ref,
                        ).then((_) => _reload()),
                      ),
                    ),
                  ],
                ),
              ),
              content: Row(
                children: [
                  BusyMaxHorizontalReveal(
                    visible: showSourcePane,
                    width: BusyMaxDimensions.sourcePaneWidth + 1,
                    transitionGeneration: _sourcePaneTransitionGeneration,
                    child: Row(
                      children: [
                        SizedBox(
                          width: BusyMaxDimensions.sourcePaneWidth,
                          child: BusyMaxBinaryPresentation(
                            alternateActive: _searchActive,
                            child: sourcePane,
                          ),
                        ),
                        const Divider(direction: Axis.vertical, size: 1),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                            20,
                            0,
                            20,
                            12,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: TextBox(
                                  controller: _searchController,
                                  focusNode: _searchFocusNode,
                                  placeholder: l10n.windowsSearch,
                                  suffix: _searchActive
                                      ? Tooltip(
                                          message: l10n.searchClearText,
                                          child: IconButton(
                                            icon: const Icon(FluentIcons.clear),
                                            onPressed: () {
                                              _searchDebounce?.cancel();
                                              _searchController.clear();
                                              setState(() => _query = '');
                                            },
                                          ),
                                        )
                                      : null,
                                  prefix: Padding(
                                    padding: const EdgeInsetsDirectional.only(
                                      start: 10,
                                    ),
                                    child: Icon(
                                      windowsBusyMaxGlyph(BusyMaxGlyph.search),
                                    ),
                                  ),
                                  onChanged: (value) {
                                    if (!_searchActive) _activateSearch();
                                    _searchDebounce?.cancel();
                                    _searchDebounce = Timer(
                                      const Duration(milliseconds: 250),
                                      () {
                                        if (!mounted) return;
                                        _query = value;
                                        _reload();
                                      },
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(width: 12),
                              if (_searchActive)
                                Tooltip(
                                  message: l10n.close,
                                  child: IconButton(
                                    icon: const Icon(FluentIcons.cancel),
                                    onPressed: _dismissSearch,
                                  ),
                                )
                              else
                                _ViewModeMenu(mode: _mode, onChanged: _setMode),
                            ],
                          ),
                        ),
                        Expanded(
                          child: BusyMaxBinaryPresentation(
                            alternateActive: _searchActive,
                            child: presentation,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSearchPresentation({
    required Future<List<ScheduleItem>> future,
    required ScheduleSearchCriteria criteria,
    required String query,
    required String locale,
    required TaskListMutationIntent? mutationIntent,
  }) => FutureBuilder<List<ScheduleItem>>(
    key: const ValueKey('windows-search-presentation'),
    future: future,
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done &&
          !snapshot.hasData) {
        return const Center(child: ProgressRing());
      }
      if (snapshot.hasError) {
        return _scheduleLoadError(context);
      }
      return Column(
        children: [
          if (criteria.range case final searchRange?)
            if (ref
                    .read(scheduleRepositoryProvider)
                    .cloudCoverageCompleteFor(
                      searchRange,
                      filters: criteria.filters(query),
                    ) !=
                true)
              InfoBar(
                title: Text(
                  ref
                              .read(scheduleRepositoryProvider)
                              .cloudCoverageCompleteFor(
                                searchRange,
                                filters: criteria.filters(query),
                              ) ==
                          null
                      ? AppLocalizations.of(context).scheduleLoading
                      : AppLocalizations.of(context).scheduleRangeIncomplete,
                ),
                severity: InfoBarSeverity.info,
              ),
          Expanded(
            child: _AgendaList(
              key: const ValueKey('windows-search-results'),
              items: snapshot.data ?? const [],
              locale: locale,
              onOpen: _showItemDetails,
              searchCriteria: criteria,
              searchQuery: query,
              taskMutationIntent: mutationIntent,
              onTaskMutationConsumed: _consumeTaskMutation,
              emptyBuilder: (context) => _WindowsScheduleEmptyState(
                searching: true,
                noVisibleSources: !criteria.hasSources,
              ),
            ),
          ),
        ],
      );
    },
  );

  Widget _buildNormalPresentation({
    required Future<List<ScheduleItem>> future,
    required ScheduleViewMode mode,
    required DateTime selectedDate,
    required int firstWeekday,
    required ScheduleRange range,
    required String locale,
    required List<CalendarSourceEntity> sources,
    required ScheduleFilters coverageFilters,
    required ScheduleNavigationIntent? navigationIntent,
    required TaskListMutationIntent? mutationIntent,
  }) => FutureBuilder<List<ScheduleItem>>(
    key: const ValueKey('windows-normal-presentation'),
    future: future,
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done &&
          !snapshot.hasData) {
        return const Center(child: ProgressRing());
      }
      if (snapshot.hasError) {
        return _scheduleLoadError(context);
      }
      return Column(
        children: [
          if (ref
                  .read(scheduleRepositoryProvider)
                  .cloudCoverageCompleteFor(range, filters: coverageFilters) !=
              true)
            InfoBar(
              title: Text(
                ref
                            .read(scheduleRepositoryProvider)
                            .cloudCoverageCompleteFor(
                              range,
                              filters: coverageFilters,
                            ) ==
                        null
                    ? AppLocalizations.of(context).scheduleLoading
                    : AppLocalizations.of(context).scheduleRangeIncomplete,
              ),
              severity: InfoBarSeverity.info,
            ),
          Expanded(
            child: BusyMaxKeyedCrossfade(
              transitionKey: mode,
              child: _ScheduleModeView(
                firstWeekday: firstWeekday,
                mode: mode,
                selectedDate: selectedDate,
                range: range,
                items: snapshot.data ?? const [],
                locale: locale,
                onOpen: _showItemDetails,
                onSelectDate: _openDay,
                onLoadMoreAgenda: _loadMoreAgenda,
                onVisibleDateChanged: _selectDate,
                navigationIntent: navigationIntent,
                taskMutationIntent: mutationIntent,
                onTaskMutationConsumed: _consumeTaskMutation,
                onEmptySlot: (start) => unawaited(_createEvent(start: start)),
                onRangeCreated: writableCalendarSources(sources).isEmpty
                    ? null
                    : (interval) => unawaited(_createEvent(interval: interval)),
                onReschedule: _rescheduleEvent,
                onTaskCompletionChanged: _setTaskCompleted,
                dayStartMinute: ref
                    .read(appSettingsControllerProvider)
                    .scheduleDayStartMinute,
                dayEndMinute: ref
                    .read(appSettingsControllerProvider)
                    .scheduleDayEndMinute,
              ),
            ),
          ),
        ],
      );
    },
  );

  Widget _scheduleLoadError(BuildContext context) => Center(
    child: InfoBar(
      title: Text(AppLocalizations.of(context).scheduleUnavailable),
      severity: InfoBarSeverity.error,
      action: Button(
        onPressed: _reload,
        child: Text(AppLocalizations.of(context).retry),
      ),
    ),
  );

  Future<void> _createEvent({
    DateTime? start,
    ScheduleInterval? interval,
  }) async {
    if (_creationCalendar == null) return;
    final changed = await showWindowsEventEditorDialog(
      context,
      ref,
      initialStart: start ?? _selectedDate,
      initialInterval: interval,
      initialAccountId: _creationCalendar?.accountId,
      initialSourceId: _creationCalendar?.id,
    );
    if (changed && mounted) _reload();
  }

  Future<void> _rescheduleEvent(
    ScheduleRescheduleRequest request,
    bool Function() isActive,
  ) async {
    final l10n = AppLocalizations.of(context);
    try {
      final result = await ScheduleReschedulingCoordinator(
        repository: ref.read(calendarRepositoryProvider),
        chooseScope: (detail, following) =>
            showWindowsRecurringEventMutationScope(
              context,
              detail.provider,
              supportsFollowingOverride: following,
            ),
        chooseGuestUpdates: (_) => showWindowsGuestUpdateDialog(
          context,
          provider: request.item.provider,
          action: WindowsGuestUpdateAction.save,
        ),
        requestSync: (accountId) async => ref
            .read(
              pendingCalendarMutationSyncRequesterForAccountProvider(accountId),
            )
            .request(),
      ).commit(request, isActive: () => mounted && isActive());
      if (!mounted) return;
      _reload();
      if (result == ScheduleRescheduleResult.savedWithNotificationFailure) {
        unawaited(
          displayInfoBar(
            context,
            builder: (context, close) => InfoBar(
              title: Text(l10n.scheduleRescheduleNotificationsFailed),
              severity: InfoBarSeverity.warning,
            ),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;
      _reload();
      unawaited(
        displayInfoBar(
          context,
          builder: (context, close) => InfoBar(
            title: Text(
              error is StaleEventTiming
                  ? l10n.scheduleRescheduleStale
                  : l10n.scheduleRescheduleFailed,
            ),
            severity: InfoBarSeverity.error,
          ),
        ),
      );
    }
  }

  Future<void> _setTaskCompleted(TaskScheduleItem item, bool completed) async {
    final intent = TaskListMutationIntent(
      presentation: TaskListMutationPresentation.completion,
      accountId: item.accountId,
      taskListId: item.sourceId,
      taskId: item.id,
      completed: completed,
      generation: ++_taskMutationGeneration,
    );
    setState(() => _taskMutationIntent = intent);
    try {
      await ref
          .read(tasksRepositoryForAccountProvider(item.accountId))
          .patchTask(
            item.sourceId,
            item.id,
            TaskPatchInput({
              'status': completed ? 'completed' : 'needsAction',
              'completed': completed
                  ? DateTime.now().toUtc().toIso8601String()
                  : null,
            }),
          );
      if (mounted) _reload();
    } on Object {
      if (mounted && _taskMutationIntent?.generation == intent.generation) {
        setState(() => _taskMutationIntent = null);
      }
      rethrow;
    }
  }

  Future<void> _createTask() async {
    if (_creationTaskList == null) return;
    final result = await showWindowsTaskEditorDialog(
      context,
      ref,
      initialDate: _selectedDate,
      initialAccountId: _creationTaskList?.accountId,
      initialTaskListId: _creationTaskList?.taskListId,
    );
    if (result != null && mounted) {
      setState(() {
        _taskMutationIntent = TaskListMutationIntent(
          presentation: TaskListMutationPresentation.insertion,
          accountId: result.accountId,
          taskListId: result.taskListId,
          taskId: result.taskId,
          generation: ++_taskMutationGeneration,
        );
      });
      _reload();
    }
  }

  void _consumeTaskMutation(TaskListMutationIntent intent) {
    if (!mounted) return;
    if (_taskMutationIntent?.generation == intent.generation) {
      setState(() => _taskMutationIntent = null);
    }
  }

  void _beginDetailsMutation(TaskMutationResult result) {
    if (!mounted) return;
    final presentation = switch (result.kind) {
      TaskMutationKind.deleted ||
      TaskMutationKind.moved => TaskListMutationPresentation.removal,
      TaskMutationKind.duplicated => TaskListMutationPresentation.insertion,
      _ => TaskListMutationPresentation.completion,
    };
    final taskId = result.createdTaskId ?? result.taskId;
    final current = _taskMutationIntent;
    if (current?.presentation == presentation &&
        current?.accountId == result.accountId &&
        current?.taskListId == result.taskListId &&
        current?.taskId == taskId &&
        current?.checklistItemId == result.checklistItemId &&
        current?.completed == result.completed) {
      return;
    }
    setState(() {
      _taskMutationIntent = TaskListMutationIntent(
        presentation: presentation,
        accountId: result.accountId,
        taskListId: result.taskListId,
        taskId: taskId,
        checklistItemId: result.checklistItemId,
        completed: result.completed,
        generation: ++_taskMutationGeneration,
      );
    });
  }

  void _commitDetailsMutation(TaskMutationResult result) {
    _beginDetailsMutation(result);
    if (mounted) _reload();
  }

  void _failDetailsMutation() {
    if (mounted) setState(() => _taskMutationIntent = null);
  }

  void _initializeSearch() {
    final visibility = _latestVisibility;
    if (visibility == null) return;
    final now = DateTime.now();
    _initialSearchCriteria = ScheduleSearchCriteria(
      referenceDate: DateTime(now.year, now.month, now.day),
      firstWeekday: _firstWeekday,
      sourceIds: visibility.visibleCalendarSourceIds,
      taskListKeys: visibility.visibleTaskListKeys,
    );
    _searchCriteria = _initialSearchCriteria;
  }

  void _activateSearch() {
    if (_searchActive) return;
    setState(() {
      _sourcePaneBeforeSearch = _sourcePaneCollapsed;
      _searchActive = true;
      _initializeSearch();
    });
  }

  void _searchFocusChanged() {
    if (_searchFocusNode.hasFocus) _activateSearch();
  }

  void _focusSearch() {
    _activateSearch();
    _searchFocusNode.requestFocus();
  }

  Widget _searchPane(
    List<AccountEntity> accounts,
    List<CalendarSourceEntity> sources,
    List<TaskListEntity> taskLists, {
    VoidCallback? refresh,
    int? firstWeekday,
  }) {
    final currentFirstWeekday = firstWeekday ?? _firstWeekday;
    return WindowsScheduleSearchPane(
      value: _searchCriteria!.copyWith(firstWeekday: currentFirstWeekday),
      accounts: accounts,
      sources: sources,
      taskLists: taskLists,
      onChanged: (value) {
        setState(
          () => _searchCriteria = value.copyWith(
            firstWeekday: currentFirstWeekday,
          ),
        );
        refresh?.call();
      },
      onClear: () {
        setState(
          () => _searchCriteria = _initialSearchCriteria?.copyWith(
            firstWeekday: currentFirstWeekday,
          ),
        );
        refresh?.call();
      },
    );
  }

  void _dismissSearch() {
    if (!_searchActive) return;
    _searchActive = false;
    _sourcePaneCollapsed = _sourcePaneBeforeSearch ?? _sourcePaneCollapsed;
    _sourcePaneBeforeSearch = null;
    _searchCriteria = null;
    _initialSearchCriteria = null;
    _searchDebounce?.cancel();
    _searchController.clear();
    _query = '';
    _searchFocusNode.unfocus();
    _reload();
  }

  void _invokeUnmodifiedShortcut(VoidCallback callback) {
    if (_searchActive) return;
    final focusContext = FocusManager.instance.primaryFocus?.context;
    if (focusContext != null &&
        (focusContext.widget is EditableText ||
            focusContext.findAncestorWidgetOfExactType<EditableText>() !=
                null)) {
      return;
    }
    callback();
  }

  Future<List<TaskListEntity>> _taskListsFor(List<AccountEntity> accounts) {
    final key =
        accounts
            .where((account) => account.isTaskCapable)
            .map((account) => account.id)
            .toList()
          ..sort();
    final encodedKey = key.join('\u0000');
    if (_taskListsKey != encodedKey || _taskListsFuture == null) {
      _taskListsKey = encodedKey;
      _taskListsFuture = Future.wait([
        for (final accountId in key)
          ref
              .read(taskListsRepositoryForAccountProvider(accountId))
              .listTaskLists(),
      ]).then((groups) => [for (final group in groups) ...group]);
    }
    return _taskListsFuture!;
  }

  Future<List<ScheduleItem>> _normalItemsFor({
    required ScheduleRange range,
    required List<AccountEntity> accounts,
    required ScheduleSourceVisibility visibility,
    required ScheduleViewMode mode,
    required int agendaTaskLimit,
  }) {
    final calendarIds = visibility.visibleCalendarSourceIds.toList()..sort();
    final taskKeys =
        visibility.visibleTaskListKeys
            .map((key) => '${key.accountId}/${key.taskListId}')
            .toList()
          ..sort();
    final accountIds = [for (final account in accounts) account.id]..sort();
    final normalKey = [
      _refreshRevision,
      mode.name,
      range.start.toIso8601String(),
      range.end.toIso8601String(),
      accountIds.join(','),
      calendarIds.join(','),
      taskKeys.join(','),
    ].join('|');
    if (_normalItemsKey == normalKey && _normalItemsFuture != null) {
      return _normalItemsFuture!;
    }
    _normalItemsKey = normalKey;
    final filters = ScheduleFilters(
      query: '',
      accountIds: accountIds.toSet(),
      sourceIds: visibility.visibleCalendarSourceIds,
      taskListKeys: visibility.visibleTaskListKeys,
      sourceFilterActive: true,
      taskListFilterActive: true,
      includeCalendarEvents: true,
      includeTasks: true,
      taskCompletion: ScheduleTaskCompletion.all,
      showNoDateTasks: mode == ScheduleViewMode.agenda,
    );
    _normalItemsFuture = _loadItems(
      range,
      filters,
      mode: mode,
      agendaTaskLimit: agendaTaskLimit,
    );
    return _normalItemsFuture!;
  }

  Future<List<ScheduleItem>> _searchItemsFor({
    required ScheduleRange range,
    required List<AccountEntity> accounts,
    required ScheduleSearchCriteria criteria,
    required String query,
  }) {
    final accountIds = [for (final account in accounts) account.id]..sort();
    final key = (
      _refreshRevision,
      range.start,
      range.end,
      accountIds.join(','),
      criteria,
      query,
    );
    if (_searchItemsKey == key && _searchItemsFuture != null) {
      return _searchItemsFuture!;
    }
    _searchItemsKey = key;
    _searchItemsFuture = ref
        .read(scheduleRepositoryProvider)
        .listItems(
          range: criteria.range ?? range,
          filters: criteria.filters(query),
        );
    return _searchItemsFuture!;
  }

  Future<List<ScheduleItem>> _loadItems(
    ScheduleRange range,
    ScheduleFilters filters, {
    required ScheduleViewMode mode,
    required int agendaTaskLimit,
  }) async {
    final repository = ref.read(scheduleRepositoryProvider);
    final items = <ScheduleItem>[
      ...await repository.listItems(range: range, filters: filters),
    ];
    if (mode == ScheduleViewMode.agenda) {
      final overdue = await repository.listOverdueTasks(
        before: range.start,
        limit: agendaTaskLimit,
        filters: filters,
      );
      final noDate = await repository.listNoDateTasks(
        limit: agendaTaskLimit,
        filters: filters,
      );
      items.addAll(overdue.items);
      items.addAll(noDate.items);
    }
    final unique = <String, ScheduleItem>{};
    for (final item in items) {
      unique['${item.kind.name}/${item.accountId}/${item.sourceId}/${item.id}'] =
          item;
    }
    final result = unique.values.toList()
      ..sort((left, right) {
        final leftStart = left.start;
        final rightStart = right.start;
        if (leftStart == null && rightStart != null) return 1;
        if (leftStart != null && rightStart == null) return -1;
        final dateOrder = leftStart?.compareTo(rightStart!) ?? 0;
        return dateOrder != 0
            ? dateOrder
            : left.title.toLowerCase().compareTo(right.title.toLowerCase());
      });
    return result;
  }

  ScheduleRange _rangeForMode() => switch (_mode) {
    ScheduleViewMode.day => ScheduleRange.day(_selectedDate),
    ScheduleViewMode.week => ScheduleRange.week(
      _selectedDate,
      firstWeekday: _firstWeekday,
    ),
    ScheduleViewMode.month => ScheduleRange.month(
      _selectedDate,
      firstWeekday: _firstWeekday,
    ),
    ScheduleViewMode.year => ScheduleRange.year(_selectedDate),
    ScheduleViewMode.agenda => ScheduleRange(
      start: _dateOnly(_selectedDate),
      end: DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day + _agendaDays,
      ),
    ),
  };

  String _periodTitle(
    AppLocalizations l10n,
    String locale,
    ScheduleRange range,
  ) => switch (_mode) {
    ScheduleViewMode.day => DateFormat.yMMMMEEEEd(locale).format(_selectedDate),
    ScheduleViewMode.week =>
      '${DateFormat.yMMMd(locale).format(range.start)} – '
          '${DateFormat.yMMMd(locale).format(range.end.subtract(const Duration(days: 1)))}',
    ScheduleViewMode.month => DateFormat.yMMMM(locale).format(_selectedDate),
    ScheduleViewMode.year => DateFormat.y(locale).format(_selectedDate),
    ScheduleViewMode.agenda => l10n.viewAgenda,
  };

  void _selectDate(DateTime date) {
    setState(() {
      _navigationIntent = null;
      _selectedDate = _dateOnly(date);
      _normalItemsKey = null;
    });
  }

  void _openDay(DateTime date) {
    _selectDate(date);
    _setMode(ScheduleViewMode.day);
  }

  void _movePeriod(int direction) {
    final next = switch (_mode) {
      ScheduleViewMode.day => DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day + direction,
      ),
      ScheduleViewMode.week => DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day + (7 * direction),
      ),
      ScheduleViewMode.month => DateTime(
        _selectedDate.year,
        _selectedDate.month + direction,
        1,
      ),
      ScheduleViewMode.year => DateTime(
        _selectedDate.year + direction,
        _selectedDate.month,
        1,
      ),
      ScheduleViewMode.agenda => _selectedDate,
    };
    setState(() {
      _selectedDate = _dateOnly(next);
      _normalItemsKey = null;
      _navigationIntent = ScheduleNavigationIntent(
        cause: ScheduleNavigationCause.adjacentPeriod,
        target: _selectedDate,
        direction: direction,
        generation: ++_navigationGeneration,
      );
    });
  }

  void _setMode(ScheduleViewMode mode) {
    if (_mode == mode) return;
    setState(() {
      _navigationIntent = null;
      _mode = mode;
      _normalItemsKey = null;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(mode),
    );
  }

  void _loadMoreAgenda() {
    setState(() {
      _agendaDays += 30;
      _agendaTaskLimit += 100;
      _normalItemsKey = null;
    });
  }

  void _setCalendarVisible(CalendarSourceEntity source, bool visible) {
    unawaited(
      ref
          .read(calendarRepositoryProvider)
          .setSourceSelected(source.id, visible)
          .then((_) => _reload()),
    );
  }

  void _setTaskListVisible(TaskListEntity list, bool visible) {
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setTaskListVisibleInSchedule(
            accountId: list.accountId,
            taskListId: list.id,
            visible: visible,
          )
          .then((_) => _reload()),
    );
  }

  Future<void> _showSourcesDialog({
    required List<AccountEntity> accounts,
    required List<CalendarSourceEntity> sources,
    required List<TaskListEntity> taskLists,
    required ScheduleSourceVisibility visibility,
  }) {
    if (_searchActive && _searchCriteria != null) {
      return showDialog<void>(
        context: context,
        builder: (context) => StatefulBuilder(
          builder: (context, update) {
            final firstWeekday = BusyMaxWeekPreferencesScope.firstWeekdayOf(
              context,
            );
            return ContentDialog(
              title: Text(AppLocalizations.of(context).searchFilters),
              content: SizedBox(
                width: 360,
                height: math.min(MediaQuery.sizeOf(context).height - 180, 620),
                child: _searchPane(
                  accounts,
                  sources,
                  taskLists,
                  firstWeekday: firstWeekday,
                  refresh: () => update(() {}),
                ),
              ),
              actions: [
                Button(
                  onPressed: () => Navigator.pop(context),
                  child: Text(AppLocalizations.of(context).close),
                ),
              ],
            );
          },
        ),
      );
    }
    final visibleCalendars = {...visibility.visibleCalendarSourceIds};
    final visibleTaskLists = {...visibility.visibleTaskListKeys};
    return showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => ContentDialog(
          title: Text(AppLocalizations.of(context).showSidebar),
          content: SizedBox(
            width: 520,
            height: math.min(MediaQuery.sizeOf(context).height - 180, 620),
            child: WindowsScheduleSourcePane(
              firstWeekday: BusyMaxWeekPreferencesScope.firstWeekdayOf(context),
              selectedDate: _selectedDate,
              accounts: accounts,
              accountInventoryResolved: _accountInventoryResolved,
              calendarSources: sources,
              taskLists: taskLists,
              visibleCalendarSourceIds: visibleCalendars,
              visibleTaskListKeys: visibleTaskLists,
              onDateSelected: (date) {
                Navigator.pop(dialogContext);
                _openDay(date);
              },
              onCalendarVisibilityChanged: (source, visible) {
                setDialogState(() {
                  if (visible) {
                    visibleCalendars.add(source.id);
                  } else {
                    visibleCalendars.remove(source.id);
                  }
                });
                _setCalendarVisible(source, visible);
              },
              onTaskListVisibilityChanged: (list, visible) {
                final key = ScheduleTaskListKey(
                  accountId: list.accountId,
                  taskListId: list.id,
                );
                setDialogState(() {
                  if (visible) {
                    visibleTaskLists.add(key);
                  } else {
                    visibleTaskLists.remove(key);
                  }
                });
                _setTaskListVisible(list, visible);
              },
              onAddAccount: () {
                Navigator.pop(dialogContext);
                unawaited(this.context.push<void>('/settings?page=accounts'));
              },
              onSourcesChanged: _reload,
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(AppLocalizations.of(context).close),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showItemDetails(ScheduleItem item) async {
    final locationDestination = await resolveSavedScheduleLocation(
      item: item,
      repository: ref.read(locationResolutionRepositoryProvider),
    );
    if (!mounted) return;
    final l10n = AppLocalizations.of(context);
    final locale = Localizations.localeOf(context).toLanguageTag();
    final time = item is CalendarScheduleItem
        ? scheduleEventIntervalLabel(context, item)
        : _itemDateLabel(context, item, locale);
    return showDialog<void>(
      context: context,
      builder: (dialogContext) => ContentDialog(
        title: Text(item.title),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SelectableText(
                [
                  time,
                  ?item.sourceName,
                  ?item.accountDisplayName,
                  if (item is CalendarScheduleItem)
                    calendarEventDescription(item),
                  if (item is CalendarScheduleItem)
                    ...googleStatusDetailLines(
                      l10n,
                      item.eventType,
                      item.googleStatusProperties,
                    ),
                  if (item case TaskScheduleItem(:final notes?)) notes,
                ].where((value) => value.trim().isNotEmpty).join('\n'),
              ),
              if (locationDestination != null) ...[
                const SizedBox(height: 12),
                _buildLocationRow(dialogContext, item, locationDestination),
              ] else if (item case CalendarScheduleItem(:final location?)) ...[
                if (location.trim().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SelectableText(location),
                ],
              ],
              if (item is CalendarScheduleItem) ...[
                if (item.joinMeetingUrl case final meetingLink?)
                  Button(
                    onPressed: () => unawaited(
                      _openEventWebLink(meetingLink, meeting: true),
                    ),
                    child: Text(l10n.joinMeeting),
                  ),
                if (item.eventLinkUrl case final eventLink?)
                  Button(
                    onPressed: () => unawaited(_openEventWebLink(eventLink)),
                    child: Text(l10n.eventLink),
                  ),
                if (item.attachmentsMayExist || item.attachmentLinks.isNotEmpty)
                  Text(l10n.attachments),
                for (final attachment in item.attachmentLinks)
                  Button(
                    onPressed: () =>
                        unawaited(_openEventWebLink(attachment.url)),
                    child: Text(attachment.name),
                  ),
                if (item.attachmentsMayExist && !item.attachmentsLoaded)
                  Text(l10n.attachmentsNotLoaded),
                if (item.provider == BusyProvider.microsoft &&
                    item.providerEventId != null)
                  Button(
                    onPressed: () {
                      Navigator.pop(dialogContext);
                      unawaited(
                        showWindowsEventAttachmentsDialog(context, item),
                      );
                    },
                    child: Text(l10n.attachments),
                  ),
                for (final uri in calendarEventDescriptionLinks(item))
                  Button(
                    onPressed: () =>
                        unawaited(_openEventWebLink(uri.toString())),
                    child: Text(uri.toString()),
                  ),
                if (item.canSendReply) Text(l10n.nextcloudAttendeeRestrictions),
                if (item.organizer != null)
                  SelectableText(
                    '${l10n.organizer}: ${scheduleEventPersonName(item.organizer)}',
                  ),
                if (item.currentUserResponse case final response?)
                  SelectableText(
                    '${l10n.yourResponse}: ${scheduleEventResponseLabel(dialogContext, response)}',
                  ),
                for (final attendee in item.attendees) ...[
                  SelectableText(
                    scheduleEventAttendeeLabel(dialogContext, attendee),
                  ),
                  if (attendee['scheduleStatus'] != null)
                    SelectableText(
                      '${l10n.nextcloudSchedulingStatus}: ${attendee['scheduleStatus']}',
                    ),
                ],
                if (item.canRespondToInvitation) ...[
                  if (item.provider == BusyProvider.nextcloud)
                    Text(l10n.nextcloudSchedulingPending),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final (response, label) in [
                        (
                          CalendarInvitationResponse.accept,
                          l10n.acceptInvitation,
                        ),
                        (
                          CalendarInvitationResponse.tentative,
                          l10n.tentativeInvitation,
                        ),
                        (
                          CalendarInvitationResponse.decline,
                          l10n.declineInvitation,
                        ),
                      ])
                        Button(
                          onPressed: () {
                            Navigator.pop(dialogContext);
                            unawaited(_respondToInvitation(item, response));
                          },
                          child: Text(label),
                        ),
                    ],
                  ),
                ],
              ],
              if (item is TaskScheduleItem)
                for (final link in item.availableSourceLinks)
                  Button(
                    onPressed: () => unawaited(_openEventWebLink(link.url)),
                    child: Text(
                      link.label?.isNotEmpty == true
                          ? link.label!
                          : l10n.openInProvider,
                    ),
                  ),
            ],
          ),
        ),
        actions: [
          if (item.capabilities.canEdit)
            Button(
              onPressed: () {
                Navigator.pop(dialogContext);
                unawaited(_edit(item));
              },
              child: Text(
                item is TaskScheduleItem ? l10n.editTask : l10n.editEvent,
              ),
            ),
          if (item.capabilities.canDelete)
            Button(
              onPressed: () {
                Navigator.pop(dialogContext);
                unawaited(_delete(item));
              },
              child: Text(switch (item) {
                CalendarScheduleItem(isNextcloudAttendee: true) =>
                  l10n.nextcloudDeclineAndRemove,
                CalendarScheduleItem(
                  isNextcloudMeeting: true,
                  isOrganizer: true,
                ) =>
                  l10n.nextcloudCancelMeeting,
                _ => l10n.delete,
              }),
            ),
          Button(
            onPressed: () {
              Navigator.pop(dialogContext);
              unawaited(_export(item));
            },
            child: Text(l10n.export),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(l10n.close),
          ),
        ],
      ),
    );
  }

  Future<void> _openEventWebLink(String value, {bool meeting = false}) async {
    if (await openScheduleWebLink(value) || !mounted) return;
    await displayInfoBar(
      context,
      builder: (context, close) => InfoBar(
        title: Text(
          meeting
              ? AppLocalizations.of(context).joinMeetingFailed
              : AppLocalizations.of(context).eventLinkOpenFailed,
        ),
        severity: InfoBarSeverity.error,
      ),
    );
  }

  Widget _buildLocationRow(
    BuildContext dialogContext,
    ScheduleItem item,
    ExternalLocationDestination destination,
  ) {
    final displayedLocation = savedScheduleLocationDisplayText(
      item,
      destination,
    );
    final action = Button(
      key: const ValueKey('windows-saved-location-open'),
      onPressed: () {
        Navigator.pop(dialogContext);
        unawaited(_openSavedLocation(destination));
      },
      child: Text(
        destination.kind == ExternalLocationDestinationKind.link
            ? AppLocalizations.of(dialogContext).openLink
            : AppLocalizations.of(dialogContext).mapsShow,
      ),
    );
    return LayoutBuilder(
      builder: (context, constraints) {
        final locationText = SelectableText(displayedLocation);
        if (constraints.maxWidth < 320) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [locationText, const SizedBox(height: 8), action],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: locationText),
            const SizedBox(width: 8),
            action,
          ],
        );
      },
    );
  }

  Future<void> _openSavedLocation(
    ExternalLocationDestination destination,
  ) async {
    try {
      final launcher =
          widget.externalLocationLauncher ??
          ExternalLocationLauncher(
            platform: () => ExternalLocationPlatform.windows,
          );
      final result = await launcher.open(destination);
      if (result == ExternalLocationLaunchResult.opened) return;
    } on Object {
      // The external handoff is best-effort and never affects saved data.
    }
    if (mounted) {
      unawaited(
        displayInfoBar(
          context,
          builder: (context, close) => InfoBar(
            title: Text(
              AppLocalizations.of(context).externalLocationOpenFailed,
            ),
            severity: InfoBarSeverity.error,
          ),
        ),
      );
    }
  }

  Future<void> _edit(ScheduleItem item) async {
    if (!mounted) return;
    final currentContext = context;
    final bool changed;
    if (item is CalendarScheduleItem) {
      changed = await showWindowsEventEditorDialog(
        currentContext,
        ref,
        eventId: item.id,
      );
    } else if (item is TaskScheduleItem) {
      changed = await showWindowsTaskDetailsDialog(
        currentContext,
        ref,
        item,
        onTaskMutationStarted: _beginDetailsMutation,
        onTaskMutationCommitted: _commitDetailsMutation,
        onTaskMutationFailed: _failDetailsMutation,
      );
    } else {
      return;
    }
    if (changed && mounted) _reload();
  }

  Future<void> _respondToInvitation(
    CalendarScheduleItem item,
    CalendarInvitationResponse response,
  ) async {
    if (!item.canRespondToInvitation) return;
    final l10n = AppLocalizations.of(context);
    try {
      RecurringEventMutationScope? scope;
      if (item.provider == BusyProvider.nextcloud &&
          item.providerRecurringEventId != null) {
        scope = await showWindowsRecurringEventMutationScope(
          context,
          item.provider,
          supportsFollowingOverride: false,
        );
        if (scope == null || !mounted) return;
      }
      final accountId = await ref
          .read(calendarRepositoryProvider)
          .respondToLocalEvent(item.id, response, recurringScope: scope);
      ref
          .read(
            pendingCalendarMutationSyncRequesterForAccountProvider(accountId),
          )
          .request();
      if (mounted) _reload();
    } on Object {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => ContentDialog(
          content: InfoBar(
            title: Text(l10n.operationFailed),
            severity: InfoBarSeverity.error,
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.close),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _export(ScheduleItem item) async {
    final l10n = AppLocalizations.of(context);
    try {
      String? rawICalendar;
      if (item is CalendarScheduleItem) {
        final repository = ref.read(calendarRepositoryProvider);
        final detail = await repository.loadEventDetail(item.id);
        if (!mounted) return;
        final recurring =
            detail != null &&
            (detail.recurrence != null ||
                detail.providerRecurringEventId != null);
        final series =
            recurring &&
                canExportAuthoritativeEventSeries(
                  provider: item.provider,
                  providerEventId: item.providerEventId,
                  davCollectionId: detail.davCollectionId,
                )
            ? await showDialog<bool>(
                context: context,
                builder: (dialogContext) => ContentDialog(
                  title: Text(l10n.export),
                  actions: [
                    Button(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      child: Text(l10n.singleOccurrence),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(dialogContext, true),
                      child: Text(l10n.entireSeries),
                    ),
                  ],
                ),
              )
            : false;
        if (series == null) return;
        if (series && item.provider == BusyProvider.google) {
          rawICalendar = await exportGoogleEventSeries(
            client: ref.read(
              googleCalendarApiClientForAccountProvider(item.accountId),
            ),
            calendarId: item.providerCalendarId,
            eventId: item.providerEventId!,
            nowUtc: DateTime.now().toUtc(),
          );
        } else if (series && item.provider == BusyProvider.microsoft) {
          rawICalendar = await exportMicrosoftEventSeries(
            client: ref.read(
              microsoftCalendarApiClientForAccountProvider(item.accountId),
            ),
            calendarId: item.providerCalendarId,
            eventId: item.providerEventId!,
            nowUtc: DateTime.now().toUtc(),
          );
        } else if (series || !recurring) {
          rawICalendar = await repository.nativeEventExport(item.id);
        }
      } else if (item is TaskScheduleItem &&
          item.provider == BusyProvider.nextcloud) {
        rawICalendar = await ref
            .read(tasksRepositoryForAccountProvider(item.accountId))
            .nativeTaskExport(item.sourceId, item.id);
      }
      final file = await exportScheduleItemWithSaveDialog(
        item,
        rawICalendar: rawICalendar,
      );
      if (file == null || !mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => ContentDialog(
          title: Text(l10n.export),
          content: Text(l10n.exportedFile(file.path)),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.close),
            ),
          ],
        ),
      );
    } on Object catch (_) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => ContentDialog(
          title: Text(l10n.export),
          content: InfoBar(
            title: Text(l10n.exportFailed(l10n.operationFailed)),
            severity: InfoBarSeverity.error,
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.close),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _delete(ScheduleItem item) async {
    if (!item.capabilities.canDelete) return;
    final l10n = AppLocalizations.of(context);
    RecurringEventMutationScope? scope;
    if (item is CalendarScheduleItem && item.providerRecurringEventId != null) {
      scope = await showDialog<RecurringEventMutationScope>(
        context: context,
        builder: (context) => ContentDialog(
          title: Text(l10n.deleteEvent),
          content: Text(l10n.chooseRecurringEventScope),
          actions: [
            Button(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.cancel),
            ),
            Button(
              onPressed: () => Navigator.pop(
                context,
                RecurringEventMutationScope.singleOccurrence,
              ),
              child: Text(l10n.singleOccurrence),
            ),
            if (supportsThisAndFollowingEventMutation(item.provider) &&
                !item.isNextcloudAttendee)
              Button(
                onPressed: () => Navigator.pop(
                  context,
                  RecurringEventMutationScope.thisAndFuture,
                ),
                child: Text(l10n.thisAndFollowingEvents),
              ),
            FilledButton(
              onPressed: () => Navigator.pop(
                context,
                RecurringEventMutationScope.entireSeries,
              ),
              child: Text(l10n.entireSeries),
            ),
          ],
        ),
      );
      if (scope == null) return;
    }
    var guestUpdatePolicy = CalendarGuestUpdatePolicy.send;
    final hasGuestDeliveryChoice =
        item is CalendarScheduleItem &&
        item.isOrganizer == true &&
        _calendarItemHasExternalGuests(item);
    if (hasGuestDeliveryChoice) {
      if (!mounted) return;
      final choice = await showWindowsGuestUpdateDialog(
        context,
        provider: item.provider,
        action: WindowsGuestUpdateAction.delete,
      );
      if (choice == null) return;
      guestUpdatePolicy = choice;
    } else if (scope == null ||
        (item is CalendarScheduleItem && item.isNextcloudAttendee)) {
      if (!mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => ContentDialog(
          title: Text(
            item is CalendarScheduleItem && item.isNextcloudAttendee
                ? l10n.nextcloudDeclineAndRemove
                : item is TaskScheduleItem
                ? l10n.deleteTask
                : l10n.deleteEvent,
          ),
          content: Text(
            item is CalendarScheduleItem && item.isNextcloudAttendee
                ? l10n.nextcloudDeclineRemovalWarning
                : item is TaskScheduleItem && item.isAssigned
                ? '${l10n.deleteTaskConfirmation(item.title)}\n\n${l10n.deleteAssignedTaskWarning}'
                : item.title,
          ),
          actions: [
            Button(
              onPressed: () => Navigator.pop(context, false),
              child: Text(l10n.cancel),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(l10n.delete),
            ),
          ],
        ),
      );
      if (!(confirmed ?? false)) return;
    }
    try {
      switch (item) {
        case CalendarScheduleItem():
          final accountId = await ref
              .read(calendarRepositoryProvider)
              .deleteLocalEvent(
                item.id,
                recurringScope: scope,
                guestUpdatePolicy: guestUpdatePolicy,
              );
          ref
              .read(
                pendingCalendarMutationSyncRequesterForAccountProvider(
                  accountId,
                ),
              )
              .request();
        case TaskScheduleItem():
          await ref
              .read(tasksRepositoryForAccountProvider(item.accountId))
              .deleteTask(
                item.sourceId,
                item.id,
                confirmedAssignedSourceDeletion: item.isAssigned,
              );
      }
      if (mounted) _reload();
    } on Object catch (_) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => ContentDialog(
          content: InfoBar(
            title: Text(l10n.operationFailed),
            severity: InfoBarSeverity.error,
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.close),
            ),
          ],
        ),
      );
    }
  }
}

bool _calendarItemHasExternalGuests(CalendarScheduleItem item) =>
    item.attendees.any(
      (attendee) => attendee['self'] != true && attendee['organizer'] != true,
    );

class _ViewModeMenu extends StatelessWidget {
  const _ViewModeMenu({required this.mode, required this.onChanged});

  final ScheduleViewMode mode;
  final ValueChanged<ScheduleViewMode> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropDownButton(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(windowsBusyMaxGlyph(_modeGlyph(mode))),
          const SizedBox(width: 8),
          Text(_modeLabel(AppLocalizations.of(context), mode)),
        ],
      ),
      items: [
        for (final value in ScheduleViewMode.values)
          MenuFlyoutItem(
            leading: Icon(windowsBusyMaxGlyph(_modeGlyph(value))),
            text: Text(_modeLabel(AppLocalizations.of(context), value)),
            onPressed: () => onChanged(value),
          ),
      ],
    );
  }
}

class _ScheduleModeView extends StatelessWidget {
  const _ScheduleModeView({
    required this.mode,
    required this.firstWeekday,
    required this.selectedDate,
    required this.range,
    required this.items,
    required this.locale,
    required this.onOpen,
    required this.onSelectDate,
    required this.onLoadMoreAgenda,
    required this.onVisibleDateChanged,
    required this.onEmptySlot,
    required this.onRangeCreated,
    required this.onReschedule,
    required this.onTaskCompletionChanged,
    required this.dayStartMinute,
    required this.dayEndMinute,
    this.navigationIntent,
    this.taskMutationIntent,
    this.onTaskMutationConsumed,
  });

  final ScheduleViewMode mode;
  final int firstWeekday;
  final DateTime selectedDate;
  final ScheduleRange range;
  final List<ScheduleItem> items;
  final String locale;
  final ValueChanged<ScheduleItem> onOpen;
  final ValueChanged<DateTime> onSelectDate;
  final VoidCallback onLoadMoreAgenda;
  final ValueChanged<DateTime> onVisibleDateChanged;
  final ValueChanged<DateTime> onEmptySlot;
  final ValueChanged<ScheduleInterval>? onRangeCreated;
  final ScheduleRescheduleCallback onReschedule;
  final void Function(TaskScheduleItem, bool) onTaskCompletionChanged;
  final int dayStartMinute;
  final int dayEndMinute;
  final ScheduleNavigationIntent? navigationIntent;
  final TaskListMutationIntent? taskMutationIntent;
  final ValueChanged<TaskListMutationIntent>? onTaskMutationConsumed;

  @override
  Widget build(BuildContext context) {
    final view = switch (mode) {
      ScheduleViewMode.day ||
      ScheduleViewMode.week => WindowsScheduleDayWeekView(
        key: ValueKey('windows-${mode.name}-planner'),
        initialDate: mode == ScheduleViewMode.day ? selectedDate : range.start,
        daysShowed: mode == ScheduleViewMode.day ? 1 : 7,
        items: items,
        onOpen: onOpen,
        onSelectDate: onSelectDate,
        onVisibleDateChanged: onVisibleDateChanged,
        onEmptySlot: onEmptySlot,
        onRangeCreated: onRangeCreated,
        onReschedule: onReschedule,
        onTaskCompletionChanged: onTaskCompletionChanged,
        dayStartMinute: dayStartMinute,
        dayEndMinute: dayEndMinute,
        navigationIntent: navigationIntent,
      ),
      ScheduleViewMode.month => WindowsScheduleMonthView(
        firstWeekday: firstWeekday,
        onReschedule: onReschedule,
        selectedDate: selectedDate,
        range: range,
        items: items,
        locale: locale,
        onOpen: onOpen,
        onSelectDate: onSelectDate,
      ),
      ScheduleViewMode.year => WindowsScheduleYearView(
        firstWeekday: firstWeekday,
        selectedDate: selectedDate,
        items: items,
        locale: locale,
        onSelectDate: onSelectDate,
      ),
      ScheduleViewMode.agenda => _AgendaList(
        items: items,
        locale: locale,
        onOpen: onOpen,
        onLoadMore: onLoadMoreAgenda,
        taskMutationIntent: taskMutationIntent,
        onTaskMutationConsumed: onTaskMutationConsumed,
      ),
    };
    final intent = navigationIntent;
    if (mode == ScheduleViewMode.month || mode == ScheduleViewMode.year) {
      final adjacent = intent?.cause == ScheduleNavigationCause.adjacentPeriod
          ? intent
          : null;
      return BusyMaxDirectionalSwitcher(
        generation: adjacent?.generation ?? 0,
        direction: adjacent?.direction ?? 0,
        child: view,
      );
    }
    return view;
  }
}

class _AgendaList extends StatelessWidget {
  const _AgendaList({
    super.key,
    this.searchCriteria,
    this.searchQuery = '',
    required this.items,
    required this.locale,
    required this.onOpen,
    this.onLoadMore,
    this.taskMutationIntent,
    this.onTaskMutationConsumed,
    this.emptyBuilder,
  });

  final ScheduleSearchCriteria? searchCriteria;
  final String searchQuery;
  final List<ScheduleItem> items;
  final String locale;
  final ValueChanged<ScheduleItem> onOpen;
  final VoidCallback? onLoadMore;
  final TaskListMutationIntent? taskMutationIntent;
  final ValueChanged<TaskListMutationIntent>? onTaskMutationConsumed;
  final WidgetBuilder? emptyBuilder;

  @override
  Widget build(BuildContext context) {
    final agendaItems = searchCriteria == null
        ? items
        : (List<ScheduleItem>.of(items)
            ..sort(compareScheduleSearchResultPresentation));
    return BusyMaxMutationList<ScheduleItem>(
      items: agendaItems,
      mutation: taskMutationIntent,
      identityOf: (item) => item is TaskScheduleItem
          ? '${item.accountId}\u0000${item.sourceId}\u0000${item.id}'
          : 'event\u0000${item.accountId}\u0000${item.sourceId}\u0000${item.id}',
      mutationApplied: (item, mutation) =>
          item is! TaskScheduleItem ||
          mutation.completed == null ||
          item.completed == mutation.completed,
      onMutationConsumed: onTaskMutationConsumed,
      emptyBuilder:
          emptyBuilder ??
          (context) =>
              Center(child: Text(AppLocalizations.of(context).noEventsOrTasks)),
      padding: const EdgeInsetsDirectional.fromSTEB(20, 0, 20, 24),
      footer: onLoadMore == null
          ? null
          : Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Button(
                onPressed: onLoadMore,
                child: Text(AppLocalizations.of(context).windowsAgendaLoadMore),
              ),
            ),
      itemBuilder: (context, item, index) {
        final displayDate = searchCriteria == null
            ? item.start
            : scheduleSearchResultDisplayDate(item);
        final day = displayDate == null ? null : _dateOnly(displayDate);
        final previousDisplayDate = index == 0 || index > agendaItems.length
            ? null
            : searchCriteria == null
            ? agendaItems[index - 1].start
            : scheduleSearchResultDisplayDate(agendaItems[index - 1]);
        final previousDay = previousDisplayDate == null
            ? null
            : _dateOnly(previousDisplayDate);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (index == 0 || day != previousDay)
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(4, 14, 4, 6),
                child: Text(
                  day == null
                      ? AppLocalizations.of(context).noDate
                      : DateFormat.yMMMMEEEEd(locale).format(day),
                  style: FluentTheme.of(context).typography.subtitle,
                ),
              ),
            _ScheduleItemCard(
              item: item,
              searchCriteria: searchCriteria,
              searchQuery: searchQuery,
              locale: locale,
              animateCompletion: _animatesTaskCompletion(item),
              completedOverride: item is TaskScheduleItem
                  ? _displayedCompletion(item)
                  : null,
              onPressed: () => onOpen(item),
            ),
          ],
        );
      },
    );
  }

  bool _animatesTaskCompletion(ScheduleItem item) {
    final intent = taskMutationIntent;
    return item is TaskScheduleItem &&
        intent?.presentation == TaskListMutationPresentation.completion &&
        intent?.taskKey ==
            '${item.accountId}\u0000${item.sourceId}\u0000${item.id}' &&
        intent?.completed != null;
  }

  bool _displayedCompletion(TaskScheduleItem task) {
    final intent = taskMutationIntent;
    if (intent?.presentation == TaskListMutationPresentation.completion &&
        intent?.taskKey ==
            '${task.accountId}\u0000${task.sourceId}\u0000${task.id}' &&
        intent?.completed != null) {
      return intent!.completed!;
    }
    return task.completed;
  }
}

class WindowsScheduleMonthView extends StatelessWidget {
  const WindowsScheduleMonthView({
    super.key,
    required this.selectedDate,
    required this.firstWeekday,
    required this.onReschedule,
    required this.range,
    required this.items,
    required this.locale,
    required this.onOpen,
    required this.onSelectDate,
  });

  final DateTime selectedDate;
  final int firstWeekday;
  final ScheduleRescheduleCallback onReschedule;
  final ScheduleRange range;
  final List<ScheduleItem> items;
  final String locale;
  final ValueChanged<ScheduleItem> onOpen;
  final ValueChanged<DateTime> onSelectDate;

  @override
  Widget build(BuildContext context) {
    final days = <DateTime>[];
    var cursor = range.start;
    while (cursor.isBefore(range.end)) {
      days.add(cursor);
      cursor = DateTime(cursor.year, cursor.month, cursor.day + 1);
    }
    return ScheduleInteractionRegion(
      onReschedule: onReschedule,
      previewColor: FluentTheme.of(
        context,
      ).accentColor.defaultBrushFor(FluentTheme.of(context).brightness),
      previewBuilder: (context, interval, allDay) => Text(
        schedulePreviewLabel(context, interval, allDay),
        style: FluentTheme.of(context).typography.caption,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 4),
            child: Row(
              children: [
                for (var index = 0; index < 7; index += 1)
                  Expanded(
                    child: Center(
                      child: Text(
                        DateFormat.E(locale).format(
                          DateTime(2026, 1, 5 + firstWeekday - 1 + index),
                        ),
                        style: FluentTheme.of(context).typography.caption,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final scale = MediaQuery.textScalerOf(context).scale(1);
                final rowHeight = 30.0 * scale;
                final headingHeight = 32.0 * scale;
                final cellHeight = math.max(
                  headingHeight + rowHeight + 10,
                  (constraints.maxHeight - 16) / (days.length / 7),
                );
                return GridView.builder(
                  padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 16),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 7,
                    mainAxisExtent: cellHeight,
                  ),
                  itemCount: days.length,
                  itemBuilder: (context, index) {
                    final day = days[index];
                    final dayItems = items
                        .where((item) => _itemOccursOn(item, day))
                        .toList();
                    final capacity = math.max(
                      0,
                      ((cellHeight - headingHeight - 10) / rowHeight).floor(),
                    );
                    final visibleCount = dayItems.length > capacity
                        ? math.max(0, capacity - 1)
                        : capacity;
                    return ScheduleDateTarget(
                      date: day,
                      child: Card(
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(
                              height: headingHeight,
                              child: HyperlinkButton(
                                onPressed: () => onSelectDate(day),
                                child: Text(
                                  '${day.day}',
                                  style: day.month == selectedDate.month
                                      ? null
                                      : TextStyle(
                                          color: FluentTheme.of(
                                            context,
                                          ).inactiveColor,
                                        ),
                                ),
                              ),
                            ),
                            for (final item in dayItems.take(visibleCount))
                              SizedBox(
                                height: rowHeight,
                                child: ScheduleEventInteraction(
                                  key: ValueKey(
                                    'windows-month-${item.accountId}-${item.sourceId}-${item.id}-$day',
                                  ),
                                  item: item,
                                  representedDate: day,
                                  dateOnly: true,
                                  child: _CompactScheduleItem(
                                    item: item,
                                    locale: locale,
                                    onPressed: () => onOpen(item),
                                  ),
                                ),
                              ),
                            if (dayItems.length > visibleCount)
                              SizedBox(
                                height: rowHeight,
                                child: Tooltip(
                                  message:
                                      '${DateFormat.yMMMMEEEEd(locale).format(day)} · ${AppLocalizations.of(context).scheduleItemCount(dayItems.length)}',
                                  child: Button(
                                    key: ValueKey(
                                      'month-overflow-${day.year}-${day.month}-${day.day}',
                                    ),
                                    onPressed: () =>
                                        _showDayItems(context, day, dayItems),
                                    child: Text(
                                      '+${dayItems.length - visibleCount}',
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showDayItems(
    BuildContext context,
    DateTime day,
    List<ScheduleItem> dayItems,
  ) => showDialog<void>(
    context: context,
    builder: (dialogContext) => ContentDialog(
      title: Text(DateFormat.yMMMMEEEEd(locale).format(day)),
      content: SizedBox(
        height: math.min(420, MediaQuery.sizeOf(context).height * .55),
        child: ListView(
          children: [
            for (final item in dayItems)
              _CompactScheduleItem(
                item: item,
                locale: locale,
                onPressed: () {
                  Navigator.pop(dialogContext);
                  onOpen(item);
                },
              ),
          ],
        ),
      ),
      actions: [
        Button(
          onPressed: () {
            Navigator.pop(dialogContext);
            onSelectDate(day);
          },
          child: Text(AppLocalizations.of(context).viewDay),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: Text(AppLocalizations.of(context).close),
        ),
      ],
    ),
  );
}

class WindowsScheduleYearView extends StatelessWidget {
  const WindowsScheduleYearView({
    super.key,
    required this.selectedDate,
    required this.firstWeekday,
    required this.items,
    required this.locale,
    required this.onSelectDate,
  });

  final DateTime selectedDate;
  final int firstWeekday;
  final List<ScheduleItem> items;
  final String locale;
  final ValueChanged<DateTime> onSelectDate;

  @override
  Widget build(BuildContext context) {
    final scale = MediaQuery.textScalerOf(context).scale(1);
    return LayoutBuilder(
      builder: (context, constraints) => GridView.builder(
        padding: const EdgeInsetsDirectional.fromSTEB(20, 0, 20, 20),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: math.max(
            1,
            ((constraints.maxWidth - 40) / (260 * scale)).floor(),
          ),
          mainAxisExtent: 300 * scale,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
        ),
        itemCount: 12,
        itemBuilder: (context, index) {
          final month = DateTime(selectedDate.year, index + 1);
          final offset = (month.weekday - firstWeekday) % DateTime.daysPerWeek;
          final dayCount = DateTime(month.year, month.month + 1, 0).day;
          return Card(
            padding: const EdgeInsets.all(8),
            child: Column(
              children: [
                Text(
                  DateFormat.MMMM(locale).format(month),
                  style: FluentTheme.of(context).typography.subtitle,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    for (var weekday = 0; weekday < 7; weekday++)
                      Expanded(
                        child: Center(
                          child: Text(
                            DateFormat.E(locale).format(
                              DateTime(2026, 1, 5 + firstWeekday - 1 + weekday),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: FluentTheme.of(context).typography.caption,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, grid) => GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 7,
                        mainAxisExtent: grid.maxHeight / 6,
                      ),
                      itemCount: 42,
                      itemBuilder: (context, cell) {
                        final number = cell - offset + 1;
                        if (number < 1 || number > dayCount) {
                          return const SizedBox.shrink();
                        }
                        final day = DateTime(month.year, month.month, number);
                        final dayItems = items
                            .where((item) => _itemOccursOn(item, day))
                            .toList();
                        final selected = _dateOnly(selectedDate) == day;
                        final today = _dateOnly(DateTime.now()) == day;
                        return Tooltip(
                          message:
                              '${DateFormat.yMMMMEEEEd(locale).format(day)} · ${AppLocalizations.of(context).scheduleItemCount(dayItems.length)}',
                          child: Button(
                            key: ValueKey(
                              'year-day-${day.year}-${day.month}-${day.day}',
                            ),
                            style: ButtonStyle(
                              padding: WidgetStateProperty.all(EdgeInsets.zero),
                            ),
                            onPressed: () => onSelectDate(day),
                            child: Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: selected || today
                                    ? Border.all(
                                        color: FluentTheme.of(context)
                                            .accentColor
                                            .defaultBrushFor(
                                              FluentTheme.of(
                                                context,
                                              ).brightness,
                                            ),
                                        width: selected ? 2 : 1,
                                      )
                                    : null,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('$number'),
                                  SizedBox(
                                    height: 5,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        for (final item in dayItems.take(3))
                                          Container(
                                            width: 4,
                                            height: 4,
                                            margin: const EdgeInsets.symmetric(
                                              horizontal: 1,
                                            ),
                                            decoration: BoxDecoration(
                                              color: _compactItemColor(
                                                context,
                                                item,
                                              ),
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

Color _compactItemColor(BuildContext context, ScheduleItem item) =>
    item is TaskScheduleItem
    ? ScheduleProjection.deterministicSourceColor(
        '${item.accountId}/${item.sourceId}',
        FluentTheme.of(context).brightness,
      )
    : ScheduleProjection.colorForItem(item, FluentTheme.of(context).brightness);

class _CompactScheduleItem extends StatelessWidget {
  const _CompactScheduleItem({
    required this.item,
    required this.locale,
    required this.onPressed,
  });

  final ScheduleItem item;
  final String locale;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final start = item.start;
    final task = item is TaskScheduleItem ? item as TaskScheduleItem : null;
    final label = item.allDay || start == null
        ? item.title
        : '${BusyMaxTimeFormatScope.of(context).format(start)} ${item.title}';
    return Tooltip(
      message: [
        label,
        item.accountEmail ?? item.accountDisplayName,
        item.sourceName,
      ].whereType<String>().join(' · '),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 3),
        child: Button(
          onPressed: onPressed,
          child: Row(
            children: [
              Icon(
                windowsBusyMaxGlyph(
                  task != null
                      ? task.completed
                            ? BusyMaxGlyph.check
                            : BusyMaxGlyph.task
                      : BusyMaxGlyph.calendar,
                ),
                size: 13,
                color: _compactItemColor(context, item),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: FluentTheme.of(context).typography.caption?.copyWith(
                    decoration: task?.completed == true
                        ? TextDecoration.lineThrough
                        : null,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WindowsScheduleEmptyState extends StatelessWidget {
  const _WindowsScheduleEmptyState({
    required this.searching,
    required this.noVisibleSources,
  });

  final bool searching;
  final bool noVisibleSources;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(windowsBusyMaxGlyph(BusyMaxGlyph.calendar), size: 40),
          const SizedBox(height: 12),
          Text(
            searching
                ? noVisibleSources
                      ? l10n.searchNoSources
                      : l10n.scheduleNoSearchResults
                : noVisibleSources
                ? l10n.scheduleNoSources
                : l10n.noEventsOrTasks,
            style: FluentTheme.of(context).typography.subtitle,
          ),
          if (searching) ...[
            const SizedBox(height: 4),
            Text(l10n.scheduleNoSearchResultsDescription),
          ],
        ],
      ),
    );
  }
}

class _ScheduleItemCard extends StatelessWidget {
  const _ScheduleItemCard({
    this.searchCriteria,
    this.searchQuery = '',
    required this.item,
    required this.locale,
    required this.onPressed,
    this.animateCompletion = false,
    this.completedOverride,
  });

  final ScheduleSearchCriteria? searchCriteria;
  final String searchQuery;
  final ScheduleItem item;
  final String locale;
  final VoidCallback onPressed;
  final bool animateCompletion;
  final bool? completedOverride;

  @override
  Widget build(BuildContext context) {
    final task = item is TaskScheduleItem ? item as TaskScheduleItem : null;
    final completed = completedOverride ?? task?.completed == true;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Card(
        child: ListTile(
          leading: Icon(
            windowsBusyMaxGlyph(
              item.kind == ScheduleItemKind.task
                  ? BusyMaxGlyph.task
                  : BusyMaxGlyph.calendar,
            ),
          ),
          title: AnimatedDefaultTextStyle(
            duration:
                MediaQuery.disableAnimationsOf(context) || !animateCompletion
                ? Duration.zero
                : BusyMaxMotion.taskCompletion,
            curve: BusyMaxMotion.presentationCurve,
            style:
                (FluentTheme.of(context).typography.body ?? const TextStyle())
                    .copyWith(
                      decoration: completed ? TextDecoration.lineThrough : null,
                      color: completed
                          ? FluentTheme.of(context).inactiveColor
                          : null,
                    ),
            child: Text(item.title),
          ),
          subtitle: Text(
            searchCriteria != null
                ? scheduleSearchResultText(
                    context,
                    item,
                    searchCriteria!,
                    searchQuery,
                  )
                : [
                    _itemDateLabel(context, item, locale),
                    ?item.sourceName,
                  ].where((value) => value.isNotEmpty).join(' · '),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          onPressed: onPressed,
        ),
      ),
    );
  }
}

BusyMaxGlyph _modeGlyph(ScheduleViewMode mode) => switch (mode) {
  ScheduleViewMode.day => BusyMaxGlyph.today,
  ScheduleViewMode.week => BusyMaxGlyph.calendar,
  ScheduleViewMode.month => BusyMaxGlyph.month,
  ScheduleViewMode.year => BusyMaxGlyph.calendar,
  ScheduleViewMode.agenda => BusyMaxGlyph.agenda,
};

String _modeLabel(AppLocalizations l10n, ScheduleViewMode mode) =>
    switch (mode) {
      ScheduleViewMode.day => l10n.viewDay,
      ScheduleViewMode.week => l10n.viewWeek,
      ScheduleViewMode.month => l10n.viewMonth,
      ScheduleViewMode.year => l10n.viewYear,
      ScheduleViewMode.agenda => l10n.viewAgenda,
    };

String _itemDateLabel(BuildContext context, ScheduleItem item, String locale) {
  final start = item.start;
  if (start == null) return '';
  return item.allDay
      ? DateFormat.yMMMd(locale).format(start)
      : formatClockDateTime(
          context,
          start,
          DateFormat.yMMMd(locale).format(start),
        );
}

DateTime _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day);

bool _sameDay(DateTime left, DateTime right) =>
    left.year == right.year &&
    left.month == right.month &&
    left.day == right.day;

bool _itemOccursOn(ScheduleItem item, DateTime day) {
  final start = item.start;
  if (start == null) return false;
  if (item is! CalendarScheduleItem) return _sameDay(start, day);
  final dayStart = _dateOnly(day);
  final dayEnd = DateTime(dayStart.year, dayStart.month, dayStart.day + 1);
  final end = item.end ?? start;
  if (end.isAtSameMomentAs(start)) return _sameDay(start, day);
  return start.isBefore(dayEnd) && end.isAfter(dayStart);
}
