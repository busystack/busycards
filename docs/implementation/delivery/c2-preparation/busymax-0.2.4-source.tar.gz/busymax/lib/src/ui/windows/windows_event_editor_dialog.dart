import 'package:busymax/src/core/auth/authorization_attempt.dart';

import 'dart:async';

import 'windows_time_picker.dart';
import '../../features/calendar/domain/event_property_policy.dart';

import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../l10n/generated/app_localizations.dart';
import '../../app/app_bootstrap.dart';
import '../../contacts/busymax_contacts_controller.dart';
import '../../calendar_providers/calendar_mutation.dart';
import '../../calendar_providers/calendar_provider_capabilities.dart';
import '../../features/accounts/data/accounts_repository.dart';
import '../../features/calendar/data/calendar_repository.dart';
import '../../features/calendar/domain/event_move_policy.dart';
import '../../features/calendar/domain/event_timing_policy.dart';
import '../../features/calendar/domain/google_status_event.dart';
import '../../features/calendar/presentation/google_status_event_labels.dart';
import '../../schedule/schedule_event_rescheduling.dart';
import '../../core/time/provider_date_time.dart';
import '../../features/calendar/presentation/event_editor_draft.dart';
import '../../google_calendar/google_calendar_models.dart';
import '../../microsoft_calendar/microsoft_calendar_models.dart';
import '../../features/recurrence/domain/event_recurrence_codec.dart';
import '../../features/recurrence/domain/recurrence_rule.dart';
import '../../features/maps/domain/location_result.dart';
import '../../providers/busy_provider.dart';
import '../common/busymax_glyph.dart';
import '../common/editor_state_builder.dart';
import 'windows_busymax_glyphs.dart';
import 'windows_event_reminders.dart';
import 'windows_guest_update_dialog.dart';
import 'windows_recurrence_dialog.dart';
import 'windows_time_zone_dialog.dart';
import 'windows_nextcloud_scheduling_dialog.dart';
import 'windows_cloud_availability_dialog.dart';

Future<bool> showWindowsEventEditorDialog(
  BuildContext context,
  WidgetRef ref, {
  String? eventId,
  DateTime? initialStart,
  ScheduleInterval? initialInterval,
  String? initialAccountId,
  String? initialSourceId,
}) async {
  final repository = ref.read(calendarRepositoryProvider);
  final detail = eventId == null
      ? null
      : await repository.loadEventDetail(eventId);
  if (eventId != null && detail == null) return false;
  final originalDraft = detail == null
      ? null
      : EventEditorDraft.fromEventDetail(detail);
  final accounts = await ref
      .read(accountsRepositoryProvider)
      .watchAccounts()
      .first;
  final sources = writableCalendarSources(
    await ref
        .read(calendarRepositoryProvider)
        .watchSourcesForAccounts(accounts.map((account) => account.id).toList())
        .first,
  );
  if (!context.mounted) return false;
  if (sources.isEmpty) {
    await showDialog<void>(
      context: context,
      builder: (context) => ContentDialog(
        title: Text(AppLocalizations.of(context).newEvent),
        content: Text(AppLocalizations.of(context).noCalendarsSynced),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: Text(AppLocalizations.of(context).close),
          ),
        ],
      ),
    );
    return false;
  }

  final title = TextEditingController(text: originalDraft?.title);
  final description = TextEditingController(
    text: originalDraft?.editableDescription,
  );
  final location = TextEditingController(text: originalDraft?.location);
  final guestEmail = TextEditingController();
  final categories = TextEditingController(
    text: originalDraft?.categories.join(', '),
  );
  final settings = ref.read(appSettingsControllerProvider);
  var selectedSource = sources.firstWhere(
    (source) =>
        source.id == (originalDraft?.sourceId ?? initialSourceId) &&
        source.accountId == (originalDraft?.accountId ?? initialAccountId),
    orElse: () =>
        preferredCreationDestination(
          sources,
          selected: settings.defaultCalendar,
          lastUsed: settings.lastUsedCalendar,
          destinationOf: (source) =>
              CreationDestination(accountId: source.accountId, id: source.id),
        ) ??
        sources.first,
  );
  final requestedStart = initialStart == null
      ? null
      : DateTime(
          initialStart.year,
          initialStart.month,
          initialStart.day,
          initialStart.hour == 0 && initialStart.minute == 0
              ? 9
              : initialStart.hour,
          initialStart.minute,
        );
  var start =
      originalDraft?.start ??
      initialInterval?.start ??
      requestedStart ??
      DateTime.now().add(const Duration(hours: 1));
  var end =
      originalDraft?.end ??
      initialInterval?.end ??
      start.add(const Duration(hours: 1));
  var allDay = originalDraft?.allDay ?? false;
  final defaultTimeZone = initialInterval != null
      ? ref.read(localTimeZoneProvider)
      : selectedSource.timeZone ?? ref.read(localTimeZoneProvider);
  var selectedTimeZone = originalDraft == null
      ? defaultTimeZone
      : originalDraft.startTimeZone;
  var endTimeZone = originalDraft == null
      ? defaultTimeZone
      : originalDraft.endTimeZone;
  if (originalDraft == null && initialInterval != null) {
    start = providerInstantInTimeZone(initialInterval.start, selectedTimeZone);
    end = providerInstantInTimeZone(initialInterval.end, selectedTimeZone);
  }
  var recurrence = EventRecurrenceCodec.decode(
    selectedSource.provider,
    originalDraft?.recurrence,
    baseDate: start,
  );
  var recurrenceChanged = false;
  var reminderMinutes = decodeWindowsEventReminderMinutes(
    originalDraft?.reminders,
  );
  var remindersChanged = false;
  var attendees = [...?originalDraft?.attendees];
  var attendeesChanged = false;
  var categoriesChanged = false;
  var eventLabelId = originalDraft?.eventLabelId;
  var eventLabelChanged = false;
  var eventType = originalDraft?.eventType ?? 'default';
  var googleStatusProperties = <String, Object?>{
    ...?originalDraft?.googleStatusProperties,
  };
  var googleStatusChanged = false;
  final statusMessage = TextEditingController(
    text: googleStatusProperties['declineMessage']?.toString() ?? '',
  );
  final statusLocationLabel = TextEditingController(
    text: googleStatusProperties['customLocation'] is Map
        ? (googleStatusProperties['customLocation'] as Map)['label']
                  ?.toString() ??
              ''
        : googleStatusProperties['officeLocation'] is Map
        ? (googleStatusProperties['officeLocation'] as Map)['label']
                  ?.toString() ??
              ''
        : '',
  );
  var onlineMeeting =
      originalDraft?.conference != null ||
      (originalDraft?.createConference ?? false);
  var responseRequested = originalDraft?.responseRequested ?? true;
  var hideAttendees = originalDraft?.hideAttendees ?? false;
  var allowNewTimeProposals = originalDraft?.allowNewTimeProposals ?? true;
  var importance = originalDraft?.importance ?? 'normal';
  var showAs = eventShowAsForProvider(
    originalDraft?.showAs,
    selectedSource.provider,
  );
  var visibility = eventVisibilityForProvider(
    originalDraft?.visibilityOrSensitivity,
    selectedSource.provider,
  );
  var locationChange =
      originalDraft?.locationChange ?? const LocationChange.unchanged();
  final initialSourceAccountId = selectedSource.accountId;
  final originalSelectedSourceId = selectedSource.id;
  final initialTitle = title.text;
  final initialDescription = description.text;
  final initialLocation = location.text;
  final initialCategories = categories.text;
  final initialStartValue = start;
  final initialEndValue = end;
  final initialAllDay = allDay;
  final initialTimeZone = selectedTimeZone;
  final initialEndTimeZone = endTimeZone;
  final initialOnlineMeeting = onlineMeeting;
  final initialResponseRequested = responseRequested;
  final initialHideAttendees = hideAttendees;
  final initialAllowNewTimeProposals = allowNewTimeProposals;
  final initialImportance = importance;
  final initialShowAs = showAs;
  final initialVisibility = visibility;
  String? guestError;
  List<BusyMaxContactSuggestion> guestSuggestions = const [];
  var guestSuggestionGeneration = 0;
  StreamSubscription<void>? contactsChanges;
  var saving = false;
  var saved = false;
  var allowPop = false;
  String? error;
  bool hasPendingEdits() =>
      selectedSource.accountId != initialSourceAccountId ||
      selectedSource.id != originalSelectedSourceId ||
      title.text != initialTitle ||
      description.text != initialDescription ||
      guestEmail.text.isNotEmpty ||
      location.text != initialLocation ||
      locationChange.changed ||
      categories.text != initialCategories ||
      start != initialStartValue ||
      end != initialEndValue ||
      allDay != initialAllDay ||
      selectedTimeZone != initialTimeZone ||
      endTimeZone != initialEndTimeZone ||
      recurrenceChanged ||
      remindersChanged ||
      attendeesChanged ||
      categoriesChanged ||
      eventLabelId != originalDraft?.eventLabelId ||
      googleStatusChanged ||
      onlineMeeting != initialOnlineMeeting ||
      responseRequested != initialResponseRequested ||
      hideAttendees != initialHideAttendees ||
      allowNewTimeProposals != initialAllowNewTimeProposals ||
      importance != initialImportance ||
      showAs != initialShowAs ||
      visibility != initialVisibility;

  AuthorizationCancellation? consentCancellation;
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => EditorStateBuilder(
      textControllers: [title, description, location, guestEmail, categories],
      builder: (context, setState) {
        contactsChanges ??= ref
            .read(busyMaxContactsControllerProvider)
            .changes
            .listen((_) {
              guestSuggestionGeneration++;
              if (dialogContext.mounted) {
                setState(() => guestSuggestions = const []);
              }
            });
        final l10n = AppLocalizations.of(context);
        final validEnd =
            EventEditorDraft.newEvent(
                  accountId: selectedSource.accountId,
                  sourceId: selectedSource.id,
                  providerCalendarId: selectedSource.providerCalendarId,
                  start: start,
                  end: end,
                )
                .copyWith(
                  title: title.text,
                  allDay: allDay,
                  startTimeZone: selectedTimeZone,
                  endTimeZone: endTimeZone,
                )
                .canSave;
        void closeDialog() {
          setState(() => allowPop = true);
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (dialogContext.mounted) Navigator.pop(dialogContext);
          });
        }

        return PopScope<void>(
          canPop: allowPop || (!saving && !hasPendingEdits()),
          onPopInvokedWithResult: (didPop, _) async {
            if (didPop || saving || allowPop) return;
            if (await _confirmDiscardEventChanges(context) && context.mounted) {
              closeDialog();
            }
          },
          child: ContentDialog(
            title: Text(detail == null ? l10n.newEvent : l10n.editEvent),
            constraints: const BoxConstraints(maxWidth: 560, maxHeight: 760),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  InfoLabel(
                    label: l10n.title,
                    child: TextBox(
                      controller: title,
                      autofocus: true,
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: l10n.calendar,
                    child: ComboBox<CalendarSourceEntity>(
                      isExpanded: true,
                      value: selectedSource,
                      items: [
                        for (final source in sources)
                          ComboBoxItem(
                            value: source,
                            child: Text(_calendarSourceLabel(source, accounts)),
                          ),
                      ],
                      onChanged: saving
                          ? null
                          : (source) {
                              if (source != null) {
                                if (googleStatusEventTypes.contains(
                                      eventType,
                                    ) &&
                                    (source.provider != BusyProvider.google ||
                                        !source.primaryCalendar)) {
                                  setState(
                                    () => error = l10n.googleStatusPrimaryOnly,
                                  );
                                  return;
                                }
                                setState(() {
                                  if (source.id != selectedSource.id) {
                                    eventLabelId = null;
                                    eventLabelChanged = true;
                                  }
                                  guestSuggestionGeneration++;
                                  guestSuggestions = const [];
                                  selectedSource = source;
                                  // Destination conversion belongs to the shared save
                                  // policy. Keep the editable data intact while browsing.
                                });
                              }
                            },
                    ),
                  ),
                  const SizedBox(height: 12),
                  ToggleSwitch(
                    checked: allDay,
                    onChanged:
                        saving ||
                            eventType == 'focusTime' ||
                            eventType == 'outOfOffice'
                        ? null
                        : (value) => setState(() => allDay = value),
                    content: Text(l10n.allDay),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: l10n.startDateTime,
                    child: Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        DatePicker(
                          selected: start,
                          onChanged: saving
                              ? null
                              : (date) => setState(() {
                                  final duration = end.difference(start);
                                  start = DateTime(
                                    date.year,
                                    date.month,
                                    date.day,
                                    start.hour,
                                    start.minute,
                                  );
                                  end = start.add(duration);
                                }),
                        ),
                        if (!allDay)
                          WindowsTimePicker(
                            selected: start,
                            onChanged: saving
                                ? null
                                : (time) => setState(() {
                                    final duration = end.difference(start);
                                    start = DateTime(
                                      start.year,
                                      start.month,
                                      start.day,
                                      time.hour,
                                      time.minute,
                                    );
                                    end = start.add(duration);
                                  }),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: l10n.endDateTime,
                    child: Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        DatePicker(
                          selected: end,
                          onChanged: saving
                              ? null
                              : (date) => setState(() {
                                  end = DateTime(
                                    date.year,
                                    date.month,
                                    date.day,
                                    end.hour,
                                    end.minute,
                                  );
                                }),
                        ),
                        if (!allDay)
                          WindowsTimePicker(
                            selected: end,
                            onChanged: saving
                                ? null
                                : (time) => setState(() {
                                    end = DateTime(
                                      end.year,
                                      end.month,
                                      end.day,
                                      time.hour,
                                      time.minute,
                                    );
                                  }),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: '${l10n.startDateTime} · ${l10n.selectTimeZone}',
                    child: Button(
                      onPressed: saving
                          ? null
                          : () async {
                              final result = await showWindowsTimeZoneDialog(
                                context,
                                selectedTimeZone:
                                    selectedTimeZone ??
                                    ref.read(localTimeZoneProvider),
                              );
                              if (result != null) {
                                setState(() => selectedTimeZone = result);
                              }
                            },
                      child: Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: Text(
                          selectedTimeZone ?? ref.read(localTimeZoneProvider),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: '${l10n.endDateTime} · ${l10n.selectTimeZone}',
                    child: Button(
                      onPressed: saving
                          ? null
                          : () async {
                              final result = await showWindowsTimeZoneDialog(
                                context,
                                selectedTimeZone:
                                    endTimeZone ??
                                    ref.read(localTimeZoneProvider),
                              );
                              if (result != null) {
                                setState(() => endTimeZone = result);
                              }
                            },
                      child: Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: Text(
                          endTimeZone ?? ref.read(localTimeZoneProvider),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: l10n.location,
                    child: TextBox(
                      key: const ValueKey('windows-event-location-field'),
                      controller: location,
                      enabled: !saving,
                      onChanged: (value) => setState(() {
                        locationChange = value == initialLocation
                            ? const LocationChange.unchanged()
                            : const LocationChange.clear();
                      }),
                    ),
                  ),
                  const SizedBox(height: 12),
                  InfoLabel(
                    label: l10n.description,
                    child: TextBox(controller: description, maxLines: 4),
                  ),
                  Expander(
                    header: Text('${l10n.reminder} · ${l10n.repeat}'),
                    initiallyExpanded:
                        originalDraft?.reminders != null ||
                        originalDraft?.recurrence != null,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        InfoLabel(
                          label: l10n.reminder,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              for (
                                var index = 0;
                                index < reminderMinutes.length;
                                index += 1
                              )
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: ComboBox<int>(
                                          isExpanded: true,
                                          value: reminderMinutes[index],
                                          items: [
                                            for (final minutes
                                                in windowsEventReminderValuesFor(
                                                  reminderMinutes[index],
                                                ))
                                              ComboBoxItem(
                                                value: minutes,
                                                child: Text(
                                                  _reminderLabel(l10n, minutes),
                                                ),
                                              ),
                                          ],
                                          onChanged: saving
                                              ? null
                                              : (value) {
                                                  if (value == null) return;
                                                  setState(() {
                                                    reminderMinutes =
                                                        normalizeWindowsEventReminderMinutes(
                                                          [
                                                            ...reminderMinutes
                                                                .take(index),
                                                            value,
                                                            ...reminderMinutes
                                                                .skip(
                                                                  index + 1,
                                                                ),
                                                          ],
                                                        );
                                                    remindersChanged = true;
                                                  });
                                                },
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      IconButton(
                                        icon: Icon(
                                          windowsBusyMaxGlyph(
                                            BusyMaxGlyph.delete,
                                          ),
                                        ),
                                        onPressed: saving
                                            ? null
                                            : () => setState(() {
                                                reminderMinutes = [
                                                  ...reminderMinutes.take(
                                                    index,
                                                  ),
                                                  ...reminderMinutes.skip(
                                                    index + 1,
                                                  ),
                                                ];
                                                remindersChanged = true;
                                              }),
                                      ),
                                    ],
                                  ),
                                ),
                              if (reminderMinutes.isEmpty ||
                                  (selectedSource.provider !=
                                          BusyProvider.microsoft &&
                                      reminderMinutes.length <
                                          windowsEventReminderMinuteOptions
                                              .length))
                                Button(
                                  onPressed: saving
                                      ? null
                                      : () => setState(() {
                                          reminderMinutes = [
                                            ...reminderMinutes,
                                            nextWindowsEventReminderMinute(
                                              reminderMinutes,
                                            ),
                                          ];
                                          remindersChanged = true;
                                        }),
                                  child: Text(l10n.addReminder),
                                ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        if (originalDraft?.providerRecurringEventId == null)
                          InfoLabel(
                            label: l10n.repeat,
                            child: Button(
                              onPressed: saving
                                  ? null
                                  : () async {
                                      final result =
                                          await showWindowsRecurrenceDialog(
                                            context,
                                            initial: recurrence,
                                            baseDate: start,
                                            allDay: allDay,
                                            timeZone:
                                                selectedTimeZone ??
                                                ref.read(localTimeZoneProvider),
                                            providerLabel: selectedSource
                                                .provider
                                                .displayName,
                                            limits:
                                                EventRecurrenceCodec.limitsFor(
                                                  selectedSource.provider,
                                                ),
                                          );
                                      if (result != null) {
                                        setState(() {
                                          recurrence = result;
                                          recurrenceChanged = true;
                                        });
                                      }
                                    },
                              child: Align(
                                alignment: AlignmentDirectional.centerStart,
                                child: Text(
                                  _recurrenceLabel(l10n, recurrence.frequency),
                                ),
                              ),
                            ),
                          ),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expander(
                    header: Text(l10n.organizationSection),
                    initiallyExpanded:
                        (originalDraft?.categories.isNotEmpty ?? false) ||
                        (originalDraft?.importance != null &&
                            originalDraft?.importance != 'normal') ||
                        showAs !=
                            eventShowAsForProvider(
                              null,
                              selectedSource.provider,
                            ) ||
                        visibility !=
                            eventVisibilityForProvider(
                              null,
                              selectedSource.provider,
                            ),
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        InfoLabel(
                          label: l10n.availabilityShowAs,
                          child: ComboBox<String>(
                            isExpanded: true,
                            value: eventShowAsForProvider(
                              showAs,
                              selectedSource.provider,
                            ),
                            items: [
                              for (final value in _showAsValues(
                                selectedSource.provider,
                              ))
                                ComboBoxItem(
                                  value: value,
                                  child: Text(_availabilityLabel(l10n, value)),
                                ),
                            ],
                            onChanged:
                                saving ||
                                    (selectedSource.provider ==
                                            BusyProvider.google &&
                                        googleStatusEventTypes.contains(
                                          eventType,
                                        ))
                                ? null
                                : (value) {
                                    if (value != null) {
                                      setState(() => showAs = value);
                                    }
                                  },
                          ),
                        ),
                        const SizedBox(height: 12),
                        InfoLabel(
                          label: l10n.visibility,
                          child: ComboBox<String>(
                            isExpanded: true,
                            value: eventVisibilityForProvider(
                              visibility,
                              selectedSource.provider,
                            ),
                            items: [
                              for (final value in _visibilityValues(
                                selectedSource.provider,
                              ))
                                ComboBoxItem(
                                  value: value,
                                  child: Text(_visibilityLabel(l10n, value)),
                                ),
                            ],
                            onChanged:
                                saving ||
                                    (selectedSource.provider ==
                                            BusyProvider.google &&
                                        eventType == 'workingLocation')
                                ? null
                                : (value) {
                                    if (value != null) {
                                      setState(() => visibility = value);
                                    }
                                  },
                          ),
                        ),
                        if (selectedSource.provider ==
                            BusyProvider.microsoft) ...[
                          const SizedBox(height: 12),
                          InfoLabel(
                            label: l10n.importance,
                            child: ComboBox<String>(
                              isExpanded: true,
                              value: importance,
                              items: [
                                ComboBoxItem(
                                  value: 'low',
                                  child: Text(l10n.importanceLow),
                                ),
                                ComboBoxItem(
                                  value: 'normal',
                                  child: Text(l10n.importanceNormal),
                                ),
                                ComboBoxItem(
                                  value: 'high',
                                  child: Text(l10n.importanceHigh),
                                ),
                              ],
                              onChanged: saving
                                  ? null
                                  : (value) {
                                      if (value != null) {
                                        setState(() => importance = value);
                                      }
                                    },
                            ),
                          ),
                        ],
                        if (selectedSource.provider != BusyProvider.google) ...[
                          const SizedBox(height: 12),
                          InfoLabel(
                            label: l10n.categories,
                            child: TextBox(
                              controller: categories,
                              enabled: !saving,
                              onChanged: (_) =>
                                  setState(() => categoriesChanged = true),
                            ),
                          ),
                        ],
                        if (selectedSource.provider == BusyProvider.microsoft)
                          FutureBuilder<List<MicrosoftMasterCategory>>(
                            key: ValueKey(
                              'outlook-categories-${selectedSource.accountId}',
                            ),
                            future: ref.read(
                              microsoftMasterCategoriesProvider(
                                selectedSource.accountId,
                              ).future,
                            ),
                            builder: (context, snapshot) {
                              final catalog = snapshot.data;
                              if (catalog == null) {
                                return snapshot.hasError
                                    ? Button(
                                        onPressed: () async {
                                          consentCancellation?.cancel();
                                          final consent =
                                              AuthorizationCancellation();
                                          consentCancellation = consent;
                                          try {
                                            try {
                                              await ref
                                                  .read(
                                                    microsoftCategoryAuthorizationProvider,
                                                  )
                                                  ?.authorizeCategoryAccess(
                                                    selectedSource.accountId,
                                                    cancellation: consent,
                                                  );
                                              if (!context.mounted ||
                                                  consent.isCancelled) {
                                                return;
                                              }
                                              ref.invalidate(
                                                microsoftMasterCategoriesProvider(
                                                  selectedSource.accountId,
                                                ),
                                              );
                                              setState(() {});
                                            } on Object {
                                              setState(
                                                () => error = l10n
                                                    .outlookCategoriesUnavailable,
                                              );
                                            }
                                          } finally {
                                            consent.cancel();
                                            if (identical(
                                              consentCancellation,
                                              consent,
                                            )) {
                                              consentCancellation = null;
                                            }
                                          }
                                        },
                                        child: Text(l10n.loadOutlookCategories),
                                      )
                                    : Text(l10n.loadOutlookCategories);
                              }
                              return Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: [
                                  for (final category in catalog)
                                    ToggleButton(
                                      checked: _categories(categories.text)
                                          .contains(category.displayName),
                                      onChanged: saving
                                          ? null
                                          : (checked) {
                                              final names = _categories(
                                                categories.text,
                                              ).toList();
                                              if (checked) {
                                                if (!names.contains(
                                                  category.displayName,
                                                )) {
                                                  names.add(
                                                    category.displayName,
                                                  );
                                                }
                                              } else {
                                                names.remove(
                                                  category.displayName,
                                                );
                                              }
                                              setState(() {
                                                categories.text = names.join(
                                                  ', ',
                                                );
                                                categoriesChanged = true;
                                              });
                                            },
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (microsoftCategorySwatchArgb(
                                                category.color,
                                              )
                                              case final swatch?) ...[
                                            Container(
                                              width: 12,
                                              height: 12,
                                              color: Color(swatch),
                                            ),
                                            const SizedBox(width: 5),
                                          ],
                                          Text(category.displayName),
                                        ],
                                      ),
                                    ),
                                ],
                              );
                            },
                          ),
                        if (selectedSource.provider == BusyProvider.google &&
                            (selectedSource.primaryCalendar ||
                                googleStatusEventTypes.contains(
                                  eventType,
                                ))) ...[
                          const SizedBox(height: 12),
                          InfoLabel(
                            label: l10n.googleEventType,
                            child: ComboBox<String>(
                              key: const Key('windows-google-event-type'),
                              isExpanded: true,
                              value: eventType,
                              items: [
                                for (final value in <String>[
                                  'default',
                                  ...googleStatusEventTypes,
                                ])
                                  ComboBoxItem(
                                    value: value,
                                    child: Text(
                                      googleEventTypeLabel(l10n, value),
                                    ),
                                  ),
                              ],
                              onChanged: saving || originalDraft != null
                                  ? null
                                  : (value) {
                                      if (value == null) return;
                                      setState(() {
                                        eventType = value;
                                        googleStatusProperties = {
                                          ...defaultGoogleStatusProperties(
                                            value,
                                          ),
                                        };
                                        googleStatusChanged = true;
                                        showAs = value == 'workingLocation'
                                            ? 'transparent'
                                            : 'opaque';
                                        visibility = value == 'workingLocation'
                                            ? 'public'
                                            : 'default';
                                        if (value == 'focusTime' ||
                                            value == 'outOfOffice') {
                                          allDay = false;
                                        } else if (value == 'workingLocation' &&
                                            allDay) {
                                          end = DateTime(
                                            start.year,
                                            start.month,
                                            start.day + 1,
                                          );
                                        }
                                        statusMessage.clear();
                                        statusLocationLabel.clear();
                                      });
                                    },
                            ),
                          ),
                          if (eventType == 'focusTime' ||
                              eventType == 'outOfOffice') ...[
                            const SizedBox(height: 12),
                            InfoLabel(
                              label: l10n.googleDeclineInvitations,
                              child: ComboBox<String>(
                                isExpanded: true,
                                value:
                                    googleStatusProperties['autoDeclineMode']
                                        ?.toString() ??
                                    'declineNone',
                                items: [
                                  for (final value in const [
                                    'declineNone',
                                    'declineOnlyNewConflictingInvitations',
                                    'declineAllConflictingInvitations',
                                  ])
                                    ComboBoxItem(
                                      value: value,
                                      child: Text(
                                        googleAutoDeclineLabel(l10n, value),
                                      ),
                                    ),
                                ],
                                onChanged: saving
                                    ? null
                                    : (value) {
                                        if (value == null) return;
                                        setState(() {
                                          googleStatusProperties = {
                                            ...googleStatusProperties,
                                            'autoDeclineMode': value,
                                          };
                                          googleStatusChanged = true;
                                        });
                                      },
                              ),
                            ),
                            if (eventType == 'focusTime') ...[
                              const SizedBox(height: 12),
                              InfoLabel(
                                label: l10n.googleChatStatus,
                                child: ComboBox<String>(
                                  isExpanded: true,
                                  value:
                                      googleStatusProperties['chatStatus'] ==
                                          'doNotDisturb'
                                      ? 'doNotDisturb'
                                      : 'available',
                                  items: [
                                    ComboBoxItem(
                                      value: 'available',
                                      child: Text(l10n.googleChatAvailable),
                                    ),
                                    ComboBoxItem(
                                      value: 'doNotDisturb',
                                      child: Text(l10n.googleChatDoNotDisturb),
                                    ),
                                  ],
                                  onChanged: saving
                                      ? null
                                      : (value) {
                                          if (value == null) return;
                                          setState(() {
                                            googleStatusProperties = {
                                              ...googleStatusProperties,
                                              'chatStatus': value,
                                            };
                                            googleStatusChanged = true;
                                          });
                                        },
                                ),
                              ),
                            ],
                            const SizedBox(height: 12),
                            InfoLabel(
                              label: l10n.googleDeclineMessage,
                              child: TextBox(
                                controller: statusMessage,
                                enabled: !saving,
                                onChanged: (value) => setState(() {
                                  googleStatusProperties = {
                                    ...googleStatusProperties,
                                    'declineMessage': value,
                                  };
                                  googleStatusChanged = true;
                                }),
                              ),
                            ),
                          ],
                          if (eventType == 'workingLocation') ...[
                            const SizedBox(height: 12),
                            InfoLabel(
                              label: l10n.googleWorkingLocation,
                              child: ComboBox<String>(
                                isExpanded: true,
                                value:
                                    googleStatusProperties['type']
                                        ?.toString() ??
                                    'homeOffice',
                                items: [
                                  for (final value in const [
                                    'homeOffice',
                                    'officeLocation',
                                    'customLocation',
                                  ])
                                    ComboBoxItem(
                                      value: value,
                                      child: Text(
                                        googleWorkingLocationLabel(l10n, value),
                                      ),
                                    ),
                                ],
                                onChanged: saving
                                    ? null
                                    : (value) {
                                        if (value == null) return;
                                        setState(() {
                                          final next =
                                              {...googleStatusProperties}
                                                ..remove('homeOffice')
                                                ..remove('officeLocation')
                                                ..remove('customLocation');
                                          next['type'] = value;
                                          next[value] = value == 'homeOffice'
                                              ? <String, Object?>{}
                                              : <String, Object?>{
                                                  'label':
                                                      statusLocationLabel.text,
                                                };
                                          googleStatusProperties = next;
                                          googleStatusChanged = true;
                                        });
                                      },
                              ),
                            ),
                            if (googleStatusProperties['type'] !=
                                'homeOffice') ...[
                              const SizedBox(height: 12),
                              InfoLabel(
                                label: l10n.googleWorkLocationLabel,
                                child: TextBox(
                                  controller: statusLocationLabel,
                                  enabled: !saving,
                                  onChanged: (value) => setState(() {
                                    final locationType =
                                        googleStatusProperties['type']
                                            ?.toString() ??
                                        'customLocation';
                                    final detail =
                                        googleStatusProperties[locationType]
                                            is Map
                                        ? Map<String, Object?>.from(
                                            googleStatusProperties[locationType]
                                                as Map,
                                          )
                                        : <String, Object?>{};
                                    googleStatusProperties = {
                                      ...googleStatusProperties,
                                      locationType: {...detail, 'label': value},
                                    };
                                    googleStatusChanged = true;
                                  }),
                                ),
                              ),
                            ],
                          ],
                        ],
                        if (selectedSource.provider == BusyProvider.google) ...[
                          const SizedBox(height: 12),
                          FutureBuilder<List<GoogleEventLabel>>(
                            key: ValueKey(
                              'google-labels-${selectedSource.accountId}-${selectedSource.providerCalendarId}',
                            ),
                            future: ref.read(
                              googleEventLabelsForCalendarProvider((
                                accountId: selectedSource.accountId,
                                calendarId: selectedSource.providerCalendarId,
                              )).future,
                            ),
                            builder: (context, snapshot) {
                              final labels = snapshot.data;
                              if (labels == null) {
                                return InfoLabel(
                                  label: l10n.eventLabel,
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          eventLabelId ?? l10n.noneValue,
                                        ),
                                      ),
                                      if (snapshot.hasError)
                                        Button(
                                          onPressed: () {
                                            ref.invalidate(
                                              googleEventLabelsForCalendarProvider(
                                                (
                                                  accountId:
                                                      selectedSource.accountId,
                                                  calendarId: selectedSource
                                                      .providerCalendarId,
                                                ),
                                              ),
                                            );
                                            setState(() {});
                                          },
                                          child: Text(l10n.retry),
                                        ),
                                    ],
                                  ),
                                );
                              }
                              final byId = {
                                for (final label in labels) label.id: label,
                              };
                              final values = <String>[
                                '',
                                ...byId.keys,
                                if (eventLabelId != null &&
                                    !byId.containsKey(eventLabelId))
                                  eventLabelId!,
                              ];
                              return InfoLabel(
                                label: l10n.eventLabel,
                                child: ComboBox<String>(
                                  key: const Key('windows-event-label'),
                                  isExpanded: true,
                                  value: eventLabelId ?? '',
                                  items: [
                                    for (final id in values)
                                      ComboBoxItem(
                                        value: id,
                                        child: Row(
                                          children: [
                                            if (byId[id] case final label?) ...[
                                              Container(
                                                width: 12,
                                                height: 12,
                                                color: Color(
                                                  0xff000000 |
                                                      int.parse(
                                                        label.backgroundColor
                                                            .substring(1),
                                                        radix: 16,
                                                      ),
                                                ),
                                              ),
                                              const SizedBox(width: 6),
                                            ],
                                            Text(
                                              id.isEmpty
                                                  ? l10n.noneValue
                                                  : byId[id]?.name ??
                                                        l10n.unknownEventLabel(
                                                          id,
                                                        ),
                                            ),
                                          ],
                                        ),
                                      ),
                                  ],
                                  onChanged: saving
                                      ? null
                                      : (id) => setState(() {
                                          eventLabelId =
                                              id == null || id.isEmpty
                                              ? null
                                              : id;
                                          eventLabelChanged =
                                              eventLabelId !=
                                              originalDraft?.eventLabelId;
                                        }),
                                ),
                              );
                            },
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (selectedSource.provider == BusyProvider.google ||
                      selectedSource.provider == BusyProvider.microsoft) ...[
                    const SizedBox(height: 16),
                    ToggleSwitch(
                      checked: onlineMeeting,
                      onChanged: saving
                          ? null
                          : (value) => setState(() => onlineMeeting = value),
                      content: Text(
                        onlineMeeting && originalDraft?.conference != null
                            ? l10n.onlineMeetingAdded
                            : selectedSource.provider == BusyProvider.google
                            ? l10n.addGoogleMeet
                            : l10n.addTeamsMeeting,
                      ),
                    ),
                  ],
                  if (selectedSource.provider == BusyProvider.google ||
                      selectedSource.provider == BusyProvider.microsoft ||
                      selectedSource.provider == BusyProvider.nextcloud) ...[
                    const SizedBox(height: 12),
                    InfoLabel(
                      label: l10n.guests,
                      child: Column(
                        children: [
                          for (final attendee in attendees)
                            _WindowsAttendeeRow(
                              attendee: attendee,
                              requiredLabel: l10n.attendeeRequired,
                              optionalLabel: l10n.attendeeOptional,
                              canEdit:
                                  !saving &&
                                  !attendee.self &&
                                  !attendee.organizer &&
                                  (selectedSource.provider !=
                                          BusyProvider.nextcloud ||
                                      selectedSource
                                              .davEffectivePermissions['canInvite'] ==
                                          true) &&
                                  (originalDraft?.canManageAttendees ?? true),
                              onOptionalChanged: (optional) => setState(() {
                                attendees = [
                                  for (final item in attendees)
                                    if (identical(item, attendee))
                                      item.withOptional(optional)
                                    else
                                      item,
                                ];
                                attendeesChanged = true;
                              }),
                              onDelete: () => setState(() {
                                attendees = [
                                  for (final item in attendees)
                                    if (!identical(item, attendee)) item,
                                ];
                                attendeesChanged = true;
                              }),
                            ),
                          if ((originalDraft?.canManageAttendees ?? true) &&
                              (selectedSource.provider !=
                                      BusyProvider.nextcloud ||
                                  selectedSource
                                          .davEffectivePermissions['canInvite'] ==
                                      true))
                            _WindowsAddGuestRow(
                              controller: guestEmail,
                              label: l10n.addGuest,
                              enabled: !saving,
                              onChanged: () {
                                setState(() => guestError = null);
                                final query = guestEmail.text.trim();
                                final generation = ++guestSuggestionGeneration;
                                final accountId = selectedSource.accountId;
                                final sourceId = selectedSource.id;
                                if (query.isEmpty) {
                                  setState(() => guestSuggestions = const []);
                                  return;
                                }
                                unawaited(() async {
                                  try {
                                    final suggestions = await ref
                                        .read(busyMaxContactsControllerProvider)
                                        .suggestAttendees(
                                          query,
                                          busyMaxAccountId: accountId,
                                          excludedAddresses: {
                                            for (final attendee in attendees)
                                              attendee.email,
                                          },
                                        );
                                    if (!dialogContext.mounted ||
                                        generation !=
                                            guestSuggestionGeneration ||
                                        selectedSource.accountId != accountId ||
                                        selectedSource.id != sourceId ||
                                        guestEmail.text.trim() != query) {
                                      return;
                                    }
                                    setState(
                                      () => guestSuggestions = suggestions,
                                    );
                                  } on Object {
                                    if (!dialogContext.mounted ||
                                        generation !=
                                            guestSuggestionGeneration ||
                                        selectedSource.accountId != accountId ||
                                        selectedSource.id != sourceId ||
                                        guestEmail.text.trim() != query) {
                                      return;
                                    }
                                    setState(() => guestSuggestions = const []);
                                  }
                                }());
                              },
                              onAdd: () {
                                final email = guestEmail.text.trim();
                                if (!_looksLikeEmail(email)) {
                                  setState(
                                    () =>
                                        guestError = l10n.feedbackInvalidEmail,
                                  );
                                  return;
                                }
                                if (!attendees.any(
                                  (item) =>
                                      item.email.toLowerCase() ==
                                      email.toLowerCase(),
                                )) {
                                  setState(() {
                                    attendees = [
                                      ...attendees,
                                      EventAttendeeDraft(email: email),
                                    ];
                                    attendeesChanged = true;
                                  });
                                }
                                guestSuggestionGeneration++;
                                guestEmail.clear();
                                setState(() => guestSuggestions = const []);
                              },
                            ),
                          for (final suggestion in guestSuggestions)
                            Button(
                              key: ValueKey(
                                'windows-guest-contact-${suggestion.email}',
                              ),
                              onPressed: saving
                                  ? null
                                  : () async {
                                      if (!guestSuggestions.contains(
                                        suggestion,
                                      )) {
                                        return;
                                      }
                                      final capturedGeneration =
                                          guestSuggestionGeneration;
                                      final capturedAccount =
                                          selectedSource.accountId;
                                      final capturedSource = selectedSource.id;
                                      try {
                                        if (!await ref
                                            .read(
                                              busyMaxContactsControllerProvider,
                                            )
                                            .suggestionEligible(
                                              suggestion,
                                              busyMaxAccountId: capturedAccount,
                                            )) {
                                          return;
                                        }
                                      } on Object {
                                        return;
                                      }
                                      if (!dialogContext.mounted ||
                                          capturedGeneration !=
                                              guestSuggestionGeneration ||
                                          selectedSource.accountId !=
                                              capturedAccount ||
                                          selectedSource.id != capturedSource ||
                                          !guestSuggestions.contains(
                                            suggestion,
                                          ) ||
                                          !(originalDraft?.canManageAttendees ??
                                              true) ||
                                          saving ||
                                          selectedSource.provider ==
                                                  BusyProvider.nextcloud &&
                                              selectedSource
                                                      .davEffectivePermissions['canInvite'] ==
                                                  false) {
                                        return;
                                      }
                                      guestSuggestionGeneration++;
                                      if (!attendees.any(
                                        (item) =>
                                            item.email.toLowerCase() ==
                                            suggestion.email.toLowerCase(),
                                      )) {
                                        setState(() {
                                          attendees = [
                                            ...attendees,
                                            EventAttendeeDraft(
                                              email: suggestion.email,
                                              displayName:
                                                  suggestion.displayName.isEmpty
                                                  ? null
                                                  : suggestion.displayName,
                                            ),
                                          ];
                                          attendeesChanged = true;
                                        });
                                      }
                                      guestEmail.clear();
                                      setState(
                                        () => guestSuggestions = const [],
                                      );
                                    },
                              child: Align(
                                alignment: AlignmentDirectional.centerStart,
                                child: Text(
                                  suggestion.displayName.isEmpty
                                      ? suggestion.email
                                      : '${suggestion.displayName} · ${suggestion.email}',
                                ),
                              ),
                            ),
                          if (guestError != null)
                            InfoBar(
                              title: Text(guestError!),
                              severity: InfoBarSeverity.warning,
                            ),
                        ],
                      ),
                    ),
                  ],
                  if (selectedSource.provider == BusyProvider.google ||
                      selectedSource.provider == BusyProvider.microsoft) ...[
                    const SizedBox(height: 8),
                    ToggleSwitch(
                      checked: responseRequested,
                      onChanged: saving
                          ? null
                          : (value) =>
                                setState(() => responseRequested = value),
                      content: Text(l10n.requestResponses),
                    ),
                    const SizedBox(height: 8),
                    ToggleSwitch(
                      checked: hideAttendees,
                      onChanged: saving
                          ? null
                          : (value) => setState(() => hideAttendees = value),
                      content: Text(l10n.hideGuestList),
                    ),
                    const SizedBox(height: 8),
                    ToggleSwitch(
                      checked: allowNewTimeProposals,
                      onChanged: saving
                          ? null
                          : (value) =>
                                setState(() => allowNewTimeProposals = value),
                      content: Text(l10n.allowNewTimeProposals),
                    ),
                  ],
                  if (selectedSource.provider == BusyProvider.nextcloud &&
                      selectedSource.davCollectionId != null &&
                      selectedSource
                              .davEffectivePermissions['canQueryFreeBusy'] ==
                          true &&
                      attendees.isNotEmpty)
                    Button(
                      onPressed: saving
                          ? null
                          : () => showWindowsNextcloudSchedulingDialog(
                              context,
                              accountId: selectedSource.accountId,
                              collectionId: selectedSource.davCollectionId!,
                              draft:
                                  (originalDraft ??
                                          EventEditorDraft.newEvent(
                                            accountId: selectedSource.accountId,
                                            sourceId: selectedSource.id,
                                            providerCalendarId: selectedSource
                                                .providerCalendarId,
                                            start: start,
                                            end: end,
                                          ))
                                      .copyWith(
                                        accountId: selectedSource.accountId,
                                        sourceId: selectedSource.id,
                                        providerCalendarId:
                                            selectedSource.providerCalendarId,
                                        start: start,
                                        end: end,
                                        allDay: allDay,
                                        startTimeZone: selectedTimeZone,
                                        endTimeZone: endTimeZone,
                                        attendees: attendees,
                                      ),
                            ),
                      child: Text(l10n.nextcloudGuestAvailability),
                    ),
                  if ((selectedSource.provider == BusyProvider.google ||
                          (selectedSource.provider == BusyProvider.microsoft &&
                              microsoftAvailabilityAccountType(
                                    accounts
                                        .where(
                                          (account) =>
                                              account.id ==
                                              selectedSource.accountId,
                                        )
                                        .firstOrNull
                                        ?.tenantId,
                                  ) ==
                                  MicrosoftAvailabilityAccountType
                                      .workSchool)) &&
                      attendees.any(
                        (attendee) => !attendee.self && !attendee.organizer,
                      ))
                    Button(
                      onPressed: saving
                          ? null
                          : () => showWindowsCloudAvailabilityDialog(
                              context,
                              calendarTimeZone: selectedSource.timeZone,
                              draft:
                                  (originalDraft ??
                                          EventEditorDraft.newEvent(
                                            accountId: selectedSource.accountId,
                                            sourceId: selectedSource.id,
                                            providerCalendarId: selectedSource
                                                .providerCalendarId,
                                            start: start,
                                            end: end,
                                          ))
                                      .copyWith(
                                        accountId: selectedSource.accountId,
                                        sourceId: selectedSource.id,
                                        providerCalendarId:
                                            selectedSource.providerCalendarId,
                                        start: start,
                                        end: end,
                                        allDay: allDay,
                                        startTimeZone: selectedTimeZone,
                                        endTimeZone: endTimeZone,
                                        attendees: attendees,
                                      ),
                            ),
                      child: Text(l10n.nextcloudGuestAvailability),
                    ),
                  if (error != null) ...[
                    const SizedBox(height: 12),
                    InfoBar(
                      title: Text(error!),
                      severity: InfoBarSeverity.error,
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              Button(
                onPressed: saving
                    ? null
                    : () async {
                        if (hasPendingEdits() &&
                            !await _confirmDiscardEventChanges(context)) {
                          return;
                        }
                        closeDialog();
                      },
                child: Text(l10n.cancel),
              ),
              FilledButton(
                onPressed: saving || title.text.trim().isEmpty || !validEnd
                    ? null
                    : () async {
                        setState(() {
                          saving = true;
                          error = null;
                        });
                        try {
                          final effectiveEnd = allDay
                              ? DateTime(end.year, end.month, end.day)
                              : end;
                          final effectiveStart = allDay
                              ? DateTime(start.year, start.month, start.day)
                              : start;
                          final encodedRecurrence =
                              recurrenceChanged && recurrence.repeats
                              ? EventRecurrenceCodec.encode(
                                  detail?.provider ?? selectedSource.provider,
                                  recurrence,
                                  baseDate: start,
                                  allDay: allDay,
                                  timeZone: selectedTimeZone,
                                )
                              : null;
                          var draft =
                              (originalDraft ??
                                      EventEditorDraft.newEvent(
                                        accountId: selectedSource.accountId,
                                        sourceId: selectedSource.id,
                                        providerCalendarId:
                                            selectedSource.providerCalendarId,
                                        start: effectiveStart,
                                        end: effectiveEnd,
                                      ))
                                  .copyWith(
                                    accountId: selectedSource.accountId,
                                    sourceId: selectedSource.id,
                                    providerCalendarId:
                                        selectedSource.providerCalendarId,
                                    title: title.text.trim(),
                                    allDay: allDay,
                                    start: effectiveStart,
                                    end: effectiveEnd,
                                    location:
                                        locationChange.changed ||
                                            originalDraft == null
                                        ? location.text
                                        : originalDraft.location,
                                    locationChange: locationChange,
                                    description:
                                        description.text ==
                                            (originalDraft
                                                    ?.editableDescription ??
                                                '')
                                        ? originalDraft?.description
                                        : description.text.trim(),
                                    startTimeZone: selectedTimeZone,
                                    endTimeZone: endTimeZone,
                                    recurrence: recurrenceChanged
                                        ? encodedRecurrence
                                        : null,
                                    recurrenceChanged: recurrenceChanged,
                                    clearRecurrence:
                                        recurrenceChanged &&
                                        !recurrence.repeats,
                                    reminders: remindersChanged
                                        ? encodeWindowsEventReminderPayload(
                                            detail?.provider ??
                                                selectedSource.provider,
                                            reminderMinutes,
                                          )
                                        : null,
                                    remindersChanged: remindersChanged,
                                    attendees: attendeesChanged
                                        ? attendees
                                        : null,
                                    attendeesChanged: attendeesChanged,
                                    importance:
                                        selectedSource.provider ==
                                            BusyProvider.microsoft
                                        ? importance
                                        : null,
                                    showAs:
                                        showAs != initialShowAs ||
                                            originalDraft == null
                                        ? showAs
                                        : null,
                                    visibilityOrSensitivity:
                                        visibility != initialVisibility ||
                                            originalDraft == null
                                        ? visibility
                                        : null,
                                    categories: categoriesChanged
                                        ? _categories(categories.text)
                                        : null,
                                    categoriesChanged: categoriesChanged,
                                    eventLabelId:
                                        eventLabelChanged &&
                                            eventLabelId != null
                                        ? eventLabelId
                                        : null,
                                    clearEventLabelId:
                                        eventLabelChanged &&
                                        eventLabelId == null,
                                    eventLabelChanged: eventLabelChanged,
                                    eventType:
                                        selectedSource.provider ==
                                            BusyProvider.google
                                        ? eventType
                                        : null,
                                    googleStatusProperties:
                                        selectedSource.provider ==
                                                BusyProvider.google &&
                                            (googleStatusChanged ||
                                                originalDraft == null)
                                        ? googleStatusProperties
                                        : null,
                                    googleStatusChanged: googleStatusChanged,
                                    createConference:
                                        onlineMeeting &&
                                        originalDraft?.conference == null,
                                    clearConference: !onlineMeeting,
                                    responseRequested:
                                        responseRequested !=
                                                initialResponseRequested ||
                                            originalDraft == null
                                        ? responseRequested
                                        : null,
                                    hideAttendees:
                                        hideAttendees != initialHideAttendees ||
                                            originalDraft == null
                                        ? hideAttendees
                                        : null,
                                    allowNewTimeProposals:
                                        allowNewTimeProposals !=
                                                initialAllowNewTimeProposals ||
                                            originalDraft == null
                                        ? allowNewTimeProposals
                                        : null,
                                  );
                          if (originalDraft?.providerRecurringEventId != null) {
                            final scope =
                                await showWindowsRecurringEventMutationScope(
                                  dialogContext,
                                  selectedSource.provider,
                                  supportsFollowingOverride: detail == null
                                      ? null
                                      : eventSupportsThisAndFollowing(detail),
                                );
                            if (scope == null) {
                              if (dialogContext.mounted) {
                                setState(() => saving = false);
                              }
                              return;
                            }
                            draft = draft.copyWith(
                              recurringMutationScope: scope,
                            );
                          }

                          final moveSource = originalDraft == null
                              ? null
                              : sources.firstWhere(
                                  (source) =>
                                      source.id == originalDraft.sourceId &&
                                      source.accountId ==
                                          originalDraft.accountId,
                                  orElse: () => selectedSource,
                                );
                          final moveStrategy = moveSource == null
                              ? CalendarEventMoveStrategy.none
                              : calendarEventMoveStrategy(
                                  sourceAccountId: moveSource.accountId,
                                  sourceId: moveSource.id,
                                  sourceProviderCalendarId:
                                      moveSource.providerCalendarId,
                                  sourceProvider: moveSource.provider,
                                  sourceDavCollectionId:
                                      moveSource.davCollectionId,
                                  destinationAccountId:
                                      selectedSource.accountId,
                                  destinationId: selectedSource.id,
                                  destinationProviderCalendarId:
                                      selectedSource.providerCalendarId,
                                  destinationProvider: selectedSource.provider,
                                  destinationDavCollectionId:
                                      selectedSource.davCollectionId,
                                  eventType: originalDraft?.eventType,
                                  recurring:
                                      originalDraft?.providerRecurringEventId !=
                                      null,
                                  recurringScope: draft.recurringMutationScope,
                                );
                          if (moveStrategy ==
                              CalendarEventMoveStrategy.copyThenDelete) {
                            if (!dialogContext.mounted) return;
                            final confirmed = await _confirmCopyThenDelete(
                              dialogContext,
                              sourceLabel: _calendarSourceLabel(
                                moveSource!,
                                accounts,
                              ),
                              destinationLabel: _calendarSourceLabel(
                                selectedSource,
                                accounts,
                              ),
                            );
                            if (!confirmed) {
                              if (dialogContext.mounted) {
                                setState(() => saving = false);
                              }
                              return;
                            }
                          }

                          var guestUpdatePolicy =
                              CalendarGuestUpdatePolicy.send;
                          final guestProvider =
                              selectedSource.provider == BusyProvider.google ||
                                  selectedSource.provider ==
                                      BusyProvider.microsoft ||
                                  selectedSource.provider ==
                                      BusyProvider.nextcloud
                              ? selectedSource.provider
                              : moveSource?.provider;
                          if ((guestProvider == BusyProvider.google ||
                                  guestProvider == BusyProvider.microsoft ||
                                  guestProvider == BusyProvider.nextcloud) &&
                              draft.isOrganizer == true &&
                              _hasExternalGuests(
                                draft.attendees,
                                originalDraft?.attendees ?? const [],
                              )) {
                            if (!dialogContext.mounted) return;
                            final choice = await showWindowsGuestUpdateDialog(
                              dialogContext,
                              provider: guestProvider!,
                              action: WindowsGuestUpdateAction.save,
                            );
                            if (choice == null) {
                              if (dialogContext.mounted) {
                                setState(() => saving = false);
                              }
                              return;
                            }
                            guestUpdatePolicy = choice;
                          }
                          if (detail == null) {
                            await repository.createLocalEvent(
                              draft,
                              guestUpdatePolicy: guestUpdatePolicy,
                            );
                            unawaited(
                              ref
                                  .read(appSettingsControllerProvider.notifier)
                                  .rememberCalendar(
                                    CreationDestination(
                                      accountId: draft.accountId,
                                      id: draft.sourceId,
                                    ),
                                  ),
                            );
                          } else {
                            await repository.updateLocalEvent(
                              draft,
                              guestUpdatePolicy: guestUpdatePolicy,
                            );
                          }
                          saved = true;
                          closeDialog();
                        } on Object catch (_) {
                          setState(() {
                            saving = false;
                            error = l10n.operationFailed;
                          });
                        }
                      },
                child: saving
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: ProgressRing(),
                      )
                    : Text(detail == null ? l10n.create : l10n.save),
              ),
            ],
          ),
        );
      },
    ),
  );
  guestSuggestionGeneration++;
  final cancellation = contactsChanges?.cancel();
  if (cancellation != null) {
    unawaited(
      cancellation.catchError((Object error, StackTrace stack) {
        FlutterError.reportError(
          FlutterErrorDetails(
            exception: error,
            stack: stack,
            library: 'contacts suggestions',
          ),
        );
      }),
    );
  }
  consentCancellation?.cancel();
  title.dispose();
  description.dispose();
  location.dispose();
  guestEmail.dispose();
  categories.dispose();
  statusMessage.dispose();
  statusLocationLabel.dispose();
  return saved;
}

class _WindowsAttendeeRow extends StatelessWidget {
  const _WindowsAttendeeRow({
    required this.attendee,
    required this.requiredLabel,
    required this.optionalLabel,
    required this.canEdit,
    required this.onOptionalChanged,
    required this.onDelete,
  });

  final EventAttendeeDraft attendee;
  final String requiredLabel;
  final String optionalLabel;
  final bool canEdit;
  final ValueChanged<bool> onOptionalChanged;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final compact =
          constraints.maxWidth < 440 ||
          MediaQuery.textScalerOf(context).scale(1) > 1.3;
      final identity = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(attendee.email),
          if (attendee.displayName != null)
            Text(
              attendee.displayName!,
              style: FluentTheme.of(context).typography.caption,
            ),
        ],
      );
      final controls = canEdit
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ComboBox<bool>(
                  value: attendee.optional,
                  items: [
                    ComboBoxItem(value: false, child: Text(requiredLabel)),
                    ComboBoxItem(value: true, child: Text(optionalLabel)),
                  ],
                  onChanged: (value) {
                    if (value != null) onOptionalChanged(value);
                  },
                ),
                IconButton(
                  icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.delete)),
                  onPressed: onDelete,
                ),
              ],
            )
          : Text(attendee.optional ? optionalLabel : requiredLabel);
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: compact
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  identity,
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: controls,
                  ),
                ],
              )
            : Row(
                children: [
                  Expanded(child: identity),
                  const SizedBox(width: 8),
                  controls,
                ],
              ),
      );
    },
  );
}

class _WindowsAddGuestRow extends StatelessWidget {
  const _WindowsAddGuestRow({
    required this.controller,
    required this.label,
    required this.enabled,
    required this.onChanged,
    required this.onAdd,
  });

  final TextEditingController controller;
  final String label;
  final bool enabled;
  final VoidCallback onChanged;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final compact =
          constraints.maxWidth < 440 ||
          MediaQuery.textScalerOf(context).scale(1) > 1.3;
      final field = TextBox(
        controller: controller,
        enabled: enabled,
        placeholder: label,
        onChanged: (_) => onChanged(),
        onSubmitted: enabled ? (_) => onAdd() : null,
      );
      final button = Button(
        onPressed: enabled ? onAdd : null,
        child: Text(label),
      );
      return compact
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                field,
                const SizedBox(height: 8),
                Align(alignment: AlignmentDirectional.centerEnd, child: button),
              ],
            )
          : Row(
              children: [
                Expanded(child: field),
                const SizedBox(width: 8),
                button,
              ],
            );
    },
  );
}

String _recurrenceLabel(AppLocalizations l10n, RecurrenceFrequency frequency) =>
    switch (frequency) {
      RecurrenceFrequency.none => l10n.repeatNone,
      RecurrenceFrequency.daily => l10n.repeatDaily,
      RecurrenceFrequency.weekly => l10n.repeatWeekly,
      RecurrenceFrequency.monthly => l10n.repeatMonthly,
      RecurrenceFrequency.yearly => l10n.repeatYearly,
    };

String _reminderLabel(AppLocalizations l10n, int minutes) {
  if (minutes == 0) return l10n.reminderAtStart;
  const minutesPerDay = Duration.minutesPerHour * Duration.hoursPerDay;
  if (minutes % minutesPerDay == 0) {
    return l10n.reminderDaysBefore(minutes ~/ minutesPerDay);
  }
  if (minutes % Duration.minutesPerHour == 0) {
    return l10n.reminderHoursBefore(minutes ~/ Duration.minutesPerHour);
  }
  return l10n.reminderMinutesBefore(minutes);
}

List<String> _showAsValues(BusyProvider provider) =>
    provider == BusyProvider.microsoft
    ? const ['free', 'tentative', 'busy', 'oof', 'workingElsewhere']
    : const ['opaque', 'transparent'];

String _availabilityLabel(AppLocalizations l10n, String value) =>
    switch (value) {
      'opaque' || 'busy' => l10n.busy,
      'transparent' || 'free' => l10n.availabilityFree,
      'tentative' => l10n.availabilityTentative,
      'oof' => l10n.availabilityOutOfOffice,
      'workingElsewhere' => l10n.availabilityWorkingElsewhere,
      _ => value,
    };

List<String> _visibilityValues(BusyProvider provider) =>
    provider == BusyProvider.microsoft
    ? const ['normal', 'personal', 'private', 'confidential']
    : const ['default', 'public', 'private', 'confidential'];

String _visibilityLabel(AppLocalizations l10n, String value) => switch (value) {
  'default' => l10n.visibilityDefault,
  'public' => l10n.visibilityPublic,
  'private' => l10n.visibilityPrivate,
  'confidential' => l10n.visibilityConfidential,
  'normal' => l10n.sensitivityNormal,
  'personal' => l10n.sensitivityPersonal,
  _ => value,
};

List<String> _categories(String value) => value
    .split(',')
    .map((category) => category.trim())
    .where((category) => category.isNotEmpty)
    .toSet()
    .toList(growable: false);

bool _looksLikeEmail(String value) =>
    RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value);

bool _hasExternalGuests(
  List<EventAttendeeDraft> attendees, [
  List<EventAttendeeDraft> previous = const [],
]) => [
  ...attendees,
  ...previous,
].any((attendee) => !attendee.self && !attendee.organizer);

Future<bool> _confirmDiscardEventChanges(BuildContext context) async {
  final l10n = AppLocalizations.of(context);
  return await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => ContentDialog(
          title: Text(l10n.discardChanges),
          content: const SizedBox.shrink(),
          actions: [
            Button(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(l10n.cancel),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(l10n.discardChangesAction),
            ),
          ],
        ),
      ) ??
      false;
}

Future<RecurringEventMutationScope?> showWindowsRecurringEventMutationScope(
  BuildContext context,
  BusyProvider provider, {
  bool? supportsFollowingOverride,
}) {
  final l10n = AppLocalizations.of(context);
  final supportsFollowing =
      supportsFollowingOverride ??
      supportsThisAndFollowingEventMutation(provider);
  return showDialog<RecurringEventMutationScope>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => ContentDialog(
      title: Text(l10n.recurringEventScope),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(l10n.chooseRecurringEventScope),
          const SizedBox(height: 12),
          Button(
            onPressed: () => Navigator.pop(
              dialogContext,
              RecurringEventMutationScope.singleOccurrence,
            ),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(l10n.singleOccurrence),
            ),
          ),
          const SizedBox(height: 8),
          Button(
            onPressed: supportsFollowing
                ? () => Navigator.pop(
                    dialogContext,
                    RecurringEventMutationScope.thisAndFuture,
                  )
                : null,
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                supportsFollowing
                    ? l10n.thisAndFollowingEvents
                    : '${l10n.thisAndFollowingEvents}\n'
                          '${l10n.thisAndFutureUnavailable}',
              ),
            ),
          ),
          const SizedBox(height: 8),
          Button(
            onPressed: () => Navigator.pop(
              dialogContext,
              RecurringEventMutationScope.entireSeries,
            ),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(l10n.entireSeries),
            ),
          ),
        ],
      ),
      actions: [
        Button(
          onPressed: () => Navigator.pop(dialogContext),
          child: Text(l10n.cancel),
        ),
      ],
    ),
  );
}

Future<bool> _confirmCopyThenDelete(
  BuildContext context, {
  required String sourceLabel,
  required String destinationLabel,
}) async {
  final l10n = AppLocalizations.of(context);
  return await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => ContentDialog(
          title: Text(l10n.copyEventAndDeleteOriginal),
          content: Text(
            l10n.copyEventMoveWarning(sourceLabel, destinationLabel),
          ),
          actions: [
            Button(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(l10n.cancel),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(l10n.copyAndDelete),
            ),
          ],
        ),
      ) ??
      false;
}

String _calendarSourceLabel(
  CalendarSourceEntity source,
  List<AccountEntity> accounts,
) {
  for (final account in accounts) {
    if (account.id == source.accountId) {
      return '${account.selectorLabel} · ${source.summary}';
    }
  }
  return '${source.provider.displayName} · ${source.summary}';
}
