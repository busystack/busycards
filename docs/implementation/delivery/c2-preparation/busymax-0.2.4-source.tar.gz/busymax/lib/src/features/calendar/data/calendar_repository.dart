import '../domain/event_property_policy.dart';
import 'dart:convert';

import 'package:busymax/src/providers/busy_provider.dart';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../../calendar_providers/calendar_colors.dart';
import '../../../calendar_providers/calendar_description.dart';
import '../../../calendar_providers/calendar_create_identity.dart';
import '../../../calendar_providers/calendar_mutation.dart';
import '../../../calendar_providers/calendar_provider_capabilities.dart';
import '../../../dav/storage/dav_collection_capabilities.dart';
import '../../../dav/nextcloud/nextcloud_collection_service.dart';
import '../../../dav/nextcloud/nextcloud_dav_context.dart';
import '../../../dav/xml/dav_xml.dart';
import '../../../calendar_providers/calendar_sync_dto.dart';
import '../../../core/time/provider_date_time.dart';
import '../../../core/time/stored_temporal_projection.dart';
import '../../../dav/ical/ical_document.dart';
import '../../../dav/ical/ical_semantics.dart';
import '../../../dav/ical/ical_timezone.dart';
import '../../../dav/mutation/dav_mutation_patch.dart';
import '../../../dav/mutation/dav_pending_operations.dart';
import '../../../dav/mutation/dav_projection_mutations.dart';
import '../../../dav/storage/dav_object_repository.dart';
import '../../../db/app_database.dart';
import '../../../google_calendar/google_calendar_mapper.dart';
import '../../../microsoft_calendar/microsoft_calendar_mapper.dart';
import '../../../microsoft_calendar/microsoft_shared_calendar_address.dart';
import '../../accounts/domain/account_collection_creation_capabilities.dart';
import '../../notifications/notification_schedule_service.dart';
import '../../recurrence/domain/event_recurrence_codec.dart';
import '../../maps/domain/geographic_point.dart';
import '../domain/event_move_policy.dart';
import '../domain/google_status_event.dart';
import '../domain/event_timing_policy.dart';
import '../../maps/domain/location_result.dart';
import '../../maps/data/location_resolution_repository.dart';
import '../presentation/event_editor_draft.dart';
import 'calendar_event_detail.dart';
import '../../../dav/nextcloud/nextcloud_scheduling_policy.dart';
import '../../../dav/nextcloud/nextcloud_meeting_mutations.dart';

typedef CalendarEventRecoveryFetcher =
    Future<CalendarEventDto> Function({
      required String calendarId,
      required String eventId,
    });

final class ImportedEventException {
  const ImportedEventException({
    required this.originalStart,
    required this.cancelled,
    required this.fields,
  });

  /// The original recurrence position, not the moved start time.
  final String originalStart;
  final bool cancelled;
  final Map<String, Object?> fields;
}

class CalendarSourceEntity {
  const CalendarSourceEntity({
    required this.id,
    required this.accountId,
    required this.provider,
    required this.providerCalendarId,
    required this.summary,
    required this.selected,
    this.remindersEnabled = true,
    required this.hidden,
    required this.readOnly,
    required this.isDeleted,
    this.primaryCalendar = false,
    this.description,
    this.backgroundColor,
    this.foregroundColor,
    this.colorId,
    this.timeZone,
    this.accessRole,
    this.dataOwner,
    this.isRemovable,
    this.authenticatedAccountEmail,
    this.pendingCreate = false,
    this.davCollectionId,
    this.allowedConferenceSolutions = const [],
    this.davEffectivePermissions = const {},
  });

  factory CalendarSourceEntity.fromRow(
    CalendarSource row, {
    DavCollection? davCollection,
    String? authenticatedAccountEmail,
    bool pendingCreate = false,
  }) {
    return CalendarSourceEntity(
      id: row.id,
      accountId: row.accountId,
      provider: BusyProviderCodec.requireStorageValue(row.provider),
      providerCalendarId: row.providerCalendarId,
      summary: row.summary,
      selected: row.selected,
      remindersEnabled: row.remindersEnabled,
      hidden: row.hidden,
      readOnly: row.readOnly,
      isDeleted: row.isDeleted,
      primaryCalendar: row.primaryCalendar,
      description: row.description,
      backgroundColor: row.backgroundColor,
      foregroundColor: row.foregroundColor,
      colorId: row.colorId,
      timeZone: row.timeZone,
      accessRole: row.accessRole,
      dataOwner: row.dataOwner,
      isRemovable: row.isRemovable,
      authenticatedAccountEmail: authenticatedAccountEmail,
      pendingCreate: pendingCreate,
      davCollectionId: row.davCollectionId,
      allowedConferenceSolutions: _conferenceSolutions(row.rawJson),
      davEffectivePermissions: row.provider == 'nextcloud'
          ? (davCollection == null
                ? _jsonMap(row.rawJson)
                : davSourcePermissionProjection(davCollection))
          : const {},
    );
  }

  final String id;
  final String accountId;
  final BusyProvider provider;
  final String providerCalendarId;
  final String summary;
  final bool selected;
  final bool remindersEnabled;
  final bool hidden;
  final bool readOnly;
  final bool isDeleted;
  final bool primaryCalendar;
  final String? description;
  final String? backgroundColor;
  final String? foregroundColor;
  final String? colorId;
  final String? timeZone;
  final String? accessRole;
  final String? dataOwner;
  final bool? isRemovable;
  final String? authenticatedAccountEmail;
  final bool pendingCreate;
  final String? davCollectionId;
  final List<String> allowedConferenceSolutions;
  final Map<String, Object?> davEffectivePermissions;

  CalendarSourceCapabilities get capabilities =>
      CalendarSourceCapabilities.fromSource(this);

  bool get isCurrentGoogleDataOwner {
    if (provider != BusyProvider.google) return false;
    final owner = dataOwner?.trim().toLowerCase();
    final identity = authenticatedAccountEmail?.trim().toLowerCase();
    return owner != null &&
        owner.isNotEmpty &&
        identity != null &&
        identity.isNotEmpty &&
        owner == identity;
  }

  bool get hasAuthenticatedGoogleIdentity =>
      provider == BusyProvider.google &&
      authenticatedAccountEmail?.trim().isNotEmpty == true;
}

enum CalendarRenameMode { unavailable, global, personal }

enum CalendarRemovalMode { unavailable, delete, removeFromList }

/// The event operations currently permitted by a calendar source.
///
/// Keeping this policy with the source model gives every presentation surface
/// and mutation entry point the same answer. Visibility is deliberately not a
/// write capability: a hidden calendar can still own an event that is opened
/// from a notification or deep link.
class CalendarSourceCapabilities {
  const CalendarSourceCapabilities({
    required this.canCreateEvents,
    required this.canEditEvents,
    required this.canDeleteEvents,
    required this.canRenameCalendar,
    required this.canDeleteCalendar,
    required this.canChangeCalendarColor,
    required this.canChangeProviderVisibility,
    required this.renameMode,
    required this.removalMode,
  });

  factory CalendarSourceCapabilities.fromSource(CalendarSourceEntity source) {
    final available = !source.isDeleted;
    final writable = !source.readOnly && available;
    final openedMicrosoftOwner =
        source.provider == BusyProvider.microsoft &&
        MicrosoftSharedPrimaryCalendarAddress.parse(
              source.providerCalendarId,
            ) !=
            null;
    final management = calendarManagementCapabilities(source.provider);
    final dav = source.davEffectivePermissions;
    final davMetadataWritable = available && dav['canWriteProperties'] == true;
    final parentPrivileges = (dav['parentPrivileges'] as List? ?? [])
        .whereType<String>()
        .toSet();
    final davRemovable = available && davPrivilege(parentPrivileges, 'unbind');
    final receivedShare =
        dav['delegated'] != true &&
        dav['ownerHref'] != null &&
        dav['principalHref'] != null &&
        Uri.parse(
              dav['ownerHref']! as String,
            ).path.replaceFirst(RegExp(r'/+$'), '') !=
            Uri.parse(
              dav['principalHref']! as String,
            ).path.replaceFirst(RegExp(r'/+$'), '');
    final renameMode = switch (source.provider) {
      BusyProvider.nextcloud when davMetadataWritable =>
        CalendarRenameMode.global,
      BusyProvider.google || BusyProvider.microsoft
          when available && source.pendingCreate =>
        CalendarRenameMode.global,
      BusyProvider.google when available =>
        source.primaryCalendar || source.isCurrentGoogleDataOwner
            ? CalendarRenameMode.global
            : CalendarRenameMode.personal,
      BusyProvider.microsoft when writable && !openedMicrosoftOwner =>
        CalendarRenameMode.global,
      _ => CalendarRenameMode.unavailable,
    };
    final removalMode = switch (source.provider) {
      BusyProvider.nextcloud when davRemovable =>
        receivedShare
            ? CalendarRemovalMode.removeFromList
            : CalendarRemovalMode.delete,
      BusyProvider.google || BusyProvider.microsoft
          when available && source.pendingCreate =>
        CalendarRemovalMode.delete,
      BusyProvider.microsoft when available && openedMicrosoftOwner =>
        CalendarRemovalMode.removeFromList,
      BusyProvider.google
          when available &&
              !source.primaryCalendar &&
              source.isCurrentGoogleDataOwner =>
        CalendarRemovalMode.delete,
      BusyProvider.google
          when available &&
              !source.primaryCalendar &&
              source.hasAuthenticatedGoogleIdentity &&
              source.dataOwner?.trim().isNotEmpty == true =>
        CalendarRemovalMode.removeFromList,
      BusyProvider.microsoft
          when available &&
              !source.primaryCalendar &&
              source.isRemovable == true =>
        CalendarRemovalMode.delete,
      _ => CalendarRemovalMode.unavailable,
    };
    return CalendarSourceCapabilities(
      canCreateEvents: source.provider == BusyProvider.nextcloud
          ? available &&
                source.davEffectivePermissions['canCreateEvents'] == true
          : writable,
      canEditEvents: source.provider == BusyProvider.nextcloud
          ? available && source.davEffectivePermissions['canEditEvents'] == true
          : writable,
      canDeleteEvents: source.provider == BusyProvider.nextcloud
          ? available &&
                source.davEffectivePermissions['canDeleteEvents'] == true
          : writable,
      canRenameCalendar:
          management.supportsRename &&
          renameMode != CalendarRenameMode.unavailable,
      canDeleteCalendar:
          management.supportsDelete &&
          removalMode == CalendarRemovalMode.delete,
      canChangeCalendarColor:
          management.supportsColor &&
          (source.provider == BusyProvider.nextcloud
              ? davMetadataWritable
              : source.provider == BusyProvider.google
              ? available
              : writable && !openedMicrosoftOwner),
      canChangeProviderVisibility:
          source.provider == BusyProvider.google &&
          available &&
          !source.primaryCalendar,
      renameMode: renameMode,
      removalMode: removalMode,
    );
  }

  static const unavailable = CalendarSourceCapabilities(
    canCreateEvents: false,
    canEditEvents: false,
    canDeleteEvents: false,
    canRenameCalendar: false,
    canDeleteCalendar: false,
    canChangeCalendarColor: false,
    canChangeProviderVisibility: false,
    renameMode: CalendarRenameMode.unavailable,
    removalMode: CalendarRemovalMode.unavailable,
  );

  final bool canCreateEvents;
  final bool canEditEvents;
  final bool canDeleteEvents;
  final bool canRenameCalendar;
  final bool canDeleteCalendar;
  final bool canChangeCalendarColor;
  final bool canChangeProviderVisibility;
  final CalendarRenameMode renameMode;
  final CalendarRemovalMode removalMode;

  bool get canRemoveCalendar => removalMode != CalendarRemovalMode.unavailable;
}

enum CalendarMutationOperation {
  createCalendar,
  createEvent,
  editEvent,
  moveEvent,
  deleteEvent,
  renameCalendar,
  changeCalendarColor,
  changeProviderVisibility,
  deleteCalendar,
  removeCalendar,
}

class CalendarMutationNotAllowed implements Exception {
  const CalendarMutationNotAllowed({
    required this.operation,
    required this.sourceId,
    this.reason = CalendarMutationDenialReason.capability,
  });

  final CalendarMutationOperation operation;
  final String sourceId;
  final CalendarMutationDenialReason reason;

  @override
  String toString() {
    return 'CalendarMutationNotAllowed('
        '${operation.name}, source: $sourceId, reason: ${reason.name})';
  }
}

enum CalendarMutationDenialReason {
  capability,
  pendingChanges,
  destinationPendingCreate,
}

List<CalendarSourceEntity> writableCalendarSources(
  Iterable<CalendarSourceEntity> sources,
) {
  return [
    for (final source in sources)
      if (source.capabilities.canCreateEvents) source,
  ];
}

class CalendarRepository {
  CalendarRepository({
    required AppDatabase database,
    NextcloudCollectionService Function(String accountId)? nextcloudCollections,
    DateTime Function()? now,
    String? localTimeZone,
    Future<void> Function()? onNotificationScheduleChanged,
  }) : _database = database,
       _nextcloudCollections = nextcloudCollections,
       _now = now ?? DateTime.now,
       _localTimeZone = localTimeZone,
       _onNotificationScheduleChanged = onNotificationScheduleChanged;

  final AppDatabase _database;
  final NextcloudCollectionService Function(String accountId)?
  _nextcloudCollections;
  final DateTime Function() _now;
  final String? _localTimeZone;
  final Future<void> Function()? _onNotificationScheduleChanged;

  Stream<List<CalendarSourceEntity>> watchSourcesForAccounts(
    List<String> accountIds,
  ) {
    if (accountIds.isEmpty) {
      return Stream.value(const []);
    }
    final query = _database.select(_database.calendarSources).join([
      leftOuterJoin(
        _database.davCollections,
        _database.davCollections.id.equalsExp(
          _database.calendarSources.davCollectionId,
        ),
      ),
      innerJoin(
        _database.accounts,
        _database.accounts.id.equalsExp(_database.calendarSources.accountId),
      ),
      leftOuterJoin(
        _database.pendingOps,
        _database.pendingOps.calendarSourceId.equalsExp(
              _database.calendarSources.id,
            ) &
            _database.pendingOps.operationType.equals('calendar.create'),
      ),
    ]);
    query.where(
      _database.calendarSources.accountId.isIn(accountIds) &
          _database.calendarSources.isDeleted.equals(false),
    );
    query.orderBy([
      OrderingTerm.asc(_database.calendarSources.accountId),
      OrderingTerm.asc(_database.calendarSources.summary),
    ]);
    return query.watch().map(
      (rows) => [
        for (final result in rows)
          CalendarSourceEntity.fromRow(
            result.readTable(_database.calendarSources),
            davCollection: result.readTableOrNull(_database.davCollections),
            authenticatedAccountEmail: result
                .readTable(_database.accounts)
                .email,
            pendingCreate: result.readTableOrNull(_database.pendingOps) != null,
          ),
      ],
    );
  }

  Future<List<CalendarSourceEntity>> listVisibleSources(
    List<String> accountIds,
  ) async {
    if (accountIds.isEmpty) {
      return const [];
    }
    final query = _database.select(_database.calendarSources).join([
      leftOuterJoin(
        _database.davCollections,
        _database.davCollections.id.equalsExp(
          _database.calendarSources.davCollectionId,
        ),
      ),
      innerJoin(
        _database.accounts,
        _database.accounts.id.equalsExp(_database.calendarSources.accountId),
      ),
      leftOuterJoin(
        _database.pendingOps,
        _database.pendingOps.calendarSourceId.equalsExp(
              _database.calendarSources.id,
            ) &
            _database.pendingOps.operationType.equals('calendar.create') &
            _database.pendingOps.state.equals('pending'),
      ),
    ]);
    query.where(
      _database.calendarSources.accountId.isIn(accountIds) &
          _database.calendarSources.selected.equals(true) &
          _database.calendarSources.hidden.equals(false) &
          _database.calendarSources.isDeleted.equals(false),
    );
    final rows = await query.get();
    return [
      for (final result in rows)
        CalendarSourceEntity.fromRow(
          result.readTable(_database.calendarSources),
          davCollection: result.readTableOrNull(_database.davCollections),
          authenticatedAccountEmail: result.readTable(_database.accounts).email,
          pendingCreate: result.readTableOrNull(_database.pendingOps) != null,
        ),
    ];
  }

  Future<CalendarEventDetail?> loadEventDetail(String eventId) async {
    final row = await (_database.select(
      _database.calendarEvents,
    )..where((event) => event.id.equals(eventId))).getSingleOrNull();
    return row == null ? null : CalendarEventDetail.fromRow(row);
  }

  Future<String?> nativeEventExport(String eventId) async {
    final detail = await loadEventDetail(eventId);
    if (detail == null) throw StateError('The event is no longer available.');
    if (detail.davCollectionId == null) return null;
    final document = detail.davObjectId == null
        ? await loadEventTimeZoneDocument(detail)
        : await DavPendingOperationQueue(
            database: _database,
            nowUtc: () => _now().toUtc(),
          ).exportRawIcsForObject(
            accountId: detail.accountId,
            collectionId: detail.davCollectionId!,
            objectId: detail.davObjectId!,
          );
    if (document == null) {
      throw StateError('The authoritative calendar resource is unavailable.');
    }
    return document;
  }

  /// Uses the editable document, including queued local changes and its
  /// embedded VTIMEZONE rules, rather than a provider or machine-zone guess.
  Future<String?> loadEventTimeZoneDocument(CalendarEventDetail detail) async {
    final collectionId = detail.davCollectionId;
    if (collectionId == null) return null;
    if (detail.davObjectId == null) {
      final create = await _pendingDavCreateForProjection(detail.id);
      return create == null ? null : _pendingCreateRawIcs(create);
    }
    return DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    ).editableRawIcsForObject(
      accountId: detail.accountId,
      collectionId: collectionId,
      objectId: detail.davObjectId!,
    );
  }

  Future<CalendarSourceEntity> _sourceEntity(CalendarSource source) async {
    final account = await (_database.select(
      _database.accounts,
    )..where((row) => row.id.equals(source.accountId))).getSingle();
    return CalendarSourceEntity.fromRow(
      source,
      davCollection: source.davCollectionId == null
          ? null
          : await (_database.select(_database.davCollections)
                  ..where((r) => r.id.equals(source.davCollectionId!)))
                .getSingleOrNull(),
      authenticatedAccountEmail: account.email,
      pendingCreate: await _pendingCalendarCreate(source.id) != null,
    );
  }

  NextcloudCollectionService _requiredNextcloudCollections(
    CalendarSource source,
  ) {
    if (_nextcloudCollections == null || source.davCollectionId == null) {
      throw UnsupportedError(
        'Nextcloud collection administration is unavailable.',
      );
    }
    return _nextcloudCollections(source.accountId);
  }

  Future<void> setSourceSelected(String sourceId, bool selected) async {
    await (_database.update(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).write(
      CalendarSourcesCompanion(
        selected: Value(selected),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
      ),
    );
  }

  Future<void> setSourceRemindersEnabled(String sourceId, bool enabled) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingle();
    await (_database.update(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).write(
      CalendarSourcesCompanion(
        remindersEnabled: Value(enabled),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
      ),
    );
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      source.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> setSourceProviderHidden(String sourceId, bool hidden) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingle();
    final entity = await _sourceEntity(source);
    _requireCalendarSourceCapability(
      source,
      operation: CalendarMutationOperation.changeProviderVisibility,
      allowed: entity.capabilities.canChangeProviderVisibility,
    );
    if (source.hidden == hidden) return;

    final now = _now();
    final nowUtc = now.toUtc().toIso8601String();
    final createOp = await _pendingCalendarCreate(source.id);
    await _database.transaction(() async {
      await (_database.update(
        _database.calendarSources,
      )..where((row) => row.id.equals(sourceId))).write(
        CalendarSourcesCompanion(
          hidden: Value(hidden),
          updatedAtLocal: Value(now.millisecondsSinceEpoch),
        ),
      );
      await _enqueueOrMergeCalendarPatch(
        source,
        request: {
          'hidden': hidden,
          calendarMutationScopeKey: calendarMutationScopePersonal,
        },
        nowUtc: nowUtc,
        dependsOnOpId: createOp?.id,
      );
    });
  }

  Future<String> createLocalSource({
    required String accountId,
    required String summary,
  }) async {
    final title = summary.trim();
    if (title.isEmpty) {
      throw ArgumentError.value(summary, 'summary', 'Calendar title is empty.');
    }
    final account = await (_database.select(
      _database.accounts,
    )..where((row) => row.id.equals(accountId))).getSingle();
    final provider = BusyProviderCodec.requireStorageValue(account.provider);
    if (accountCollectionCreationModes(provider).calendarMode !=
        CalendarCollectionCreationMode.cloudPendingOperation) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.createCalendar,
        sourceId: accountId,
      );
    }

    final uuid = const Uuid();
    final providerCalendarId = 'local:${uuid.v4()}';
    final id = sourceId(
      accountId: accountId,
      provider: provider,
      providerCalendarId: providerCalendarId,
    );
    final operationId = uuid.v4();
    final now = _now();
    final nowUtc = now.toUtc().toIso8601String();
    await _database.transaction(() async {
      await _database
          .into(_database.calendarSources)
          .insert(
            CalendarSourcesCompanion.insert(
              id: id,
              accountId: accountId,
              provider: provider.storageValue,
              providerCalendarId: providerCalendarId,
              summary: title,
              rawJson: Value(
                jsonEncode({
                  'id': providerCalendarId,
                  'summary': title,
                  '_localCreated': true,
                }),
              ),
              createdAtLocal: now.millisecondsSinceEpoch,
              updatedAtLocal: now.millisecondsSinceEpoch,
            ),
          );
      await _database.pendingOpsDao.enqueue(
        PendingOpsCompanion.insert(
          id: operationId,
          accountId: accountId,
          provider: Value(provider.storageValue),
          entityType: 'calendar',
          operation: 'create',
          operationType: const Value('calendar.create'),
          calendarSourceId: Value(id),
          providerCalendarId: Value(providerCalendarId),
          localTempId: Value(providerCalendarId),
          requestJson: jsonEncode({'summary': title}),
          createdAtUtc: nowUtc,
          updatedAtUtc: nowUtc,
        ),
      );
    });
    return id;
  }

  Future<void> renameLocalSource(String sourceId, String summary) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingle();
    final entity = await _sourceEntity(source);
    _requireCalendarSourceCapability(
      source,
      operation: CalendarMutationOperation.renameCalendar,
      allowed: entity.capabilities.canRenameCalendar,
    );
    final title = summary.trim();
    if (entity.provider == BusyProvider.nextcloud) {
      final result = await _requiredNextcloudCollections(source).update(
        source.davCollectionId!,
        {const DavPropertyName(davNamespace, 'displayname'): title},
      );
      if (result == NextcloudMutationOutcome.refreshPending) {
        throw const NextcloudRefreshPending();
      }
      return;
    }
    if (title.isEmpty) {
      throw ArgumentError.value(summary, 'summary', 'Calendar title is empty.');
    }
    final now = _now();
    final nowUtc = now.toUtc().toIso8601String();
    final createOp = await _pendingCalendarCreate(source.id);
    await _database.transaction(() async {
      await (_database.update(
        _database.calendarSources,
      )..where((row) => row.id.equals(sourceId))).write(
        CalendarSourcesCompanion(
          summary: Value(title),
          updatedAtLocal: Value(now.millisecondsSinceEpoch),
        ),
      );
      var rewroteCreate = false;
      if (_isProvablyUnsentCalendarCreate(createOp)) {
        final createSnapshot = createOp!;
        final request = _calendarPendingRequest(createSnapshot)
          ..['summary'] = title;
        rewroteCreate =
            await (_database.update(_database.pendingOps)..where(
                  (row) =>
                      row.id.equals(createSnapshot.id) &
                      row.state.equals(createSnapshot.state) &
                      row.attemptCount.equals(createSnapshot.attemptCount) &
                      row.requestJson.equals(createSnapshot.requestJson) &
                      row.updatedAtUtc.equals(createSnapshot.updatedAtUtc),
                ))
                .write(
                  PendingOpsCompanion(
                    requestJson: Value(jsonEncode(request)),
                    updatedAtUtc: Value(nowUtc),
                  ),
                ) ==
            1;
      }
      if (!rewroteCreate) {
        await _enqueueOrMergeCalendarPatch(
          source,
          request: {
            'summary': title,
            calendarMutationScopeKey:
                entity.capabilities.renameMode == CalendarRenameMode.personal
                ? calendarMutationScopePersonal
                : calendarMutationScopeGlobal,
          },
          nowUtc: nowUtc,
          dependsOnOpId: createOp?.id,
        );
      }
    });
  }

  Future<void> setSourceColor(
    String sourceId,
    CalendarColorChoice choice,
  ) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingle();
    final entity = await _sourceEntity(source);
    _requireCalendarSourceCapability(
      source,
      operation: CalendarMutationOperation.changeCalendarColor,
      allowed: entity.capabilities.canChangeCalendarColor,
    );
    final supportedChoice = calendarColorChoices(entity.provider).any(
      (candidate) =>
          candidate.providerValue == choice.providerValue &&
          candidate.backgroundColor.toLowerCase() ==
              choice.backgroundColor.toLowerCase(),
    );
    if (entity.provider == BusyProvider.nextcloud && supportedChoice) {
      final result = await _requiredNextcloudCollections(source)
          .update(source.davCollectionId!, {
            const DavPropertyName(appleIcalNamespace, 'calendar-color'):
                choice.backgroundColor,
          });
      if (result == NextcloudMutationOutcome.refreshPending) {
        throw const NextcloudRefreshPending();
      }
      return;
    }
    if (!supportedChoice) {
      throw ArgumentError.value(
        choice.providerValue,
        'choice',
        'Unsupported calendar color.',
      );
    }

    final now = _now();
    final nowUtc = now.toUtc().toIso8601String();
    final createOp = await _pendingCalendarCreate(source.id);
    final foregroundColor = calendarColorForegroundHex(choice.backgroundColor);
    final request = switch (entity.provider) {
      BusyProvider.google => <String, Object?>{
        'backgroundColor': choice.backgroundColor,
        'foregroundColor': foregroundColor,
        calendarMutationScopeKey: calendarMutationScopePersonal,
      },
      BusyProvider.microsoft => <String, Object?>{
        'colorId': choice.providerValue,
      },
      BusyProvider.appleICloud || BusyProvider.nextcloud => throw StateError(
        'DAV calendar colors are not mutable.',
      ),
      BusyProvider.webCal => throw StateError(
        'WebCal subscription colors use local subscription operations.',
      ),
    };
    await _database.transaction(() async {
      await (_database.update(
        _database.calendarSources,
      )..where((row) => row.id.equals(sourceId))).write(
        CalendarSourcesCompanion(
          backgroundColor: Value(choice.backgroundColor),
          foregroundColor: entity.provider == BusyProvider.google
              ? Value(foregroundColor)
              : const Value.absent(),
          colorId: Value(
            entity.provider == BusyProvider.microsoft
                ? choice.providerValue
                : null,
          ),
          updatedAtLocal: Value(now.millisecondsSinceEpoch),
        ),
      );
      await _enqueueOrMergeCalendarPatch(
        source,
        request: request,
        nowUtc: nowUtc,
        dependsOnOpId: createOp?.id,
      );
    });
  }

  Future<void> deleteLocalSource(String sourceId) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingle();
    final entity = await _sourceEntity(source);
    if (entity.provider == BusyProvider.nextcloud) {
      final result = await _requiredNextcloudCollections(
        source,
      ).remove(source.davCollectionId!);
      if (result == NextcloudMutationOutcome.refreshPending) {
        throw const NextcloudRefreshPending();
      }
      return;
    }
    final removalMode = entity.capabilities.removalMode;
    final openedMicrosoftOwner =
        entity.provider == BusyProvider.microsoft &&
        MicrosoftSharedPrimaryCalendarAddress.parse(
              source.providerCalendarId,
            ) !=
            null;
    final createOp = await _pendingCalendarCreate(source.id);
    _requireCalendarSourceCapability(
      source,
      operation: removalMode == CalendarRemovalMode.removeFromList
          ? CalendarMutationOperation.removeCalendar
          : CalendarMutationOperation.deleteCalendar,
      allowed: createOp != null || entity.capabilities.canRemoveCalendar,
    );
    final now = _now();
    final nowUtc = now.toUtc().toIso8601String();
    await _database.transaction(() async {
      if (_isProvablyUnsentCalendarCreate(createOp)) {
        final deleted =
            await (_database.delete(_database.pendingOps)..where(
                  (row) =>
                      row.id.equals(createOp!.id) &
                      row.state.equals(createOp.state) &
                      row.attemptCount.equals(createOp.attemptCount) &
                      row.requestJson.equals(createOp.requestJson) &
                      row.updatedAtUtc.equals(createOp.updatedAtUtc),
                ))
                .go();
        if (deleted != 1) {
          throw StateError(
            'The calendar creation is no longer safe to cancel locally.',
          );
        }
        await (_database.delete(_database.pendingOps)..where(
              (row) =>
                  row.accountId.equals(source.accountId) &
                  row.calendarSourceId.equals(source.id),
            ))
            .go();
        await (_database.delete(
          _database.calendarSources,
        )..where((row) => row.id.equals(sourceId))).go();
        return;
      }
      final otherWork = (await _pendingCalendarWork(
        source.id,
      )).where((operation) => operation.id != createOp?.id);
      if (otherWork.isNotEmpty) {
        throw CalendarMutationNotAllowed(
          operation: removalMode == CalendarRemovalMode.removeFromList
              ? CalendarMutationOperation.removeCalendar
              : CalendarMutationOperation.deleteCalendar,
          sourceId: source.id,
          reason: CalendarMutationDenialReason.pendingChanges,
        );
      }
      await (_database.update(
        _database.calendarSources,
      )..where((row) => row.id.equals(sourceId))).write(
        CalendarSourcesCompanion(
          isDeleted: const Value(true),
          hidden: const Value(true),
          rawJson: openedMicrosoftOwner
              ? Value(
                  jsonEncode({
                    ..._jsonMap(source.rawJson),
                    '_busymaxLocallyRemovedOwnerCalendar': true,
                  }),
                )
              : const Value.absent(),
          updatedAtLocal: Value(now.millisecondsSinceEpoch),
        ),
      );
      if (openedMicrosoftOwner) return;
      await _database.pendingOpsDao.enqueue(
        PendingOpsCompanion.insert(
          id: const Uuid().v4(),
          accountId: source.accountId,
          provider: Value(source.provider),
          entityType: 'calendar',
          operation: removalMode == CalendarRemovalMode.removeFromList
              ? 'remove'
              : 'delete',
          operationType: Value(
            removalMode == CalendarRemovalMode.removeFromList
                ? 'calendar.remove'
                : 'calendar.delete',
          ),
          calendarSourceId: Value(source.id),
          providerCalendarId: Value(source.providerCalendarId),
          dependsOnOpId: Value(createOp?.id),
          requestJson: jsonEncode({
            calendarRemovalPreviousHiddenKey: source.hidden,
          }),
          baselineRawJson: Value(source.rawJson),
          createdAtUtc: nowUtc,
          updatedAtUtc: nowUtc,
        ),
      );
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      source.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> upsertSource({
    required String accountId,
    required CalendarSourceDto source,
    bool reopenLocallyRemovedOwner = false,
  }) async {
    final now = _now().millisecondsSinceEpoch;
    final id = sourceId(
      accountId: accountId,
      provider: source.provider,
      providerCalendarId: source.providerCalendarId,
    );
    await _database.transaction(() async {
      final existing = await (_database.select(
        _database.calendarSources,
      )..where((row) => row.id.equals(id))).getSingleOrNull();
      final locallyRemovedOwner =
          source.provider == BusyProvider.microsoft &&
          MicrosoftSharedPrimaryCalendarAddress.parse(
                source.providerCalendarId,
              ) !=
              null &&
          existing != null &&
          existing.isDeleted &&
          _jsonMap(existing.rawJson)['_busymaxLocallyRemovedOwnerCalendar'] ==
              true;
      if (locallyRemovedOwner && !reopenLocallyRemovedOwner) return;
      final pendingPatchFields = existing == null
          ? const <String>{}
          : await _pendingCalendarPatchFields(existing.id);
      final preservePendingColor =
          pendingPatchFields.contains('backgroundColor') ||
          pendingPatchFields.contains('foregroundColor') ||
          pendingPatchFields.contains('colorId');
      final preservePendingHidden = pendingPatchFields.contains('hidden');
      final preservePendingRemoval =
          existing != null && await _hasActiveCalendarRemoval(existing.id);
      final isDeleted = preservePendingRemoval || source.isDeleted;
      await _database
          .into(_database.calendarSources)
          .insertOnConflictUpdate(
            CalendarSourcesCompanion.insert(
              id: id,
              accountId: accountId,
              provider: source.provider.storageValue,
              providerCalendarId: source.providerCalendarId,
              summary: pendingPatchFields.contains('summary')
                  ? existing!.summary
                  : source.summary,
              description: Value(
                pendingPatchFields.contains('description')
                    ? existing!.description
                    : source.description,
              ),
              primaryCalendar: Value(source.primaryCalendar),
              selected: Value(existing?.selected ?? source.selected),
              remindersEnabled: Value(existing?.remindersEnabled ?? true),
              hidden: Value(
                isDeleted ||
                    (preservePendingHidden ? existing!.hidden : source.hidden),
              ),
              readOnly: Value(source.readOnly),
              backgroundColor: Value(
                preservePendingColor
                    ? existing!.backgroundColor
                    : source.backgroundColor,
              ),
              foregroundColor: Value(
                preservePendingColor
                    ? existing!.foregroundColor
                    : source.foregroundColor,
              ),
              colorId: Value(
                preservePendingColor ? existing!.colorId : source.colorId,
              ),
              timeZone: Value(
                pendingPatchFields.contains('timeZone')
                    ? existing!.timeZone
                    : source.timeZone,
              ),
              accessRole: Value(source.accessRole),
              dataOwner: Value(source.dataOwner),
              isRemovable: Value(source.isRemovable),
              isDeleted: Value(isDeleted),
              rawJson: Value(jsonEncode(source.rawJson)),
              createdAtLocal: existing?.createdAtLocal ?? now,
              updatedAtLocal: now,
            ),
          );
      if (source.provider == BusyProvider.google && source.isDeleted) {
        await LocationResolutionRepository(
          _database,
        ).removeGoogleSeriesSourcesForCalendar(
          accountId: accountId,
          sourceId: id,
        );
      }
    });
  }

  /// Reconciles a provider's complete calendar-list snapshot.
  ///
  /// A missing provider calendar is tombstoned locally together with its
  /// synchronized event cache. Calendar creations that are still queued are
  /// excluded because they cannot be expected to appear in the provider
  /// snapshot yet.
  Future<void> reconcileProviderSourceSnapshot({
    required String accountId,
    required BusyProvider provider,
    required Set<String> activeProviderCalendarIds,
  }) async {
    final now = _now().millisecondsSinceEpoch;
    await _database.transaction(() async {
      final pendingCreates =
          await (_database.select(_database.pendingOps)..where(
                (row) =>
                    row.accountId.equals(accountId) &
                    row.operationType.equals('calendar.create'),
              ))
              .get();
      final pendingCreateSourceIds = {
        for (final operation in pendingCreates)
          if (operation.calendarSourceId != null) operation.calendarSourceId!,
      };
      final pendingCreateProviderIds = {
        for (final operation in pendingCreates)
          if (operation.providerCalendarId != null)
            operation.providerCalendarId!,
      };
      final sources =
          await (_database.select(_database.calendarSources)..where(
                (row) =>
                    row.accountId.equals(accountId) &
                    row.provider.equals(provider.storageValue),
              ))
              .get();
      final missingSourceIds = {
        for (final source in sources)
          if (!activeProviderCalendarIds.contains(source.providerCalendarId) &&
              !(provider == BusyProvider.microsoft &&
                  MicrosoftSharedPrimaryCalendarAddress.parse(
                        source.providerCalendarId,
                      ) !=
                      null) &&
              !pendingCreateSourceIds.contains(source.id) &&
              !pendingCreateProviderIds.contains(source.providerCalendarId))
            source.id,
      };
      if (missingSourceIds.isEmpty) return;

      for (final sourceId in missingSourceIds) {
        await LocationResolutionRepository(
          _database,
        ).removeGoogleSeriesSourcesForCalendar(
          accountId: accountId,
          sourceId: sourceId,
        );
      }

      final missingEventIds = {
        for (final event
            in await (_database.select(_database.calendarEvents)..where(
                  (row) =>
                      row.accountId.equals(accountId) &
                      row.calendarSourceId.isIn(missingSourceIds),
                ))
                .get())
          event.id,
      };

      await (_database.update(_database.calendarSources)..where(
            (row) =>
                row.accountId.equals(accountId) & row.id.isIn(missingSourceIds),
          ))
          .write(
            CalendarSourcesCompanion(
              isDeleted: const Value(true),
              hidden: const Value(true),
              updatedAtLocal: Value(now),
            ),
          );
      await (_database.update(_database.calendarEvents)..where(
            (row) =>
                row.accountId.equals(accountId) &
                row.calendarSourceId.isIn(missingSourceIds) &
                row.syncStatus.equals('synced') &
                row.isDeleted.equals(false),
          ))
          .write(
            CalendarEventsCompanion(
              isDeleted: const Value(true),
              updatedAtLocal: Value(now),
            ),
          );
      if (missingEventIds.isNotEmpty) {
        await (_database.delete(_database.notificationSchedule)..where(
              (row) =>
                  row.accountId.equals(accountId) &
                  row.sourceType.equals('event') &
                  row.sourceId.isIn(missingEventIds),
            ))
            .go();
      }
      await (_database.delete(_database.syncCursors)..where(
            (row) =>
                row.accountId.equals(accountId) &
                row.provider.equals(provider.storageValue) &
                row.projectionSourceId.isIn(missingSourceIds),
          ))
          .go();
    });
  }

  Future<void> restoreSourceAfterRemovalFailure(PendingOp op) async {
    final operationType =
        op.operationType ?? '${op.entityType}.${op.operation}';
    if (operationType != 'calendar.delete' &&
        operationType != 'calendar.remove') {
      return;
    }
    final sourceId = op.calendarSourceId;
    if (sourceId == null) return;
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingleOrNull();
    if (source == null || !source.isDeleted) return;
    await (_database.update(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).write(
      CalendarSourcesCompanion(
        isDeleted: const Value(false),
        hidden: Value(_calendarRemovalPreviousHidden(op)),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
      ),
    );
  }

  Future<void> discardPendingCalendarCreation(PendingOp op) async {
    if (_calendarOperationType(op) != 'calendar.create') return;
    final sourceId = op.calendarSourceId;
    if (sourceId == null) return;
    await _database.transaction(() async {
      final accountOperations = await (_database.select(
        _database.pendingOps,
      )..where((row) => row.accountId.equals(op.accountId))).get();
      final discardedIds = <String>{op.id};
      var changed = true;
      while (changed) {
        changed = false;
        for (final operation in accountOperations) {
          if (discardedIds.contains(operation.id) ||
              (operation.calendarSourceId != sourceId &&
                  !discardedIds.contains(operation.dependsOnOpId))) {
            continue;
          }
          discardedIds.add(operation.id);
          changed = true;
        }
      }
      for (final operationId in discardedIds) {
        await _database.pendingOpsDao.deleteOp(operationId);
      }
      await (_database.delete(
        _database.calendarSources,
      )..where((row) => row.id.equals(sourceId))).go();
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      op.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> discardPendingEventCreation(PendingOp op) async {
    if (_calendarOperationType(op) != 'event.create') return;
    final eventId = op.eventId;
    if (eventId == null) return;
    final accountOperations = await (_database.select(
      _database.pendingOps,
    )..where((row) => row.accountId.equals(op.accountId))).get();
    final discardedIds = <String>{op.id};
    var changed = true;
    while (changed) {
      changed = false;
      for (final operation in accountOperations) {
        if (discardedIds.contains(operation.id) ||
            (operation.eventId != eventId &&
                !discardedIds.contains(operation.dependsOnOpId))) {
          continue;
        }
        discardedIds.add(operation.id);
        changed = true;
      }
    }
    final createdEventIds = {
      for (final operation in accountOperations)
        if (discardedIds.contains(operation.id) &&
            _calendarOperationType(operation) == 'event.create' &&
            operation.eventId != null)
          operation.eventId!,
    };
    await _database.transaction(() async {
      for (final operation in accountOperations) {
        if (!discardedIds.contains(operation.id) ||
            operation.entityType != 'event' ||
            operation.eventId == null ||
            createdEventIds.contains(operation.eventId)) {
          continue;
        }
        await _restoreEventProjectionAfterDiscard(
          operation,
          ignoredOperationIds: discardedIds,
        );
      }
      await (_database.delete(
        _database.pendingOps,
      )..where((row) => row.id.isIn(discardedIds))).go();
      await (_database.delete(_database.calendarEvents)..where(
            (row) =>
                row.accountId.equals(op.accountId) &
                row.id.isIn(createdEventIds),
          ))
          .go();
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      op.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> restoreEventAfterMutationDiscard(
    PendingOp op, {
    CalendarEventRecoveryFetcher? fetchProviderEvent,
  }) async {
    if (op.entityType != 'event' ||
        _calendarOperationType(op) == 'event.create') {
      return;
    }
    final eventId = op.eventId;
    if (eventId == null) {
      throw StateError('The event recovery identity is unavailable.');
    }
    final target = await (_database.select(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).getSingleOrNull();
    if (target == null) return;
    final provider = BusyProviderCodec.requireStorageValue(target.provider);
    CalendarEventDto? providerSnapshot;
    final operationBaseline = _jsonMap(op.baselineRawJson);
    final recoveryBaseline = operationBaseline.isNotEmpty
        ? operationBaseline
        : _jsonMap(target.baselineRawJson);
    if (!_isCompleteProviderEventBaseline(provider, recoveryBaseline)) {
      if (fetchProviderEvent == null) {
        throw StateError('The provider event recovery client is unavailable.');
      }
      providerSnapshot = await fetchProviderEvent(
        calendarId: target.providerCalendarId,
        eventId: target.providerEventId,
      );
    }
    await _database.transaction(
      () => _restoreEventProjectionAfterDiscard(
        op,
        ignoredOperationIds: {op.id},
        providerSnapshot: providerSnapshot,
      ),
    );
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      op.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> _restoreEventProjectionAfterDiscard(
    PendingOp op, {
    required Set<String> ignoredOperationIds,
    CalendarEventDto? providerSnapshot,
  }) async {
    final eventId = op.eventId;
    if (eventId == null) return;
    final target = await (_database.select(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).getSingleOrNull();
    if (target == null) return;
    final request = _jsonMap(op.requestJson);
    final seriesProviderEventId = request[calendarEventTargetProviderIdKey]
        ?.toString();
    final affectedEvents = seriesProviderEventId == null
        ? [target]
        : await (_database.select(_database.calendarEvents)..where(
                (row) =>
                    row.accountId.equals(target.accountId) &
                    row.provider.equals(target.provider) &
                    row.providerCalendarId.equals(target.providerCalendarId) &
                    (row.id.equals(target.id) |
                        row.providerEventId.equals(seriesProviderEventId) |
                        row.providerRecurringEventId.equals(
                          seriesProviderEventId,
                        )),
              ))
              .get();
    final affectedIds = {for (final event in affectedEvents) event.id};
    final remainingOperations =
        await (_database.select(_database.pendingOps)..where(
              (row) =>
                  row.accountId.equals(op.accountId) &
                  row.entityType.equals('event') &
                  row.id.isNotIn(ignoredOperationIds) &
                  row.eventId.isIn(affectedIds),
            ))
            .get();
    if (remainingOperations.isNotEmpty) return;

    for (final event in affectedEvents) {
      final provider = BusyProviderCodec.requireStorageValue(event.provider);
      final operationBaseline = event.id == eventId
          ? _jsonMap(op.baselineRawJson)
          : const <String, Object?>{};
      final restored = event.id == eventId && providerSnapshot != null
          ? providerSnapshot
          : _eventFromRecoveryBaseline(
              event,
              provider,
              operationBaseline.isNotEmpty
                  ? operationBaseline
                  : _jsonMap(event.baselineRawJson),
            );
      final restoredId = CalendarRepository.eventId(
        accountId: event.accountId,
        provider: provider,
        providerCalendarId: restored.providerCalendarId,
        providerEventId: restored.providerEventId,
        providerOriginalStartKey: restored.providerOriginalStartKey,
      );
      if (restoredId != event.id) {
        throw StateError('The event recovery baseline identity changed.');
      }
      await upsertEvent(accountId: event.accountId, event: restored);
    }
  }

  CalendarEventDto _eventFromRecoveryBaseline(
    CalendarEvent event,
    BusyProvider provider,
    Map<String, Object?> baseline,
  ) {
    if (!_isCompleteProviderEventBaseline(provider, baseline)) {
      throw StateError('A complete event recovery baseline is unavailable.');
    }
    baseline.putIfAbsent('id', () => event.providerEventId);
    // Preserve the original-start component of the local row identity for
    // legacy occurrence rows, but never manufacture a series identity. The
    // provider baseline alone decides whether the restored event is recurring.
    switch (provider) {
      case BusyProvider.google:
        if (event.providerOriginalStartKey case final originalStart?) {
          baseline.putIfAbsent(
            'originalStartTime',
            () => originalStart.length == 10
                ? {'date': originalStart}
                : {'dateTime': originalStart},
          );
        }
      case BusyProvider.microsoft:
        if (event.providerOriginalStartKey case final originalStart?) {
          baseline.putIfAbsent('originalStart', () => originalStart);
        }
      case BusyProvider.appleICloud ||
          BusyProvider.nextcloud ||
          BusyProvider.webCal:
        break;
    }
    return switch (provider) {
      BusyProvider.google => googleCalendarEventFromJson(
        event.providerCalendarId,
        baseline,
      ),
      BusyProvider.microsoft => microsoftCalendarEventFromJson(
        event.providerCalendarId,
        baseline,
      ),
      BusyProvider.appleICloud ||
      BusyProvider.nextcloud ||
      BusyProvider.webCal => throw StateError(
        'Provider event recovery is unavailable for ${provider.storageValue}.',
      ),
    };
  }

  bool _isCompleteProviderEventBaseline(
    BusyProvider provider,
    Map<String, Object?> baseline,
  ) {
    if (baseline.isEmpty ||
        baseline.containsKey(calendarEventSemanticBaselineKey)) {
      return false;
    }
    final start = _jsonObjectMap(baseline['start']);
    final end = _jsonObjectMap(baseline['end']);
    return switch (provider) {
      BusyProvider.google =>
        _hasNonEmptyValue(start, 'date', 'dateTime') &&
            _hasNonEmptyValue(end, 'date', 'dateTime'),
      BusyProvider.microsoft =>
        _hasNonEmptyValue(start, 'dateTime') &&
            _hasNonEmptyValue(end, 'dateTime'),
      BusyProvider.appleICloud ||
      BusyProvider.nextcloud ||
      BusyProvider.webCal => false,
    };
  }

  bool _hasNonEmptyValue(
    Map<String, Object?> values,
    String key, [
    String? alternativeKey,
  ]) {
    final value = values[key]?.toString().trim();
    if (value != null && value.isNotEmpty) return true;
    final alternative = alternativeKey == null
        ? null
        : values[alternativeKey]?.toString().trim();
    return alternative != null && alternative.isNotEmpty;
  }

  Future<void> restoreSourceAfterPatchDiscard(PendingOp op) async {
    if (_calendarOperationType(op) != 'calendar.patch') return;
    final sourceId = op.calendarSourceId;
    if (sourceId == null) return;
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingleOrNull();
    if (source == null) return;
    final request = _jsonMap(op.requestJson);
    final previous = _jsonObjectMap(request[calendarPatchPreviousValuesKey]);
    final baseline = _jsonMap(op.baselineRawJson);
    final changesSummary = request.containsKey('summary');
    final changesColor =
        request.containsKey('backgroundColor') ||
        request.containsKey('foregroundColor') ||
        request.containsKey('colorId');
    final changesHidden = request.containsKey('hidden');
    if (!changesSummary && !changesColor && !changesHidden) return;
    final provider = BusyProviderCodec.requireStorageValue(source.provider);
    final baselineSummary = switch (provider) {
      BusyProvider.google =>
        baseline['summaryOverride']?.toString().trim().isNotEmpty == true
            ? baseline['summaryOverride']!.toString()
            : baseline['summary']?.toString(),
      BusyProvider.microsoft => baseline['name']?.toString(),
      BusyProvider.appleICloud ||
      BusyProvider.nextcloud ||
      BusyProvider.webCal => null,
    };
    final baselineColorId = switch (provider) {
      BusyProvider.google => baseline['colorId']?.toString(),
      BusyProvider.microsoft => baseline['color']?.toString(),
      BusyProvider.appleICloud ||
      BusyProvider.nextcloud ||
      BusyProvider.webCal => null,
    };
    final baselineBackground = switch (provider) {
      BusyProvider.google => baseline['backgroundColor']?.toString(),
      BusyProvider.microsoft => calendarSourceBackgroundColorHex(
        provider: provider,
        backgroundColor: baseline['hexColor']?.toString(),
        colorId: baselineColorId,
      ),
      BusyProvider.appleICloud ||
      BusyProvider.nextcloud ||
      BusyProvider.webCal => null,
    };
    await (_database.update(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).write(
      CalendarSourcesCompanion(
        summary: changesSummary
            ? Value(
                previous['summary']?.toString() ??
                    baselineSummary ??
                    source.summary,
              )
            : const Value.absent(),
        backgroundColor: changesColor
            ? Value(
                previous.containsKey('backgroundColor')
                    ? previous['backgroundColor']?.toString()
                    : baselineBackground,
              )
            : const Value.absent(),
        foregroundColor: changesColor
            ? Value(
                previous.containsKey('foregroundColor')
                    ? previous['foregroundColor']?.toString()
                    : baseline['foregroundColor']?.toString(),
              )
            : const Value.absent(),
        colorId: changesColor
            ? Value(
                previous.containsKey('colorId')
                    ? previous['colorId']?.toString()
                    : baselineColorId,
              )
            : const Value.absent(),
        hidden: changesHidden
            ? Value(
                previous['hidden'] is bool
                    ? previous['hidden']! as bool
                    : baseline['hidden'] == true,
              )
            : const Value.absent(),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
      ),
    );
  }

  /// Stores a provider event.
  ///
  /// Pull syncs must preserve local optimistic state while an event is dirty or
  /// has an outstanding mutation. Mutation acknowledgements remain
  /// authoritative so they can transition the row back to `synced`.
  Future<void> upsertEvent({
    required String accountId,
    required CalendarEventDto event,
    bool preservePendingLocalChanges = false,
  }) async {
    final now = _now().millisecondsSinceEpoch;
    final calendarSourceId = sourceId(
      accountId: accountId,
      provider: event.provider,
      providerCalendarId: event.providerCalendarId,
    );
    final id = eventId(
      accountId: accountId,
      provider: event.provider,
      providerCalendarId: event.providerCalendarId,
      providerEventId: event.providerEventId,
      providerOriginalStartKey: event.providerOriginalStartKey,
    );
    final eventRow = CalendarEventsCompanion.insert(
      id: id,
      accountId: accountId,
      calendarSourceId: calendarSourceId,
      provider: event.provider.storageValue,
      providerCalendarId: event.providerCalendarId,
      providerEventId: event.providerEventId,
      providerRecurringEventId: Value(event.providerRecurringEventId),
      providerOriginalStartKey: Value(event.providerOriginalStartKey),
      etagOrChangeKey: Value(event.etagOrChangeKey),
      status: Value(event.status),
      title: event.title,
      description: Value(event.description),
      location: Value(event.location),
      locationLatitude: Value(event.locationPoint?.latitude),
      locationLongitude: Value(event.locationPoint?.longitude),
      allDay: Value(event.allDay),
      startDate: Value(event.startDate),
      startDateTime: Value(event.startDateTime),
      startTimeZone: Value(event.startTimeZone),
      endDate: Value(event.endDate),
      endDateTime: Value(event.endDateTime),
      endTimeZone: Value(event.endTimeZone),
      recurrenceJson: Value(_json(event.recurrenceJson)),
      remindersJson: Value(_json(event.remindersJson)),
      attendeesJson: Value(_json(event.attendeesJson)),
      categoriesJson: Value(_json(event.categoriesJson)),
      organizerJson: Value(_json(event.organizerJson)),
      creatorJson: Value(_json(event.creatorJson)),
      colorId: Value(event.colorId),
      colorHex: Value(event.colorHex),
      visibility: Value(event.visibility),
      transparencyOrShowAs: Value(event.transparencyOrShowAs),
      eventType: Value(event.eventType),
      webLink: Value(event.webLink),
      conferenceJson: Value(_json(event.conferenceJson)),
      attachmentsJson: Value(_json(event.attachmentsJson)),
      isCancelled: Value(event.isCancelled),
      isDeleted: Value(event.isDeleted),
      rawJson: Value(jsonEncode(event.rawJson)),
      createdAtServer: Value(event.createdAtServer),
      updatedAtServer: Value(event.updatedAtServer),
      createdAtLocal: now,
      updatedAtLocal: now,
      syncStatus: const Value('synced'),
      baselineRawJson: Value(jsonEncode(event.rawJson)),
    );
    if (!preservePendingLocalChanges) {
      await _database
          .into(_database.calendarEvents)
          .insertOnConflictUpdate(eventRow);
      await _reconcileGoogleSeriesMaster(id, event);
      return;
    }

    var stored = false;
    await _database.transaction(() async {
      final localEvent = await (_database.select(
        _database.calendarEvents,
      )..where((row) => row.id.equals(id))).getSingleOrNull();
      if (localEvent != null) {
        if (localEvent.syncStatus != 'synced') {
          return;
        }
        final pendingMutation =
            await (_database.select(_database.pendingOps)
                  ..where(
                    (row) =>
                        row.accountId.equals(accountId) &
                        row.entityType.equals('event') &
                        row.eventId.equals(id),
                  )
                  ..limit(1))
                .getSingleOrNull();
        if (pendingMutation != null) {
          return;
        }
      }
      await _database
          .into(_database.calendarEvents)
          .insertOnConflictUpdate(eventRow);
      stored = true;
    });
    if (stored) await _reconcileGoogleSeriesMaster(id, event);
  }

  Future<void> _reconcileGoogleSeriesMaster(
    String eventId,
    CalendarEventDto event,
  ) async {
    if (event.provider != BusyProvider.google ||
        event.providerRecurringEventId != null) {
      return;
    }
    final row = await (_database.select(
      _database.calendarEvents,
    )..where((candidate) => candidate.id.equals(eventId))).getSingleOrNull();
    if (row != null) {
      await LocationResolutionRepository(
        _database,
      ).reconcileGoogleSeriesMaster(row);
    }
  }

  Future<void> saveSyncState({
    required String accountId,
    required BusyProvider provider,
    required String syncKind,
    String? calendarSourceId,
    String? rangeStart,
    String? rangeEnd,
    required String cursorKind,
    required String cursorValue,
    bool full = false,
    String? lastError,
    String? stateJson,
  }) async {
    final id = syncStateId(
      accountId: accountId,
      provider: provider,
      syncKind: syncKind,
      calendarSourceId: calendarSourceId,
    );
    final now = _now().millisecondsSinceEpoch;
    await _database.transaction(() async {
      // Older releases keyed state by exact range bounds. Remove those rows
      // before inserting the stable scope key; the legacy unique index still
      // includes the range columns.
      await (_database.delete(_database.syncCursors)..where((row) {
            final sameSource = calendarSourceId == null
                ? row.projectionSourceId.isNull()
                : row.projectionSourceId.equals(calendarSourceId);
            return row.accountId.equals(accountId) &
                row.provider.equals(provider.storageValue) &
                row.syncScopeKind.equals(syncKind) &
                sameSource &
                row.id.equals(id).not();
          }))
          .go();
      await _database
          .into(_database.syncCursors)
          .insertOnConflictUpdate(
            SyncCursorsCompanion.insert(
              id: id,
              accountId: accountId,
              projectionSourceId: Value(calendarSourceId),
              provider: provider.storageValue,
              transport: 'rest',
              syncScopeKind: syncKind,
              cursorKind: cursorKind,
              cursorValue: cursorValue,
              rangeStart: Value(rangeStart),
              rangeEnd: Value(rangeEnd),
              baselineGeneration: Value(full ? now : 0),
              lastCompleteSyncAt: Value(now),
              lastFailureCode: Value(lastError),
              stateJson: Value(stateJson),
            ),
          );
    });
  }

  Future<String> createLocalEvent(
    EventEditorDraft draft, {
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
    bool rebuildNotifications = true,
  }) async {
    final operationId = await _createLocalEvent(
      draft,
      guestUpdatePolicy: guestUpdatePolicy,
      rebuildNotifications: false,
    );
    if (rebuildNotifications) {
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        draft.accountId,
      );
      await _onNotificationScheduleChanged?.call();
    }
    return operationId;
  }

  Future<String> _createLocalEvent(
    EventEditorDraft draft, {
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
    bool rebuildNotifications = true,
  }) async {
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(draft.sourceId))).getSingle();
    await _requireWritableSource(
      source,
      database: _database,
      operation: CalendarMutationOperation.createEvent,
    );
    if (source.accountId != draft.accountId ||
        source.providerCalendarId != draft.providerCalendarId) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.createEvent,
        sourceId: source.id,
      );
    }
    if (source.davCollectionId != null) {
      return _createLocalDavEvent(
        source,
        draft,
        rebuildNotifications: rebuildNotifications,
      );
    }
    final calendarCreateOp = await _pendingCalendarCreate(source.id);
    final now = _now().millisecondsSinceEpoch;
    final provider = BusyProviderCodec.requireStorageValue(source.provider);
    if (provider == BusyProvider.google) {
      validateGoogleStatusEvent(
        primaryCalendar: source.primaryCalendar,
        eventType: draft.eventType,
        originalEventType: null,
        allDay: draft.allDay,
        start: draft.start,
        end: draft.end,
        visibility: draft.visibilityOrSensitivity,
        transparency: draft.showAs,
        properties: draft.googleStatusProperties,
      );
    }
    final conferenceRequest = _conferenceRequest(draft, provider);
    final localEventId = 'local:${const Uuid().v4()}';
    final operationId = const Uuid().v4();
    final startTimeZone = _effectiveStartTimeZone(
      draft,
      source.timeZone,
      _localTimeZone,
    );
    final endTimeZone = _effectiveEndTimeZone(
      draft,
      source.timeZone,
      startTimeZone,
      _localTimeZone,
    );
    final id = eventId(
      accountId: draft.accountId,
      provider: provider,
      providerCalendarId: draft.providerCalendarId,
      providerEventId: localEventId,
    );
    final request = _eventRequest(
      draft,
      provider,
      isCreate: true,
      startTimeZone: startTimeZone,
      endTimeZone: endTimeZone,
      conference: conferenceRequest,
      guestUpdatePolicy: guestUpdatePolicy,
    );
    switch (provider) {
      case BusyProvider.google:
        request[calendarEventGoogleCreateIdKey] = googleCalendarCreateEventId(
          operationId,
        );
      case BusyProvider.microsoft:
        request[calendarEventMicrosoftTransactionIdKey] =
            microsoftCalendarCreateTransactionId(operationId);
      case BusyProvider.appleICloud:
      case BusyProvider.nextcloud:
      case BusyProvider.webCal:
        break;
    }
    final requestJson = jsonEncode(request);
    await _database.transaction(() async {
      await _database
          .into(_database.calendarEvents)
          .insert(
            CalendarEventsCompanion.insert(
              id: id,
              accountId: draft.accountId,
              calendarSourceId: draft.sourceId,
              provider: source.provider,
              providerCalendarId: draft.providerCalendarId,
              providerEventId: localEventId,
              title: draft.title.trim(),
              description: Value(draft.description),
              location: Value(draft.location),
              locationLatitude: Value(
                provider == BusyProvider.microsoft
                    ? draft.effectiveLocationPoint?.latitude
                    : null,
              ),
              locationLongitude: Value(
                provider == BusyProvider.microsoft
                    ? draft.effectiveLocationPoint?.longitude
                    : null,
              ),
              allDay: Value(draft.allDay),
              startDate: Value(draft.allDay ? _date(draft.start) : null),
              startDateTime: Value(
                draft.allDay
                    ? null
                    : _eventDateTimeWireValue(draft.start, startTimeZone),
              ),
              startTimeZone: Value(startTimeZone),
              endDate: Value(draft.allDay ? _date(draft.end) : null),
              endDateTime: Value(
                draft.allDay
                    ? null
                    : _eventDateTimeWireValue(draft.end, endTimeZone),
              ),
              endTimeZone: Value(endTimeZone),
              recurrenceJson: Value(_json(draft.recurrence)),
              remindersJson: Value(_json(draft.reminders)),
              attendeesJson: Value(_json(_localAttendeesJson(draft, provider))),
              categoriesJson: Value(_json(_categoriesJson(draft, provider))),
              organizerJson: Value(
                _json(_optimisticOrganizer(draft, provider)),
              ),
              colorId: Value(draft.colorId),
              eventType: Value(draft.eventType),
              visibility: Value(draft.visibilityOrSensitivity),
              transparencyOrShowAs: Value(draft.showAs),
              conferenceJson: Value(
                _json(conferenceRequest ?? draft.conference),
              ),
              createdAtLocal: now,
              updatedAtLocal: now,
              syncStatus: const Value('pending'),
              rawJson: Value(jsonEncode(_optimisticEventRaw(draft, provider))),
              baselineRawJson: const Value('{}'),
            ),
          );
      await _database
          .into(_database.pendingOps)
          .insert(
            PendingOpsCompanion.insert(
              id: operationId,
              accountId: draft.accountId,
              provider: Value(source.provider),
              entityType: 'event',
              operation: 'create',
              operationType: const Value('event.create'),
              calendarSourceId: Value(draft.sourceId),
              providerCalendarId: Value(draft.providerCalendarId),
              eventId: Value(id),
              localTempId: Value(localEventId),
              dependsOnOpId: Value(calendarCreateOp?.id),
              requestJson: requestJson,
              createdAtUtc: DateTime.now().toUtc().toIso8601String(),
              updatedAtUtc: DateTime.now().toUtc().toIso8601String(),
            ),
          );
      final selection = draft.locationChange.selection;
      if (provider == BusyProvider.google && selection != null) {
        await LocationResolutionRepository(_database).apply(
          LocationItemIdentity(
            kind: LocationItemKind.event,
            accountId: draft.accountId,
            sourceId: draft.sourceId,
            itemId: id,
          ),
          draft.location ?? '',
          LocationChange.replace(selection),
        );
      }
    });
    if (rebuildNotifications) {
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        draft.accountId,
      );
      await _onNotificationScheduleChanged?.call();
    }
    return operationId;
  }

  Future<List<String>> createImportedEventsBatch({
    required CalendarSourceEntity destination,
    required List<
      ({
        String icalUid,
        EventEditorDraft draft,
        List<ImportedEventException> exceptions,
      })
    >
    events,
  }) async {
    if (events.isEmpty) return const [];
    if (events.any(
      (event) =>
          event.draft.accountId != destination.accountId ||
          event.draft.sourceId != destination.id ||
          event.draft.providerCalendarId != destination.providerCalendarId ||
          event.draft.attendees.isNotEmpty ||
          event.draft.createConference ||
          event.draft.conference != null,
    )) {
      throw ArgumentError('The import batch contains an unsafe event draft.');
    }
    final operationIds = <String>[];
    await _database.transaction(() async {
      for (final event in events) {
        final operationId = await createLocalEvent(
          event.draft,
          guestUpdatePolicy: CalendarGuestUpdatePolicy.doNotSend,
          rebuildNotifications: false,
        );
        operationIds.add(operationId);
        final masterOp = await (_database.select(
          _database.pendingOps,
        )..where((row) => row.id.equals(operationId))).getSingle();
        if (destination.provider == BusyProvider.google) {
          final request = _jsonMap(masterOp.requestJson);
          request[calendarEventImportIcalUidKey] = event.icalUid;
          await (_database.update(
            _database.pendingOps,
          )..where((row) => row.id.equals(operationId))).write(
            PendingOpsCompanion(requestJson: Value(jsonEncode(request))),
          );
        }
        for (final exception in event.exceptions) {
          await _database
              .into(_database.pendingOps)
              .insert(
                PendingOpsCompanion.insert(
                  id: const Uuid().v4(),
                  accountId: destination.accountId,
                  provider: Value(destination.provider.storageValue),
                  entityType: 'event',
                  operation: 'importException',
                  operationType: const Value('event.importException'),
                  calendarSourceId: Value(destination.id),
                  providerCalendarId: Value(destination.providerCalendarId),
                  eventId: Value(masterOp.eventId),
                  dependsOnOpId: Value(operationId),
                  requestJson: jsonEncode({
                    'originalStart': exception.originalStart,
                    'cancelled': exception.cancelled,
                    ...exception.fields,
                  }),
                  createdAtUtc: _now().toUtc().toIso8601String(),
                  updatedAtUtc: _now().toUtc().toIso8601String(),
                ),
              );
        }
        await _database
            .into(_database.icalImportReceipts)
            .insert(
              IcalImportReceiptsCompanion.insert(
                calendarSourceId: destination.id,
                icalUid: event.icalUid,
                eventId: const Value(null),
                importedAtUtc: _now().toUtc().toIso8601String(),
              ),
            );
      }
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      destination.accountId,
    );
    await _onNotificationScheduleChanged?.call();
    return operationIds;
  }

  Future<void> updateLocalEvent(
    EventEditorDraft draft, {
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
    EventTimingBaseline? timingBaseline,
  }) async {
    if (timingBaseline == null) {
      final eventChanged = await _database.transaction(() async {
        return _updateLocalEvent(
          draft,
          guestUpdatePolicy: guestUpdatePolicy,
          deferNotifications: true,
        );
      });
      if (!eventChanged) return;
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        draft.accountId,
      );
      await _onNotificationScheduleChanged?.call();
      return;
    }
    // Compare and change timing in the same transaction. Rebase unrelated
    // fields on the latest detail, including provider-only and HTML content.
    await _database.transaction(() async {
      final latest = draft.eventId == null
          ? null
          : await loadEventDetail(draft.eventId!);
      if (latest == null || !timingBaseline.matches(latest)) {
        throw const StaleEventTiming();
      }
      if (!detailAllowsTimingEdit(latest) ||
          latest.accountId != draft.accountId ||
          latest.sourceId != draft.sourceId ||
          latest.allDay != draft.allDay ||
          latest.providerCalendarId != draft.providerCalendarId) {
        throw CalendarMutationNotAllowed(
          operation: CalendarMutationOperation.editEvent,
          sourceId: draft.sourceId,
        );
      }
      if (draft.start == null ||
          draft.end == null ||
          !draft.end!.isAfter(draft.start!)) {
        throw ArgumentError('An event interval must be positive.');
      }
      await _updateLocalEvent(
        EventEditorDraft.fromEventDetail(latest).copyWith(
          start: draft.start,
          end: draft.end,
          recurringMutationScope: draft.recurringMutationScope,
        ),
        guestUpdatePolicy: guestUpdatePolicy,
        timingOnly: true,
      );
    });
    try {
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        draft.accountId,
      );
      await _onNotificationScheduleChanged?.call();
    } catch (error) {
      throw EventNotificationRefreshFailure(error);
    }
  }

  Future<bool> _updateLocalEvent(
    EventEditorDraft draft, {
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
    bool timingOnly = false,
    bool deferNotifications = false,
  }) async {
    if (draft.descriptionEditUnsafe) {
      throw const MicrosoftMeetingBodyEditUnsafe();
    }
    final eventId = draft.eventId;
    if (eventId == null) {
      await createLocalEvent(
        draft,
        guestUpdatePolicy: guestUpdatePolicy,
        rebuildNotifications: false,
      );
      return true;
    }
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(draft.sourceId))).getSingle();
    final existing = await (_database.select(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).getSingle();
    final originalSource = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(existing.calendarSourceId))).getSingle();
    _requireMicrosoftSharedPrivateAccess(
      originalSource,
      existing,
      operation: CalendarMutationOperation.editEvent,
    );
    _requireFullEventEditingAllowed(existing);
    _requireAttendeeManagementAllowed(existing, draft);
    final editBaseline = _eventEditBaseline(draft, existing);
    await _requireWritableSource(
      source,
      database: _database,
      operation: CalendarMutationOperation.editEvent,
    );
    if (source.accountId != draft.accountId ||
        source.providerCalendarId != draft.providerCalendarId) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.editEvent,
        sourceId: source.id,
      );
    }
    final sourceChanged =
        draft.accountId != existing.accountId ||
        draft.sourceId != existing.calendarSourceId ||
        draft.providerCalendarId != existing.providerCalendarId;
    if (sourceChanged && existing.eventType == 'fromGmail') {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.moveEvent,
        sourceId: existing.calendarSourceId,
      );
    }
    if (sourceChanged) {
      await _requireWritableSource(
        originalSource,
        database: _database,
        operation: CalendarMutationOperation.deleteEvent,
      );
      await _moveLocalEvent(
        originalSource: originalSource,
        destinationSource: source,
        existing: existing,
        draft: draft,
        guestUpdatePolicy: guestUpdatePolicy,
      );
      return true;
    }
    if (source.provider != existing.provider ||
        source.accountId != existing.accountId ||
        source.providerCalendarId != existing.providerCalendarId) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.editEvent,
        sourceId: source.id,
      );
    }
    if (source.davCollectionId != null) {
      await _updateLocalDavEvent(
        source,
        existing,
        draft,
        timingOnly: timingOnly,
        deferNotifications: deferNotifications,
      );
      return true;
    }
    final provider = BusyProviderCodec.requireStorageValue(source.provider);
    if (provider == BusyProvider.google) {
      validateGoogleStatusEvent(
        primaryCalendar: source.primaryCalendar,
        eventType: draft.eventType,
        originalEventType: existing.eventType ?? 'default',
        allDay: draft.allDay,
        start: draft.start,
        end: draft.end,
        visibility: draft.visibilityOrSensitivity,
        transparency: draft.showAs,
        properties: draft.googleStatusProperties,
      );
    }
    final recurringOccurrence = _eventRequiresRecurringScope(existing);
    final recurringScope = draft.recurringMutationScope;
    if (recurringOccurrence && recurringScope == null) {
      throw UnsupportedError('A recurring-event editing scope is required.');
    }
    if (recurringScope == RecurringEventMutationScope.thisAndFuture &&
        provider != BusyProvider.google) {
      throw UnsupportedError(
        '${provider.displayName} does not expose a documented '
        'this-and-following mutation through this API.',
      );
    }
    if (recurringScope == RecurringEventMutationScope.thisAndFuture &&
        !_googleEventCanSplit(existing)) {
      throw UnsupportedError(
        'This Google series contains event-type or conference data that '
        'cannot be split safely.',
      );
    }
    if (draft.recurrenceChanged && recurringOccurrence) {
      throw UnsupportedError(
        'Editing a recurring series from an individual occurrence is not '
        'supported.',
      );
    }
    final now = _now().millisecondsSinceEpoch;
    final conferenceRequest = _conferenceRequest(draft, provider);
    final startTimeZone = _effectiveStartTimeZone(
      draft,
      source.timeZone,
      _localTimeZone,
    );
    final endTimeZone = _effectiveEndTimeZone(
      draft,
      source.timeZone,
      startTimeZone,
      _localTimeZone,
    );
    final seriesMutation =
        recurringOccurrence &&
        (recurringScope == RecurringEventMutationScope.entireSeries ||
            recurringScope == RecurringEventMutationScope.thisAndFuture);
    final seriesBaseline = seriesMutation
        ? await _seriesMasterBaseline(existing)
        : null;
    final request = _eventDeltaRequest(
      draft,
      editBaseline,
      provider,
      startTimeZone: startTimeZone,
      endTimeZone: endTimeZone,
      conference: conferenceRequest,
      guestUpdatePolicy: guestUpdatePolicy,
    );
    if (timingOnly) {
      request.removeWhere(
        (key, _) => !{
          'allDay',
          'start',
          'end',
          'startTimeZone',
          'endTimeZone',
          calendarEventGuestUpdatePolicyKey,
        }.contains(key),
      );
      // TZDateTime emits compact offsets; provider wire timestamps use RFC3339.
      for (final key in ['start', 'end']) {
        final value = request[key];
        if (value is String) {
          request[key] = value.replaceFirstMapped(
            RegExp(r'([+-]\d{2})(\d{2})$'),
            (match) => '${match[1]}:${match[2]}',
          );
        }
      }
    }
    if (provider == BusyProvider.google && existing.eventType == 'fromGmail') {
      const allowed = {
        'colorId',
        'remindersJson',
        'visibility',
        'transparencyOrShowAs',
        calendarEventAttendeesField,
        calendarEventGuestUpdatePolicyKey,
      };
      final cleared = request[calendarEventClearFieldsKey];
      final clearsOnlyAttendees =
          cleared is List &&
          cleared.length == 1 &&
          cleared.single == calendarEventAttendeesField;
      if (request.keys.any(
        (field) =>
            !allowed.contains(field) &&
            !(field == calendarEventClearFieldsKey && clearsOnlyAttendees),
      )) {
        throw CalendarMutationNotAllowed(
          operation: CalendarMutationOperation.editEvent,
          sourceId: source.id,
        );
      }
    }
    if (!_eventRequestHasMutation(request)) {
      return false;
    }
    if (request.containsKey('allDay') &&
        !detailAllowsTimingEdit(CalendarEventDetail.fromRow(existing))) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.editEvent,
        sourceId: source.id,
      );
    }
    if (recurringOccurrence) {
      request[calendarEventRecurringScopeKey] = recurringScope!.name;
      if (seriesMutation) {
        request[calendarEventTargetProviderIdKey] =
            existing.providerRecurringEventId;
        request[calendarEventOriginalStartKey] =
            existing.providerOriginalStartKey ?? _storedEventStart(existing);
        request[calendarEventOriginalEndKey] = _storedEventEnd(existing);
        request[calendarEventTimingBaselineKey] = _storedEventTimingBaseline(
          existing,
        );
      }
    }
    final requestJson = jsonEncode(request);
    await _database.transaction(() async {
      final predecessor = await _latestPendingEventMutation(
        accountId: draft.accountId,
        eventId: eventId,
        seriesEvent: seriesMutation ? existing : null,
      );
      final projection = _eventPatchProjection(
        draft: draft,
        existing: existing,
        provider: provider,
        request: request,
        startTimeZone: startTimeZone,
        endTimeZone: endTimeZone,
        conference: conferenceRequest,
        now: now,
      );
      if (seriesMutation) {
        await _writeCloudSeriesProjection(
          existing: existing,
          draft: draft,
          scope: recurringScope!,
          provider: provider,
          conference: conferenceRequest,
          startTimeZone: startTimeZone,
          endTimeZone: endTimeZone,
          now: now,
          timingOnly: timingOnly,
        );
      } else {
        await (_database.update(
          _database.calendarEvents,
        )..where((row) => row.id.equals(eventId))).write(projection);
      }
      await _database
          .into(_database.pendingOps)
          .insert(
            PendingOpsCompanion.insert(
              id: const Uuid().v4(),
              accountId: draft.accountId,
              provider: Value(source.provider),
              entityType: 'event',
              operation: 'patch',
              operationType: const Value('event.patch'),
              calendarSourceId: Value(draft.sourceId),
              providerCalendarId: Value(draft.providerCalendarId),
              eventId: Value(eventId),
              dependsOnOpId: Value(predecessor?.id),
              requestJson: requestJson,
              baselineUpdatedUtc: Value(
                seriesBaseline?.updatedAtServer ?? editBaseline.updatedAtServer,
              ),
              baselineRawJson: Value(
                (seriesBaseline == null
                        ? null
                        : seriesBaseline.baselineRawJson ??
                              seriesBaseline.rawJson) ??
                    _eventDetailBaselineRawJson(editBaseline),
              ),
              createdAtUtc: DateTime.now().toUtc().toIso8601String(),
              updatedAtUtc: DateTime.now().toUtc().toIso8601String(),
            ),
          );
    });
    if (timingOnly || deferNotifications) {
      return true;
    }
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      draft.accountId,
    );
    await _onNotificationScheduleChanged?.call();
    return true;
  }

  Future<void> _moveLocalEvent({
    required CalendarSource originalSource,
    required CalendarSource destinationSource,
    required CalendarEvent existing,
    required EventEditorDraft draft,
    required CalendarGuestUpdatePolicy guestUpdatePolicy,
  }) async {
    if (await _pendingCalendarCreate(destinationSource.id) != null) {
      throw CalendarMutationNotAllowed(
        operation: CalendarMutationOperation.moveEvent,
        sourceId: destinationSource.id,
        reason: CalendarMutationDenialReason.destinationPendingCreate,
      );
    }
    final sourceProvider = BusyProviderCodec.requireStorageValue(
      originalSource.provider,
    );
    final destinationProvider = BusyProviderCodec.requireStorageValue(
      destinationSource.provider,
    );
    final recurring = _eventRequiresRecurringScope(existing);
    final scope = draft.recurringMutationScope;
    if (recurring && scope == null) {
      throw UnsupportedError('A recurring-event movement scope is required.');
    }
    if (scope == RecurringEventMutationScope.thisAndFuture) {
      throw UnsupportedError(
        'This and following events cannot be moved safely. Move this event or '
        'the entire series.',
      );
    }
    await _requireEventReadyToMove(existing);

    final strategy = calendarEventMoveStrategy(
      sourceAccountId: originalSource.accountId,
      sourceId: originalSource.id,
      sourceProviderCalendarId: originalSource.providerCalendarId,
      sourceProvider: sourceProvider,
      sourceDavCollectionId: originalSource.davCollectionId,
      destinationAccountId: destinationSource.accountId,
      destinationId: destinationSource.id,
      destinationProviderCalendarId: destinationSource.providerCalendarId,
      destinationProvider: destinationProvider,
      destinationDavCollectionId: destinationSource.davCollectionId,
      eventType: existing.eventType,
      recurring: recurring,
      recurringScope: scope,
    );
    switch (strategy) {
      case CalendarEventMoveStrategy.none:
        throw StateError('The destination calendar is unchanged.');
      case CalendarEventMoveStrategy.googleNative:
        await _moveLocalGoogleEvent(
          originalSource: originalSource,
          destinationSource: destinationSource,
          existing: existing,
          draft: draft,
          guestUpdatePolicy: guestUpdatePolicy,
        );
        return;
      case CalendarEventMoveStrategy.davNative:
        await _moveLocalDavEvent(
          originalSource: originalSource,
          destinationSource: destinationSource,
          existing: existing,
          draft: draft,
        );
        return;
      case CalendarEventMoveStrategy.copyThenDelete:
        await _copyThenDeleteLocalEvent(
          originalSource: originalSource,
          destinationSource: destinationSource,
          existing: existing,
          draft: draft,
          sourceProvider: sourceProvider,
          destinationProvider: destinationProvider,
          guestUpdatePolicy: guestUpdatePolicy,
        );
        return;
    }
  }

  Future<void> _requireEventReadyToMove(CalendarEvent existing) async {
    final pending =
        await (_database.select(_database.pendingOps)
              ..where(
                (row) =>
                    row.entityType.equals('event') &
                    row.eventId.equals(existing.id),
              )
              ..limit(1))
            .getSingleOrNull();
    if (existing.syncStatus != 'synced' || pending != null) {
      throw StateError(
        'Wait for this event to finish synchronizing before moving it.',
      );
    }
  }

  Future<void> _moveLocalGoogleEvent({
    required CalendarSource originalSource,
    required CalendarSource destinationSource,
    required CalendarEvent existing,
    required EventEditorDraft draft,
    required CalendarGuestUpdatePolicy guestUpdatePolicy,
  }) async {
    final recurring = _eventRequiresRecurringScope(existing);
    final scope = draft.recurringMutationScope;
    final provider = BusyProvider.google;
    final startTimeZone = _effectiveStartTimeZone(
      draft,
      destinationSource.timeZone,
      _localTimeZone,
    );
    final endTimeZone = _effectiveEndTimeZone(
      draft,
      destinationSource.timeZone,
      startTimeZone,
      _localTimeZone,
    );
    final conferenceRequest = _conferenceRequest(draft, provider);
    final seriesMutation =
        recurring && scope == RecurringEventMutationScope.entireSeries;
    final patchRequest = _eventDeltaRequest(
      draft,
      _eventEditBaseline(draft, existing),
      provider,
      startTimeZone: startTimeZone,
      endTimeZone: endTimeZone,
      conference: conferenceRequest,
      guestUpdatePolicy: guestUpdatePolicy,
    );
    final targetProviderEventId = seriesMutation
        ? existing.providerRecurringEventId!
        : existing.providerEventId;
    if (seriesMutation) {
      patchRequest[calendarEventRecurringScopeKey] = scope!.name;
      patchRequest[calendarEventTargetProviderIdKey] = targetProviderEventId;
      patchRequest[calendarEventOriginalStartKey] =
          existing.providerOriginalStartKey ?? _storedEventStart(existing);
      patchRequest[calendarEventOriginalEndKey] = _storedEventEnd(existing);
      patchRequest[calendarEventTimingBaselineKey] = _storedEventTimingBaseline(
        existing,
      );
    }
    final moveOperationId = const Uuid().v4();
    final patchOperationId = const Uuid().v4();
    final nowUtc = DateTime.now().toUtc().toIso8601String();
    final patchCreatedAtUtc = DateTime.parse(
      nowUtc,
    ).add(const Duration(microseconds: 1)).toIso8601String();
    final now = _now().millisecondsSinceEpoch;
    await _database.transaction(() async {
      if (seriesMutation && _eventRequestHasMutation(patchRequest)) {
        await _writeCloudSeriesProjection(
          existing: existing,
          draft: draft,
          scope: scope!,
          provider: provider,
          conference: conferenceRequest,
          startTimeZone: startTimeZone,
          endTimeZone: endTimeZone,
          now: now,
        );
      } else {
        await (_database.update(
          _database.calendarEvents,
        )..where((row) => row.id.equals(existing.id))).write(
          _eventPatchProjection(
            draft: draft,
            existing: existing,
            provider: provider,
            request: patchRequest,
            startTimeZone: startTimeZone,
            endTimeZone: endTimeZone,
            conference: conferenceRequest,
            now: now,
          ),
        );
        if (provider == BusyProvider.google &&
            existing.providerRecurringEventId == null &&
            existing.recurrenceJson != null) {
          await LocationResolutionRepository(
            _database,
          ).removeGoogleSeriesSource(
            accountId: existing.accountId,
            sourceId: existing.calendarSourceId,
            providerSeriesId: existing.providerEventId,
          );
        }
      }
      await _database
          .into(_database.pendingOps)
          .insert(
            PendingOpsCompanion.insert(
              id: moveOperationId,
              accountId: existing.accountId,
              provider: Value(existing.provider),
              entityType: 'event',
              operation: 'move',
              operationType: const Value('event.move'),
              calendarSourceId: Value(originalSource.id),
              providerCalendarId: Value(originalSource.providerCalendarId),
              eventId: Value(existing.id),
              requestJson: jsonEncode({
                calendarEventDestinationCalendarIdKey:
                    destinationSource.providerCalendarId,
                calendarEventDestinationSourceIdKey: destinationSource.id,
                calendarEventTargetProviderIdKey: targetProviderEventId,
                calendarEventGuestUpdatePolicyKey: guestUpdatePolicy.name,
                if (seriesMutation)
                  calendarEventRecurringScopeKey:
                      RecurringEventMutationScope.entireSeries.name,
              }),
              baselineUpdatedUtc: seriesMutation
                  ? const Value(null)
                  : Value(existing.updatedAtServer),
              baselineRawJson: seriesMutation
                  ? const Value(null)
                  : Value(existing.baselineRawJson),
              createdAtUtc: nowUtc,
              updatedAtUtc: nowUtc,
            ),
          );
      if (_eventRequestHasMutation(patchRequest)) {
        await _database
            .into(_database.pendingOps)
            .insert(
              PendingOpsCompanion.insert(
                id: patchOperationId,
                accountId: existing.accountId,
                provider: Value(destinationSource.provider),
                entityType: 'event',
                operation: 'patch',
                operationType: const Value('event.patch'),
                calendarSourceId: Value(destinationSource.id),
                providerCalendarId: Value(destinationSource.providerCalendarId),
                eventId: Value(existing.id),
                dependsOnOpId: Value(moveOperationId),
                requestJson: jsonEncode(patchRequest),
                createdAtUtc: patchCreatedAtUtc,
                updatedAtUtc: patchCreatedAtUtc,
              ),
            );
      }
    });
    await _rebuildEventNotificationsFor({existing.accountId});
  }

  Future<void> _moveLocalDavEvent({
    required CalendarSource originalSource,
    required CalendarSource destinationSource,
    required CalendarEvent existing,
    required EventEditorDraft draft,
  }) async {
    final scheduling = await _davSchedulingPolicy(originalSource);
    _requireDavSchedulingUnchanged(
      draft,
      creating: false,
      scheduling: scheduling,
    );
    final sourceCollectionId = originalSource.davCollectionId;
    final destinationCollectionId = destinationSource.davCollectionId;
    final objectId = existing.davObjectId;
    final uid = existing.icalUid;
    final start = draft.start;
    final end = draft.end;
    if (sourceCollectionId == null ||
        destinationCollectionId == null ||
        objectId == null ||
        uid == null ||
        start == null ||
        end == null) {
      throw StateError('The DAV event is not ready to move.');
    }
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    final baselineRawIcs = await queue.editableRawIcsForObject(
      accountId: existing.accountId,
      collectionId: sourceCollectionId,
      objectId: objectId,
    );
    final recurring = _eventRequiresRecurringScope(existing);
    final target = IcalComponentKey(
      componentType: 'VEVENT',
      uid: uid,
      recurrenceIdKey: recurring ? null : existing.recurrenceIdKey,
    );
    final startTimeZone = _effectiveStartTimeZone(
      draft,
      destinationSource.timeZone,
      _localTimeZone,
    );
    final endTimeZone = _effectiveEndTimeZone(
      draft,
      destinationSource.timeZone,
      startTimeZone,
      _localTimeZone,
    );
    var input = _davEventInput(
      draft,
      start: start,
      end: end,
      startTimeZone: startTimeZone,
      endTimeZone: endTimeZone,
      scheduling: scheduling,
      nowUtc: _now().toUtc(),
    );
    if (recurring) {
      input = _seriesDavEventInput(
        baselineRawIcs: baselineRawIcs,
        uid: uid,
        existing: existing,
        desired: input,
      );
    }
    final patch = buildDavEventUpdatePatch(
      target: target,
      baselineRawIcs: baselineRawIcs,
      input: input,
    );
    final candidate =
        patch?.applyTo(baselineRawIcs, nowUtc: _now().toUtc()) ??
        baselineRawIcs;
    await _database.transaction(() async {
      await queue.enqueueMove(
        accountId: existing.accountId,
        sourceCollectionId: sourceCollectionId,
        destinationCollectionId: destinationCollectionId,
        objectId: objectId,
        target: target,
        localProjectionId: existing.id,
        postMovePatch: patch,
      );
      await DavObjectRepository(
        database: _database,
      ).projectLocalMutationCandidate(
        accountId: existing.accountId,
        collectionId: sourceCollectionId,
        provider: BusyProviderCodec.requireStorageValue(
          originalSource.provider,
        ),
        objectId: objectId,
        candidateRawIcs: candidate,
        projectedAtUtc: _now().toUtc(),
      );
      await (_database.update(_database.calendarEvents)..where(
            (row) =>
                row.accountId.equals(existing.accountId) &
                row.davObjectId.equals(objectId),
          ))
          .write(
            CalendarEventsCompanion(
              calendarSourceId: Value(destinationSource.id),
              providerCalendarId: Value(destinationSource.providerCalendarId),
              davCollectionId: Value(destinationCollectionId),
              syncStatus: const Value('pending'),
              updatedAtLocal: Value(_now().millisecondsSinceEpoch),
            ),
          );
    });
    await _rebuildEventNotificationsFor({existing.accountId});
  }

  Future<void> _copyThenDeleteLocalEvent({
    required CalendarSource originalSource,
    required CalendarSource destinationSource,
    required CalendarEvent existing,
    required EventEditorDraft draft,
    required BusyProvider sourceProvider,
    required BusyProvider destinationProvider,
    required CalendarGuestUpdatePolicy guestUpdatePolicy,
  }) async {
    if ((sourceProvider == BusyProvider.nextcloud ||
            destinationProvider == BusyProvider.nextcloud) &&
        (_jsonMapList(existing.attendeesJson).isNotEmpty ||
            draft.attendees.isNotEmpty)) {
      throw schedulingDenied('DavMeetingCopyDeleteUnsupported');
    }
    final effectiveSelection = await _eventMoveLocationSelection(
      draft,
      existing,
    );
    final copyDraft = _eventCopyDraft(
      draft,
      existing: existing,
      sourceProvider: sourceProvider,
      destinationProvider: destinationProvider,
      effectiveSelection: effectiveSelection,
    );
    final createOperationId = await createLocalEvent(
      copyDraft,
      guestUpdatePolicy: guestUpdatePolicy,
      rebuildNotifications: false,
    );
    try {
      if (originalSource.davCollectionId != null) {
        await _queueDavEventDeletionAfterCopy(
          source: originalSource,
          existing: existing,
          recurringScope: draft.recurringMutationScope,
          dependsOnOperationId: createOperationId,
        );
      } else {
        await _queueCloudEventDeletionAfterCopy(
          existing: existing,
          recurringScope: draft.recurringMutationScope,
          guestUpdatePolicy: guestUpdatePolicy,
          dependsOnOperationId: createOperationId,
        );
      }
    } on Object {
      await _discardQueuedEventCreate(createOperationId);
      await _rebuildEventNotificationsFor({destinationSource.accountId});
      rethrow;
    }
    await (_database.update(
      _database.calendarEvents,
    )..where((row) => row.id.equals(existing.id))).write(
      CalendarEventsCompanion(
        syncStatus: const Value('pending'),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
      ),
    );
    await _rebuildEventNotificationsFor({
      originalSource.accountId,
      destinationSource.accountId,
    });
  }

  EventEditorDraft _eventCopyDraft(
    EventEditorDraft draft, {
    required CalendarEvent existing,
    required BusyProvider sourceProvider,
    required BusyProvider destinationProvider,
    required LocationResult? effectiveSelection,
  }) {
    final recurring = _eventRequiresRecurringScope(existing);
    final scope = draft.recurringMutationScope;
    Object? recurrence = draft.recurrence;
    if (recurring && scope == RecurringEventMutationScope.singleOccurrence) {
      recurrence = null;
    } else if (recurrence != null && sourceProvider != destinationProvider) {
      final sourceRule = EventRecurrenceCodec.decode(
        sourceProvider,
        recurrence,
        baseDate: draft.start,
      );
      if (sourceRule.isSupported && sourceRule.repeats) {
        if (!EventRecurrenceCodec.canEncode(destinationProvider, sourceRule)) {
          throw UnsupportedError(
            '${destinationProvider.displayName} cannot represent this '
            'recurrence rule.',
          );
        }
        recurrence = EventRecurrenceCodec.encode(
          destinationProvider,
          sourceRule,
          baseDate: draft.start ?? DateTime.now(),
          allDay: draft.allDay,
          timeZone: draft.startTimeZone,
        );
      } else {
        final destinationRule = EventRecurrenceCodec.decode(
          destinationProvider,
          recurrence,
          baseDate: draft.start,
        );
        if (!destinationRule.isSupported || !destinationRule.repeats) {
          throw UnsupportedError(
            '${destinationProvider.displayName} cannot represent this '
            'recurrence rule.',
          );
        }
      }
    }
    if (recurring && scope == RecurringEventMutationScope.entireSeries) {
      final rule = EventRecurrenceCodec.decode(
        destinationProvider,
        recurrence,
        baseDate: draft.start,
      );
      if (!rule.isSupported || !rule.repeats) {
        throw UnsupportedError(
          'The recurrence rule is unavailable. Move one occurrence instead.',
        );
      }
    }
    final attendees =
        destinationProvider == BusyProvider.appleICloud ||
            destinationProvider == BusyProvider.nextcloud
        ? const <EventAttendeeDraft>[]
        : [
            for (final attendee in draft.attendees)
              if (!attendee.self && !attendee.organizer)
                EventAttendeeDraft(
                  email: attendee.email,
                  displayName: attendee.displayName,
                  optional: attendee.optional,
                ),
          ];
    final sameProviderAccount =
        sourceProvider == destinationProvider &&
        existing.accountId == draft.accountId;
    return EventEditorDraft(
      accountId: draft.accountId,
      sourceId: draft.sourceId,
      providerCalendarId: draft.providerCalendarId,
      title: draft.title,
      allDay: draft.allDay,
      start: draft.start,
      end: draft.end,
      startTimeZone: draft.startTimeZone,
      endTimeZone: draft.endTimeZone,
      location: draft.location,
      locationPoint: effectiveSelection?.point,
      locationChange: draft.locationChange.changed
          ? draft.locationChange
          : effectiveSelection == null
          ? const LocationChange.unchanged()
          : LocationChange.replace(effectiveSelection),
      description: draft.description,
      descriptionContentType: destinationProvider == BusyProvider.microsoft
          ? draft.descriptionContentType
          : null,
      descriptionHtml: destinationProvider == BusyProvider.microsoft
          ? draft.descriptionHtml
          : null,
      recurrence: recurrence,
      recurrenceChanged: true,
      reminders: sourceProvider == destinationProvider
          ? draft.reminders
          : _eventRemindersForProvider(draft.reminders, destinationProvider),
      remindersChanged: true,
      attendees: attendees,
      attendeesChanged: true,
      importance: destinationProvider == BusyProvider.microsoft
          ? draft.importance
          : null,
      showAs: eventShowAsForProvider(draft.showAs, destinationProvider),
      visibilityOrSensitivity: eventVisibilityForProvider(
        draft.visibilityOrSensitivity,
        destinationProvider,
      ),
      colorId: sameProviderAccount ? draft.colorId : null,
      // Google labels are scoped to one calendar, not merely one account.
      eventLabelId: null,
      categories: destinationProvider == BusyProvider.google
          ? const []
          : draft.categories,
      categoriesChanged: true,
      responseRequested: destinationProvider == BusyProvider.microsoft
          ? draft.responseRequested
          : null,
      hideAttendees:
          destinationProvider == BusyProvider.google ||
              destinationProvider == BusyProvider.microsoft
          ? draft.hideAttendees
          : null,
      allowNewTimeProposals: destinationProvider == BusyProvider.microsoft
          ? draft.allowNewTimeProposals
          : null,
      isOrganizer: true,
    );
  }

  Future<LocationResult?> _eventMoveLocationSelection(
    EventEditorDraft draft,
    CalendarEvent existing,
  ) async {
    if (draft.locationChange.changed) {
      return draft.locationChange.selection;
    }
    final point =
        draft.locationPoint ??
        GeographicPoint.tryParse(
          latitude: existing.locationLatitude,
          longitude: existing.locationLongitude,
        );
    if (point != null) {
      final address = draft.originalDetail?.locationAddress;
      return LocationResult(
        label: (draft.location ?? '').trim().isEmpty
            ? point.directionsValue
            : draft.location!.trim(),
        point: point,
        address: address == null
            ? const {}
            : {
                for (final entry in address.entries)
                  if (entry.value case final String value when value.isNotEmpty)
                    entry.key: value,
              },
        source: 'provider',
        attribution: '',
      );
    }
    return LocationResolutionRepository(_database).load(
      LocationItemIdentity(
        kind: LocationItemKind.event,
        accountId: existing.accountId,
        sourceId: existing.calendarSourceId,
        itemId: existing.id,
      ),
      existing.location ?? '',
    );
  }

  Future<void> _queueCloudEventDeletionAfterCopy({
    required CalendarEvent existing,
    required RecurringEventMutationScope? recurringScope,
    required CalendarGuestUpdatePolicy guestUpdatePolicy,
    required String dependsOnOperationId,
  }) async {
    final series = recurringScope == RecurringEventMutationScope.entireSeries;
    final seriesBaseline = series
        ? await _seriesMasterBaseline(existing)
        : null;
    final request = <String, Object?>{
      calendarEventGuestUpdatePolicyKey: guestUpdatePolicy.name,
      calendarEventCopyConfirmationRequiredKey: true,
      if (recurringScope != null)
        calendarEventRecurringScopeKey: recurringScope.name,
      if (series) ...{
        calendarEventTargetProviderIdKey: existing.providerRecurringEventId,
        calendarEventOriginalStartKey:
            existing.providerOriginalStartKey ?? _storedEventStart(existing),
        calendarEventOriginalEndKey: _storedEventEnd(existing),
      },
    };
    final now = DateTime.now().toUtc().toIso8601String();
    await _database
        .into(_database.pendingOps)
        .insert(
          PendingOpsCompanion.insert(
            id: const Uuid().v4(),
            accountId: existing.accountId,
            provider: Value(existing.provider),
            entityType: 'event',
            operation: 'delete',
            operationType: const Value('event.delete'),
            calendarSourceId: Value(existing.calendarSourceId),
            providerCalendarId: Value(existing.providerCalendarId),
            eventId: Value(existing.id),
            dependsOnOpId: Value(dependsOnOperationId),
            requestJson: jsonEncode(request),
            baselineUpdatedUtc: Value(
              seriesBaseline?.updatedAtServer ?? existing.updatedAtServer,
            ),
            baselineRawJson: Value(
              (seriesBaseline == null
                      ? null
                      : seriesBaseline.baselineRawJson ??
                            seriesBaseline.rawJson) ??
                  existing.baselineRawJson,
            ),
            createdAtUtc: now,
            updatedAtUtc: now,
          ),
        );
  }

  Future<void> _queueDavEventDeletionAfterCopy({
    required CalendarSource source,
    required CalendarEvent existing,
    required RecurringEventMutationScope? recurringScope,
    required String dependsOnOperationId,
  }) async {
    final collectionId = source.davCollectionId;
    final objectId = existing.davObjectId;
    final uid = existing.icalUid;
    if (collectionId == null || objectId == null || uid == null) {
      throw StateError('The DAV event baseline is unavailable.');
    }
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    if (recurringScope == RecurringEventMutationScope.singleOccurrence) {
      final occurrenceKey = existing.occurrenceKey;
      if (occurrenceKey == null) {
        throw StateError('The DAV occurrence identity is unavailable.');
      }
      final raw = await queue.editableRawIcsForObject(
        accountId: existing.accountId,
        collectionId: collectionId,
        objectId: objectId,
      );
      final operationId = await queue.enqueueUpdate(
        accountId: existing.accountId,
        collectionId: collectionId,
        objectId: objectId,
        patch: buildDavEventOccurrenceCancellationPatch(
          uid: uid,
          occurrenceKey: occurrenceKey,
          baselineRawIcs: raw,
          thisAndFuture: false,
          nowUtc: () => _now().toUtc(),
        ),
        dependsOnOperationId: dependsOnOperationId,
      );
      await _requireCopyConfirmation(operationId);
      return;
    }
    final object = await (_database.select(
      _database.davObjects,
    )..where((row) => row.id.equals(objectId))).getSingle();
    final semantic = IcalSemanticDocument.parse(object.rawIcsBody);
    final targets = <IcalComponentKey>[
      for (final component in semantic.components)
        if (component.componentType == 'VEVENT' &&
            component.uid == uid &&
            (recurringScope == RecurringEventMutationScope.entireSeries ||
                component.recurrenceIdKey == existing.recurrenceIdKey))
          IcalComponentKey(
            componentType: component.componentType,
            uid: uid,
            recurrenceIdKey: component.recurrenceIdKey,
          ),
    ];
    if (targets.isEmpty) {
      throw StateError('The DAV event component is unavailable.');
    }
    final identities = targets.map(_icalComponentIdentity).toSet();
    final documents = {
      for (final component in semantic.components)
        if (identities.contains(
          _icalComponentIdentity(
            IcalComponentKey(
              componentType: component.componentType,
              uid: component.uid!,
              recurrenceIdKey: component.recurrenceIdKey,
            ),
          ),
        ))
          component.documentComponent,
    };
    final hasOtherComponent = semantic.document.calendarComponents.any(
      (component) =>
          component.name != 'VTIMEZONE' && !documents.contains(component),
    );
    if (!hasOtherComponent) {
      final operationId = await queue.enqueueDelete(
        accountId: existing.accountId,
        collectionId: collectionId,
        objectId: objectId,
        target: targets.first,
        scope: recurringScope == RecurringEventMutationScope.entireSeries
            ? DavMutationScope.recurrenceMaster
            : DavMutationScope.object,
        dependsOnOperationId: dependsOnOperationId,
      );
      await _requireCopyConfirmation(operationId);
      return;
    }
    final operationId = await queue.enqueueUpdate(
      accountId: existing.accountId,
      collectionId: collectionId,
      objectId: objectId,
      patch: buildDavComponentRemovalPatch(
        targets: targets,
        scope: recurringScope == RecurringEventMutationScope.entireSeries
            ? DavMutationScope.recurrenceMaster
            : DavMutationScope.object,
      ),
      dependsOnOperationId: dependsOnOperationId,
    );
    await _requireCopyConfirmation(operationId);
  }

  Future<void> _requireCopyConfirmation(String operationId) async {
    final operation = await (_database.select(
      _database.pendingOps,
    )..where((row) => row.id.equals(operationId))).getSingle();
    final request = _jsonMap(operation.requestJson)
      ..[calendarEventCopyConfirmationRequiredKey] = true;
    await (_database.update(_database.pendingOps)
          ..where((row) => row.id.equals(operationId)))
        .write(PendingOpsCompanion(requestJson: Value(jsonEncode(request))));
  }

  Future<void> _discardQueuedEventCreate(String operationId) async {
    final operation = await (_database.select(
      _database.pendingOps,
    )..where((row) => row.id.equals(operationId))).getSingleOrNull();
    if (operation == null || operation.attemptCount != 0) return;
    await _database.transaction(() async {
      await _database.pendingOpsDao.deleteOp(operationId);
      final eventId = operation.eventId;
      if (eventId != null) {
        await (_database.delete(
          _database.calendarEvents,
        )..where((row) => row.id.equals(eventId))).go();
      }
    });
  }

  Future<void> _rebuildEventNotificationsFor(Set<String> accountIds) async {
    for (final accountId in accountIds) {
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        accountId,
      );
    }
    await _onNotificationScheduleChanged?.call();
  }

  Future<void> _writeCloudSeriesProjection({
    required CalendarEvent existing,
    required EventEditorDraft draft,
    required RecurringEventMutationScope scope,
    required BusyProvider provider,
    required Object? conference,
    required String? startTimeZone,
    required String? endTimeZone,
    required int now,
    bool timingOnly = false,
  }) async {
    final recurringEventId = existing.providerRecurringEventId;
    if (recurringEventId == null) {
      throw StateError('The recurring event identifier is unavailable.');
    }
    final rows =
        await (_database.select(_database.calendarEvents)..where(
              (row) =>
                  row.accountId.equals(existing.accountId) &
                  row.provider.equals(existing.provider) &
                  row.providerCalendarId.equals(existing.providerCalendarId) &
                  row.providerRecurringEventId.equals(recurringEventId) &
                  row.isDeleted.equals(false),
            ))
            .get();
    DateTime? wall(DateTime? value) =>
        value == null ? null : providerCivilDateTime(value);
    final existingStart = wall(_storedEventStartDateTime(existing));
    final existingEnd = wall(_storedEventEndDateTime(existing));
    final startChanged =
        draft.allDay != existing.allDay || wall(draft.start) != existingStart;
    final endChanged =
        draft.allDay != existing.allDay || wall(draft.end) != existingEnd;
    final startDelta =
        startChanged && draft.start != null && existingStart != null
        ? wall(draft.start)!.difference(existingStart)
        : Duration.zero;
    final endDelta = endChanged && draft.end != null && existingEnd != null
        ? wall(draft.end)!.difference(existingEnd)
        : Duration.zero;
    final raw = _jsonMap(existing.rawJson);
    final existingBody = _jsonObjectMap(raw['body']);
    final descriptionChanged =
        (draft.description ?? '') != (existing.description ?? '') ||
        (provider == BusyProvider.microsoft &&
            (draft.descriptionContentType?.toLowerCase() !=
                    existingBody['contentType']?.toString().toLowerCase() ||
                (draft.descriptionHtml != null &&
                    draft.descriptionHtml != existingBody['content'])));
    final locationChanged =
        (draft.location ?? '') != (existing.location ?? '') ||
        (provider == BusyProvider.microsoft && draft.locationChange.changed);
    final remindersChanged = !_sameJsonValue(
      _decodeStoredJson(existing.remindersJson),
      draft.reminders,
    );
    final colorChanged = draft.colorId != existing.colorId;
    final visibilityChanged =
        draft.visibilityOrSensitivity != existing.visibility;
    final showAsChanged = draft.showAs != existing.transparencyOrShowAs;
    final importanceChanged = draft.importance != raw['importance']?.toString();
    final responseRequestedChanged =
        draft.responseRequested != raw['responseRequested'];
    final hideAttendeesChanged = provider == BusyProvider.google
        ? draft.hideAttendees !=
              (raw['guestsCanSeeOtherGuests'] is bool
                  ? !(raw['guestsCanSeeOtherGuests'] as bool)
                  : null)
        : draft.hideAttendees != raw['hideAttendees'];
    final newTimeProposalsChanged =
        draft.allowNewTimeProposals != raw['allowNewTimeProposals'];
    final rawChanged =
        (provider == BusyProvider.microsoft &&
            (draft.locationChange.changed || descriptionChanged)) ||
        importanceChanged ||
        responseRequestedChanged ||
        hideAttendeesChanged ||
        newTimeProposalsChanged;

    for (final row in rows) {
      if (!_seriesRowInScope(row, existing, scope)) continue;
      final rowStart = wall(_storedEventStartDateTime(row));
      final rowEnd = wall(_storedEventEndDateTime(row));
      final shiftedStart = startChanged && rowStart != null
          ? rowStart.add(startDelta)
          : rowStart;
      final shiftedEnd = endChanged && rowEnd != null
          ? rowEnd.add(endDelta)
          : rowEnd;
      final companion = CalendarEventsCompanion(
        title: draft.title.trim() != existing.title
            ? Value(draft.title.trim())
            : const Value.absent(),
        description: descriptionChanged
            ? Value(draft.description)
            : const Value.absent(),
        location: locationChanged
            ? Value(draft.location)
            : const Value.absent(),
        locationLatitude: locationChanged && provider == BusyProvider.microsoft
            ? Value(draft.effectiveLocationPoint?.latitude)
            : const Value.absent(),
        locationLongitude: locationChanged && provider == BusyProvider.microsoft
            ? Value(draft.effectiveLocationPoint?.longitude)
            : const Value.absent(),
        allDay: startChanged || endChanged
            ? Value(draft.allDay)
            : const Value.absent(),
        startDate: startChanged
            ? Value(draft.allDay ? _date(shiftedStart) : null)
            : const Value.absent(),
        startDateTime: startChanged
            ? Value(
                draft.allDay || shiftedStart == null
                    ? null
                    : providerWallTimeIso8601String(shiftedStart),
              )
            : const Value.absent(),
        startTimeZone:
            startChanged || draft.startTimeZone != existing.startTimeZone
            ? Value(draft.allDay ? null : startTimeZone)
            : const Value.absent(),
        endDate: endChanged
            ? Value(draft.allDay ? _date(shiftedEnd) : null)
            : const Value.absent(),
        endDateTime: endChanged
            ? Value(
                draft.allDay || shiftedEnd == null
                    ? null
                    : providerWallTimeIso8601String(shiftedEnd),
              )
            : const Value.absent(),
        endTimeZone: endChanged || draft.endTimeZone != existing.endTimeZone
            ? Value(draft.allDay ? null : endTimeZone)
            : const Value.absent(),
        remindersJson: remindersChanged
            ? Value(_json(draft.reminders))
            : const Value.absent(),
        attendeesJson: draft.attendeesChanged
            ? Value(_json(_localAttendeesJson(draft, provider)))
            : const Value.absent(),
        categoriesJson: draft.categoriesChanged
            ? Value(_json(_categoriesJson(draft, provider)))
            : const Value.absent(),
        colorId: colorChanged ? Value(draft.colorId) : const Value.absent(),
        visibility: visibilityChanged
            ? Value(draft.visibilityOrSensitivity)
            : const Value.absent(),
        transparencyOrShowAs: showAsChanged
            ? Value(draft.showAs)
            : const Value.absent(),
        conferenceJson: conference != null
            ? Value(_json(conference))
            : const Value.absent(),
        rawJson: rawChanged
            ? Value(
                jsonEncode(
                  _optimisticEventRaw(
                    draft,
                    provider,
                    existingJson: row.rawJson,
                    descriptionChanged: descriptionChanged,
                  ),
                ),
              )
            : const Value.absent(),
        updatedAtLocal: Value(now),
        syncStatus: const Value('pending'),
      );
      await (_database.update(
        _database.calendarEvents,
      )..where((table) => table.id.equals(row.id))).write(
        timingOnly
            ? CalendarEventsCompanion(
                allDay: companion.allDay,
                startDate: companion.startDate,
                startDateTime: companion.startDateTime,
                startTimeZone: companion.startTimeZone,
                endDate: companion.endDate,
                endDateTime: companion.endDateTime,
                endTimeZone: companion.endTimeZone,
                updatedAtLocal: companion.updatedAtLocal,
                syncStatus: companion.syncStatus,
              )
            : companion,
      );
    }
    if (provider == BusyProvider.google &&
        locationChanged &&
        scope == RecurringEventMutationScope.entireSeries) {
      await LocationResolutionRepository(_database).removeGoogleSeriesSource(
        accountId: existing.accountId,
        sourceId: existing.calendarSourceId,
        providerSeriesId: recurringEventId,
      );
    }
  }

  Future<void> _markCloudSeriesDeleted({
    required CalendarEvent existing,
    required RecurringEventMutationScope scope,
    required int now,
  }) async {
    final recurringEventId = existing.providerRecurringEventId;
    if (recurringEventId == null) {
      throw StateError('The recurring event identifier is unavailable.');
    }
    final rows =
        await (_database.select(_database.calendarEvents)..where(
              (row) =>
                  row.accountId.equals(existing.accountId) &
                  row.provider.equals(existing.provider) &
                  row.providerCalendarId.equals(existing.providerCalendarId) &
                  row.providerRecurringEventId.equals(recurringEventId) &
                  row.isDeleted.equals(false),
            ))
            .get();
    for (final row in rows) {
      if (!_seriesRowInScope(row, existing, scope)) continue;
      await (_database.update(
        _database.calendarEvents,
      )..where((table) => table.id.equals(row.id))).write(
        CalendarEventsCompanion(
          isDeleted: const Value(true),
          syncStatus: const Value('pending'),
          updatedAtLocal: Value(now),
        ),
      );
    }
    if (existing.provider == BusyProvider.google.storageValue &&
        scope == RecurringEventMutationScope.entireSeries) {
      await LocationResolutionRepository(_database).removeGoogleSeriesSource(
        accountId: existing.accountId,
        sourceId: existing.calendarSourceId,
        providerSeriesId: recurringEventId,
      );
    }
  }

  Future<PendingOp?> _latestPendingEventMutation({
    required String accountId,
    required String eventId,
    CalendarEvent? seriesEvent,
  }) async {
    final eventIds = {eventId};
    if (seriesEvent != null) {
      final rows =
          await (_database.select(_database.calendarEvents)..where(
                (row) =>
                    row.accountId.equals(accountId) &
                    row.provider.equals(seriesEvent.provider) &
                    row.providerCalendarId.equals(
                      seriesEvent.providerCalendarId,
                    ) &
                    (row.providerRecurringEventId.equals(
                          seriesEvent.providerRecurringEventId!,
                        ) |
                        row.providerEventId.equals(
                          seriesEvent.providerRecurringEventId!,
                        )),
              ))
              .get();
      eventIds.addAll(rows.map((row) => row.id));
    }
    final query = _database.select(_database.pendingOps)
      ..where(
        (row) =>
            row.accountId.equals(accountId) &
            row.entityType.equals('event') &
            row.eventId.isIn(eventIds) &
            (row.operationType.isIn(const [
                  'event.create',
                  'event.patch',
                  'event.move',
                  'event.respond',
                ]) |
                (row.operationType.isNull() &
                    row.operation.isIn(const [
                      'create',
                      'patch',
                      'move',
                      'respond',
                    ]))),
      )
      ..orderBy([
        (row) => OrderingTerm.desc(row.createdAtUtc),
        (row) => OrderingTerm.desc(row.updatedAtUtc),
      ]);
    final edits = await query.get();
    final predecessorIds = {
      for (final edit in edits)
        if (edit.dependsOnOpId != null) edit.dependsOnOpId!,
    };
    for (final edit in edits) {
      if (!predecessorIds.contains(edit.id)) {
        return edit;
      }
    }
    return edits.isEmpty ? null : edits.first;
  }

  Future<CalendarEvent> _seriesMasterBaseline(CalendarEvent occurrence) async {
    final seriesId = occurrence.providerRecurringEventId;
    if (seriesId == null || seriesId.isEmpty) {
      throw StateError(
        'The recurring series master identifier is unavailable.',
      );
    }
    final master =
        await (_database.select(_database.calendarEvents)..where(
              (row) =>
                  row.accountId.equals(occurrence.accountId) &
                  row.provider.equals(occurrence.provider) &
                  row.providerCalendarId.equals(occurrence.providerCalendarId) &
                  row.providerEventId.equals(seriesId) &
                  row.providerRecurringEventId.isNull(),
            ))
            .getSingleOrNull();
    if (master == null) {
      throw StateError('The recurring series master baseline is unavailable.');
    }
    return master;
  }

  Future<String> deleteLocalEvent(
    String eventId, {
    RecurringEventMutationScope? recurringScope,
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
  }) async {
    final existing = await (_database.select(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).getSingle();
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(existing.calendarSourceId))).getSingle();
    _requireMicrosoftSharedPrivateAccess(
      source,
      existing,
      operation: CalendarMutationOperation.deleteEvent,
    );
    await _requireWritableSource(
      source,
      database: _database,
      operation: CalendarMutationOperation.deleteEvent,
    );
    if (source.davCollectionId != null) {
      return _deleteLocalDavEvent(
        source,
        existing,
        recurringScope: recurringScope,
      );
    }
    final provider = BusyProviderCodec.requireStorageValue(existing.provider);
    final recurringOccurrence = _eventRequiresRecurringScope(existing);
    if (recurringOccurrence && recurringScope == null) {
      throw UnsupportedError('A recurring-event deletion scope is required.');
    }
    if (recurringScope == RecurringEventMutationScope.thisAndFuture &&
        provider != BusyProvider.google) {
      throw UnsupportedError(
        '${provider.displayName} does not expose a documented '
        'this-and-following mutation through this API.',
      );
    }
    final seriesMutation =
        recurringOccurrence &&
        (recurringScope == RecurringEventMutationScope.entireSeries ||
            recurringScope == RecurringEventMutationScope.thisAndFuture);
    final seriesBaseline = seriesMutation
        ? await _seriesMasterBaseline(existing)
        : null;
    final request = <String, Object?>{
      calendarEventGuestUpdatePolicyKey: guestUpdatePolicy.name,
      if (recurringScope != null)
        calendarEventRecurringScopeKey: recurringScope.name,
      if (seriesMutation) ...{
        calendarEventTargetProviderIdKey: existing.providerRecurringEventId,
        calendarEventOriginalStartKey:
            existing.providerOriginalStartKey ?? _storedEventStart(existing),
        calendarEventOriginalEndKey: _storedEventEnd(existing),
      },
    };
    final now = _now().millisecondsSinceEpoch;
    await _database.transaction(() async {
      final predecessor = await _latestPendingEventMutation(
        accountId: existing.accountId,
        eventId: existing.id,
        seriesEvent: seriesMutation ? existing : null,
      );
      if (seriesMutation) {
        await _markCloudSeriesDeleted(
          existing: existing,
          scope: recurringScope!,
          now: now,
        );
      } else {
        await (_database.update(
          _database.calendarEvents,
        )..where((row) => row.id.equals(eventId))).write(
          CalendarEventsCompanion(
            isDeleted: const Value(true),
            syncStatus: const Value('pending'),
            updatedAtLocal: Value(now),
          ),
        );
      }
      await _database
          .into(_database.pendingOps)
          .insert(
            PendingOpsCompanion.insert(
              id: const Uuid().v4(),
              accountId: existing.accountId,
              provider: Value(existing.provider),
              entityType: 'event',
              operation: 'delete',
              operationType: const Value('event.delete'),
              calendarSourceId: Value(existing.calendarSourceId),
              providerCalendarId: Value(existing.providerCalendarId),
              eventId: Value(existing.id),
              dependsOnOpId: Value(predecessor?.id),
              requestJson: jsonEncode(request),
              baselineUpdatedUtc: Value(
                seriesBaseline?.updatedAtServer ?? existing.updatedAtServer,
              ),
              baselineRawJson: Value(
                (seriesBaseline == null
                        ? null
                        : seriesBaseline.baselineRawJson ??
                              seriesBaseline.rawJson) ??
                    existing.baselineRawJson,
              ),
              createdAtUtc: DateTime.now().toUtc().toIso8601String(),
              updatedAtUtc: DateTime.now().toUtc().toIso8601String(),
            ),
          );
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      existing.accountId,
    );
    await _onNotificationScheduleChanged?.call();
    return existing.accountId;
  }

  Future<String> respondToLocalEvent(
    String eventId,
    CalendarInvitationResponse response, {
    bool sendResponse = true,
    RecurringEventMutationScope? recurringScope,
  }) async {
    final existing = await (_database.select(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).getSingle();
    final provider = BusyProviderCodec.requireStorageValue(existing.provider);
    if (provider == BusyProvider.nextcloud) {
      if (!sendResponse) {
        throw UnsupportedError('Nextcloud replies use server scheduling.');
      }
      return _respondToLocalDavEvent(
        existing,
        response,
        recurringScope: recurringScope,
      );
    }
    if (provider != BusyProvider.google && provider != BusyProvider.microsoft) {
      throw UnsupportedError(
        '${provider.displayName} invitation responses are not supported.',
      );
    }
    if (existing.isDeleted || existing.isCancelled) {
      throw StateError('A deleted or cancelled event cannot be answered.');
    }

    final attendees = _jsonMapList(existing.attendeesJson);
    final attendeeEmail = provider == BusyProvider.google
        ? _googleSelfAttendeeEmail(attendees)
        : null;
    if (provider == BusyProvider.google && attendeeEmail == null) {
      throw StateError(
        'The Google event does not identify the signed-in attendee.',
      );
    }

    final now = _now().millisecondsSinceEpoch;
    final raw = _jsonMap(existing.rawJson);
    final updatedAttendees = provider == BusyProvider.google
        ? _withGoogleSelfResponse(attendees, response)
        : attendees;
    final updatedRaw = provider == BusyProvider.microsoft
        ? _withMicrosoftResponse(raw, response)
        : raw;
    final predecessor = await _latestPendingEventMutation(
      accountId: existing.accountId,
      eventId: eventId,
    );
    await _database.transaction(() async {
      await (_database.delete(_database.pendingOps)..where(
            (row) =>
                row.accountId.equals(existing.accountId) &
                row.eventId.equals(eventId) &
                row.operationType.equals('event.respond'),
          ))
          .go();
      await (_database.update(
        _database.calendarEvents,
      )..where((row) => row.id.equals(eventId))).write(
        CalendarEventsCompanion(
          attendeesJson: provider == BusyProvider.google
              ? Value(jsonEncode(updatedAttendees))
              : const Value.absent(),
          rawJson: provider == BusyProvider.microsoft
              ? Value(jsonEncode(updatedRaw))
              : const Value.absent(),
          updatedAtLocal: Value(now),
          syncStatus: const Value('pending'),
        ),
      );
      await _database
          .into(_database.pendingOps)
          .insert(
            PendingOpsCompanion.insert(
              id: const Uuid().v4(),
              accountId: existing.accountId,
              provider: Value(existing.provider),
              entityType: 'event',
              operation: 'respond',
              operationType: const Value('event.respond'),
              calendarSourceId: Value(existing.calendarSourceId),
              providerCalendarId: Value(existing.providerCalendarId),
              eventId: Value(existing.id),
              dependsOnOpId: Value(predecessor?.id),
              requestJson: jsonEncode({
                'response': response.name,
                if (attendeeEmail != null) 'attendeeEmail': attendeeEmail,
                'sendResponse': sendResponse,
              }),
              createdAtUtc: DateTime.now().toUtc().toIso8601String(),
              updatedAtUtc: DateTime.now().toUtc().toIso8601String(),
            ),
          );
    });
    return existing.accountId;
  }

  Future<String> _respondToLocalDavEvent(
    CalendarEvent existing,
    CalendarInvitationResponse response, {
    RecurringEventMutationScope? recurringScope,
  }) async {
    if (existing.isDeleted || existing.isCancelled) {
      throw StateError('The meeting is no longer available.');
    }
    final source =
        await (_database.select(_database.calendarSources)..where(
              (r) =>
                  r.id.equals(existing.calendarSourceId) &
                  r.accountId.equals(existing.accountId),
            ))
            .getSingle();
    await _requireWritableSource(
      source,
      database: _database,
      operation: CalendarMutationOperation.editEvent,
    );
    final policy = await _davSchedulingPolicy(source);
    final objectId = existing.davObjectId;
    final uid = existing.icalUid;
    if (policy == null ||
        objectId == null ||
        uid == null ||
        source.davCollectionId == null) {
      throw schedulingDenied('DavAttendeeResponseUnavailable');
    }
    final recurring = _eventRequiresRecurringScope(existing);
    if (recurring &&
        (recurringScope == null ||
            recurringScope == RecurringEventMutationScope.thisAndFuture)) {
      throw UnsupportedError(
        'Choose this occurrence or the entire series for a reply.',
      );
    }
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    await _database.transaction(() async {
      final baseline = await queue.editableRawIcsForObject(
        accountId: existing.accountId,
        collectionId: source.davCollectionId!,
        objectId: objectId,
      );
      final DavMutationPatch patch;
      try {
        patch = buildNextcloudResponsePatch(
          baselineRawIcs: baseline,
          uid: uid,
          policy: policy,
          participationStatus: switch (response) {
            CalendarInvitationResponse.accept => 'ACCEPTED',
            CalendarInvitationResponse.tentative => 'TENTATIVE',
            CalendarInvitationResponse.decline => 'DECLINED',
          },
          nowUtc: _now().toUtc(),
          occurrenceKey: recurring ? existing.occurrenceKey : null,
          entireSeries:
              recurringScope == RecurringEventMutationScope.entireSeries,
        );
      } on NextcloudResponseUnchanged {
        return;
      }
      await queue.enqueueUpdate(
        accountId: existing.accountId,
        collectionId: source.davCollectionId!,
        objectId: objectId,
        patch: patch,
      );
      await DavObjectRepository(
        database: _database,
      ).projectLocalMutationCandidate(
        accountId: existing.accountId,
        collectionId: source.davCollectionId!,
        provider: BusyProvider.nextcloud,
        objectId: objectId,
        candidateRawIcs: patch.applyTo(baseline, nowUtc: _now().toUtc()),
        projectedAtUtc: _now().toUtc(),
      );
    });
    await _rebuildEventNotificationsFor({existing.accountId});
    return existing.accountId;
  }

  Future<String> _createLocalDavEvent(
    CalendarSource source,
    EventEditorDraft draft, {
    required bool rebuildNotifications,
  }) async {
    final scheduling = await _davSchedulingPolicy(source);
    _requireDavSchedulingUnchanged(
      draft,
      creating: true,
      scheduling: scheduling,
    );
    final start = draft.start;
    final end = draft.end;
    final collectionId = source.davCollectionId;
    if (start == null ||
        end == null ||
        collectionId == null ||
        !draft.canSave) {
      throw ArgumentError(
        'A valid DAV event range and collection are required.',
      );
    }
    final startTimeZone = _effectiveStartTimeZone(
      draft,
      source.timeZone,
      _localTimeZone,
    );
    final endTimeZone = _effectiveEndTimeZone(
      draft,
      source.timeZone,
      startTimeZone,
      _localTimeZone,
    );
    final object = buildDavEventObject(
      _davEventInput(
        draft,
        start: start,
        end: end,
        startTimeZone: startTimeZone,
        endTimeZone: endTimeZone,
        scheduling: scheduling,
        nowUtc: _now().toUtc(),
      ),
      nowUtc: () => _now().toUtc(),
    );
    final projectionId = 'dav-local-event-${const Uuid().v4()}';
    final now = _now();
    final nowMillis = now.millisecondsSinceEpoch;
    final native = IcalSemanticDocument.parse(object.rawIcs).components.single;
    final participants = [
      for (final raw in native.attendees)
        scheduling == null
            ? raw
            : nextcloudParticipantProjection(raw, scheduling),
    ];
    final organizer = native.organizers.firstOrNull;
    final projectedOrganizer = organizer == null || scheduling == null
        ? organizer
        : nextcloudParticipantProjection(organizer, scheduling);
    final projectionJson = jsonEncode({
      'transport': 'caldav',
      'uid': object.uid,
      'localPendingCreate': true,
      if (scheduling != null) ...{
        'isOrganizer': projectedOrganizer == null
            ? null
            : projectedOrganizer['self'],
        'canManageAttendees': scheduling.canInvite,
        'attendees': participants,
        'organizer': projectedOrganizer,
      },
    });
    late final String operationId;
    await _database.transaction(() async {
      await _database
          .into(_database.calendarEvents)
          .insert(
            CalendarEventsCompanion.insert(
              id: projectionId,
              accountId: draft.accountId,
              calendarSourceId: source.id,
              provider: source.provider,
              providerCalendarId: source.providerCalendarId,
              providerEventId: object.uid,
              davCollectionId: Value(collectionId),
              icalUid: Value(object.uid),
              occurrenceKey: Value(object.uid),
              providerRecurringEventId: Value(
                _hasDavRecurrence(draft.recurrence) ? object.uid : null,
              ),
              title: draft.title.trim(),
              description: Value(draft.description),
              location: Value(draft.location),
              locationLatitude: Value(draft.effectiveLocationPoint?.latitude),
              locationLongitude: Value(draft.effectiveLocationPoint?.longitude),
              allDay: Value(draft.allDay),
              startDate: Value(draft.allDay ? _date(start) : null),
              startDateTime: Value(
                draft.allDay ? null : start.toIso8601String(),
              ),
              startTimeZone: Value(startTimeZone),
              endDate: Value(draft.allDay ? _date(end) : null),
              endDateTime: Value(draft.allDay ? null : end.toIso8601String()),
              endTimeZone: Value(endTimeZone),
              recurrenceJson: Value(_json(draft.recurrence)),
              remindersJson: Value(_json(draft.reminders)),
              attendeesJson: Value(
                participants.isEmpty ? null : jsonEncode(participants),
              ),
              organizerJson: Value(
                projectedOrganizer == null
                    ? null
                    : jsonEncode(projectedOrganizer),
              ),
              categoriesJson: Value(_json(draft.categories)),
              visibility: Value(draft.visibilityOrSensitivity),
              transparencyOrShowAs: Value(draft.showAs),
              isDeleted: const Value(false),
              rawJson: Value(projectionJson),
              baselineRawJson: Value(projectionJson),
              createdAtLocal: nowMillis,
              updatedAtLocal: nowMillis,
              syncStatus: const Value('pending'),
            ),
          );
      operationId =
          await DavPendingOperationQueue(
            database: _database,
            nowUtc: () => _now().toUtc(),
          ).enqueueCreate(
            accountId: draft.accountId,
            collectionId: collectionId,
            object: object,
            localProjectionId: projectionId,
          );
    });
    if (rebuildNotifications) {
      await _notificationScheduleService().rebuildUpcomingEventNotifications(
        draft.accountId,
      );
      await _onNotificationScheduleChanged?.call();
    }
    return operationId;
  }

  Future<void> _updateLocalDavEvent(
    CalendarSource source,
    CalendarEvent existing,
    EventEditorDraft draft, {
    bool timingOnly = false,
    bool deferNotifications = false,
  }) async {
    final scheduling = await _davSchedulingPolicy(source);
    _requireDavSchedulingUnchanged(
      draft,
      creating: false,
      scheduling: scheduling,
    );
    final collectionId = source.davCollectionId;
    final uid = existing.icalUid;
    final start = draft.start;
    final end = draft.end;
    if (collectionId == null || uid == null || start == null || end == null) {
      throw StateError('The DAV event projection is incomplete.');
    }
    final recurring = _eventRequiresRecurringScope(existing);
    final recurringScope = draft.recurringMutationScope;
    if (recurring && recurringScope == null) {
      throw UnsupportedError(
        'A supported recurring-event editing scope is required.',
      );
    }
    final startTimeZone = timingOnly
        ? existing.startTimeZone
        : _effectiveStartTimeZone(draft, source.timeZone, _localTimeZone);
    final endTimeZone = timingOnly
        ? existing.endTimeZone
        : _effectiveEndTimeZone(
            draft,
            source.timeZone,
            startTimeZone,
            _localTimeZone,
          );
    var input = _davEventInput(
      draft,
      start: start,
      end: end,
      startTimeZone: startTimeZone,
      endTimeZone: endTimeZone,
      scheduling: scheduling,
      nowUtc: _now().toUtc(),
    );
    final target = IcalComponentKey(
      componentType: 'VEVENT',
      uid: uid,
      recurrenceIdKey: existing.recurrenceIdKey,
    );
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    DavMutationPatch? patch;
    late final String baselineRawIcs;
    final objectId = existing.davObjectId;
    if (objectId == null) {
      final create = await _pendingDavCreateForProjection(existing.id);
      if (create == null) {
        throw StateError('The pending DAV event create is unavailable.');
      }
      baselineRawIcs = _pendingCreateRawIcs(create);
    } else {
      baselineRawIcs = await queue.editableRawIcsForObject(
        accountId: existing.accountId,
        collectionId: collectionId,
        objectId: objectId,
      );
    }
    if (recurringScope == RecurringEventMutationScope.entireSeries) {
      input = _seriesDavEventInput(
        baselineRawIcs: baselineRawIcs,
        uid: uid,
        existing: existing,
        desired: input,
      );
      patch = buildDavEventUpdatePatch(
        target: IcalComponentKey(componentType: 'VEVENT', uid: uid),
        baselineRawIcs: baselineRawIcs,
        input: input,
        timingOnly: timingOnly,
      );
    } else if (recurringScope == RecurringEventMutationScope.thisAndFuture ||
        (recurringScope == RecurringEventMutationScope.singleOccurrence &&
            existing.recurrenceIdKey == null)) {
      final occurrenceKey = existing.occurrenceKey;
      if (occurrenceKey == null || objectId == null) {
        throw UnsupportedError(
          'Occurrence editing requires a synchronized occurrence.',
        );
      }
      patch = buildDavEventOccurrenceExceptionPatch(
        uid: uid,
        occurrenceKey: occurrenceKey,
        baselineRawIcs: baselineRawIcs,
        input: input,
        timingOnly: timingOnly,
        thisAndFuture:
            recurringScope == RecurringEventMutationScope.thisAndFuture,
        nowUtc: () => _now().toUtc(),
      );
    } else {
      patch = buildDavEventUpdatePatch(
        target: target,
        baselineRawIcs: baselineRawIcs,
        input: input,
        timingOnly: timingOnly,
      );
    }
    if (patch == null) return;
    if (scheduling != null &&
        input.attendeesChanged &&
        (recurringScope == RecurringEventMutationScope.entireSeries ||
            recurringScope == RecurringEventMutationScope.thisAndFuture)) {
      patch = nextcloudSeriesGuestPatch(
        initial: patch,
        baselineRawIcs: baselineRawIcs,
        attendees: input.attendees,
        nowUtc: _now().toUtc(),
        entireSeries:
            recurringScope == RecurringEventMutationScope.entireSeries,
        fromRecurrenceKey: patch.target.recurrenceIdKey,
      );
    }
    final candidate = patch.applyTo(baselineRawIcs, nowUtc: _now().toUtc());

    await _database.transaction(() async {
      if (objectId == null) {
        final updated = await queue.updateUnsentCreate(
          accountId: existing.accountId,
          collectionId: collectionId,
          localProjectionId: existing.id,
          patch: patch!,
        );
        if (!updated) {
          throw StateError(
            'The pending DAV event create is no longer editable.',
          );
        }
      } else {
        await queue.enqueueUpdate(
          accountId: existing.accountId,
          collectionId: collectionId,
          objectId: objectId,
          patch: patch!,
        );
      }
      if (objectId == null) {
        await _writeDavEventProjection(
          existing.id,
          draft,
          startTimeZone: startTimeZone,
          endTimeZone: endTimeZone,
        );
      } else {
        await DavObjectRepository(
          database: _database,
        ).projectLocalMutationCandidate(
          accountId: existing.accountId,
          collectionId: collectionId,
          provider: BusyProviderCodec.requireStorageValue(source.provider),
          objectId: objectId,
          candidateRawIcs: candidate,
          projectedAtUtc: _now().toUtc(),
        );
      }
    });
    if (timingOnly || deferNotifications) return;
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      existing.accountId,
    );
    await _onNotificationScheduleChanged?.call();
  }

  /// Queues a lossless URI ATTACH change through the existing DAV conditional
  /// mutation path. Binary and unrecognized ATTACH properties are untouched.
  Future<CalendarEventDetail?> changeNextcloudUriAttachmentReference({
    required String accountId,
    required String eventId,
    String? addUrl,
    String? removeUrl,
  }) async {
    final existing =
        await (_database.select(_database.calendarEvents)..where(
              (row) =>
                  row.id.equals(eventId) &
                  row.accountId.equals(accountId) &
                  row.isDeleted.equals(false),
            ))
            .getSingleOrNull();
    if (existing == null || existing.provider != 'nextcloud') {
      throw UnsupportedError('This is not an editable Nextcloud event.');
    }
    final source =
        await (_database.select(_database.calendarSources)..where(
              (row) =>
                  row.id.equals(existing.calendarSourceId) &
                  row.accountId.equals(accountId) &
                  row.isDeleted.equals(false),
            ))
            .getSingleOrNull();
    final collectionId = source?.davCollectionId;
    final uid = existing.icalUid;
    if (collectionId == null || uid == null) {
      throw StateError('The DAV event identity is unavailable.');
    }
    if (existing.providerRecurringEventId != null &&
        existing.occurrenceKey != null &&
        existing.recurrenceIdKey == null) {
      throw UnsupportedError(
        'A virtual occurrence cannot change attachment references.',
      );
    }
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    final objectId = existing.davObjectId;
    final baselineRawIcs = objectId == null
        ? _pendingCreateRawIcs(
            await _pendingDavCreateForProjection(existing.id) ??
                (throw StateError('The pending DAV create is unavailable.')),
          )
        : await queue.editableRawIcsForObject(
            accountId: accountId,
            collectionId: collectionId,
            objectId: objectId,
          );
    final target = IcalComponentKey(
      componentType: 'VEVENT',
      uid: uid,
      recurrenceIdKey: existing.recurrenceIdKey,
    );
    final patch = buildDavUriAttachmentPatch(
      baselineRawIcs: baselineRawIcs,
      target: target,
      addUrl: addUrl,
      removeUrl: removeUrl,
    );
    if (patch == null) return loadEventDetail(eventId);
    final candidate = patch.applyTo(baselineRawIcs, nowUtc: _now().toUtc());
    await _database.transaction(() async {
      if (objectId == null) {
        final updated = await queue.updateUnsentCreate(
          accountId: accountId,
          collectionId: collectionId,
          localProjectionId: existing.id,
          patch: patch,
        );
        if (!updated) {
          throw StateError('The pending DAV create is no longer editable.');
        }
        final component = IcalDocumentPatcher(
          IcalDocument.parse(candidate),
        ).requireComponent(target);
        await (_database.update(
          _database.calendarEvents,
        )..where((row) => row.id.equals(existing.id))).write(
          CalendarEventsCompanion(
            attachmentsJson: Value(
              jsonEncode([
                for (final property in component.propertiesNamed('ATTACH'))
                  property.rawValue,
              ]),
            ),
            syncStatus: const Value('pending'),
            updatedAtLocal: Value(_now().millisecondsSinceEpoch),
          ),
        );
      } else {
        await queue.enqueueUpdate(
          accountId: accountId,
          collectionId: collectionId,
          objectId: objectId,
          patch: patch,
        );
        await DavObjectRepository(
          database: _database,
        ).projectLocalMutationCandidate(
          accountId: accountId,
          collectionId: collectionId,
          provider: BusyProvider.nextcloud,
          objectId: objectId,
          candidateRawIcs: candidate,
          projectedAtUtc: _now().toUtc(),
        );
      }
    });
    return loadEventDetail(eventId);
  }

  Future<String> _deleteLocalDavEvent(
    CalendarSource source,
    CalendarEvent existing, {
    RecurringEventMutationScope? recurringScope,
  }) async {
    final collectionId = source.davCollectionId;
    final uid = existing.icalUid;
    if (collectionId == null || uid == null) {
      throw StateError('The DAV event projection is incomplete.');
    }
    final recurring = _eventRequiresRecurringScope(existing);
    final scheduling = await _davSchedulingPolicy(source);
    if (recurringScope == RecurringEventMutationScope.singleOccurrence &&
        scheduling?.canReply == true &&
        _jsonMap(existing.rawJson)['isOrganizer'] == false) {
      return _respondToLocalDavEvent(
        existing,
        CalendarInvitationResponse.decline,
        recurringScope: recurringScope,
      );
    }
    if (recurring && recurringScope == null) {
      throw UnsupportedError(
        'A supported recurring-event deletion scope is required.',
      );
    }
    final queue = DavPendingOperationQueue(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
    final objectId = existing.davObjectId;
    await _database.transaction(() async {
      if (objectId == null) {
        if (recurringScope == RecurringEventMutationScope.singleOccurrence ||
            recurringScope == RecurringEventMutationScope.thisAndFuture) {
          throw UnsupportedError(
            'Occurrence deletion requires a synchronized occurrence.',
          );
        }
        final cancelled = await queue.cancelUnsentCreate(
          accountId: existing.accountId,
          collectionId: collectionId,
          localProjectionId: existing.id,
        );
        if (!cancelled) {
          throw StateError(
            'The DAV event create may already be in progress and cannot be '
            'cancelled locally.',
          );
        }
        await (_database.delete(
          _database.calendarEvents,
        )..where((row) => row.id.equals(existing.id))).go();
        return;
      }

      final object = await (_database.select(
        _database.davObjects,
      )..where((row) => row.id.equals(objectId))).getSingleOrNull();
      if (object == null || object.collectionId != collectionId) {
        throw StateError('The DAV event baseline is unavailable.');
      }
      final provider = BusyProviderCodec.requireStorageValue(source.provider);
      if (recurringScope == RecurringEventMutationScope.singleOccurrence ||
          recurringScope == RecurringEventMutationScope.thisAndFuture) {
        final occurrenceKey = existing.occurrenceKey;
        if (occurrenceKey == null) {
          throw StateError('The DAV occurrence identity is unavailable.');
        }
        final editableRawIcs = await queue.editableRawIcsForObject(
          accountId: existing.accountId,
          collectionId: collectionId,
          objectId: objectId,
        );
        final patch = buildDavEventOccurrenceCancellationPatch(
          uid: uid,
          occurrenceKey: occurrenceKey,
          baselineRawIcs: editableRawIcs,
          schedulingOrganizer:
              scheduling?.canInvite == true &&
              _jsonMap(existing.rawJson)['isOrganizer'] == true,
          thisAndFuture:
              recurringScope == RecurringEventMutationScope.thisAndFuture,
          nowUtc: () => _now().toUtc(),
        );
        final candidate = patch.applyTo(editableRawIcs, nowUtc: _now().toUtc());
        await queue.enqueueUpdate(
          accountId: existing.accountId,
          collectionId: collectionId,
          objectId: objectId,
          patch: patch,
        );
        await DavObjectRepository(
          database: _database,
        ).projectLocalMutationCandidate(
          accountId: existing.accountId,
          collectionId: collectionId,
          provider: provider,
          objectId: objectId,
          candidateRawIcs: candidate,
          projectedAtUtc: _now().toUtc(),
        );
        return;
      }

      final semantic = IcalSemanticDocument.parse(object.rawIcsBody);
      final targets = <IcalComponentKey>[
        for (final component in semantic.components)
          if (component.componentType == 'VEVENT' &&
              component.uid == uid &&
              (recurringScope == RecurringEventMutationScope.entireSeries ||
                  component.recurrenceIdKey == existing.recurrenceIdKey))
            IcalComponentKey(
              componentType: component.componentType,
              uid: uid,
              recurrenceIdKey: component.recurrenceIdKey,
            ),
      ];
      if (targets.isEmpty) {
        throw StateError('The DAV event component is unavailable.');
      }
      final targetIdentities = targets.map(_icalComponentIdentity).toSet();
      final targetDocumentComponents = {
        for (final component in semantic.components)
          if (targetIdentities.contains(
            _icalComponentIdentity(
              IcalComponentKey(
                componentType: component.componentType,
                uid: component.uid!,
                recurrenceIdKey: component.recurrenceIdKey,
              ),
            ),
          ))
            component.documentComponent,
      };
      final hasUntargetedCalendarComponent = semantic
          .document
          .calendarComponents
          .any(
            (component) =>
                component.name != 'VTIMEZONE' &&
                !targetDocumentComponents.contains(component),
          );
      if (!hasUntargetedCalendarComponent) {
        await queue.enqueueDelete(
          accountId: existing.accountId,
          collectionId: collectionId,
          objectId: objectId,
          target: targets.first,
          scope: recurring
              ? DavMutationScope.recurrenceMaster
              : DavMutationScope.object,
        );
        await (_database.update(
          _database.calendarEvents,
        )..where((row) => row.davObjectId.equals(objectId))).write(
          CalendarEventsCompanion(
            isDeleted: const Value(true),
            syncStatus: const Value('pending'),
            updatedAtLocal: Value(_now().millisecondsSinceEpoch),
          ),
        );
        return;
      }
      final patch = buildDavComponentRemovalPatch(
        targets: targets,
        scope: recurring
            ? DavMutationScope.recurrenceMaster
            : DavMutationScope.object,
      );
      final candidate = patch.applyTo(
        object.rawIcsBody,
        nowUtc: _now().toUtc(),
      );
      await queue.enqueueUpdate(
        accountId: existing.accountId,
        collectionId: collectionId,
        objectId: objectId,
        patch: patch,
      );
      await DavObjectRepository(
        database: _database,
      ).projectLocalMutationCandidate(
        accountId: existing.accountId,
        collectionId: collectionId,
        provider: provider,
        objectId: objectId,
        candidateRawIcs: candidate,
        projectedAtUtc: _now().toUtc(),
      );
    });
    await _notificationScheduleService().rebuildUpcomingEventNotifications(
      existing.accountId,
    );
    await _onNotificationScheduleChanged?.call();
    return existing.accountId;
  }

  Future<NextcloudSchedulingPolicy?> _davSchedulingPolicy(
    CalendarSource source,
  ) async {
    if (source.provider != 'nextcloud' || source.davCollectionId == null) {
      return null;
    }
    final collection =
        await (_database.select(_database.davCollections)..where(
              (r) =>
                  r.id.equals(source.davCollectionId!) &
                  r.accountId.equals(source.accountId),
            ))
            .getSingle();
    return NextcloudSchedulingPolicy.load(_database, collection);
  }

  Future<PendingOp?> _pendingDavCreateForProjection(String projectionId) {
    return (_database.select(_database.pendingOps)
          ..where(
            (row) =>
                row.eventId.equals(projectionId) &
                row.operationType.equals('dav.create') &
                row.state.equals('pending') &
                row.attemptCount.equals(0),
          )
          ..limit(1))
        .getSingleOrNull();
  }

  Future<void> _writeDavEventProjection(
    String eventId,
    EventEditorDraft draft, {
    required String? startTimeZone,
    required String? endTimeZone,
  }) {
    return (_database.update(
      _database.calendarEvents,
    )..where((row) => row.id.equals(eventId))).write(
      CalendarEventsCompanion(
        title: Value(draft.title.trim()),
        description: Value(draft.description),
        location: Value(draft.location),
        locationLatitude: draft.locationChange.changed
            ? Value(draft.effectiveLocationPoint?.latitude)
            : const Value.absent(),
        locationLongitude: draft.locationChange.changed
            ? Value(draft.effectiveLocationPoint?.longitude)
            : const Value.absent(),
        allDay: Value(draft.allDay),
        startDate: Value(draft.allDay ? _date(draft.start) : null),
        startDateTime: Value(
          draft.allDay
              ? null
              : _eventDateTimeWireValue(draft.start, startTimeZone),
        ),
        startTimeZone: Value(startTimeZone),
        endDate: Value(draft.allDay ? _date(draft.end) : null),
        endDateTime: Value(
          draft.allDay ? null : _eventDateTimeWireValue(draft.end, endTimeZone),
        ),
        endTimeZone: Value(endTimeZone),
        recurrenceJson: draft.recurrenceChanged
            ? Value(_json(draft.recurrence))
            : const Value.absent(),
        remindersJson: Value(_json(draft.reminders)),
        attendeesJson: draft.attendeesChanged
            ? Value(
                _json([
                  for (final attendee in draft.attendees)
                    attendee.toGoogleJson(),
                ]),
              )
            : const Value.absent(),
        categoriesJson: draft.categoriesChanged
            ? Value(_json(draft.categories))
            : const Value.absent(),
        visibility: Value(draft.visibilityOrSensitivity),
        transparencyOrShowAs: Value(draft.showAs),
        updatedAtLocal: Value(_now().millisecondsSinceEpoch),
        syncStatus: const Value('pending'),
      ),
    );
  }

  Future<PendingOp?> _pendingCalendarCreate(String sourceId) {
    return (_database.select(_database.pendingOps)
          ..where(
            (row) =>
                row.calendarSourceId.equals(sourceId) &
                row.operationType.equals('calendar.create'),
          )
          ..limit(1))
        .getSingleOrNull();
  }

  Future<List<PendingOp>> _pendingCalendarWork(String sourceId) {
    return (_database.select(
      _database.pendingOps,
    )..where((row) => row.calendarSourceId.equals(sourceId))).get();
  }

  bool _isProvablyUnsentCalendarCreate(PendingOp? operation) =>
      operation != null &&
      operation.state == 'pending' &&
      operation.attemptCount == 0;

  Future<Set<String>> _pendingCalendarPatchFields(String sourceId) async {
    final operations =
        await (_database.select(_database.pendingOps)..where(
              (row) =>
                  row.calendarSourceId.equals(sourceId) &
                  row.operationType.equals('calendar.patch') &
                  row.state.equals('pending'),
            ))
            .get();
    const projectedFields = <String>{
      'summary',
      'description',
      'timeZone',
      'backgroundColor',
      'foregroundColor',
      'colorId',
      'hidden',
    };
    return {
      for (final operation in operations)
        ..._calendarPendingRequest(
          operation,
        ).keys.where(projectedFields.contains),
    };
  }

  Future<bool> _hasActiveCalendarRemoval(String sourceId) async {
    final operations =
        await (_database.select(_database.pendingOps)..where(
              (row) =>
                  row.calendarSourceId.equals(sourceId) &
                  (row.operationType.equals('calendar.delete') |
                      row.operationType.equals('calendar.remove')) &
                  row.state.equals('pending'),
            ))
            .get();
    return operations.any(
      (operation) =>
          operation.nextAttemptAtUtc?.startsWith('9999-12-31') != true,
    );
  }

  Future<void> _enqueueOrMergeCalendarPatch(
    CalendarSource source, {
    required Map<String, Object?> request,
    required String nowUtc,
    String? dependsOnOpId,
  }) async {
    final queuedRequest = _calendarPatchRequestWithPreviousValues(
      source,
      request,
    );
    final requestedScope =
        queuedRequest[calendarMutationScopeKey]?.toString() ??
        calendarMutationScopeGlobal;
    final candidates =
        await (_database.select(_database.pendingOps)
              ..where(
                (row) =>
                    row.calendarSourceId.equals(source.id) &
                    row.operationType.equals('calendar.patch') &
                    row.state.equals('pending') &
                    row.attemptCount.equals(0),
              )
              ..orderBy([(row) => OrderingTerm.asc(row.createdAtUtc)]))
            .get();
    PendingOp? existing;
    for (final candidate in candidates) {
      final candidateScope =
          _calendarPendingRequest(
            candidate,
          )[calendarMutationScopeKey]?.toString() ??
          calendarMutationScopeGlobal;
      if (candidateScope == requestedScope) {
        existing = candidate;
        break;
      }
    }
    if (existing != null) {
      final existingOp = existing;
      final existingRequest = _calendarPendingRequest(existingOp);
      final existingPrevious = _jsonObjectMap(
        existingRequest[calendarPatchPreviousValuesKey],
      );
      final queuedPrevious = _jsonObjectMap(
        queuedRequest[calendarPatchPreviousValuesKey],
      );
      final merged = existingRequest..addAll(queuedRequest);
      merged[calendarPatchPreviousValuesKey] = {
        ...queuedPrevious,
        ...existingPrevious,
      };
      await (_database.update(
        _database.pendingOps,
      )..where((row) => row.id.equals(existingOp.id))).write(
        PendingOpsCompanion(
          requestJson: Value(jsonEncode(merged)),
          dependsOnOpId: Value(existingOp.dependsOnOpId ?? dependsOnOpId),
          updatedAtUtc: Value(nowUtc),
        ),
      );
      return;
    }
    await _database.pendingOpsDao.enqueue(
      PendingOpsCompanion.insert(
        id: const Uuid().v4(),
        accountId: source.accountId,
        provider: Value(source.provider),
        entityType: 'calendar',
        operation: 'patch',
        operationType: const Value('calendar.patch'),
        calendarSourceId: Value(source.id),
        providerCalendarId: Value(source.providerCalendarId),
        dependsOnOpId: Value(dependsOnOpId),
        requestJson: jsonEncode(queuedRequest),
        baselineRawJson: Value(source.rawJson),
        createdAtUtc: nowUtc,
        updatedAtUtc: nowUtc,
      ),
    );
  }

  NotificationScheduleService _notificationScheduleService() {
    return NotificationScheduleService(
      database: _database,
      nowUtc: () => _now().toUtc(),
    );
  }

  Future<void> markMissingEventsDeleted({
    required String accountId,
    required BusyProvider provider,
    required String providerCalendarId,
    required DateTime rangeStart,
    required DateTime rangeEnd,
    required Set<String> returnedLocalEventIds,
  }) async {
    final source = sourceId(
      accountId: accountId,
      provider: provider,
      providerCalendarId: providerCalendarId,
    );
    final rows =
        await (_database.select(_database.calendarEvents)..where(
              (row) =>
                  row.accountId.equals(accountId) &
                  row.calendarSourceId.equals(source) &
                  row.isDeleted.equals(false),
            ))
            .get();
    final now = _now().millisecondsSinceEpoch;
    for (final row in rows) {
      if (returnedLocalEventIds.contains(row.id) ||
          row.syncStatus != 'synced') {
        continue;
      }
      if (!storedCalendarEventOverlapsUtcRange(row, rangeStart, rangeEnd)) {
        continue;
      }
      await (_database.update(
        _database.calendarEvents,
      )..where((table) => table.id.equals(row.id))).write(
        CalendarEventsCompanion(
          isDeleted: const Value(true),
          syncStatus: const Value('synced'),
          updatedAtLocal: Value(now),
        ),
      );
    }
  }

  /// Applies a confirmed Microsoft deletion to its existing scoped identity.
  /// ID-only calendar-view markers must not create a second occurrence row.
  Future<void> markMicrosoftRemovedEventDeleted({
    required String accountId,
    required String providerCalendarId,
    required String providerEventId,
  }) async {
    final scopedSourceId = sourceId(
      accountId: accountId,
      provider: BusyProvider.microsoft,
      providerCalendarId: providerCalendarId,
    );
    await _database.transaction(() async {
      final matches =
          await (_database.select(_database.calendarEvents)..where(
                (row) =>
                    row.accountId.equals(accountId) &
                    row.calendarSourceId.equals(scopedSourceId) &
                    row.provider.equals(BusyProvider.microsoft.storageValue) &
                    row.providerEventId.equals(providerEventId) &
                    row.isDeleted.equals(false),
              ))
              .get();
      if (matches.isEmpty) return;
      if (matches.length != 1) {
        throw StateError('Ambiguous Microsoft event removal identity.');
      }
      final match = matches.single;
      if (match.syncStatus != 'synced') return;
      final pending =
          await (_database.select(_database.pendingOps)
                ..where(
                  (row) =>
                      row.accountId.equals(accountId) &
                      row.entityType.equals('event') &
                      row.eventId.equals(match.id),
                )
                ..limit(1))
              .getSingleOrNull();
      if (pending != null) return;
      await (_database.update(
        _database.calendarEvents,
      )..where((row) => row.id.equals(match.id))).write(
        CalendarEventsCompanion(
          isDeleted: const Value(true),
          updatedAtLocal: Value(_now().millisecondsSinceEpoch),
        ),
      );
    });
  }

  Future<void> markExpandedRecurringMastersDeleted({
    required String accountId,
    required BusyProvider provider,
    required String providerCalendarId,
    required Set<String> providerRecurringEventIds,
  }) async {
    if (providerRecurringEventIds.isEmpty) {
      return;
    }
    final source = sourceId(
      accountId: accountId,
      provider: provider,
      providerCalendarId: providerCalendarId,
    );
    await _database.transaction(() async {
      final masters =
          await (_database.select(_database.calendarEvents)..where(
                (row) =>
                    row.accountId.equals(accountId) &
                    row.calendarSourceId.equals(source) &
                    row.provider.equals(provider.storageValue) &
                    row.providerEventId.isIn(providerRecurringEventIds) &
                    row.providerRecurringEventId.isNull() &
                    row.syncStatus.equals('synced') &
                    row.isDeleted.equals(false),
              ))
              .get();
      if (masters.isEmpty) return;

      if (provider == BusyProvider.google) {
        final resolutions = LocationResolutionRepository(_database);
        for (final master in masters) {
          await resolutions.reconcileGoogleSeriesMaster(master);
        }
      }

      await (_database.update(
        _database.calendarEvents,
      )..where((row) => row.id.isIn(masters.map((master) => master.id)))).write(
        CalendarEventsCompanion(
          isDeleted: const Value(true),
          syncStatus: const Value('synced'),
          updatedAtLocal: Value(_now().millisecondsSinceEpoch),
        ),
      );
    });
  }

  Future<SyncCursor?> syncState({
    required String accountId,
    required BusyProvider provider,
    required String syncKind,
    String? calendarSourceId,
  }) {
    final id = syncStateId(
      accountId: accountId,
      provider: provider,
      syncKind: syncKind,
      calendarSourceId: calendarSourceId,
    );
    return (_database.select(
      _database.syncCursors,
    )..where((row) => row.id.equals(id))).getSingleOrNull();
  }

  static String syncStateId({
    required String accountId,
    required BusyProvider provider,
    required String syncKind,
    String? calendarSourceId,
  }) {
    return [
      accountId,
      provider.storageValue,
      syncKind,
      calendarSourceId ?? 'account',
    ].join('|');
  }

  static String sourceId({
    required String accountId,
    required BusyProvider provider,
    required String providerCalendarId,
  }) {
    return '$accountId|${provider.storageValue}|$providerCalendarId';
  }

  static String eventId({
    required String accountId,
    required BusyProvider provider,
    required String providerCalendarId,
    required String providerEventId,
    String? providerOriginalStartKey,
  }) {
    return [
      accountId,
      provider.storageValue,
      providerCalendarId,
      providerEventId,
      providerOriginalStartKey ?? '',
    ].join('|');
  }
}

Future<void> _requireWritableSource(
  CalendarSource source, {
  required AppDatabase database,
  required CalendarMutationOperation operation,
}) async {
  final collection = source.davCollectionId == null
      ? null
      : await (database.select(database.davCollections)..where(
              (r) =>
                  r.accountId.equals(source.accountId) &
                  r.id.equals(source.davCollectionId!),
            ))
            .getSingleOrNull();
  final capabilities = CalendarSourceEntity.fromRow(
    source,
    davCollection: collection,
  ).capabilities;
  final allowed = switch (operation) {
    CalendarMutationOperation.createEvent => capabilities.canCreateEvents,
    CalendarMutationOperation.editEvent ||
    CalendarMutationOperation.moveEvent => capabilities.canEditEvents,
    CalendarMutationOperation.deleteEvent => capabilities.canDeleteEvents,
    _ => false,
  };
  if (allowed) {
    return;
  }
  throw CalendarMutationNotAllowed(operation: operation, sourceId: source.id);
}

void _requireFullEventEditingAllowed(CalendarEvent event) {
  final provider = BusyProviderCodec.requireStorageValue(event.provider);
  if (provider != BusyProvider.google) return;
  final raw = _jsonMap(event.rawJson);
  final organizer = _jsonMap(event.organizerJson);
  final allowed =
      raw['locked'] != true &&
      (organizer['self'] == true || raw['guestsCanModify'] == true);
  if (allowed) return;
  throw CalendarMutationNotAllowed(
    operation: CalendarMutationOperation.editEvent,
    sourceId: event.calendarSourceId,
  );
}

void _requireMicrosoftSharedPrivateAccess(
  CalendarSource source,
  CalendarEvent event, {
  required CalendarMutationOperation operation,
}) {
  if (MicrosoftSharedPrimaryCalendarAddress.parse(source.providerCalendarId) ==
          null ||
      event.visibility?.toLowerCase() != 'private') {
    return;
  }
  final metadata = _jsonMap(source.rawJson);
  if (metadata['canViewPrivateItems'] == true) return;
  throw CalendarMutationNotAllowed(operation: operation, sourceId: source.id);
}

void _requireAttendeeManagementAllowed(
  CalendarEvent event,
  EventEditorDraft draft,
) {
  if (!draft.attendeesChanged) return;
  final provider = BusyProviderCodec.requireStorageValue(event.provider);
  if (provider != BusyProvider.google) return;
  final raw = _jsonMap(event.rawJson);
  final organizer = _jsonMap(event.organizerJson);
  final allowed =
      organizer['self'] == true || raw['guestsCanInviteOthers'] != false;
  if (allowed) return;
  throw CalendarMutationNotAllowed(
    operation: CalendarMutationOperation.editEvent,
    sourceId: event.calendarSourceId,
  );
}

void _requireCalendarSourceCapability(
  CalendarSource source, {
  required CalendarMutationOperation operation,
  required bool allowed,
}) {
  if (allowed) {
    return;
  }
  throw CalendarMutationNotAllowed(operation: operation, sourceId: source.id);
}

Map<String, Object?> _calendarPendingRequest(PendingOp op) {
  final decoded = jsonDecode(op.requestJson);
  if (decoded is! Map) {
    return <String, Object?>{};
  }
  return decoded.cast<String, Object?>();
}

String _calendarOperationType(PendingOp op) {
  return op.operationType ?? '${op.entityType}.${op.operation}';
}

Map<String, Object?> _calendarPatchRequestWithPreviousValues(
  CalendarSource source,
  Map<String, Object?> request,
) {
  final queued = <String, Object?>{...request};
  final previous = <String, Object?>{};
  if (request.containsKey('summary')) {
    previous['summary'] = source.summary;
  }
  if (request.containsKey('backgroundColor') ||
      request.containsKey('foregroundColor') ||
      request.containsKey('colorId')) {
    previous['backgroundColor'] = source.backgroundColor;
    previous['foregroundColor'] = source.foregroundColor;
    previous['colorId'] = source.colorId;
  }
  if (request.containsKey('hidden')) {
    previous['hidden'] = source.hidden;
  }
  if (previous.isNotEmpty) {
    queued[calendarPatchPreviousValuesKey] = previous;
  }
  return queued;
}

bool _calendarRemovalPreviousHidden(PendingOp op) {
  final requestValue = _jsonMap(
    op.requestJson,
  )[calendarRemovalPreviousHiddenKey];
  if (requestValue is bool) return requestValue;
  final baselineValue = _jsonMap(op.baselineRawJson)['hidden'];
  return baselineValue is bool ? baselineValue : false;
}

void _requireDavSchedulingUnchanged(
  EventEditorDraft draft, {
  required bool creating,
  NextcloudSchedulingPolicy? scheduling,
}) {
  final changesAttendees = creating
      ? draft.attendees.isNotEmpty
      : draft.attendeesChanged;
  if ((changesAttendees &&
          (scheduling?.canInvite != true || draft.isOrganizer == false)) ||
      draft.createConference ||
      (creating && draft.conference != null)) {
    throw UnsupportedError(
      'This DAV calendar does not authorize the requested attendee changes '
      'or support creating conferencing data.',
    );
  }
}

DavEventMutationInput _davEventInput(
  EventEditorDraft draft, {
  required DateTime start,
  required DateTime end,
  required String? startTimeZone,
  required String? endTimeZone,
  NextcloudSchedulingPolicy? scheduling,
  DateTime? nowUtc,
}) {
  return DavEventMutationInput(
    attendees: draft.attendees,
    attendeesChanged: draft.attendeesChanged,
    organizerAddress: scheduling?.organizerAddress,
    schedulingOrganizer:
        scheduling?.canInvite == true && draft.isOrganizer != false,
    mutationAtUtc: nowUtc,
    title: draft.title,
    allDay: draft.allDay,
    start: start,
    end: end,
    startTimeZone: startTimeZone,
    endTimeZone: endTimeZone,
    description: draft.description,
    location: draft.location,
    locationPoint: draft.effectiveLocationPoint,
    locationChanged: draft.locationChange.changed,
    recurrence: draft.recurrence,
    recurrenceChanged: draft.recurrenceChanged,
    reminders: draft.reminders,
    remindersChanged: draft.remindersChanged,
    categories: draft.categories,
    categoriesChanged: draft.categoriesChanged,
    classification: draft.visibilityOrSensitivity,
    transparency: draft.showAs,
  );
}

DavEventMutationInput _seriesDavEventInput({
  required String baselineRawIcs,
  required String uid,
  required CalendarEvent existing,
  required DavEventMutationInput desired,
}) {
  final semantic = IcalSemanticDocument.parse(baselineRawIcs);
  final masters = semantic.components.where(
    (component) =>
        component.componentType == 'VEVENT' &&
        component.uid == uid &&
        component.recurrenceIdKey == null,
  );
  if (masters.length != 1 || masters.single.start == null) {
    throw StateError('The DAV recurrence master is unavailable.');
  }
  final master = masters.single;
  final masterStart = _editableIcalTemporal(master.start!);
  final masterEnd = master.end == null
      ? masterStart.add(master.duration?.duration ?? const Duration(hours: 1))
      : _editableIcalTemporal(master.end!);
  var projectedStart = DateTime.tryParse(
    existing.allDay ? existing.startDate ?? '' : existing.startDateTime ?? '',
  );
  var projectedEnd = DateTime.tryParse(
    existing.allDay ? existing.endDate ?? '' : existing.endDateTime ?? '',
  );
  if (projectedStart == null || projectedEnd == null) {
    throw StateError('The DAV occurrence projection is incomplete.');
  }
  final resolver = IcalTimeZoneResolver.fromDocument(semantic);
  if (!existing.allDay) {
    if (existing.startTimeZone case final zone?) {
      projectedStart = resolver.fromUtc(
        providerDateTimeAsUtcInstant(existing.startDateTime, zone)!,
        zone,
      );
    }
    if (existing.endTimeZone case final zone?) {
      projectedEnd = resolver.fromUtc(
        providerDateTimeAsUtcInstant(existing.endDateTime, zone)!,
        zone,
      );
    }
  }
  final startDelta = providerCivilDateTime(
    desired.start,
  ).difference(providerCivilDateTime(projectedStart));
  final endDelta = providerCivilDateTime(
    desired.end,
  ).difference(providerCivilDateTime(projectedEnd));
  final startChanged = startDelta != Duration.zero;
  final endChanged = endDelta != Duration.zero;
  final allDayChanged = desired.allDay != existing.allDay;
  final seriesStart = startChanged
      ? providerCivilDateTime(masterStart).add(startDelta)
      : masterStart;
  final seriesEnd = endChanged
      ? providerCivilDateTime(masterEnd).add(endDelta)
      : masterEnd;
  final masterTimeZone = _icalTimeZone(master.start!);
  final masterEndTimeZone = master.end == null
      ? masterTimeZone
      : _icalTimeZone(master.end!);
  return DavEventMutationInput(
    title: desired.title != existing.title
        ? desired.title
        : master.summary ?? '',
    allDay: allDayChanged ? desired.allDay : master.start!.isDate,
    start: seriesStart,
    end: seriesEnd,
    startTimeZone: startChanged || allDayChanged
        ? desired.startTimeZone
        : masterTimeZone,
    endTimeZone: endChanged || allDayChanged
        ? desired.endTimeZone
        : masterEndTimeZone,
    description: (desired.description ?? '') != (existing.description ?? '')
        ? desired.description
        : master.description,
    location: (desired.location ?? '') != (existing.location ?? '')
        ? desired.location
        : master.location,
    locationPoint: desired.locationChanged
        ? desired.locationPoint
        : master.locationPoint,
    locationChanged: desired.locationChanged,
    recurrence: desired.recurrence,
    recurrenceChanged: desired.recurrenceChanged,
    attendees: desired.attendees,
    attendeesChanged: desired.attendeesChanged,
    organizerAddress: desired.organizerAddress,
    schedulingOrganizer: desired.schedulingOrganizer,
    mutationAtUtc: desired.mutationAtUtc,
    reminders: desired.reminders,
    categories: desired.categories,
    categoriesChanged: desired.categoriesChanged,
    classification:
        (desired.classification ?? '') != (existing.visibility ?? '')
        ? desired.classification
        : master.classification,
    transparency:
        (desired.transparency ?? '') != (existing.transparencyOrShowAs ?? '')
        ? desired.transparency
        : master.transparency,
  );
}

DateTime _editableIcalTemporal(IcalTemporalValue value) {
  final wall = value.localValue;
  if (value.kind == IcalTemporalKind.utcDateTime) return wall.toUtc();
  return DateTime(
    wall.year,
    wall.month,
    wall.day,
    wall.hour,
    wall.minute,
    wall.second,
  );
}

String? _icalTimeZone(IcalTemporalValue value) => switch (value.kind) {
  IcalTemporalKind.utcDateTime => 'UTC',
  IcalTemporalKind.tzidDateTime => value.timeZoneId,
  IcalTemporalKind.date || IcalTemporalKind.floatingDateTime => null,
};

String _icalComponentIdentity(IcalComponentKey key) =>
    '${key.componentType.toUpperCase()}\u0000${key.uid}\u0000'
    '${key.recurrenceIdKey ?? ''}';

bool _hasDavRecurrence(Object? recurrence) {
  if (recurrence is List) return recurrence.isNotEmpty;
  if (recurrence is Map && recurrence['rules'] is List) {
    return (recurrence['rules']! as List).isNotEmpty;
  }
  return false;
}

String _pendingCreateRawIcs(PendingOp operation) {
  try {
    final decoded = jsonDecode(operation.requestJson);
    if (decoded is Map && decoded['rawIcs'] is String) {
      return decoded['rawIcs']! as String;
    }
  } on FormatException {
    // Invalid pending payloads use the same local-state error.
  }
  throw StateError('The pending DAV event body is invalid.');
}

String? _json(Object? value) => value == null ? null : jsonEncode(value);

CalendarEventDetail _eventEditBaseline(
  EventEditorDraft draft,
  CalendarEvent existing,
) {
  final original = draft.originalDetail;
  if (original != null && original.id == existing.id) {
    return original;
  }
  return CalendarEventDetail.fromRow(existing);
}

String? _eventDetailBaselineRawJson(CalendarEventDetail detail) {
  final baseline = detail.baselineRaw ?? detail.raw;
  return baseline == null ? null : jsonEncode(baseline);
}

DateTime? _eventDetailStartDateTime(CalendarEventDetail detail) {
  return providerDateTimeAsCivilTime(
    detail.allDay ? detail.startDate : detail.startDateTime,
    detail.startTimeZone,
  );
}

DateTime? _eventDetailEndDateTime(CalendarEventDetail detail) {
  return providerDateTimeAsCivilTime(
    detail.allDay ? detail.endDate : detail.endDateTime,
    detail.endTimeZone,
  );
}

CalendarEventsCompanion _eventPatchProjection({
  required EventEditorDraft draft,
  required CalendarEvent existing,
  required BusyProvider provider,
  required Map<String, Object?> request,
  required String? startTimeZone,
  required String? endTimeZone,
  required Object? conference,
  required int now,
}) {
  final rangeChanged = request.containsKey('allDay');
  final rawChanged = switch (provider) {
    BusyProvider.google =>
      request.containsKey('hideAttendees') ||
          request.containsKey('eventLabelId'),
    BusyProvider.microsoft =>
      request.containsKey('importance') ||
          request.containsKey('description') ||
          request.containsKey('responseRequested') ||
          request.containsKey('hideAttendees') ||
          request.containsKey('allowNewTimeProposals') ||
          request.containsKey('structuredLocation'),
    BusyProvider.appleICloud ||
    BusyProvider.nextcloud ||
    BusyProvider.webCal => false,
  };
  return CalendarEventsCompanion(
    title: request.containsKey('title')
        ? Value(draft.title.trim())
        : const Value.absent(),
    description: request.containsKey('description')
        ? Value(draft.description)
        : const Value.absent(),
    location: request.containsKey('location')
        ? Value(draft.location)
        : const Value.absent(),
    locationLatitude: request.containsKey('structuredLocation')
        ? Value(draft.locationChange.selection?.point.latitude)
        : const Value.absent(),
    locationLongitude: request.containsKey('structuredLocation')
        ? Value(draft.locationChange.selection?.point.longitude)
        : const Value.absent(),
    allDay: rangeChanged ? Value(draft.allDay) : const Value.absent(),
    startDate: rangeChanged
        ? Value(draft.allDay ? _date(draft.start) : null)
        : const Value.absent(),
    startDateTime: rangeChanged
        ? Value(
            draft.allDay
                ? null
                : _eventDateTimeWireValue(draft.start, startTimeZone),
          )
        : const Value.absent(),
    startTimeZone: rangeChanged ? Value(startTimeZone) : const Value.absent(),
    endDate: rangeChanged
        ? Value(draft.allDay ? _date(draft.end) : null)
        : const Value.absent(),
    endDateTime: rangeChanged
        ? Value(
            draft.allDay
                ? null
                : _eventDateTimeWireValue(draft.end, endTimeZone),
          )
        : const Value.absent(),
    endTimeZone: rangeChanged ? Value(endTimeZone) : const Value.absent(),
    recurrenceJson: request.containsKey(calendarEventRecurrenceField)
        ? Value(_json(draft.recurrence))
        : const Value.absent(),
    remindersJson: request.containsKey('remindersJson')
        ? Value(_json(draft.reminders))
        : const Value.absent(),
    attendeesJson: request.containsKey(calendarEventAttendeesField)
        ? Value(_json(_localAttendeesJson(draft, provider)))
        : const Value.absent(),
    categoriesJson: request.containsKey('categoriesJson')
        ? Value(_json(_categoriesJson(draft, provider)))
        : const Value.absent(),
    colorId: request.containsKey('colorId')
        ? Value(draft.colorId)
        : const Value.absent(),
    visibility:
        request.containsKey('visibility') || request.containsKey('sensitivity')
        ? Value(draft.visibilityOrSensitivity)
        : const Value.absent(),
    transparencyOrShowAs: request.containsKey('transparencyOrShowAs')
        ? Value(draft.showAs)
        : const Value.absent(),
    conferenceJson: request.containsKey('conferenceJson')
        ? Value(_json(conference))
        : const Value.absent(),
    rawJson: rawChanged
        ? Value(
            jsonEncode(
              _optimisticEventRawForPatch(
                draft,
                provider,
                request: request,
                existingJson: existing.rawJson,
              ),
            ),
          )
        : const Value.absent(),
    updatedAtLocal: Value(now),
    syncStatus: const Value('pending'),
  );
}

Map<String, Object?> _eventDeltaRequest(
  EventEditorDraft draft,
  CalendarEventDetail original,
  BusyProvider provider, {
  required String? startTimeZone,
  required String? endTimeZone,
  required Object? conference,
  required CalendarGuestUpdatePolicy guestUpdatePolicy,
}) {
  final full = _eventRequest(
    draft,
    provider,
    isCreate: false,
    startTimeZone: startTimeZone,
    endTimeZone: endTimeZone,
    conference: conference,
    guestUpdatePolicy: guestUpdatePolicy,
  );
  final result = <String, Object?>{
    calendarEventGuestUpdatePolicyKey: guestUpdatePolicy.name,
  };
  void copy(String key) {
    if (full.containsKey(key)) result[key] = full[key];
  }

  if (draft.title.trim() != original.title) copy('title');
  final originalBody = provider == BusyProvider.microsoft
      ? _jsonObjectMap(_jsonObjectMap(original.raw)['body'])
      : const <String, Object?>{};
  final descriptionChanged =
      (draft.description ?? '') != (original.description ?? '') ||
      (provider == BusyProvider.microsoft &&
          (draft.descriptionContentType?.toLowerCase() !=
                  originalBody['contentType']?.toString().toLowerCase() ||
              (draft.descriptionHtml != null &&
                  draft.descriptionHtml != originalBody['content'])));
  if (descriptionChanged) {
    result['description'] = draft.description ?? '';
    copy('descriptionContentType');
    copy('descriptionHtml');
  }
  if ((draft.location ?? '') != (original.location ?? '')) {
    result['location'] = draft.location ?? '';
  }
  if (provider == BusyProvider.microsoft &&
      (draft.locationChange.changed || result.containsKey('location'))) {
    result['structuredLocation'] = _graphLocation(draft);
  }
  final rangeChanged =
      draft.allDay != original.allDay ||
      !_sameCivilDateTime(draft.start, _eventDetailStartDateTime(original)) ||
      !_sameCivilDateTime(draft.end, _eventDetailEndDateTime(original)) ||
      draft.startTimeZone != original.startTimeZone ||
      draft.endTimeZone != original.endTimeZone;
  if (rangeChanged) {
    copy('allDay');
    copy('start');
    copy('end');
    copy('startTimeZone');
    copy('endTimeZone');
  }
  if (draft.recurrenceChanged) copy(calendarEventRecurrenceField);
  if (!_sameJsonValue(original.reminders, draft.reminders)) {
    copy('remindersJson');
  }
  if (draft.attendeesChanged) copy(calendarEventAttendeesField);
  if (draft.colorId != original.colorId) copy('colorId');
  if (provider == BusyProvider.google &&
      draft.eventLabelChanged &&
      (draft.eventLabelId ?? '') !=
          (_jsonObjectMap(original.raw)['eventLabelId']?.toString() ?? '')) {
    copy('eventLabelId');
  }
  if (provider == BusyProvider.google && draft.googleStatusChanged) {
    copy('googleStatusProperties');
    if (!googleStatusEventTypes.contains(original.eventType)) {
      throw StateError('The existing Google status event type is unavailable.');
    }
    result[calendarEventGoogleStatusTypeContextKey] = original.eventType;
  }
  if (draft.categoriesChanged) copy('categoriesJson');
  if (draft.visibilityOrSensitivity != original.visibility) {
    copy(provider == BusyProvider.google ? 'visibility' : 'sensitivity');
  }
  if (draft.showAs != original.transparencyOrShowAs) {
    copy('transparencyOrShowAs');
  }
  final raw = _jsonObjectMap(original.raw);
  if (draft.importance != raw['importance']?.toString()) copy('importance');
  if (conference != null) copy('conferenceJson');
  if (draft.responseRequested != raw['responseRequested']) {
    copy('responseRequested');
  }
  final existingHidden = provider == BusyProvider.google
      ? raw['guestsCanSeeOtherGuests'] is bool
            ? !(raw['guestsCanSeeOtherGuests'] as bool)
            : null
      : raw['hideAttendees'];
  if (draft.hideAttendees != existingHidden) copy('hideAttendees');
  if (draft.allowNewTimeProposals != raw['allowNewTimeProposals']) {
    copy('allowNewTimeProposals');
  }
  final clearFields = <String>{
    for (final value in full[calendarEventClearFieldsKey] as List? ?? const [])
      value.toString(),
  }..removeWhere((field) => !result.containsKey(field));
  if (clearFields.isNotEmpty) {
    result[calendarEventClearFieldsKey] = clearFields.toList();
  }
  return result;
}

bool _sameCivilDateTime(DateTime? left, DateTime? right) {
  if (left == null || right == null) return left == right;
  return left.year == right.year &&
      left.month == right.month &&
      left.day == right.day &&
      left.hour == right.hour &&
      left.minute == right.minute &&
      left.second == right.second &&
      left.millisecond == right.millisecond &&
      left.microsecond == right.microsecond;
}

Map<String, Object?> _eventRequest(
  EventEditorDraft draft,
  BusyProvider provider, {
  required bool isCreate,
  String? startTimeZone,
  String? endTimeZone,
  Object? conference,
  required CalendarGuestUpdatePolicy guestUpdatePolicy,
}) {
  final attendees = _attendeesJson(draft, provider);
  final clearFields = <String>[
    if (!isCreate && draft.recurrenceChanged && draft.recurrence == null)
      calendarEventRecurrenceField,
    if (!isCreate && draft.attendeesChanged && attendees == null)
      calendarEventAttendeesField,
  ];
  return {
    'title': draft.title.trim(),
    'description': draft.description,
    'descriptionContentType': draft.descriptionContentType,
    'descriptionHtml': draft.descriptionHtml,
    'location': draft.location,
    if (provider == BusyProvider.microsoft &&
        (isCreate || draft.locationChange.changed))
      'structuredLocation': _graphLocation(draft),
    'allDay': draft.allDay,
    'start': _eventDateTimeWireValue(draft.start, startTimeZone),
    'end': _eventDateTimeWireValue(draft.end, endTimeZone),
    'startTimeZone': startTimeZone,
    'endTimeZone': endTimeZone,
    if (isCreate || draft.recurrenceChanged)
      calendarEventRecurrenceField: draft.recurrence,
    'remindersJson': draft.reminders,
    if (isCreate || draft.attendeesChanged)
      calendarEventAttendeesField: attendees,
    'colorId': draft.colorId,
    if (provider == BusyProvider.google &&
        (isCreate ? draft.eventLabelId != null : draft.eventLabelChanged))
      'eventLabelId': draft.eventLabelId ?? '',
    if (provider == BusyProvider.google &&
        isCreate &&
        googleStatusEventTypes.contains(draft.eventType))
      'eventType': draft.eventType,
    if (provider == BusyProvider.google &&
        googleStatusEventTypes.contains(draft.eventType) &&
        (isCreate || draft.googleStatusChanged))
      'googleStatusProperties': draft.googleStatusProperties,
    if (isCreate || draft.categoriesChanged)
      'categoriesJson': _categoriesJson(draft, provider),
    'visibility': provider == BusyProvider.google
        ? draft.visibilityOrSensitivity
        : null,
    'sensitivity': provider == BusyProvider.microsoft
        ? draft.visibilityOrSensitivity
        : null,
    'transparencyOrShowAs': draft.showAs,
    'importance': draft.importance,
    if (conference != null) 'conferenceJson': conference,
    'responseRequested': draft.responseRequested,
    'hideAttendees': draft.hideAttendees,
    'allowNewTimeProposals': draft.allowNewTimeProposals,
    calendarEventGuestUpdatePolicyKey: guestUpdatePolicy.name,
    if (clearFields.isNotEmpty) calendarEventClearFieldsKey: clearFields,
  };
}

String? _eventDateTimeWireValue(DateTime? value, String? timeZone) {
  if (value == null) return null;
  if (isUtcTimeZone(timeZone)) {
    return DateTime.utc(
      value.year,
      value.month,
      value.day,
      value.hour,
      value.minute,
      value.second,
      value.millisecond,
      value.microsecond,
    ).toIso8601String();
  }
  if (timeZone == null || timeZone.isEmpty) return value.toIso8601String();
  return providerWallTimeIso8601String(value);
}

Map<String, Object?> _graphLocation(EventEditorDraft draft) {
  final selection = draft.locationChange.selection;
  return microsoftStructuredLocation(
    displayName: draft.location ?? '',
    details: selection,
  );
}

Object? _conferenceRequest(EventEditorDraft draft, BusyProvider provider) {
  if (!draft.createConference) return null;
  return switch (provider) {
    BusyProvider.google => {
      'createRequest': {
        'requestId': const Uuid().v4(),
        'conferenceSolutionKey': {'type': 'hangoutsMeet'},
      },
    },
    BusyProvider.microsoft => 'teamsForBusiness',
    BusyProvider.appleICloud ||
    BusyProvider.nextcloud ||
    BusyProvider.webCal => null,
  };
}

String? _effectiveStartTimeZone(
  EventEditorDraft draft,
  String? sourceTimeZone,
  String? localTimeZone,
) {
  if (draft.allDay) {
    return null;
  }
  return _effectiveTimedEventZone(
    explicitTimeZone: draft.startTimeZone,
    sourceTimeZone: sourceTimeZone,
    localTimeZone: localTimeZone,
  );
}

String? _effectiveEndTimeZone(
  EventEditorDraft draft,
  String? sourceTimeZone,
  String? startTimeZone,
  String? localTimeZone,
) {
  if (draft.allDay) {
    return null;
  }
  final explicit = _nonBlank(draft.endTimeZone);
  return explicit ??
      _nonBlank(startTimeZone) ??
      _nonBlank(localTimeZone) ??
      _nonBlank(sourceTimeZone) ??
      'UTC';
}

String _effectiveTimedEventZone({
  required String? explicitTimeZone,
  required String? sourceTimeZone,
  required String? localTimeZone,
}) {
  final explicit = _nonBlank(explicitTimeZone);
  return explicit ??
      _nonBlank(localTimeZone) ??
      _nonBlank(sourceTimeZone) ??
      'UTC';
}

String? _nonBlank(String? value) {
  final trimmed = value?.trim();
  return trimmed == null || trimmed.isEmpty ? null : trimmed;
}

Object? _attendeesJson(EventEditorDraft draft, BusyProvider provider) {
  if (draft.attendees.isEmpty) {
    return null;
  }
  return [
    for (final attendee in draft.attendees)
      provider == BusyProvider.microsoft
          ? attendee.toMicrosoftJson()
          : attendee.toGoogleJson(),
  ];
}

Object? _localAttendeesJson(EventEditorDraft draft, BusyProvider provider) {
  if (draft.attendees.isEmpty) return null;
  return [
    for (final attendee in draft.attendees)
      if (provider == BusyProvider.microsoft)
        {
          ...attendee.rawJson,
          ...attendee.toMicrosoftJson(),
          if (attendee.responseStatus case final response?
              when response.isNotEmpty)
            'status': {'response': response},
        }
      else
        {
          ...attendee.rawJson,
          ...attendee.toGoogleJson(),
          // The provider serializer omits false, but optimistic local state
          // must override an original optional:true when changing to required.
          'optional': attendee.optional,
          if (attendee.self) 'self': true,
          if (attendee.organizer) 'organizer': true,
        },
  ];
}

Map<String, Object?>? _optimisticOrganizer(
  EventEditorDraft draft,
  BusyProvider provider, {
  String? existingJson,
}) {
  final existing = _jsonMap(existingJson);
  if (provider != BusyProvider.google || draft.isOrganizer == null) {
    return existing.isEmpty ? null : existing;
  }
  return {...existing, 'self': draft.isOrganizer};
}

Map<String, Object?> _optimisticEventRaw(
  EventEditorDraft draft,
  BusyProvider provider, {
  String? existingJson,
  bool descriptionChanged = false,
}) {
  final raw = {..._jsonMap(existingJson)};
  if (provider == BusyProvider.microsoft && draft.locationChange.changed) {
    raw['location'] = _graphLocation(draft);
    raw['locations'] = [_graphLocation(draft)];
  }
  switch (provider) {
    case BusyProvider.google:
      if (googleStatusEventTypes.contains(draft.eventType)) {
        raw['eventType'] = draft.eventType;
        if (googleStatusPropertiesKey(draft.eventType) case final key?) {
          raw[key] = draft.googleStatusProperties;
        }
      }
      if (draft.eventLabelId case final label?) {
        raw['eventLabelId'] = label;
      }
      if (draft.hideAttendees case final hidden?) {
        raw['guestsCanSeeOtherGuests'] = !hidden;
      }
    case BusyProvider.microsoft:
      if (descriptionChanged) {
        final html = draft.descriptionHtml;
        raw['body'] =
            html != null ||
                draft.descriptionContentType?.toLowerCase() == 'html'
            ? {
                'contentType': 'html',
                'content': html ?? escapeHtml(draft.description ?? ''),
              }
            : {'contentType': 'text', 'content': draft.description ?? ''};
      }
      if (draft.importance case final importance?) {
        raw['importance'] = importance;
      }
      if (draft.responseRequested case final requested?) {
        raw['responseRequested'] = requested;
      }
      if (draft.hideAttendees case final hidden?) {
        raw['hideAttendees'] = hidden;
      }
      if (draft.allowNewTimeProposals case final allowed?) {
        raw['allowNewTimeProposals'] = allowed;
      }
      if (draft.isOrganizer case final organizer?) {
        raw['isOrganizer'] = organizer;
      }
    case BusyProvider.appleICloud:
    case BusyProvider.nextcloud:
    case BusyProvider.webCal:
      break;
  }
  return raw;
}

Map<String, Object?> _optimisticEventRawForPatch(
  EventEditorDraft draft,
  BusyProvider provider, {
  required Map<String, Object?> request,
  String? existingJson,
}) {
  final raw = {..._jsonMap(existingJson)};
  if (provider == BusyProvider.microsoft &&
      request.containsKey('structuredLocation')) {
    raw['location'] = request['structuredLocation'];
    raw['locations'] = [request['structuredLocation']];
  }
  switch (provider) {
    case BusyProvider.google:
      final statusKey = googleStatusPropertiesKey(draft.eventType);
      if (request.containsKey('googleStatusProperties') && statusKey != null) {
        raw[statusKey] = draft.googleStatusProperties;
      }
      if (request.containsKey('eventLabelId')) {
        if (draft.eventLabelId case final label? when label.isNotEmpty) {
          raw['eventLabelId'] = label;
        } else {
          raw.remove('eventLabelId');
        }
      }
      if (request.containsKey('hideAttendees')) {
        final hidden = draft.hideAttendees;
        if (hidden == null) {
          raw.remove('guestsCanSeeOtherGuests');
        } else {
          raw['guestsCanSeeOtherGuests'] = !hidden;
        }
      }
    case BusyProvider.microsoft:
      if (request.containsKey('description')) {
        final html = draft.descriptionHtml;
        raw['body'] =
            html != null ||
                draft.descriptionContentType?.toLowerCase() == 'html'
            ? {
                'contentType': 'html',
                'content': html ?? escapeHtml(draft.description ?? ''),
              }
            : {'contentType': 'text', 'content': draft.description ?? ''};
      }
      _setOrRemoveRawField(
        raw,
        request: request,
        key: 'importance',
        value: draft.importance,
      );
      _setOrRemoveRawField(
        raw,
        request: request,
        key: 'responseRequested',
        value: draft.responseRequested,
      );
      _setOrRemoveRawField(
        raw,
        request: request,
        key: 'hideAttendees',
        value: draft.hideAttendees,
      );
      _setOrRemoveRawField(
        raw,
        request: request,
        key: 'allowNewTimeProposals',
        value: draft.allowNewTimeProposals,
      );
    case BusyProvider.appleICloud:
    case BusyProvider.nextcloud:
    case BusyProvider.webCal:
      break;
  }
  return raw;
}

void _setOrRemoveRawField(
  Map<String, Object?> raw, {
  required Map<String, Object?> request,
  required String key,
  required Object? value,
}) {
  if (!request.containsKey(key)) return;
  if (value == null) {
    raw.remove(key);
  } else {
    raw[key] = value;
  }
}

List<Map<String, Object?>> _jsonMapList(String? value) {
  if (value == null || value.isEmpty) return const [];
  try {
    final decoded = jsonDecode(value);
    if (decoded is! List) return const [];
    return [
      for (final item in decoded)
        if (item is Map) Map<String, Object?>.from(item),
    ];
  } on FormatException {
    return const [];
  }
}

Map<String, Object?> _jsonMap(String? value) {
  if (value == null || value.isEmpty) return const {};
  try {
    final decoded = jsonDecode(value);
    return decoded is Map ? Map<String, Object?>.from(decoded) : const {};
  } on FormatException {
    return const {};
  }
}

Map<String, Object?> _jsonObjectMap(Object? value) {
  return value is Map ? Map<String, Object?>.from(value) : const {};
}

List<String> _conferenceSolutions(String? rawJson) {
  final raw = _jsonMap(rawJson);
  final allowed = raw['allowedOnlineMeetingProviders'];
  final conferenceProperties = raw['conferenceProperties'];
  final googleAllowed = conferenceProperties is Map
      ? conferenceProperties['allowedConferenceSolutionTypes']
      : null;
  final providers = <String>{
    if (allowed is List)
      for (final value in allowed)
        if (value != null && value.toString().trim().isNotEmpty)
          value.toString().trim(),
    if (googleAllowed is List)
      for (final value in googleAllowed)
        if (value != null && value.toString().trim().isNotEmpty)
          value.toString().trim(),
    if (raw['defaultOnlineMeetingProvider'] case final value?
        when value.toString().trim().isNotEmpty)
      value.toString().trim(),
  };
  return providers.toList(growable: false);
}

String? _googleSelfAttendeeEmail(List<Map<String, Object?>> attendees) {
  for (final attendee in attendees) {
    if (attendee['self'] != true) continue;
    final email = attendee['email']?.toString().trim();
    if (email != null && email.isNotEmpty) return email;
  }
  return null;
}

List<Map<String, Object?>> _withGoogleSelfResponse(
  List<Map<String, Object?>> attendees,
  CalendarInvitationResponse response,
) {
  final status = switch (response) {
    CalendarInvitationResponse.accept => 'accepted',
    CalendarInvitationResponse.tentative => 'tentative',
    CalendarInvitationResponse.decline => 'declined',
  };
  return [
    for (final attendee in attendees)
      attendee['self'] == true
          ? {...attendee, 'responseStatus': status}
          : attendee,
  ];
}

Map<String, Object?> _withMicrosoftResponse(
  Map<String, Object?> raw,
  CalendarInvitationResponse response,
) {
  final current = raw['responseStatus'];
  final responseStatus = current is Map
      ? Map<String, Object?>.from(current)
      : <String, Object?>{};
  responseStatus['response'] = switch (response) {
    CalendarInvitationResponse.accept => 'accepted',
    CalendarInvitationResponse.tentative => 'tentativelyAccepted',
    CalendarInvitationResponse.decline => 'declined',
  };
  return {...raw, 'responseStatus': responseStatus};
}

Object? _categoriesJson(EventEditorDraft draft, BusyProvider provider) {
  if (provider != BusyProvider.microsoft) {
    return null;
  }
  return draft.categories;
}

String? _storedEventStart(CalendarEvent event) =>
    event.allDay ? event.startDate : event.startDateTime;

String? _storedEventEnd(CalendarEvent event) =>
    event.allDay ? event.endDate : event.endDateTime;

bool _eventRequiresRecurringScope(CalendarEvent event) =>
    CalendarEventDetail.fromRow(event).requiresRecurringMutationScope;

DateTime? _storedEventStartDateTime(CalendarEvent event) =>
    providerDateTimeAsCivilTime(_storedEventStart(event), event.startTimeZone);

DateTime? _storedEventEndDateTime(CalendarEvent event) =>
    providerDateTimeAsCivilTime(_storedEventEnd(event), event.endTimeZone);

Map<String, Object?> _storedEventTimingBaseline(CalendarEvent event) => {
  'start': _storedEventStart(event),
  'end': _storedEventEnd(event),
  'startTimeZone': event.startTimeZone,
  'endTimeZone': event.endTimeZone,
};

bool _seriesRowInScope(
  CalendarEvent row,
  CalendarEvent target,
  RecurringEventMutationScope scope,
) {
  if (scope == RecurringEventMutationScope.entireSeries) return true;
  if (scope != RecurringEventMutationScope.thisAndFuture) {
    return row.id == target.id;
  }
  final targetStart = _seriesOriginalStart(target);
  final rowStart = _seriesOriginalStart(row);
  if (targetStart == null || rowStart == null) return row.id == target.id;
  return !rowStart.isBefore(targetStart);
}

bool _googleEventCanSplit(CalendarEvent event) {
  return googleEventCanSplit(
    eventType: event.eventType,
    conference: _decodeStoredJson(event.conferenceJson),
  );
}

DateTime? _seriesOriginalStart(CalendarEvent event) {
  return DateTime.tryParse(event.providerOriginalStartKey ?? '') ??
      _storedEventStartDateTime(event);
}

Object? _decodeStoredJson(String? value) {
  if (value == null || value.isEmpty) return null;
  try {
    return jsonDecode(value);
  } on FormatException {
    return null;
  }
}

bool _sameJsonValue(Object? left, Object? right) {
  return jsonEncode(_normalizedJson(left)) ==
      jsonEncode(_normalizedJson(right));
}

bool _eventRequestHasMutation(Map<String, Object?> request) {
  const metadata = {
    calendarEventGuestUpdatePolicyKey,
    calendarEventRecurringScopeKey,
    calendarEventTargetProviderIdKey,
    calendarEventOriginalStartKey,
    calendarEventOriginalEndKey,
    calendarEventTimingBaselineKey,
    calendarEventDestinationCalendarIdKey,
    calendarEventDestinationSourceIdKey,
    calendarEventGoogleStatusTypeContextKey,
  };
  return request.entries.any(
    (entry) =>
        !metadata.contains(entry.key) &&
        (entry.value != null || entry.key == calendarEventClearFieldsKey),
  );
}

Object _eventRemindersForProvider(Object? reminders, BusyProvider provider) {
  final minutes = <int>[];
  if (reminders is Map) {
    final map = reminders.cast<Object?, Object?>();
    final single = map['reminderMinutesBeforeStart'];
    if (single is int && single >= 0) minutes.add(single);
    final overrides = map['overrides'];
    if (overrides is List) {
      for (final override in overrides) {
        if (override is! Map) continue;
        final value = override['minutes'];
        if (value is int && value >= 0 && !minutes.contains(value)) {
          minutes.add(value);
        }
      }
    }
    final davMinutes = map['minutes'];
    if (davMinutes is List) {
      for (final value in davMinutes.whereType<int>()) {
        if (value >= 0 && !minutes.contains(value)) minutes.add(value);
      }
    }
  }
  if (provider == BusyProvider.microsoft) {
    return minutes.isEmpty
        ? const {'isReminderOn': false}
        : {'isReminderOn': true, 'reminderMinutesBeforeStart': minutes.first};
  }
  return {
    'useDefault': false,
    'overrides': [
      for (final value in minutes) {'method': 'popup', 'minutes': value},
    ],
  };
}

Object? _normalizedJson(Object? value) {
  if (value is Map) {
    final entries = value.entries.toList()
      ..sort(
        (left, right) => left.key.toString().compareTo(right.key.toString()),
      );
    return {
      for (final entry in entries)
        entry.key.toString(): _normalizedJson(entry.value),
    };
  }
  if (value is List) {
    return [for (final item in value) _normalizedJson(item)];
  }
  return value;
}

String? _date(DateTime? value) {
  if (value == null) {
    return null;
  }
  return '${value.year.toString().padLeft(4, '0')}-'
      '${value.month.toString().padLeft(2, '0')}-'
      '${value.day.toString().padLeft(2, '0')}';
}
