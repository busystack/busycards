import '../calendar_providers/calendar_colors.dart';
import '../calendar_providers/calendar_mutation.dart';
import '../calendar_providers/calendar_description.dart';
import '../calendar_providers/calendar_sync_dto.dart';
import '../core/time/provider_date_time.dart';
import '../features/maps/domain/geographic_point.dart';
import '../features/maps/domain/location_result.dart';
import 'package:busymax/src/providers/busy_provider.dart';

Map<String, Object?> microsoftStructuredLocation({
  required String displayName,
  LocationResult? details,
}) {
  final address = <String, String>{
    if (details != null)
      for (final key in [
        'street',
        'city',
        'state',
        'postalCode',
        'countryOrRegion',
      ])
        if (details.address[key]?.isNotEmpty == true)
          key: details.address[key]!,
  };
  return {
    'displayName': displayName,
    if (details != null) 'coordinates': details.point.toJson(),
    if (address.isNotEmpty) 'address': address,
  };
}

CalendarSourceDto microsoftCalendarSourceFromJson(Map<String, Object?> json) {
  final canEdit = json['canEdit'];
  return CalendarSourceDto(
    provider: BusyProvider.microsoft,
    providerCalendarId: json['id']?.toString() ?? '',
    summary: json['name']?.toString().trim().isNotEmpty == true
        ? json['name']!.toString()
        : 'Calendar',
    primaryCalendar: json['isDefaultCalendar'] == true,
    selected: true,
    hidden: false,
    readOnly: canEdit is bool ? !canEdit : false,
    backgroundColor: calendarSourceBackgroundColorHex(
      provider: BusyProvider.microsoft,
      backgroundColor: json['hexColor']?.toString(),
      colorId: json['color']?.toString(),
    ),
    colorId: json['color']?.toString(),
    accessRole: canEdit is bool && canEdit ? 'writer' : 'reader',
    isRemovable: json['isRemovable'] as bool?,
    isDeleted: json['@removed'] != null,
    rawJson: json,
  );
}

CalendarEventDto microsoftCalendarEventFromJson(
  String calendarId,
  Map<String, Object?> json,
) {
  final start = _mapValue(json['start']);
  final end = _mapValue(json['end']);
  final location = _mapValue(json['location']);
  final body = _mapValue(json['body']);
  final isAllDay = json['isAllDay'] == true;
  final status = json['isCancelled'] == true ? 'cancelled' : null;
  return CalendarEventDto(
    provider: BusyProvider.microsoft,
    providerCalendarId: calendarId,
    providerEventId: json['id']?.toString() ?? '',
    providerRecurringEventId: json['seriesMasterId']?.toString(),
    providerOriginalStartKey: json['originalStart']?.toString(),
    etagOrChangeKey: json['changeKey']?.toString(),
    status: status,
    title: json['subject']?.toString().trim().isNotEmpty == true
        ? json['subject']!.toString()
        : '(No title)',
    description: calendarDescriptionDocumentFromBody(
      content: body['content']?.toString(),
      contentType: body['contentType']?.toString(),
    ).text,
    location: location['displayName']?.toString(),
    locationPoint: GeographicPoint.fromJson(location['coordinates']),
    locationAddress: location['address'] is Map
        ? Map<String, Object?>.from(location['address'] as Map)
        : null,
    allDay: isAllDay,
    startDate: isAllDay ? _dateOnly(start['dateTime']) : null,
    startDateTime: start['dateTime']?.toString(),
    startTimeZone: start['timeZone']?.toString(),
    endDate: isAllDay ? _dateOnly(end['dateTime']) : null,
    endDateTime: end['dateTime']?.toString(),
    endTimeZone: end['timeZone']?.toString(),
    recurrenceJson: json['recurrence'],
    remindersJson: {
      'isReminderOn': json['isReminderOn'],
      'reminderMinutesBeforeStart': json['reminderMinutesBeforeStart'],
    },
    attendeesJson: json['attendees'],
    categoriesJson: json['categories'],
    organizerJson: json['organizer'],
    // Outlook category names are not color IDs. Their color is resolved from
    // the account's master-category collection, never from array position.
    colorId: null,
    colorHex: null,
    visibility: json['sensitivity']?.toString(),
    transparencyOrShowAs: json['showAs']?.toString(),
    eventType: json['type']?.toString(),
    webLink: json['webLink']?.toString(),
    conferenceJson: json['onlineMeeting'],
    // Graph's hasAttachments flag is not a listing. An empty collection is
    // authoritative only when Graph actually supplied one (or said false).
    attachmentsJson: json['attachments'] is List
        ? json['attachments']
        : json['hasAttachments'] == false
        ? const []
        : null,
    isCancelled: json['isCancelled'] == true,
    isDeleted: json['@removed'] != null,
    createdAtServer: json['createdDateTime']?.toString(),
    updatedAtServer: json['lastModifiedDateTime']?.toString(),
    rawJson: json,
  );
}

Map<String, Object?> microsoftCalendarMutationToJson(
  CalendarMutation mutation,
) {
  return _compact({'name': mutation.summary, 'color': mutation.colorId});
}

Map<String, Object?> microsoftEventMutationToJson(
  CalendarEventMutation mutation,
) {
  final startTimeZone = mutation.startTimeZone ?? 'UTC';
  final endTimeZone = mutation.endTimeZone ?? startTimeZone;
  final result = _compact({
    'subject': mutation.title,
    if (_bodyPatch(mutation) != null) 'body': _bodyPatch(mutation),
    if (mutation.structuredLocation != null || mutation.location != null)
      'location':
          mutation.structuredLocation ?? {'displayName': mutation.location},
    'isAllDay': mutation.allDay,
    if (_startDateTime(mutation) != null)
      'start': {
        'dateTime': _startDateTime(mutation),
        'timeZone': startTimeZone,
      },
    if (_endDateTime(mutation) != null)
      'end': {'dateTime': _endDateTime(mutation), 'timeZone': endTimeZone},
    'recurrence': mutation.recurrence,
    'attendees': mutation.clearAttendees
        ? const <Object?>[]
        : mutation.attendees,
    'categories': mutation.categories,
    'importance': mutation.importance,
    'showAs': mutation.transparencyOrShowAs,
    'sensitivity': mutation.sensitivity ?? mutation.visibility,
    'responseRequested': mutation.responseRequested,
    'hideAttendees': mutation.hideAttendees,
    'allowNewTimeProposals': mutation.allowNewTimeProposals,
    'transactionId': mutation.transactionId,
    if (mutation.reminders is Map) ..._reminderPatch(mutation.reminders!),
    if (_onlineMeetingProvider(mutation.conference) != null) ...{
      'isOnlineMeeting': true,
      'onlineMeetingProvider': _onlineMeetingProvider(mutation.conference),
    },
  });
  if (mutation.clearRecurrence) {
    result['recurrence'] = null;
  }
  return result;
}

Map<String, Object?>? _bodyPatch(CalendarEventMutation mutation) {
  final contentType = mutation.descriptionContentType?.toLowerCase();
  final html = mutation.descriptionHtml;
  if (contentType == 'html' || html != null) {
    return {
      'contentType': 'html',
      'content': html ?? escapeHtml(mutation.description ?? ''),
    };
  }
  if (mutation.description != null) {
    return {'contentType': 'text', 'content': mutation.description};
  }
  return null;
}

String? _onlineMeetingProvider(Object? conference) {
  if (conference is String && conference.trim().isNotEmpty) {
    return conference.trim();
  }
  return null;
}

Map<String, Object?> _reminderPatch(Object reminders) {
  if (reminders is! Map) {
    return const {};
  }
  final map = reminders.cast<String, Object?>();
  return _compact({
    'isReminderOn': map['isReminderOn'],
    'reminderMinutesBeforeStart': map['reminderMinutesBeforeStart'],
  });
}

String? _startDateTime(CalendarEventMutation mutation) {
  if (mutation.allDay == true && mutation.startDate != null) {
    return '${mutation.startDate}T00:00:00.0000000';
  }
  return _graphWallTime(mutation.startDateTime, mutation.startTimeZone);
}

String? _endDateTime(CalendarEventMutation mutation) {
  if (mutation.allDay == true && mutation.endDate != null) {
    return '${mutation.endDate}T00:00:00.0000000';
  }
  return _graphWallTime(
    mutation.endDateTime,
    mutation.endTimeZone ?? mutation.startTimeZone,
  );
}

String? _graphWallTime(String? value, String? zone) {
  if (value == null || !RegExp(r'[+-]\d{2}:?\d{2}$').hasMatch(value)) {
    return value;
  }
  final wall = providerDateTimeAsWallTime(value, zone);
  return wall == null ? value : providerWallTimeIso8601String(wall);
}

Map<String, Object?> _mapValue(Object? value) {
  if (value is Map<String, Object?>) {
    return value;
  }
  if (value is Map) {
    return value.cast<String, Object?>();
  }
  return const {};
}

String? _dateOnly(Object? value) {
  final text = value?.toString();
  if (text == null || text.length < 10) {
    return null;
  }
  return text.substring(0, 10);
}

Map<String, Object?> _compact(Map<String, Object?> input) {
  return {
    for (final entry in input.entries)
      if (entry.value != null) entry.key: entry.value,
  };
}
