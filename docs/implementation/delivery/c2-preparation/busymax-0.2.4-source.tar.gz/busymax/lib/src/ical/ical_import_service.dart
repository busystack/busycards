import 'package:drift/drift.dart';
import '../features/maps/domain/location_result.dart';

import '../dav/dav_errors.dart';
import '../dav/ical/ical_document.dart';
import '../dav/ical/ical_semantics.dart';
import '../dav/ical/ical_timezone.dart';
import '../dav/nextcloud/nextcloud_native_import.dart';
import '../dav/storage/dav_collection_capabilities.dart';
import '../db/app_database.dart';
import '../features/calendar/data/calendar_repository.dart';
import '../features/calendar/presentation/event_editor_draft.dart';
import '../features/recurrence/domain/event_recurrence_codec.dart';
import '../providers/busy_provider.dart';
import 'ical_ingestion.dart';

final class IcalImportSelection {
  const IcalImportSelection(this.destination, {this.newCopies = false});
  final CalendarSourceEntity destination;
  final bool newCopies;
  NativeImportDuplicates get duplicatePolicy => newCopies
      ? NativeImportDuplicates.newCopies
      : NativeImportDuplicates.skip;
}

final class IcalImportPreview {
  const IcalImportPreview({
    required this.ingestion,
    required this.eventCount,
    required this.invalidEventCount,
    required this.fieldsThatWillBeOmitted,
  });

  final IcalIngestionResult ingestion;
  final int eventCount;
  final int invalidEventCount;
  final Set<String> fieldsThatWillBeOmitted;
  NextcloudNativeImportPreview get nativePreview =>
      NextcloudNativeImportPreview.parse(ingestion.document);
}

final class IcalImportSkippedSet {
  const IcalImportSkippedSet({required this.uid, required this.reason});

  final String uid;
  final String reason;
}

final class IcalImportReport {
  const IcalImportReport({
    required this.queued,
    required this.duplicatesSkipped,
    required this.unsupportedRecurrenceSets,
    required this.invalidEvents,
    required this.fieldsIntentionallyOmitted,
    this.followUpPending = false,
  });

  final int queued;
  final int duplicatesSkipped;
  final List<IcalImportSkippedSet> unsupportedRecurrenceSets;
  final int invalidEvents;
  final Set<String> fieldsIntentionallyOmitted;
  final bool followUpPending;
}

final class IcalImportService {
  IcalImportService({
    required AppDatabase database,
    required CalendarRepository calendarRepository,
    Future<void> Function(String accountId)? onNativeImported,
  }) : _database = database,
       _calendarRepository = calendarRepository,
       _onNativeImported = onNativeImported;

  final AppDatabase _database;
  final CalendarRepository _calendarRepository;
  final Future<void> Function(String)? _onNativeImported;

  IcalImportPreview parsePreview(List<int> bytes) {
    final ingestion = IcalIngestion.parseBytes(
      bytes,
      policy: IcalIngestionPolicy.fileImport,
    );
    final omitted = <String>{};
    if (ingestion.document.root.firstProperty('METHOD') != null) {
      omitted.add('scheduling method');
    }
    for (final set in ingestion.recurrenceSets) {
      for (final event in set.semantic.components) {
        if (event.attendees.isNotEmpty) omitted.add('attendees');
        if (event.organizers.isNotEmpty) omitted.add('organizer');
        if (event.url != null) omitted.add('URL');
        if (event.documentComponent.propertiesNamed('ATTACH').isNotEmpty) {
          omitted.add('attachments');
        }
        if (event.documentComponent.propertiesNamed('IMAGE').isNotEmpty) {
          omitted.add('images');
        }
        if (event.documentComponent.propertiesNamed('SOURCE').isNotEmpty) {
          omitted.add('source links');
        }
        if (event.documentComponent.propertiesNamed('CONFERENCE').isNotEmpty) {
          omitted.add('conference links');
        }
        if (event.alarms.any((alarm) => _alarmMinutes([alarm]).isEmpty)) {
          omitted.add('unsupported alarms');
        }
      }
    }
    for (final componentType in ingestion.unprojectedComponentTypes) {
      omitted.add('$componentType components');
    }
    return IcalImportPreview(
      ingestion: ingestion,
      eventCount: ingestion.recurrenceSets.length,
      invalidEventCount: ingestion.rejectedEvents.length,
      fieldsThatWillBeOmitted: Set.unmodifiable(omitted),
    );
  }

  Future<List<CalendarSourceEntity>> writableDestinations() async {
    final rows =
        await (_database.select(_database.calendarSources)..where(
              (row) =>
                  (row.readOnly.equals(false) |
                      row.provider.equals('nextcloud')) &
                  row.isDeleted.equals(false) &
                  row.provider.equals(BusyProvider.webCal.storageValue).not(),
            ))
            .get();
    final pendingIds = <String>{
      for (final op
          in await (_database.select(_database.pendingOps)..where(
                (row) =>
                    row.operationType.equals('calendar.create') &
                    row.state.isIn(const ['pending', 'retry', 'in_progress']),
              ))
              .get())
        if (op.calendarSourceId != null) op.calendarSourceId!,
    };
    final collections =
        await (_database.select(_database.davCollections)..where(
              (r) => r.deleted.equals(false) & r.serverMissing.equals(false),
            ))
            .get();
    final native = {for (final c in collections) c.id: c};
    final sources = [
      for (final row in rows)
        CalendarSourceEntity.fromRow(
          row,
          davCollection: native[row.davCollectionId],
          pendingCreate: pendingIds.contains(row.id),
        ),
    ];
    final accounts = await (_database.select(
      _database.accounts,
    )..where((r) => r.provider.equals('nextcloud'))).get();
    return [
      ...sources.where(
        (s) =>
            s.capabilities.canCreateEvents ||
            (s.davCollectionId != null &&
                native[s.davCollectionId] != null &&
                collectionCapabilitiesFromStored(
                  native[s.davCollectionId]!,
                ).canCreateTask),
      ),
      for (final collection in collections)
        if (accounts.any((a) => a.id == collection.accountId) &&
            !sources.any((s) => s.davCollectionId == collection.id) &&
            collectionCapabilitiesFromStored(collection).canCreateTask)
          CalendarSourceEntity(
            id: 'dav-import-${collection.id}',
            accountId: collection.accountId,
            provider: BusyProvider.nextcloud,
            providerCalendarId: collection.hrefKey,
            summary: collection.displayName,
            selected: true,
            hidden: false,
            readOnly: collection.readOnly,
            isDeleted: false,
            davCollectionId: collection.id,
            davEffectivePermissions: davSourcePermissionProjection(collection),
          ),
    ];
  }

  Future<IcalImportReport> importPreview({
    required IcalImportPreview preview,
    required CalendarSourceEntity destination,
    NativeImportDuplicates nativeDuplicates = NativeImportDuplicates.skip,
    bool normalizeNativeSchedulingMethod = false,
  }) async {
    if (destination.provider == BusyProvider.nextcloud &&
        destination.davCollectionId != null) {
      final results = await NextcloudNativeImportService(_database).import(
        accountId: destination.accountId,
        collectionId: destination.davCollectionId!,
        preview: preview.nativePreview,
        duplicates: nativeDuplicates,
        normalizeSchedulingMethod: normalizeNativeSchedulingMethod,
      );
      var followUpPending = false;
      if (results.any((r) => r.status == NativeImportItemStatus.queued)) {
        try {
          await _onNativeImported?.call(destination.accountId);
        } on Object {
          followUpPending = true;
        }
      }
      return IcalImportReport(
        queued: results
            .where((r) => r.status == NativeImportItemStatus.queued)
            .length,
        followUpPending: followUpPending,
        duplicatesSkipped: results
            .where((r) => r.status == NativeImportItemStatus.duplicate)
            .length,
        unsupportedRecurrenceSets: [
          for (final result in results)
            if (result.status == NativeImportItemStatus.unsupported ||
                result.status == NativeImportItemStatus.failed)
              IcalImportSkippedSet(
                uid: result.uid,
                reason: result.code ?? 'IcalImportFailed',
              ),
        ],
        invalidEvents: 0,
        fieldsIntentionallyOmitted: {
          if (preview.nativePreview.schedulingMethod != null)
            'scheduling method',
        },
      );
    }
    if (!destination.capabilities.canCreateEvents ||
        destination.provider == BusyProvider.webCal) {
      throw ArgumentError('The selected calendar is not writable.');
    }
    final receipts = await (_database.select(
      _database.icalImportReceipts,
    )..where((row) => row.calendarSourceId.equals(destination.id))).get();
    final importedUids = {for (final receipt in receipts) receipt.icalUid};
    final drafts =
        <
          ({
            String icalUid,
            EventEditorDraft draft,
            List<ImportedEventException> exceptions,
          })
        >[];
    final unsupported = <IcalImportSkippedSet>[];
    var duplicates = 0;
    final omitted = {...preview.fieldsThatWillBeOmitted};
    for (final set in preview.ingestion.recurrenceSets) {
      if (importedUids.contains(set.uid)) {
        duplicates += 1;
        continue;
      }
      final prepared = _prepareDraft(set, destination);
      if (prepared.reason != null) {
        unsupported.add(
          IcalImportSkippedSet(uid: set.uid, reason: prepared.reason!),
        );
        continue;
      }
      omitted.addAll(prepared.omittedFields);
      drafts.add((
        icalUid: set.uid,
        draft: prepared.draft!,
        exceptions: prepared.exceptions,
      ));
    }
    await _calendarRepository.createImportedEventsBatch(
      destination: destination,
      events: drafts,
    );
    return IcalImportReport(
      queued: drafts.length,
      duplicatesSkipped: duplicates,
      unsupportedRecurrenceSets: List.unmodifiable(unsupported),
      invalidEvents: preview.invalidEventCount,
      fieldsIntentionallyOmitted: Set.unmodifiable(omitted),
    );
  }
}

_PreparedImportDraft _prepareDraft(
  IcalRecurrenceSet set,
  CalendarSourceEntity destination,
) {
  final semantic = set.semantic;
  final masters = semantic.components
      .where((component) => component.recurrenceId == null)
      .toList();
  if (masters.length != 1) {
    return const _PreparedImportDraft.unsupported(
      'The recurrence set does not contain exactly one master event.',
    );
  }
  final master = masters.single;
  final title = master.summary?.trim();
  if (title == null || title.isEmpty) {
    return const _PreparedImportDraft.unsupported(
      'BusyMax requires an event summary.',
    );
  }
  final startValue = master.start;
  if (startValue == null) {
    return const _PreparedImportDraft.unsupported(
      'The event does not contain DTSTART.',
    );
  }
  if (startValue.kind == IcalTemporalKind.floatingDateTime) {
    return const _PreparedImportDraft.unsupported(
      'Floating date-times cannot be imported without guessing a timezone.',
    );
  }
  final resolver = IcalTimeZoneResolver.fromDocument(semantic);
  final providerTimeZones = IcalTimeZoneResolver.system();
  DateTime? resolvedStartInstant;
  DateTime? resolvedEndInstant;
  try {
    if (startValue.kind != IcalTemporalKind.date) {
      resolvedStartInstant = resolver.toUtc(startValue);
    }
    if (startValue.kind == IcalTemporalKind.tzidDateTime) {
      providerTimeZones.toUtc(startValue);
    }
    final semanticEnd = master.end;
    if (semanticEnd != null && semanticEnd.kind != IcalTemporalKind.date) {
      resolvedEndInstant = resolver.toUtc(semanticEnd);
    }
    if (master.end?.kind == IcalTemporalKind.tzidDateTime) {
      providerTimeZones.toUtc(master.end!);
    }
  } on DavException catch (error) {
    if (error.code == 'IcalUnknownTimeZone') {
      return const _PreparedImportDraft.unsupported(
        'The destination cannot represent this embedded custom timezone.',
      );
    }
    return _PreparedImportDraft.unsupported(error.safeMessage);
  }

  final allDay = startValue.kind == IcalTemporalKind.date;
  final start = _draftDateTime(startValue);
  final endValue = master.end;
  final DateTime end;
  String? endTimeZone;
  if (endValue != null) {
    if (endValue.kind == IcalTemporalKind.floatingDateTime) {
      return const _PreparedImportDraft.unsupported(
        'Floating date-times cannot be imported without guessing a timezone.',
      );
    }
    if ((endValue.kind == IcalTemporalKind.date) != allDay) {
      return const _PreparedImportDraft.unsupported(
        'The event start and end use incompatible value types.',
      );
    }
    end = _draftDateTime(endValue);
    endTimeZone = _timeZone(endValue);
  } else if (master.duration != null) {
    end = _addWallDuration(startValue, master.duration!.duration);
    endTimeZone = _timeZone(startValue);
  } else if (allDay) {
    end = DateTime(start.year, start.month, start.day + 1);
  } else {
    return const _PreparedImportDraft.unsupported(
      'Zero-duration date-time events cannot be represented by BusyMax.',
    );
  }
  final positiveRange = allDay
      ? end.isAfter(start)
      : endValue != null
      ? resolvedStartInstant != null &&
            resolvedEndInstant != null &&
            resolvedEndInstant.isAfter(resolvedStartInstant)
      : master.duration != null && master.duration!.duration > Duration.zero;
  if (!positiveRange) {
    return const _PreparedImportDraft.unsupported(
      'The event has a non-positive duration.',
    );
  }

  final recurrenceMap = <String, Object?>{
    'rules': master.recurrenceRules,
    'dates': master.recurrenceDates,
    'excludedDates': master.exceptionDates,
  };
  Object? recurrence;
  if (master.recurrenceRules.isNotEmpty ||
      master.recurrenceDates.isNotEmpty ||
      master.exceptionDates.isNotEmpty) {
    if (destination.provider == BusyProvider.microsoft &&
        (master.recurrenceDates.isNotEmpty ||
            master.exceptionDates.isNotEmpty)) {
      return const _PreparedImportDraft.unsupported(
        'Microsoft cannot represent this event’s RDATE or EXDATE set.',
      );
    }
    final rule = EventRecurrenceCodec.decode(
      BusyProvider.google,
      recurrenceMap,
      baseDate: start,
    );
    if (!rule.repeats ||
        !EventRecurrenceCodec.canEncode(destination.provider, rule)) {
      return _PreparedImportDraft.unsupported(
        '${destination.provider.displayName} cannot represent this recurrence rule.',
      );
    }
    recurrence = EventRecurrenceCodec.encode(
      destination.provider,
      rule,
      baseDate: start,
      allDay: allDay,
      timeZone: _timeZone(startValue),
      original: recurrenceMap,
    );
  }

  final reminderMinutes = _alarmMinutes(master.alarms);
  final reminders = switch (destination.provider) {
    BusyProvider.microsoft when reminderMinutes.isNotEmpty => {
      'isReminderOn': true,
      'reminderMinutesBeforeStart': reminderMinutes.first,
    },
    BusyProvider.google ||
    BusyProvider.appleICloud ||
    BusyProvider.nextcloud when reminderMinutes.isNotEmpty => {
      'useDefault': false,
      'overrides': [
        for (final minutes in reminderMinutes)
          {'method': 'popup', 'minutes': minutes},
      ],
    },
    _ => null,
  };
  final omitted = <String>{};
  if (destination.provider == BusyProvider.microsoft &&
      reminderMinutes.length > 1) {
    omitted.add('additional reminders');
  }
  if (destination.provider == BusyProvider.google &&
      master.categories.isNotEmpty) {
    omitted.add('categories');
  }
  final categories = destination.provider == BusyProvider.google
      ? const <String>[]
      : master.categories;
  if (!_supportedClassification(master.classification)) {
    return _PreparedImportDraft.unsupported(
      'This iCalendar classification is not supported by ${destination.provider.displayName}.',
    );
  }
  final visibilityOrSensitivity = _classification(
    master.classification,
    destination.provider,
  );
  if (destination.provider == BusyProvider.google) {
    for (final component in set.semantic.components) {
      if (component.recurrenceId == null ||
          component.status == 'CANCELLED' ||
          component.classification == null) {
        continue;
      }
      if (_classification(component.classification, destination.provider) !=
          visibilityOrSensitivity) {
        return const _PreparedImportDraft.unsupported(
          'Google cannot represent a detached occurrence with different visibility from its series.',
        );
      }
    }
  }
  final preparedExceptions = _prepareExceptions(
    set,
    master: master,
    resolver: resolver,
    destination: destination,
  );
  if (preparedExceptions.reason case final reason?) {
    return _PreparedImportDraft.unsupported(reason);
  }
  if (destination.provider == BusyProvider.google &&
      set.semantic.components.any(
        (component) =>
            component.recurrenceId != null && component.categories.isNotEmpty,
      )) {
    omitted.add('categories');
  }
  return _PreparedImportDraft(
    draft:
        EventEditorDraft.newEvent(
          accountId: destination.accountId,
          sourceId: destination.id,
          providerCalendarId: destination.providerCalendarId,
          start: start,
          end: end,
        ).copyWith(
          title: title,
          allDay: allDay,
          startTimeZone: _timeZone(startValue),
          endTimeZone: endTimeZone,
          description: master.description,
          location: master.location,
          locationChange: master.locationPoint == null
              ? const LocationChange.unchanged()
              : LocationChange.replace(
                  LocationResult(
                    label: master.location ?? '',
                    point: master.locationPoint!,
                    source: 'ical',
                    attribution: 'Imported iCalendar GEO',
                  ),
                ),
          recurrence: recurrence,
          recurrenceChanged: recurrence != null,
          reminders: reminders,
          remindersChanged: reminders != null,
          attendees: const [],
          attendeesChanged: false,
          showAs: _transparency(master.transparency, destination.provider),
          visibilityOrSensitivity: visibilityOrSensitivity,
          categories: categories,
          categoriesChanged: categories.isNotEmpty,
          createConference: false,
          clearConference: true,
          isOrganizer: true,
        ),
    reason: null,
    omittedFields: omitted,
    exceptions: preparedExceptions.values,
  );
}

({List<ImportedEventException> values, String? reason}) _prepareExceptions(
  IcalRecurrenceSet set, {
  required IcalSemanticComponent master,
  required IcalTimeZoneResolver resolver,
  required CalendarSourceEntity destination,
}) {
  final exceptions = <ImportedEventException>[];
  if (set.semantic.components.any(
        (component) => component.recurrenceId != null,
      ) &&
      destination.provider != BusyProvider.google &&
      destination.provider != BusyProvider.microsoft) {
    return (
      values: const [],
      reason: 'This destination cannot safely import detached occurrences.',
    );
  }
  for (final component in set.semantic.components) {
    final recurrenceId = component.recurrenceId;
    if (recurrenceId == null) continue;
    if (component.recurrenceRange != null ||
        component.recurrenceRules.isNotEmpty ||
        component.recurrenceDates.isNotEmpty) {
      return (
        values: const [],
        reason: 'This detached recurrence rule cannot be represented.',
      );
    }
    if (recurrenceId.kind == IcalTemporalKind.floatingDateTime ||
        (recurrenceId.kind == IcalTemporalKind.date) !=
            (master.start?.kind == IcalTemporalKind.date)) {
      return (
        values: const [],
        reason: 'The exception original start has an incompatible time type.',
      );
    }
    final String originalStart;
    try {
      if (recurrenceId.kind == IcalTemporalKind.date) {
        originalStart = _dateOnly(_draftDateTime(recurrenceId));
      } else {
        IcalTimeZoneResolver.system().toUtc(recurrenceId);
        originalStart = resolver.toUtc(recurrenceId).toIso8601String();
      }
    } on DavException {
      return (
        values: const [],
        reason: 'The exception timezone cannot be represented.',
      );
    }
    final cancelled = component.status == 'CANCELLED';
    final fields = <String, Object?>{};
    if (!cancelled) {
      if (!_supportedClassification(component.classification)) {
        return (
          values: const [],
          reason:
              'This iCalendar classification is not supported by ${destination.provider.displayName}.',
        );
      }
      if (component.classification != null) {
        fields['sensitivity'] = _classification(
          component.classification,
          destination.provider,
        );
      }
      if (component.transparency != null) {
        fields['transparencyOrShowAs'] = _transparency(
          component.transparency,
          destination.provider,
        );
      }
      if (destination.provider == BusyProvider.microsoft &&
          component.documentComponent.firstProperty('CATEGORIES') != null) {
        fields['categoriesJson'] = component.categories;
      }
      if (component.summary case final title?) fields['title'] = title;
      if (component.description case final description?) {
        fields['description'] = description;
      }
      if (component.location case final location?) {
        fields['location'] = location;
      }
      final start = component.start;
      final end = component.end;
      if ((start == null) != (end == null)) {
        return (
          values: const [],
          reason: 'A moved exception needs both start and end.',
        );
      }
      if (start != null && end != null) {
        if (start.kind == IcalTemporalKind.floatingDateTime ||
            end.kind == IcalTemporalKind.floatingDateTime ||
            (start.kind == IcalTemporalKind.date) !=
                (end.kind == IcalTemporalKind.date)) {
          return (
            values: const [],
            reason: 'The moved exception uses incompatible time values.',
          );
        }
        try {
          if (start.kind != IcalTemporalKind.date) {
            IcalTimeZoneResolver.system().toUtc(start);
            IcalTimeZoneResolver.system().toUtc(end);
            if (!resolver.toUtc(end).isAfter(resolver.toUtc(start))) {
              return (
                values: const [],
                reason: 'The moved exception has a non-positive interval.',
              );
            }
          } else if (!_draftDateTime(end).isAfter(_draftDateTime(start))) {
            return (
              values: const [],
              reason:
                  'The moved all-day exception has a non-positive interval.',
            );
          }
        } on DavException {
          return (
            values: const [],
            reason: 'The moved exception timezone cannot be represented.',
          );
        }
        fields['allDay'] = start.kind == IcalTemporalKind.date;
        fields['start'] = _wireTemporal(start);
        fields['end'] = _wireTemporal(end);
        fields['startTimeZone'] = _timeZone(start);
        fields['endTimeZone'] = _timeZone(end);
      }
      final minutes = _alarmMinutes(component.alarms);
      // An exception is its own VEVENT. No VALARM means reminders are off,
      // even when the newly created provider occurrence inherits master alarms.
      fields['remindersJson'] = destination.provider == BusyProvider.microsoft
          ? {
              'isReminderOn': minutes.isNotEmpty,
              if (minutes.isNotEmpty)
                'reminderMinutesBeforeStart': minutes.first,
            }
          : {
              'useDefault': false,
              'overrides': [
                for (final value in minutes)
                  {'method': 'popup', 'minutes': value},
              ],
            };
    }
    exceptions.add(
      ImportedEventException(
        originalStart: originalStart,
        cancelled: cancelled,
        fields: fields,
      ),
    );
  }
  return (values: List.unmodifiable(exceptions), reason: null);
}

bool _supportedClassification(String? value) =>
    value == null ||
    const {
      'PUBLIC',
      'PRIVATE',
      'CONFIDENTIAL',
    }.contains(value.trim().toUpperCase());

String? _classification(String? value, BusyProvider provider) {
  final normalized = value?.trim().toUpperCase();
  if (provider == BusyProvider.microsoft) {
    return switch (normalized) {
      'PUBLIC' => 'normal',
      'PRIVATE' => 'private',
      'CONFIDENTIAL' => 'confidential',
      _ => null,
    };
  }
  return normalized?.toLowerCase();
}

String _dateOnly(DateTime value) =>
    '${value.year.toString().padLeft(4, '0')}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';

String _wireTemporal(IcalTemporalValue value) {
  final instant = _draftDateTime(value);
  return value.kind == IcalTemporalKind.date
      ? _dateOnly(instant)
      : instant.toIso8601String();
}

DateTime _draftDateTime(IcalTemporalValue value) {
  final wall = value.localValue;
  if (value.kind == IcalTemporalKind.utcDateTime) return wall.toUtc();
  return DateTime(
    wall.year,
    wall.month,
    wall.day,
    wall.hour,
    wall.minute,
    wall.second,
  );
}

DateTime _addWallDuration(IcalTemporalValue value, Duration duration) {
  final wall = value.localValue.add(duration);
  if (value.kind == IcalTemporalKind.utcDateTime) return wall.toUtc();
  return DateTime(
    wall.year,
    wall.month,
    wall.day,
    wall.hour,
    wall.minute,
    wall.second,
  );
}

String? _timeZone(IcalTemporalValue value) => switch (value.kind) {
  IcalTemporalKind.utcDateTime => 'UTC',
  IcalTemporalKind.tzidDateTime => value.timeZoneId,
  IcalTemporalKind.date || IcalTemporalKind.floatingDateTime => null,
};

String? _transparency(String? value, BusyProvider provider) {
  final normalized = value?.toUpperCase();
  if (provider == BusyProvider.microsoft) {
    return normalized == 'TRANSPARENT' ? 'free' : 'busy';
  }
  return switch (normalized) {
    'TRANSPARENT' => 'transparent',
    'OPAQUE' => 'opaque',
    _ => null,
  };
}

List<int> _alarmMinutes(List<IcalComponent> alarms) {
  final values = <int>[];
  for (final alarm in alarms) {
    final action = alarm.firstProperty('ACTION')?.rawValue.toUpperCase();
    final trigger = alarm.firstProperty('TRIGGER');
    if ((action != 'DISPLAY' && action != 'AUDIO') || trigger == null) continue;
    if (trigger.parameterValue('RELATED')?.toUpperCase() == 'END') continue;
    try {
      final duration = parseIcalDuration(trigger.rawValue.toUpperCase());
      if (duration == null || duration.duration > Duration.zero) continue;
      final before = -duration.duration;
      if (before.inSeconds % 60 != 0) continue;
      if (!values.contains(before.inMinutes)) values.add(before.inMinutes);
    } on DavException {
      // Unsupported alarms are intentionally omitted and reported by preview.
    }
  }
  return values;
}

final class _PreparedImportDraft {
  const _PreparedImportDraft({
    required this.draft,
    required this.reason,
    this.omittedFields = const {},
    this.exceptions = const [],
  });

  const _PreparedImportDraft.unsupported(String reason)
    : draft = null,
      reason = reason,
      omittedFields = const {},
      exceptions = const [];

  final EventEditorDraft? draft;
  final String? reason;
  final Set<String> omittedFields;
  final List<ImportedEventException> exceptions;
}
