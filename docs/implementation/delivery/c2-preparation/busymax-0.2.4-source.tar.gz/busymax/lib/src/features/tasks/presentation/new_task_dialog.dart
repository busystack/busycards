import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/app_bootstrap.dart';
import '../../../app/busymax_dialogs.dart';
import '../../../google_tasks/api/google_tasks_json.dart';
import '../../../l10n/l10n.dart';
import 'package:busymax/src/providers/busy_provider.dart';
import 'package:busymax/src/features/tasks/domain/task_capabilities.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../task_lists/data/task_lists_repository.dart';
import '../data/tasks_repository.dart';
import 'task_details_draft.dart';
import 'task_details_editor.dart';

class NewTaskDraft {
  const NewTaskDraft({
    required this.accountId,
    required this.taskListId,
    required this.input,
  });

  final String accountId;
  final String taskListId;
  final TaskCreateInput input;

  String get title => input.title;
  DateTime? get dueUtc => input.dueUtc;
  List<String> get categories => input.categories;
}

typedef TaskCategorySuggestionsStreamForAccount =
    Stream<List<String>> Function(String accountId);

Future<NewTaskDraft?> showBusyMaxNewTaskDialog(
  BuildContext context, {
  required WidgetRef ref,
  required List<AccountEntity> accounts,
  required String? initialAccountId,
  required String? initialListId,
  DateTime? initialDueUtc,
}) {
  return showBusyMaxModalEditorDialog<NewTaskDraft>(
    context,
    maxWidth: 640,
    maxHeight: 760,
    builder: (dialogContext) => UncontrolledProviderScope(
      container: ProviderScope.containerOf(context),
      child: NewTaskEditorPanel(
        accounts: accounts,
        initialAccountId: initialAccountId,
        initialListId: initialListId,
        initialDueUtc: initialDueUtc,
        onSubmitted: (draft) => Navigator.of(dialogContext).pop(draft),
        onCancel: () => Navigator.of(dialogContext).pop(),
      ),
    ),
  );
}

class NewTaskEditorPanel extends ConsumerStatefulWidget {
  const NewTaskEditorPanel({
    super.key,
    required this.accounts,
    required this.onSubmitted,
    required this.onCancel,
    this.initialAccountId,
    this.initialListId,
    this.initialDueUtc,
    this.categorySuggestionsForAccount,
    this.useNativeDatePicker = false,
  }) : assert(accounts.length > 0, 'A task editor requires an account.');

  final List<AccountEntity> accounts;
  final String? initialAccountId;
  final String? initialListId;
  final DateTime? initialDueUtc;
  final FutureOr<void> Function(NewTaskDraft draft) onSubmitted;
  final VoidCallback onCancel;
  final TaskCategorySuggestionsStreamForAccount? categorySuggestionsForAccount;
  final bool useNativeDatePicker;

  @override
  ConsumerState<NewTaskEditorPanel> createState() => _NewTaskEditorPanelState();
}

class _NewTaskEditorPanelState extends ConsumerState<NewTaskEditorPanel> {
  String? _accountId;
  String? _taskListId;
  TaskDetailsDraft? _draftSnapshot;

  @override
  void initState() {
    super.initState();
    _accountId =
        widget.accounts.any((account) => account.id == widget.initialAccountId)
        ? widget.initialAccountId
        : widget.accounts.first.id;
    _taskListId = widget.initialListId;
  }

  @override
  Widget build(BuildContext context) {
    final accountId = _accountId ?? widget.accounts.first.id;
    final account = _requireAccount(accountId);
    final provider = account.provider;
    final localTimeZone = ref.watch(localTimeZoneProvider);
    final repository = ref.watch(
      taskListsRepositoryForAccountProvider(accountId),
    );
    final categorySuggestionsStream =
        widget.categorySuggestionsForAccount?.call(accountId) ??
        ref
            .watch(tasksRepositoryForAccountProvider(accountId))
            .watchCategorySuggestions();

    return StreamBuilder<List<String>>(
      stream: categorySuggestionsStream,
      builder: (context, categorySnapshot) {
        final categorySuggestions = categorySnapshot.data ?? const <String>[];
        return StreamBuilder<List<TaskListEntity>>(
          stream: repository.watchTaskLists(),
          builder: (context, snapshot) {
            final taskLists = snapshot.data ?? const <TaskListEntity>[];
            final effectiveListId = _effectiveListId(taskLists);
            final capabilities = _capabilitiesFor(
              provider,
              accountId,
              effectiveListId,
            );
            final editorTask = _newTaskEntity(
              accountId: accountId,
              taskListId: effectiveListId ?? '',
              initialDueUtc: widget.initialDueUtc,
            );
            final initialDraft = _initialDraftFor(
              editorTask,
              effectiveListId,
              localTimeZone,
            );

            return TaskDetailsEditor(
              key: ValueKey('new-task-editor-$accountId-$effectiveListId'),
              task: editorTask,
              provider: provider,
              taskLists: taskLists,
              capabilities: capabilities,
              localTimeZone: localTimeZone,
              initialDraft: initialDraft,
              editorTitle: context.l10n.newTask,
              saveLabel: context.l10n.create,
              accountLabel: _accountEditorLabel(context, account, provider),
              accountIds: [for (final account in widget.accounts) account.id],
              selectedAccountId: accountId,
              accountLabelFor: _accountLabel,
              onAccountSelected: _selectAccount,
              allowTaskListSelection: true,
              showAdvancedActions: false,
              showDeleteAction: false,
              isCreate: true,
              confirmTaskSwitch: false,
              useNativeDatePicker: widget.useNativeDatePicker,
              categorySuggestions: categorySuggestions,
              canSaveDraft: (draft) => draft.taskListId.isNotEmpty,
              onDraftChanged: (draft) {
                if (_draftSnapshot?.taskListId != draft.taskListId) {
                  setState(() => _draftSnapshot = draft);
                } else {
                  _draftSnapshot = draft;
                }
              },
              onRefresh: () {},
              onSave: (draft, _) =>
                  _submit(draft, capabilities, localTimeZone: localTimeZone),
              onCreateSubtask: (_) async {},
              onMoveToTop: () {},
              onDelete: () async {},
              onCancel: widget.onCancel,
            );
          },
        );
      },
    );
  }

  String? _effectiveListId(List<TaskListEntity> taskLists) {
    final snapshotListId = _draftSnapshot?.taskListId;
    if (taskLists.any((list) => list.id == snapshotListId)) {
      return snapshotListId;
    }
    if (taskLists.any((list) => list.id == _taskListId)) {
      return _taskListId;
    }
    if (taskLists.isEmpty) {
      return null;
    }
    return taskLists.first.id;
  }

  TaskCollectionCapabilities _capabilitiesFor(
    BusyProvider provider,
    String accountId,
    String? taskListId,
  ) {
    if (provider == BusyProvider.google || provider == BusyProvider.microsoft) {
      return adapterDefaultTaskCapabilities(provider);
    }
    if (taskListId == null) return noTaskCollectionCapabilities;
    return ref
            .watch(
              davTaskCollectionCapabilitiesProvider((
                accountId: accountId,
                taskListId: taskListId,
              )),
            )
            .valueOrNull ??
        noTaskCollectionCapabilities;
  }

  TaskDetailsDraft? _initialDraftFor(
    TaskEntity editorTask,
    String? effectiveListId,
    String localTimeZone,
  ) {
    final snapshot = _draftSnapshot;
    if (snapshot != null) {
      return snapshot.copyWith(taskListId: effectiveListId ?? '');
    }
    return TaskDetailsDraft.fromTask(
      editorTask,
      localTimeZone,
    ).copyWith(taskListId: effectiveListId ?? '');
  }

  TaskEntity _newTaskEntity({
    required String accountId,
    required String taskListId,
    required DateTime? initialDueUtc,
  }) {
    return TaskEntity(
      accountId: accountId,
      taskListId: taskListId,
      id: 'new-task',
      title: '',
      notes: '',
      status: 'needsAction',
      dueUtc: initialDueUtc == null
          ? null
          : encodeGoogleDateOnly(initialDueUtc),
      localDirty: false,
      pendingDelete: false,
      pendingMove: false,
      rawJson: '{}',
      updatedLocalAtUtc: '',
    );
  }

  AccountEntity? _accountForId(String accountId) {
    for (final account in widget.accounts) {
      if (account.id == accountId) {
        return account;
      }
    }
    return null;
  }

  AccountEntity _requireAccount(String accountId) {
    final account = _accountForId(accountId);
    if (account == null) {
      throw StateError('The selected task account is unavailable.');
    }
    return account;
  }

  String _accountLabel(String accountId) {
    return _accountForId(accountId)?.selectorLabel ?? accountId;
  }

  String _accountEditorLabel(
    BuildContext context,
    AccountEntity? account,
    BusyProvider provider,
  ) {
    final label = account?.displayLabel.trim();
    if (label != null && label.isNotEmpty) {
      return label;
    }
    return provider.displayName;
  }

  void _selectAccount(String value) {
    if (value == _accountId) {
      return;
    }
    final provider = _requireAccount(value).provider;
    final capabilities = adapterDefaultTaskCapabilities(provider);
    setState(() {
      _accountId = value;
      _taskListId = null;
      if (!capabilities.supportsCategories && _draftSnapshot != null) {
        _draftSnapshot = _draftSnapshot!.copyWith(categories: const []);
      }
    });
  }

  Future<void> _submit(
    TaskDetailsDraft draft,
    TaskCollectionCapabilities capabilities, {
    required String localTimeZone,
  }) async {
    final accountId = _accountId;
    if (accountId == null ||
        draft.taskListId.isEmpty ||
        draft.title.trim().isEmpty) {
      return;
    }
    await widget.onSubmitted(
      NewTaskDraft(
        accountId: accountId,
        taskListId: draft.taskListId,
        input: draft.toCreateInput(capabilities, localTimeZone: localTimeZone),
      ),
    );
  }
}
