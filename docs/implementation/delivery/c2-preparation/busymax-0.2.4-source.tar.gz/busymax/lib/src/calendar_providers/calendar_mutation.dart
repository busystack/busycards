class CalendarMutation {
  const CalendarMutation({
    this.summary,
    this.description,
    this.timeZone,
    this.backgroundColor,
    this.foregroundColor,
    this.colorId,
    this.hidden,
  });

  final String? summary;
  final String? description;
  final String? timeZone;
  final String? backgroundColor;
  final String? foregroundColor;
  final String? colorId;
  final bool? hidden;
}

const calendarMutationScopeKey = '_calendarMutationScope';
const calendarMutationScopeGlobal = 'global';
const calendarMutationScopePersonal = 'personal';
const calendarRemovalPreviousHiddenKey = '_previousHidden';
const calendarPatchPreviousValuesKey = '_previousValues';

const calendarEventClearFieldsKey = '_clearFields';
const calendarEventRecurrenceField = 'recurrenceJson';
const calendarEventAttendeesField = 'attendeesJson';
const calendarEventGuestUpdatePolicyKey = '_guestUpdatePolicy';
const calendarEventRecurringScopeKey = '_recurringScope';
const calendarEventTargetProviderIdKey = '_targetProviderEventId';
const calendarEventOriginalStartKey = '_originalStart';
const calendarEventOriginalEndKey = '_originalEnd';
// Occurrence identity stays in _originalStart; each edit has its own interval.
const calendarEventTimingBaselineKey = '_timingBaseline';
const calendarEventDestinationCalendarIdKey = '_destinationCalendarId';
const calendarEventDestinationSourceIdKey = '_destinationSourceId';
const calendarEventCopyConfirmationRequiredKey = '_copyConfirmationRequired';
const calendarEventCopyConfirmedKey = '_copyConfirmed';
const calendarEventCopyDestinationEventIdKey = '_copyDestinationEventId';
const calendarEventSemanticBaselineKey = '__busymaxSemanticBaseline';
const calendarEventImportIcalUidKey = '_importIcalUid';
// Discriminator for a status-property PATCH, never an event-type mutation.
const calendarEventGoogleStatusTypeContextKey = '_googleStatusTypeContext';

enum CalendarGuestUpdatePolicy { send, doNotSend }

enum CalendarInvitationResponse { accept, tentative, decline }

class CalendarEventMutation {
  const CalendarEventMutation({
    this.title,
    this.description,
    this.descriptionContentType,
    this.descriptionHtml,
    this.location,
    this.structuredLocation,
    this.allDay,
    this.startDate,
    this.startDateTime,
    this.startTimeZone,
    this.endDate,
    this.endDateTime,
    this.endTimeZone,
    this.recurrence,
    this.clearRecurrence = false,
    this.reminders,
    this.attendees,
    this.clearAttendees = false,
    this.colorId,
    this.eventLabelId,
    this.eventType,
    this.googleStatusEventTypeContext,
    this.googleStatusProperties,
    this.visibility,
    this.transparencyOrShowAs,
    this.conference,
    this.categories,
    this.importance,
    this.sensitivity,
    this.responseRequested,
    this.hideAttendees,
    this.allowNewTimeProposals,
    this.providerEventId,
    this.transactionId,
    this.providerRaw,
  });

  final String? title;
  final String? description;
  final String? descriptionContentType;
  final String? descriptionHtml;
  final String? location;

  /// Explicit Graph replacement. Null means leave structured location intact.
  final Map<String, Object?>? structuredLocation;
  final bool? allDay;
  final String? startDate;
  final String? startDateTime;
  final String? startTimeZone;
  final String? endDate;
  final String? endDateTime;
  final String? endTimeZone;
  final Object? recurrence;
  final bool clearRecurrence;
  final Object? reminders;
  final Object? attendees;
  final bool clearAttendees;
  final String? colorId;

  /// Null leaves the label untouched; empty explicitly clears it.
  final String? eventLabelId;
  final String? eventType;
  final String? googleStatusEventTypeContext;
  final Map<String, Object?>? googleStatusProperties;
  final String? visibility;
  final String? transparencyOrShowAs;
  final Object? conference;
  final List<String>? categories;
  final String? importance;
  final String? sensitivity;
  final bool? responseRequested;
  final bool? hideAttendees;
  final bool? allowNewTimeProposals;
  final String? providerEventId;
  final String? transactionId;
  final Map<String, Object?>? providerRaw;
}
