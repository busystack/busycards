part of '../app_database.dart';

@DriftAccessor(tables: [PendingOps])
class PendingOpsDao extends DatabaseAccessor<AppDatabase>
    with _$PendingOpsDaoMixin {
  PendingOpsDao(super.db);

  Future<void> enqueue(PendingOpsCompanion row) {
    return into(pendingOps).insertOnConflictUpdate(row);
  }

  Future<List<PendingOp>> pendingOpsForReplay(
    String accountId,
    DateTime nowUtc,
  ) {
    final query = select(pendingOps)
      ..where(
        (row) =>
            row.accountId.equals(accountId) &
            (row.nextAttemptAtUtc.isNull() |
                row.nextAttemptAtUtc.isSmallerOrEqualValue(
                  nowUtc.toIso8601String(),
                )),
      )
      ..orderBy([(row) => OrderingTerm.asc(row.createdAtUtc)]);
    return query.get();
  }

  Future<void> deleteOp(String id) {
    final query = delete(pendingOps)..where((row) => row.id.equals(id));
    return query.go();
  }

  /// Deletes [snapshot] only when the queued payload still matches the
  /// revision that a replayer actually sent.
  Future<bool> deleteOpIfUnchanged(PendingOp snapshot) async {
    final query = delete(pendingOps)
      ..where(
        (row) =>
            row.id.equals(snapshot.id) &
            row.requestJson.equals(snapshot.requestJson) &
            row.updatedAtUtc.equals(snapshot.updatedAtUtc) &
            row.attemptCount.equals(snapshot.attemptCount),
      );
    return await query.go() == 1;
  }

  Future<PendingOp?> getOp(String id) {
    final query = select(pendingOps)..where((row) => row.id.equals(id));
    return query.getSingleOrNull();
  }

  Stream<List<PendingOp>> watchBlockedOps(String accountId) {
    final query = select(pendingOps)
      ..where(
        (row) =>
            row.accountId.equals(accountId) &
            row.nextAttemptAtUtc.isBiggerOrEqualValue('9999-12-31'),
      )
      ..orderBy([(row) => OrderingTerm.asc(row.createdAtUtc)]);
    return query.watch();
  }

  /// Watches recovery-blocked operations across every account.
  ///
  /// Diagnostics is application-wide: restricting it to the currently
  /// selected account can hide the operation that is protecting a calendar or
  /// task list from removal.
  Stream<List<PendingOp>> watchAllBlockedOps() {
    final query = select(pendingOps)
      ..where((row) => row.nextAttemptAtUtc.isBiggerOrEqualValue('9999-12-31'))
      ..orderBy([(row) => OrderingTerm.asc(row.createdAtUtc)]);
    return query.watch();
  }

  Future<void> retryNow(String id, DateTime nowUtc) {
    final query = update(pendingOps)..where((row) => row.id.equals(id));
    return query.write(
      PendingOpsCompanion(
        nextAttemptAtUtc: Value(nowUtc.toIso8601String()),
        lastErrorCode: const Value(null),
        lastErrorMessage: const Value(null),
        updatedAtUtc: Value(nowUtc.toIso8601String()),
      ),
    );
  }

  /// Makes a failed DAV operation replayable and records that replay must
  /// reconcile first, independently of the legacy attempt counter.
  Future<bool> retryFailedDavOperationNow(
    PendingOp snapshot,
    DateTime nowUtc, {
    String? requestJson,
  }) async {
    final timestamp = nowUtc.toUtc().toIso8601String();
    final query = update(pendingOps)
      ..where(
        (row) =>
            row.id.equals(snapshot.id) &
            row.accountId.equals(snapshot.accountId) &
            row.state.equals('failed') &
            row.updatedAtUtc.equals(snapshot.updatedAtUtc),
      );
    final updated = await query.write(
      PendingOpsCompanion(
        state: const Value('retry'),
        retryClassification: const Value('manual_retry'),
        nextAttemptAtUtc: Value(timestamp),
        lastErrorCode: const Value(null),
        lastErrorMessage: const Value(null),
        lastError: const Value(null),
        requestJson: requestJson == null
            ? const Value.absent()
            : Value(requestJson),
        updatedAtUtc: Value(timestamp),
      ),
    );
    return updated == 1;
  }

  Future<void> updateAttempt({
    required String id,
    required int attemptCount,
    required DateTime nextAttemptAtUtc,
    String? lastErrorCode,
    String? lastErrorMessage,
    String? state,
  }) {
    final query = update(pendingOps)..where((row) => row.id.equals(id));
    return query.write(
      PendingOpsCompanion(
        attemptCount: Value(attemptCount),
        nextAttemptAtUtc: Value(nextAttemptAtUtc.toIso8601String()),
        lastErrorCode: Value(lastErrorCode),
        lastErrorMessage: Value(lastErrorMessage),
        state: state == null ? const Value.absent() : Value(state),
        updatedAtUtc: Value(DateTime.now().toUtc().toIso8601String()),
      ),
    );
  }

  /// Records a failed attempt only if the queued payload has not been edited
  /// since [snapshot] was read by the replayer.
  Future<bool> updateAttemptIfUnchanged({
    required PendingOp snapshot,
    required int attemptCount,
    required DateTime nextAttemptAtUtc,
    String? lastErrorCode,
    String? lastErrorMessage,
  }) async {
    final query = update(pendingOps)
      ..where(
        (row) =>
            row.id.equals(snapshot.id) &
            row.requestJson.equals(snapshot.requestJson) &
            row.updatedAtUtc.equals(snapshot.updatedAtUtc) &
            row.attemptCount.equals(snapshot.attemptCount),
      );
    final updated = await query.write(
      PendingOpsCompanion(
        attemptCount: Value(attemptCount),
        nextAttemptAtUtc: Value(nextAttemptAtUtc.toIso8601String()),
        lastErrorCode: Value(lastErrorCode),
        lastErrorMessage: Value(lastErrorMessage),
        updatedAtUtc: Value(DateTime.now().toUtc().toIso8601String()),
      ),
    );
    return updated == 1;
  }
}
