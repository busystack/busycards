import 'package:busymax/src/l10n/time_format_scope.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:yaru/yaru.dart';

import '../../../app/busymax_design.dart';
import '../../../calendar_providers/calendar_description.dart';
import '../../../l10n/l10n.dart';
import '../../../schedule/schedule_item.dart';
import '../../../providers/busy_provider.dart';
import '../../../schedule/schedule_projection.dart';
import '../../maps/application/external_location_launcher.dart';
import '../application/saved_schedule_location.dart';
import 'schedule_anchored_popover.dart';
import 'schedule_event_block.dart';
import 'schedule_event_details_format.dart';
import '../../calendar/presentation/google_status_event_labels.dart';

enum ScheduleItemDetailsAction {
  export,
  edit,
  delete,
  joinMeeting,
  attachments,
  acceptInvitation,
  tentativeInvitation,
  declineInvitation,
  openLocation,
}

Future<ScheduleItemDetailsAction?> showScheduleItemDetailsPopover({
  required BuildContext context,
  required BuildContext anchorContext,
  required ScheduleItem item,
  ExternalLocationDestination? locationDestination,
  Future<ExternalLocationDestination?>? locationDestinationFuture,
  Offset? anchorPoint,
}) {
  final supportsLocationOpening = scheduleItemSupportsLocationOpening(item);
  return showScheduleAnchoredPopover<ScheduleItemDetailsAction>(
    context: context,
    anchorContext: anchorContext,
    anchorPoint: anchorPoint,
    semanticLabel: item.title,
    builder: (context, arrowSide, arrowAlignment) {
      return _ScheduleItemDetailsPopoverCard(
        item: item,
        locationDestination: supportsLocationOpening
            ? locationDestination ??
                  projectedScheduleItemLocationDestination(item)
            : null,
        locationDestinationFuture: supportsLocationOpening
            ? locationDestinationFuture
            : null,
        arrowSide: arrowSide,
        arrowAlignment: arrowAlignment,
      );
    },
  );
}

class _ScheduleItemDetailsPopoverCard extends StatelessWidget {
  const _ScheduleItemDetailsPopoverCard({
    required this.item,
    required this.locationDestination,
    required this.locationDestinationFuture,
    required this.arrowSide,
    required this.arrowAlignment,
  });

  final ScheduleItem item;
  final ExternalLocationDestination? locationDestination;
  final Future<ExternalLocationDestination?>? locationDestinationFuture;
  final BusyMaxPopoverArrowSide arrowSide;
  final double arrowAlignment;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final itemColor = ScheduleProjection.colorForItem(
      item,
      colorScheme.brightness,
    );
    return Material(
      color: Colors.transparent,
      child: BusyMaxContentPopoverSurface(
        arrowSide: arrowSide,
        arrowAlignment: arrowAlignment,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(BusyMaxSpacing.lg),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: BusyMaxSizes.iconSm,
                    height: BusyMaxSizes.iconSm,
                    margin: const EdgeInsets.only(top: BusyMaxSpacing.xs),
                    decoration: BoxDecoration(
                      color: itemColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: BusyMaxSpacing.sm),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          item.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: BusyMaxSpacing.xxs),
                        Text(
                          _kindLabel(context, item),
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(color: colorScheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: BusyMaxSpacing.sm),
                  _PopoverActions(item: item),
                ],
              ),
              if (item case final CalendarScheduleItem event
                  when event.joinMeetingUrl != null) ...[
                const SizedBox(height: BusyMaxSpacing.md),
                SizedBox(
                  width: double.infinity,
                  child: BusyMaxPushButton.suggested(
                    onPressed: () => Navigator.of(
                      context,
                    ).pop(ScheduleItemDetailsAction.joinMeeting),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.video_call_outlined),
                        const SizedBox(width: BusyMaxSpacing.xs),
                        Text(context.l10n.joinMeeting),
                      ],
                    ),
                  ),
                ),
              ],
              if (item case final CalendarScheduleItem event
                  when event.provider == BusyProvider.microsoft &&
                      event.providerEventId != null) ...[
                const SizedBox(height: BusyMaxSpacing.xs),
                BusyMaxPushButton.standard(
                  onPressed: () => Navigator.of(
                    context,
                  ).pop(ScheduleItemDetailsAction.attachments),
                  child: Text(context.l10n.attachments),
                ),
              ],
              if (item case final CalendarScheduleItem event
                  when event.canRespondToInvitation) ...[
                const SizedBox(height: BusyMaxSpacing.md),
                _InvitationResponseActions(item: event),
              ],
              const SizedBox(height: BusyMaxSpacing.lg),
              _ScheduleItemDetails(
                item: item,
                locationDestination: locationDestination,
                locationDestinationFuture: locationDestinationFuture,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InvitationResponseActions extends StatelessWidget {
  const _InvitationResponseActions({required this.item});

  final CalendarScheduleItem item;

  @override
  Widget build(BuildContext context) {
    final selected = _selectedResponse(item.currentUserResponse);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          context.l10n.respond,
          style: Theme.of(context).textTheme.labelLarge,
        ),
        const SizedBox(height: BusyMaxSpacing.xs),
        Wrap(
          spacing: BusyMaxSpacing.xs,
          runSpacing: BusyMaxSpacing.xs,
          children: [
            _responseButton(
              context,
              selected: selected == ScheduleItemDetailsAction.acceptInvitation,
              action: ScheduleItemDetailsAction.acceptInvitation,
              label: context.l10n.acceptInvitation,
            ),
            _responseButton(
              context,
              selected:
                  selected == ScheduleItemDetailsAction.tentativeInvitation,
              action: ScheduleItemDetailsAction.tentativeInvitation,
              label: context.l10n.tentativeInvitation,
            ),
            _responseButton(
              context,
              selected: selected == ScheduleItemDetailsAction.declineInvitation,
              action: ScheduleItemDetailsAction.declineInvitation,
              label: context.l10n.declineInvitation,
            ),
          ],
        ),
      ],
    );
  }

  Widget _responseButton(
    BuildContext context, {
    required bool selected,
    required ScheduleItemDetailsAction action,
    required String label,
  }) {
    void onPressed() => Navigator.of(context).pop(action);
    return selected
        ? BusyMaxPushButton.suggested(onPressed: onPressed, child: Text(label))
        : BusyMaxPushButton.standard(onPressed: onPressed, child: Text(label));
  }
}

ScheduleItemDetailsAction? _selectedResponse(String? response) {
  return switch (response?.toLowerCase()) {
    'accepted' => ScheduleItemDetailsAction.acceptInvitation,
    'tentative' ||
    'tentativelyaccepted' => ScheduleItemDetailsAction.tentativeInvitation,
    'declined' => ScheduleItemDetailsAction.declineInvitation,
    _ => null,
  };
}

class _PopoverActions extends StatelessWidget {
  const _PopoverActions({required this.item});

  final ScheduleItem item;

  @override
  Widget build(BuildContext context) {
    final actions = <Widget>[
      BusyMaxPopoverIconButton(
        icon: YaruIcons.share,
        tooltip: context.l10n.export,
        onPressed: () =>
            Navigator.of(context).pop(ScheduleItemDetailsAction.export),
      ),
      if (item.capabilities.canEdit)
        BusyMaxPopoverIconButton(
          icon: Icons.edit_outlined,
          tooltip: _editLabel(context, item),
          onPressed: () =>
              Navigator.of(context).pop(ScheduleItemDetailsAction.edit),
        ),
      if (item.capabilities.canDelete)
        BusyMaxPopoverIconButton(
          icon: YaruIcons.trash,
          tooltip: switch (item) {
            CalendarScheduleItem(isNextcloudAttendee: true) =>
              context.l10n.nextcloudDeclineAndRemove,
            CalendarScheduleItem(isNextcloudMeeting: true, isOrganizer: true) =>
              context.l10n.nextcloudCancelMeeting,
            _ => context.l10n.delete,
          },
          destructive: true,
          onPressed: () =>
              Navigator.of(context).pop(ScheduleItemDetailsAction.delete),
        ),
      BusyMaxPopoverIconButton(
        icon: YaruIcons.window_close,
        tooltip: MaterialLocalizations.of(context).closeButtonTooltip,
        onPressed: () => Navigator.of(context).pop(),
      ),
    ];
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var index = 0; index < actions.length; index += 1) ...[
          if (index > 0) const SizedBox(width: BusyMaxSpacing.xs),
          actions[index],
        ],
      ],
    );
  }
}

class _ScheduleItemDetails extends StatelessWidget {
  const _ScheduleItemDetails({
    required this.item,
    required this.locationDestination,
    required this.locationDestinationFuture,
  });

  final ScheduleItem item;
  final ExternalLocationDestination? locationDestination;
  final Future<ExternalLocationDestination?>? locationDestinationFuture;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ExternalLocationDestination?>(
      future: locationDestinationFuture,
      initialData: locationDestination,
      builder: (context, snapshot) => _details(
        context,
        snapshot.connectionState == ConnectionState.done
            ? snapshot.data
            : locationDestination,
      ),
    );
  }

  Widget _details(
    BuildContext context,
    ExternalLocationDestination? destination,
  ) {
    final details = <Widget>[
      _ScheduleDetailRow(
        icon: Icons.schedule,
        text: item is CalendarScheduleItem
            ? scheduleEventIntervalLabel(context, item as CalendarScheduleItem)
            : _dateTimeLabel(context, item),
      ),
      _ScheduleDetailRow(
        icon: item is TaskScheduleItem
            ? YaruIcons.task_list
            : YaruIcons.calendar,
        text: ScheduleProjection.sourceLabelForScheduleItem(item),
      ),
      if (_accountLabel(item) case final account? when account.isNotEmpty)
        _ScheduleDetailRow(icon: Icons.person_outline, text: account),
      if (item is CalendarScheduleItem)
        ..._eventDetails(context, item as CalendarScheduleItem, destination),
      if (item is TaskScheduleItem)
        ..._taskDetails(context, item as TaskScheduleItem, destination),
    ];

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final detail in details) ...[
          detail,
          if (detail != details.last) const SizedBox(height: BusyMaxSpacing.sm),
        ],
      ],
    );
  }
}

class _ScheduleDetailRow extends StatelessWidget {
  const _ScheduleDetailRow({
    required this.icon,
    required this.text,
    this.maxLines = 3,
  });

  final IconData icon;
  final String text;
  final int? maxLines;

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) {
      return const SizedBox.shrink();
    }
    final colorScheme = Theme.of(context).colorScheme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: BusyMaxSizes.iconSm,
          color: colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: BusyMaxSpacing.sm),
        Expanded(
          child: Text(
            text,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ],
    );
  }
}

class _ScheduleDetailRichRow extends StatelessWidget {
  const _ScheduleDetailRichRow({
    required this.icon,
    required this.html,
    required this.fallbackText,
  });

  final IconData icon;
  final String html;
  final String fallbackText;

  @override
  Widget build(BuildContext context) {
    final document = htmlCalendarDescriptionDocument(html);
    final text = document.text.isEmpty ? fallbackText.trim() : document.text;
    if (text.isEmpty) {
      return const SizedBox.shrink();
    }
    final colorScheme = Theme.of(context).colorScheme;
    final baseStyle = Theme.of(
      context,
    ).textTheme.bodyMedium?.copyWith(color: colorScheme.onSurfaceVariant);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: BusyMaxSizes.iconSm,
          color: colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: BusyMaxSpacing.sm),
        Expanded(
          child: Text.rich(
            _descriptionTextSpan(text, document.ranges, baseStyle),
          ),
        ),
      ],
    );
  }
}

class _ScheduleLocationDetailRow extends StatelessWidget {
  const _ScheduleLocationDetailRow({
    required this.item,
    required this.destination,
  });

  final ScheduleItem item;
  final ExternalLocationDestination destination;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final text = savedScheduleLocationDisplayText(item, destination);
    final action = BusyMaxPushButton.standard(
      key: const ValueKey('saved-location-open'),
      onPressed: () =>
          Navigator.of(context).pop(ScheduleItemDetailsAction.openLocation),
      child: Text(
        destination.kind == ExternalLocationDestinationKind.link
            ? context.l10n.openLink
            : context.l10n.mapsShow,
      ),
    );
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          Icons.place_outlined,
          size: BusyMaxSizes.iconSm,
          color: colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: BusyMaxSpacing.sm),
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final locationText = SelectableText(
                text,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              );
              if (constraints.maxWidth < 320) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    locationText,
                    const SizedBox(height: BusyMaxSpacing.xs),
                    action,
                  ],
                );
              }
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: locationText),
                  const SizedBox(width: BusyMaxSpacing.sm),
                  action,
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

List<Widget> _eventDetails(
  BuildContext context,
  CalendarScheduleItem item,
  ExternalLocationDestination? locationDestination,
) {
  final description = item.description?.trim();
  final organizer = _organizerName(item.organizer);
  final attendeeResponses = [
    for (final attendee in item.attendees)
      if (attendee['organizer'] != true && attendee['self'] != true)
        _attendeeResponseLabel(context, attendee),
  ];
  return [
    for (final line in googleStatusDetailLines(
      context.l10n,
      item.eventType,
      item.googleStatusProperties,
    ))
      _ScheduleDetailRow(icon: Icons.event_note_outlined, text: line),
    if (locationDestination != null)
      _ScheduleLocationDetailRow(item: item, destination: locationDestination)
    else if (scheduleItemLocationText(item).trim().isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.place_outlined,
        text: scheduleItemLocationText(item),
      ),
    if (organizer != null)
      _ScheduleDetailRow(
        icon: Icons.person_outline,
        text: '${context.l10n.organizer}: $organizer',
      ),
    if (item.currentUserResponse case final response?)
      _ScheduleDetailRow(
        icon: Icons.how_to_reg_outlined,
        text:
            '${context.l10n.yourResponse}: '
            '${_responseStatusLabel(context, response)}',
      ),
    if (item.canSendReply)
      _ScheduleDetailRow(
        icon: Icons.info_outline,
        text: context.l10n.nextcloudAttendeeRestrictions,
        maxLines: null,
      ),
    for (final attendee in item.attendees)
      if (attendee['scheduleStatus'] != null)
        _ScheduleDetailRow(
          icon: Icons.mark_email_read_outlined,
          text:
              '${context.l10n.nextcloudSchedulingStatus}: ${attendee['email'] ?? ''} · ${attendee['scheduleStatus']}',
          maxLines: null,
        ),
    if (attendeeResponses.isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.groups_outlined,
        text:
            '${context.l10n.guestResponses}:\n'
            '${attendeeResponses.join('\n')}',
        maxLines: null,
      ),
    if (item.reminderMinutesBeforeStart.isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.notifications_outlined,
        text:
            '${context.l10n.reminder}: '
            '${item.reminderMinutesBeforeStart.map((minutes) => _reminderBeforeLabel(context, minutes)).join(', ')}',
      ),
    if (item.categories.isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.sell_outlined,
        text: '${context.l10n.categories}: ${item.categories.join(', ')}',
      ),
    if (item.descriptionHtml != null &&
        isHtmlContentType(item.descriptionContentType))
      _ScheduleDetailRichRow(
        icon: Icons.notes,
        html: item.descriptionHtml!,
        fallbackText: description ?? '',
      )
    else if (description != null && description.isNotEmpty)
      _ScheduleDetailRow(icon: Icons.notes, text: description, maxLines: null),
    for (final uri in calendarEventDescriptionLinks(item))
      _ScheduleWebLinkButton(label: uri.toString(), url: uri.toString()),
    if (item.eventLinkUrl case final link?)
      _ScheduleWebLinkButton(label: context.l10n.eventLink, url: link),
    if (item.attachmentsMayExist || item.attachmentLinks.isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.attach_file,
        text: context.l10n.attachments,
      ),
    for (final attachment in item.attachmentLinks)
      _ScheduleWebLinkButton(label: attachment.name, url: attachment.url),
    if (item.attachmentsMayExist && !item.attachmentsLoaded)
      _ScheduleDetailRow(
        icon: Icons.info_outline,
        text: context.l10n.attachmentsNotLoaded,
      ),
  ];
}

class _ScheduleWebLinkButton extends StatelessWidget {
  const _ScheduleWebLinkButton({required this.label, required this.url});

  final String label;
  final String url;

  @override
  Widget build(BuildContext context) => Align(
    alignment: AlignmentDirectional.centerStart,
    child: BusyMaxPushButton.standard(
      onPressed: () async {
        if (await openScheduleWebLink(url) || !context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(context.l10n.eventLinkOpenFailed)),
        );
      },
      child: Text(label, overflow: TextOverflow.ellipsis),
    ),
  );
}

String? _organizerName(Map<String, Object?>? organizer) {
  if (organizer == null) return null;
  final emailAddress = organizer['emailAddress'];
  final nested = emailAddress is Map ? emailAddress : const {};
  for (final value in [
    organizer['displayName'],
    nested['name'],
    organizer['email'],
    nested['address'],
  ]) {
    final text = value?.toString().trim();
    if (text != null && text.isNotEmpty) return text;
  }
  return null;
}

String _attendeeResponseLabel(
  BuildContext context,
  Map<String, Object?> attendee,
) {
  final emailAddress = attendee['emailAddress'];
  final nested = emailAddress is Map ? emailAddress : const {};
  final name =
      [
            attendee['displayName'],
            nested['name'],
            attendee['email'],
            nested['address'],
          ]
          .map((value) => value?.toString().trim())
          .whereType<String>()
          .firstWhere((value) => value.isNotEmpty, orElse: () => '—');
  final statusObject = attendee['status'];
  final status =
      attendee['responseStatus']?.toString() ??
      (statusObject is Map ? statusObject['response']?.toString() : null);
  final optional =
      attendee['optional'] == true ||
      attendee['type']?.toString().toLowerCase() == 'optional';
  return '$name — ${_responseStatusLabel(context, status)}'
      '${optional ? ' · ${context.l10n.attendeeOptional}' : ''}';
}

String _responseStatusLabel(BuildContext context, String? response) {
  return switch (response?.toLowerCase()) {
    'accepted' => context.l10n.responseAccepted,
    'tentative' || 'tentativelyaccepted' => context.l10n.responseTentative,
    'declined' => context.l10n.responseDeclined,
    'needsaction' => context.l10n.responseNeedsAction,
    'organizer' => context.l10n.responseOrganizer,
    'none' || 'notresponded' || null => context.l10n.responseNotResponded,
    final value => value,
  };
}

List<Widget> _taskDetails(
  BuildContext context,
  TaskScheduleItem item,
  ExternalLocationDestination? locationDestination,
) {
  final notes = item.notes?.trim();
  return [
    _ScheduleDetailRow(
      icon: item.completed ? YaruIcons.checkmark : Icons.radio_button_unchecked,
      text: item.completed ? context.l10n.completed : context.l10n.openStatus,
    ),
    if (item.reminder != null)
      _ScheduleDetailRow(
        icon: Icons.notifications_outlined,
        text:
            '${context.l10n.reminder}: '
            '${formatClockDateTime(context, item.reminder!, DateFormat.yMMMd(Localizations.localeOf(context).toLanguageTag()).format(item.reminder!))}',
      ),
    if (item.categories.isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.sell_outlined,
        text: '${context.l10n.categories}: ${item.categories.join(', ')}',
      ),
    if (locationDestination != null)
      _ScheduleLocationDetailRow(item: item, destination: locationDestination)
    else if (scheduleItemLocationText(item).trim().isNotEmpty)
      _ScheduleDetailRow(
        icon: Icons.place_outlined,
        text: scheduleItemLocationText(item),
      ),
    if (notes != null && notes.isNotEmpty)
      _ScheduleDetailRow(icon: Icons.notes, text: notes),
    for (final link in item.availableSourceLinks)
      _ScheduleWebLinkButton(
        label: link.label?.isNotEmpty == true
            ? link.label!
            : context.l10n.openInProvider,
        url: link.url,
      ),
  ];
}

String _reminderBeforeLabel(BuildContext context, int minutes) {
  return switch (minutes) {
    0 => context.l10n.reminderAtStart,
    < 60 => context.l10n.reminderMinutesBefore(minutes),
    < 1440 when minutes % 60 == 0 => context.l10n.reminderHoursBefore(
      minutes ~/ 60,
    ),
    >= 1440 when minutes % 1440 == 0 => context.l10n.reminderDaysBefore(
      minutes ~/ 1440,
    ),
    _ => context.l10n.reminderMinutesBefore(minutes),
  };
}

String _kindLabel(BuildContext context, ScheduleItem item) {
  return item is CalendarScheduleItem
      ? context.l10n.createEventAtTime
      : context.l10n.createTaskAtDate;
}

String _editLabel(BuildContext context, ScheduleItem item) {
  return item is CalendarScheduleItem
      ? context.l10n.editEvent
      : context.l10n.editTask;
}

TextSpan _descriptionTextSpan(
  String text,
  List<CalendarDescriptionStyleRange> ranges,
  TextStyle? baseStyle,
) {
  final children = <TextSpan>[];
  final boundaries = <int>{0, text.length};
  for (final range in ranges) {
    if (range.start >= 0 &&
        range.end <= text.length &&
        range.start < range.end) {
      boundaries
        ..add(range.start)
        ..add(range.end);
    }
  }
  final sorted = boundaries.toList()..sort();
  for (var index = 0; index < sorted.length - 1; index += 1) {
    final start = sorted[index];
    final end = sorted[index + 1];
    final styles = <CalendarDescriptionInlineStyle>{};
    for (final range in ranges) {
      if (range.start <= start && range.end >= end) {
        styles.addAll(range.styles);
      }
    }
    children.add(
      TextSpan(
        text: text.substring(start, end),
        style: baseStyle?.copyWith(
          fontWeight: styles.contains(CalendarDescriptionInlineStyle.bold)
              ? FontWeight.w700
              : null,
          fontStyle: styles.contains(CalendarDescriptionInlineStyle.italic)
              ? FontStyle.italic
              : null,
          decoration: styles.contains(CalendarDescriptionInlineStyle.underline)
              ? TextDecoration.underline
              : null,
        ),
      ),
    );
  }
  return TextSpan(style: baseStyle, children: children);
}

String _dateTimeLabel(BuildContext context, ScheduleItem item) {
  if (item.start == null) {
    return context.l10n.noDate;
  }
  final locale = Localizations.localeOf(context).toLanguageTag();
  final dateFormat = DateFormat.yMMMd(locale);
  final day = dateFormat.format(item.start!);
  if (item.allDay) {
    return '$day · ${context.l10n.allDay}';
  }
  return '$day · ${scheduleTimeRange(context, item)}';
}

String? _accountLabel(ScheduleItem item) {
  final name = item.accountDisplayName?.trim();
  final email = item.accountEmail?.trim();
  if (name != null && name.isNotEmpty && email != null && email.isNotEmpty) {
    if (name.toLowerCase() == email.toLowerCase()) {
      return email;
    }
    return '$name · $email';
  }
  if (name != null && name.isNotEmpty) {
    return name;
  }
  if (email != null && email.isNotEmpty) {
    return email;
  }
  return null;
}
