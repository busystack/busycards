import 'package:busymax/src/providers/busy_provider.dart';
import '../features/calendar/domain/event_timing_policy.dart';
import '../features/tasks/domain/task_checklist_item.dart';
import '../features/tasks/domain/task_source_links.dart';
import '../features/maps/domain/geographic_point.dart';
import 'event_attachment_link.dart';

enum ScheduleItemKind { calendarEvent, task, localReminder }

class ScheduleItemCapabilities {
  const ScheduleItemCapabilities({
    required this.canEdit,
    required this.canDelete,
  });

  static const editable = ScheduleItemCapabilities(
    canEdit: true,
    canDelete: true,
  );
  static const readOnly = ScheduleItemCapabilities(
    canEdit: false,
    canDelete: false,
  );

  final bool canEdit;
  final bool canDelete;
}

sealed class ScheduleItem {
  String get id;
  String get accountId;
  BusyProvider get provider;
  String get sourceId;
  String get title;
  String? get sourceName;
  String? get accountDisplayName;
  String? get accountEmail;
  DateTime? get start;
  DateTime? get end;
  bool get allDay;
  List<String> get categories;
  ScheduleItemKind get kind;
  ScheduleItemCapabilities get capabilities;
}

class CalendarScheduleItem implements ScheduleItem {
  const CalendarScheduleItem({
    required this.id,
    required this.accountId,
    required this.provider,
    required this.sourceId,
    required this.providerCalendarId,
    this.providerEventId,
    required this.title,
    required this.allDay,
    this.start,
    this.providerRecurringEventId,
    this.eventType,
    this.googleStatusProperties = const {},
    this.timingBaseline,
    this.end,
    this.location,
    this.locationPoint,
    this.description,
    this.descriptionContentType,
    this.descriptionHtml,
    this.attendees = const [],
    this.organizer,
    this.joinMeetingUrl,
    this.eventLinkUrl,
    this.attachmentLinks = const [],
    this.attachmentsLoaded = false,
    this.attachmentsMayExist = false,
    this.startTimeZone,
    this.endTimeZone,
    this.isOrganizer,
    this.guestsCanModify,
    this.locked = false,
    this.currentUserResponse,
    this.canSendReply = false,
    this.timingEditable = true,
    this.isFederated = false,
    this.colorHex,
    this.categories = const [],
    this.reminderMinutesBeforeStart = const [],
    this.sourceName,
    this.accountDisplayName,
    this.accountEmail,
    this.capabilities = ScheduleItemCapabilities.editable,
  });

  @override
  final String id;
  @override
  final String accountId;
  @override
  final BusyProvider provider;
  @override
  final String sourceId;
  final String providerCalendarId;
  final String? providerEventId;
  final String? providerRecurringEventId;
  final String? eventType;
  final Map<String, Object?> googleStatusProperties;
  final EventTimingBaseline? timingBaseline;

  bool get canReschedule =>
      timingEditable &&
      start != null &&
      end != null &&
      end!.isAfter(start!) &&
      canEditEventTiming(
        provider: provider,
        canEdit: capabilities.canEdit,
        isOrganizer: provider == BusyProvider.nextcloud && attendees.isEmpty
            ? null
            : isOrganizer,
        locked: locked,
        guestsCanModify: guestsCanModify,
        isFederated: isFederated,
      );
  @override
  final String title;
  @override
  final DateTime? start;
  @override
  final DateTime? end;
  @override
  final bool allDay;
  final String? location;
  final GeographicPoint? locationPoint;
  final String? description;
  final String? descriptionContentType;
  final String? descriptionHtml;
  final List<Map<String, Object?>> attendees;
  final Map<String, Object?>? organizer;
  final String? joinMeetingUrl;
  final String? eventLinkUrl;
  final List<EventAttachmentLink> attachmentLinks;
  final bool attachmentsLoaded;
  final bool attachmentsMayExist;
  final String? startTimeZone;
  final String? endTimeZone;
  final bool? isOrganizer;
  final bool? guestsCanModify;
  final bool locked;
  final String? currentUserResponse;
  final String? colorHex;
  @override
  final List<String> categories;
  final List<int> reminderMinutesBeforeStart;
  @override
  final String? sourceName;
  @override
  final String? accountDisplayName;
  @override
  final String? accountEmail;
  @override
  final ScheduleItemCapabilities capabilities;

  bool get canRespondToInvitation {
    return isOrganizer == false &&
        currentUserResponse != null &&
        (provider == BusyProvider.google ||
            provider == BusyProvider.microsoft ||
            (provider == BusyProvider.nextcloud && canSendReply));
  }

  final bool canSendReply;
  final bool timingEditable;
  final bool isFederated;

  bool get isNextcloudMeeting =>
      provider == BusyProvider.nextcloud &&
      !isFederated &&
      attendees.isNotEmpty;
  bool get isNextcloudAttendee => isNextcloudMeeting && isOrganizer == false;

  @override
  ScheduleItemKind get kind => ScheduleItemKind.calendarEvent;
}

class TaskScheduleItem implements ScheduleItem {
  const TaskScheduleItem({
    required this.id,
    required this.accountId,
    required this.provider,
    required this.sourceId,
    required this.title,
    required this.completed,
    required this.allDay,
    this.start,
    this.due,
    this.end,
    this.notes,
    this.isAssigned = false,
    this.originalTaskUrl,
    this.sourceLinks = const [],
    this.location,
    this.locationPoint,
    this.categories = const [],
    this.reminder,
    this.parentId,
    this.parentTitle,
    this.hierarchyDepth = 0,
    this.hasSubtasks = false,
    this.checklistItems = const [],
    this.sourceName,
    this.accountDisplayName,
    this.accountEmail,
    this.capabilities = ScheduleItemCapabilities.editable,
  });

  @override
  final String id;
  @override
  final String accountId;
  @override
  final BusyProvider provider;
  @override
  final String sourceId;
  @override
  final String title;
  @override
  final DateTime? start;
  @override
  final DateTime? end;
  @override
  final bool allDay;
  final bool completed;
  final bool isAssigned;
  final String? originalTaskUrl;
  final List<TaskSourceLink> sourceLinks;

  List<TaskSourceLink> get availableSourceLinks => sourceLinks.isNotEmpty
      ? sourceLinks
      : originalTaskUrl == null
      ? const []
      : [TaskSourceLink(url: originalTaskUrl!)];

  /// Actual provider due value, independent of the scheduling start.
  final DateTime? due;
  final String? notes;
  final String? location;
  final GeographicPoint? locationPoint;
  @override
  final List<String> categories;
  final DateTime? reminder;
  final String? parentId;
  final String? parentTitle;
  final int hierarchyDepth;
  final bool hasSubtasks;
  final List<TaskChecklistItemEntity> checklistItems;
  @override
  final String? sourceName;
  @override
  final String? accountDisplayName;
  @override
  final String? accountEmail;
  @override
  final ScheduleItemCapabilities capabilities;

  @override
  ScheduleItemKind get kind => ScheduleItemKind.task;
}
