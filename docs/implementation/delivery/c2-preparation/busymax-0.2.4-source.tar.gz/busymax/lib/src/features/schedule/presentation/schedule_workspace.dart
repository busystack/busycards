import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../../app/app_bootstrap.dart';
import '../../../app/busymax_about_dialog.dart';
import '../../../app/busymax_design.dart';
import '../../../app/busymax_header_actions.dart';
import '../../../app/common/busymax_motion_widgets.dart';
import '../../../app/busymax_dialogs.dart';
import '../../../app/busymax_keyboard_shortcuts_dialog.dart';
import '../../../app/busymax_layout.dart';
import '../../../app/busymax_shortcuts.dart';
import '../../../app/busymax_surface_colors.dart';
import '../../../app/busymax_window_close.dart';
import '../../../app/linux/linux_page_frame.dart';
import '../../../core/logging/redacting_logger.dart';
import '../../../calendar_providers/calendar_mutation.dart';
import '../../../features/accounts/data/accounts_repository.dart';
import '../../../features/calendar/data/calendar_repository.dart';
import '../../../features/connectivity/network_connectivity_service.dart';
import '../../../features/feedback/presentation/feedback_dialog.dart';
import '../../../features/sync/sync_auth_error.dart';
import '../../../l10n/l10n.dart';
import '../../../l10n/week_preferences_scope.dart';
import '../../../schedule/schedule_commands.dart';
import '../../../schedule/schedule_filters.dart';
import '../../../schedule/schedule_item.dart';
import '../../../schedule/schedule_event_rescheduling.dart';
import '../../../ui/common/schedule/schedule_interactions.dart';
import '../../calendar/domain/event_timing_policy.dart';
import '../../../schedule/schedule_projection.dart';
import '../../../schedule/schedule_range.dart';
import '../../../schedule/schedule_navigation_intent.dart';
import '../../../schedule/task_list_mutation_intent.dart';
import '../../../schedule/schedule_repository.dart';
import '../../../schedule/schedule_scope.dart';
import '../../../schedule/schedule_source_visibility.dart';
import '../../../schedule/schedule_view_mode.dart';
import 'package:busymax/src/providers/busy_provider.dart';
import '../../calendar/presentation/event_editor.dart';
import '../../calendar/presentation/event_editor_draft.dart';
import '../../calendar/presentation/event_guest_delivery_dialog.dart';
import '../../task_lists/data/task_lists_repository.dart';
import '../../tasks/data/tasks_repository.dart';
import '../../tasks/domain/task_checklist_item.dart';
import '../../tasks/presentation/new_task_dialog.dart';
import '../../tasks/presentation/task_details_pane.dart';
import '../../maps/application/external_location_launcher.dart';
import '../application/saved_schedule_location.dart';
import 'schedule_agenda_view.dart';
import 'schedule_anchored_popover.dart';
import 'schedule_create_menu.dart';
import 'schedule_day_week_view.dart';
import 'schedule_empty_states.dart';
import 'schedule_item_details_popover.dart';
import 'linux_event_attachments_dialog.dart';
import 'schedule_event_details_format.dart';
import 'schedule_item_exporter.dart';
import 'cloud_calendar_series_export.dart';
import 'schedule_item_selection.dart';
import 'schedule_month_view.dart';
import 'schedule_sidebar.dart';
import 'schedule_search_filters.dart';
import '../../../schedule/schedule_search_criteria.dart';
import 'schedule_toolbar.dart';
import 'schedule_year_view.dart';

enum _ScheduleShortcut {
  search,
  sidebar,
  dismissSearch,
  previous,
  next,
  newEvent,
  newTask,
  today,
  day,
  week,
  month,
  year,
  agenda,
}

bool _calendarItemHasExternalGuests(CalendarScheduleItem item) {
  return item.attendees.any(
    (attendee) => attendee['self'] != true && attendee['organizer'] != true,
  );
}

class _ScheduleShortcutIntent extends Intent {
  const _ScheduleShortcutIntent(this.command);

  final _ScheduleShortcut command;
}

const _scheduleShortcuts = <ShortcutActivator, Intent>{
  BusyMaxShortcutActivators.search: _ScheduleShortcutIntent(
    _ScheduleShortcut.search,
  ),
  BusyMaxShortcutActivators.sidebar: _ScheduleShortcutIntent(
    _ScheduleShortcut.sidebar,
  ),
  BusyMaxShortcutActivators.dismiss: _ScheduleShortcutIntent(
    _ScheduleShortcut.dismissSearch,
  ),
  SingleActivator(LogicalKeyboardKey.arrowLeft, shift: true):
      _ScheduleShortcutIntent(_ScheduleShortcut.previous),
  SingleActivator(LogicalKeyboardKey.arrowRight, shift: true):
      _ScheduleShortcutIntent(_ScheduleShortcut.next),
  SingleActivator(LogicalKeyboardKey.keyE): _ScheduleShortcutIntent(
    _ScheduleShortcut.newEvent,
  ),
  SingleActivator(LogicalKeyboardKey.keyT): _ScheduleShortcutIntent(
    _ScheduleShortcut.newTask,
  ),
  SingleActivator(LogicalKeyboardKey.keyT, shift: true):
      _ScheduleShortcutIntent(_ScheduleShortcut.today),
  SingleActivator(LogicalKeyboardKey.digit1): _ScheduleShortcutIntent(
    _ScheduleShortcut.day,
  ),
  SingleActivator(LogicalKeyboardKey.numpad1): _ScheduleShortcutIntent(
    _ScheduleShortcut.day,
  ),
  SingleActivator(LogicalKeyboardKey.digit2): _ScheduleShortcutIntent(
    _ScheduleShortcut.week,
  ),
  SingleActivator(LogicalKeyboardKey.numpad2): _ScheduleShortcutIntent(
    _ScheduleShortcut.week,
  ),
  SingleActivator(LogicalKeyboardKey.digit3): _ScheduleShortcutIntent(
    _ScheduleShortcut.month,
  ),
  SingleActivator(LogicalKeyboardKey.numpad3): _ScheduleShortcutIntent(
    _ScheduleShortcut.month,
  ),
  SingleActivator(LogicalKeyboardKey.digit4): _ScheduleShortcutIntent(
    _ScheduleShortcut.year,
  ),
  SingleActivator(LogicalKeyboardKey.numpad4): _ScheduleShortcutIntent(
    _ScheduleShortcut.year,
  ),
  SingleActivator(LogicalKeyboardKey.digit5): _ScheduleShortcutIntent(
    _ScheduleShortcut.agenda,
  ),
  SingleActivator(LogicalKeyboardKey.numpad5): _ScheduleShortcutIntent(
    _ScheduleShortcut.agenda,
  ),
};

class ScheduleWorkspace extends ConsumerStatefulWidget {
  const ScheduleWorkspace({
    super.key,
    this.initialScope = ScheduleScope.all,
    this.initialDate,
    this.initialTaskAccountId,
    this.initialTaskListId,
    this.initialTaskId,
    this.externalLocationLauncher,
  });

  final ScheduleScope initialScope;
  @visibleForTesting
  final DateTime? initialDate;
  final String? initialTaskAccountId;
  final String? initialTaskListId;
  final String? initialTaskId;
  final ExternalLocationLauncher? externalLocationLauncher;

  @override
  ConsumerState<ScheduleWorkspace> createState() => _ScheduleWorkspaceState();
}

class _ScheduleWorkspaceState extends ConsumerState<ScheduleWorkspace> {
  static const _agendaInitialDays = 30;
  static const _agendaPageDays = 30;
  static const _agendaInitialTaskBucketLimit = 8;
  static const _agendaTaskBucketPageSize = 8;
  static const _pointerAnchorLifetime = Duration(seconds: 1);

  var _selectedDate = DateTime.now();
  var _mode = ScheduleViewMode.week;
  late ScheduleScope _scope;
  _TaskDetailsTarget? _taskDetailsTarget;
  var _sidebarCollapsed = false;
  var _sidebarTransitionGeneration = 0;
  var _searchActive = false;
  var _searchQuery = '';
  bool? _sidebarBeforeSearch;
  ScheduleSearchCriteria? _searchCriteria;
  ScheduleSearchCriteria? _initialSearchCriteria;
  var _searchFirstWeekday = DateTime.monday;
  List<CalendarSourceEntity> _searchSources = const [];
  List<TaskListEntity> _searchTaskLists = const [];
  ScheduleSourceVisibility? _searchVisibility;
  final _searchController = TextEditingController();
  final _workspaceFocusNode = FocusNode();
  var _fallbackSearchFocusRequest = 0;
  var _latestCanShowSidebar = false;
  var _latestAccounts = const <AccountEntity>[];
  var _latestWritableSources = const <CalendarSourceEntity>[];
  var _latestVisibleTaskLists = const <TaskListEntity>[];
  var _latestCanCreateTask = false;
  var _latestItems = const <ScheduleItem>[];
  final _itemAnchorContexts = <String, BuildContext>{};
  final _createMenuController = BusyMaxMenuController();
  BusyMaxMenuSession? _createChoiceMenuSession;
  final _pointerAnchorClock = Stopwatch()..start();
  Offset? _recentSchedulePointerPosition;
  Duration? _recentSchedulePointerTime;
  ScheduleWorkspaceCommand? _pendingAnchoredCommand;
  ScheduleWorkspaceCommand? _revealedNotificationTarget;
  List<CalendarSourceEntity> _pendingAnchoredSources =
      const <CalendarSourceEntity>[];
  var _agendaLoadedDays = _agendaInitialDays;
  var _agendaOverdueTaskLimit = _agendaInitialTaskBucketLimit;
  var _agendaNoDateTaskLimit = _agendaInitialTaskBucketLimit;
  ScheduleViewMode? _lastSettingsMode;
  var _initialTaskHandled = false;
  var _initialTaskOpening = false;
  var _initialTaskWatchGeneration = 0;
  StreamSubscription<ScheduleTaskTarget?>? _initialTaskTargetSubscription;
  var _taskDetailsDirty = false;
  final _anchoredPopoverController = ScheduleAnchoredPopoverController();
  var _handlingModalHeaderAction = false;
  final _taskDetailsOverlayKey = GlobalKey<_ScheduleTaskDetailsOverlayState>();
  var _taskDetailsLifecycleGeneration = 0;
  Future<void>? _taskDetailsDismissal;
  var _navigationGeneration = 0;
  ScheduleNavigationIntent? _navigationIntent;
  var _taskListMutationGeneration = 0;
  TaskListMutationIntent? _taskListMutationIntent;

  @override
  void initState() {
    super.initState();
    if (widget.initialDate != null) {
      _selectedDate = DateUtils.dateOnly(widget.initialDate!);
    }
    _scope = widget.initialScope;
    _applyInitialScope();
    _scheduleInitialTaskWatch();
  }

  @override
  void dispose() {
    final createChoiceMenuSession = _createChoiceMenuSession;
    _createChoiceMenuSession = null;
    if (createChoiceMenuSession != null) {
      unawaited(createChoiceMenuSession.dismiss());
    }
    unawaited(_initialTaskTargetSubscription?.cancel());
    _searchController.dispose();
    _workspaceFocusNode.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final firstWeekday = _firstWeekday(context);
    if (_searchFirstWeekday == firstWeekday) return;
    _searchFirstWeekday = firstWeekday;
    _searchCriteria = _searchCriteria?.copyWith(firstWeekday: firstWeekday);
    _initialSearchCriteria = _initialSearchCriteria?.copyWith(
      firstWeekday: firstWeekday,
    );
  }

  @override
  void didUpdateWidget(covariant ScheduleWorkspace oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialScope != widget.initialScope) {
      _scope = widget.initialScope;
      _applyInitialScope();
    }
    if (oldWidget.initialTaskAccountId != widget.initialTaskAccountId ||
        oldWidget.initialTaskListId != widget.initialTaskListId ||
        oldWidget.initialTaskId != widget.initialTaskId) {
      _initialTaskHandled = false;
      _initialTaskOpening = false;
      _scheduleInitialTaskWatch();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Sync expands recurring cloud events into occurrence rows after the local
    // save. Requery when those rows arrive so the month view updates itself.
    ref.watch(scheduleDataRevisionProvider);
    final settings = ref.watch(appSettingsControllerProvider);
    _syncModeFromSettings(settings.scheduleViewMode);
    final range = _range(context);
    final searchActive = _searchActive;
    final accountsState = ref.watch(accountsStreamProvider);
    final accounts = accountsState.valueOrNull ?? const [];
    final accountsLoading =
        accountsState.isLoading && accountsState.valueOrNull == null;
    final accountsUnavailable =
        accountsState.hasError && accountsState.valueOrNull == null;
    final accountIds = accounts.map((account) => account.id).toList();
    final sourcesStream = ref
        .watch(calendarRepositoryProvider)
        .watchSourcesForAccounts(accountIds);

    return _scheduleShortcutScope(
      ScheduleAnchoredPopoverScope(
        controller: _anchoredPopoverController,
        child: StreamBuilder<List<CalendarSourceEntity>>(
          stream: sourcesStream,
          builder: (context, sourcesSnapshot) {
            final sourcesLoading =
                sourcesSnapshot.connectionState == ConnectionState.waiting &&
                !sourcesSnapshot.hasData;
            final sourcesUnavailable =
                sourcesSnapshot.hasError && !sourcesSnapshot.hasData;
            final sources =
                sourcesSnapshot.data ?? const <CalendarSourceEntity>[];
            return FutureBuilder<List<TaskListEntity>>(
              future: _taskListsForAccounts(accounts),
              builder: (context, listsSnapshot) {
                final taskListsLoading =
                    listsSnapshot.connectionState == ConnectionState.waiting &&
                    !listsSnapshot.hasData;
                final taskListsUnavailable =
                    listsSnapshot.hasError && !listsSnapshot.hasData;
                final taskLists =
                    listsSnapshot.data ?? const <TaskListEntity>[];
                final visibility = ScheduleSourceVisibility.fromSources(
                  calendarSources: sources,
                  taskLists: taskLists,
                  settings: settings,
                );
                _searchSources = sources;
                _searchTaskLists = taskLists;
                _searchVisibility = visibility;
                if (_searchActive &&
                    _searchCriteria == null &&
                    !sourcesLoading &&
                    !taskListsLoading) {
                  _initializeSearch();
                }
                final firstWeekday = _firstWeekday(context);
                final revealed = _revealedNotificationTarget;
                final visibleSourceIds = {
                  ...visibility.visibleCalendarSourceIds,
                  if (revealed?.kind ==
                          ScheduleWorkspaceCommandKind.openCalendarEvent &&
                      revealed?.sourceId != null)
                    revealed!.sourceId!,
                };
                final visibleSources = sources
                    .where((source) => visibleSourceIds.contains(source.id))
                    .toList();
                final writableSources = writableCalendarSources(visibleSources);
                final routedTaskListKey = _initialTaskListKey;
                final visibleTaskListKeys = <ScheduleTaskListKey>{
                  ...routedTaskListKey == null
                      ? visibility.visibleTaskListKeys
                      : <ScheduleTaskListKey>{routedTaskListKey},
                  if (revealed?.kind == ScheduleWorkspaceCommandKind.openTask &&
                      revealed?.accountId != null &&
                      revealed?.sourceId != null)
                    ScheduleTaskListKey(
                      accountId: revealed!.accountId!,
                      taskListId: revealed.sourceId!,
                    ),
                };
                final visibleTaskLists = taskLists
                    .where(
                      (list) => visibleTaskListKeys.contains(
                        ScheduleTaskListKey(
                          accountId: list.accountId,
                          taskListId: list.id,
                        ),
                      ),
                    )
                    .toList();
                final canCreateTask = visibleTaskLists.isNotEmpty;
                _latestAccounts = accounts;
                _latestWritableSources = writableSources;
                _latestVisibleTaskLists = visibleTaskLists;
                _latestCanCreateTask = canCreateTask;

                return FutureBuilder<_ScheduleItemsResult>(
                  future: _scheduleItems(
                    repository: ref.watch(scheduleRepositoryProvider),
                    range: range,
                    searchActive: searchActive,
                    accountIds: accountIds.toSet(),
                    sourceIds: visibleSourceIds,
                    taskListKeys: visibleTaskListKeys,
                  ),
                  builder: (context, snapshot) {
                    final itemsLoading =
                        snapshot.connectionState == ConnectionState.waiting &&
                        (searchActive || !snapshot.hasData);
                    final scheduleLoading =
                        accountsLoading ||
                        sourcesLoading ||
                        taskListsLoading ||
                        itemsLoading;
                    final scheduleUnavailable =
                        accountsUnavailable ||
                        sourcesUnavailable ||
                        taskListsUnavailable ||
                        (snapshot.hasError && !snapshot.hasData);
                    final scopedItems = searchActive
                        ? snapshot.data?.items ?? const <ScheduleItem>[]
                        : ScheduleProjection.filterByScope(
                            snapshot.data?.items ?? const <ScheduleItem>[],
                            _scope,
                          );
                    final items =
                        !searchActive && _mode == ScheduleViewMode.agenda
                        ? _agendaItems(scopedItems, range)
                        : scopedItems;
                    _latestItems = items;
                    final miniCalendarItemsFuture = searchActive
                        ? Future<List<ScheduleItem>>.value(const [])
                        : ref
                              .watch(scheduleRepositoryProvider)
                              .listItems(
                                range: ScheduleRange.month(
                                  _selectedDate,
                                  firstWeekday: firstWeekday,
                                ),
                                filters: ScheduleFilters(
                                  accountIds: accountIds.toSet(),
                                  sourceIds:
                                      visibility.visibleCalendarSourceIds,
                                  taskListKeys: visibleTaskListKeys,
                                  sourceFilterActive: true,
                                  taskListFilterActive: true,
                                  includeCalendarEvents:
                                      _scope != ScheduleScope.tasks,
                                  includeTasks: _scope != ScheduleScope.events,
                                  taskCompletion: ScheduleTaskCompletion.all,
                                  showNoDateTasks: false,
                                ),
                              );
                    final displayRange = searchActive
                        ? _searchCriteria?.range ??
                              _rangeForSearchResults(items, range)
                        : range;
                    final displayMode = searchActive
                        ? ScheduleViewMode.agenda
                        : _mode;
                    _consumePendingCommand(visibleSources, accounts, sources);
                    final canShowSidebar = BusyMaxLayoutRules.showSidebar(
                      MediaQuery.sizeOf(context).width,
                    );
                    Widget buildSidebar() {
                      if (searchActive && _searchCriteria != null) {
                        return SizedBox(
                          width: BusyMaxSizes.sidebarWidth,
                          child: _searchFilterPanel(),
                        );
                      }
                      return SizedBox(
                        width: BusyMaxSizes.sidebarWidth,
                        child: FutureBuilder<List<ScheduleItem>>(
                          future: miniCalendarItemsFuture,
                          builder: (context, miniSnapshot) {
                            final miniCalendarItems =
                                ScheduleProjection.filterByScope(
                                  miniSnapshot.data ?? const <ScheduleItem>[],
                                  _scope,
                                );
                            return ScheduleSidebar(
                              selectedDate: _selectedDate,
                              firstWeekday: firstWeekday,
                              items: miniCalendarItems,
                              showEndBorder: false,
                              onDateSelected: _openDay,
                              onMonthSelected: _setMonth,
                              onYearSelected: _setYear,
                              onWeekSelected: _setWeek,
                              onAddAccount: () => unawaited(
                                context.push<void>('/settings?page=accounts'),
                              ),
                            );
                          },
                        ),
                      );
                    }

                    final header = ScheduleToolbar(
                      mode: _mode,
                      range: range,
                      selectedDate: _selectedDate,
                      onToday: _goToToday,
                      onPrevious: _previous,
                      onNext: _next,
                      onModeChanged: _setMode,
                      canCreateEvent: writableSources.isNotEmpty,
                      canCreateTask: canCreateTask,
                      onCreateEvent: () => unawaited(
                        _openNewEvent(
                          writableSources,
                          _defaultSelectedDateStart(),
                        ),
                      ),
                      onCreateTask: () => unawaited(
                        _openNewTask(
                          accounts,
                          due: _day(_defaultSelectedDateStart()),
                        ),
                      ),
                      createMenuController: _createMenuController,
                      onRefresh: () => unawaited(_refreshAll()),
                      canRefresh: accounts.isNotEmpty,
                      canShowSidebar: canShowSidebar,
                      sidebarVisible: canShowSidebar && !_sidebarCollapsed,
                      onToggleSidebar: () => _handleHeaderAction(
                        BusyMaxHeaderAction.sidebarToggle,
                      ),
                      onSearch: () =>
                          _handleHeaderAction(BusyMaxHeaderAction.search),
                      searchActive: searchActive,
                      searchController: _searchController,
                      searchFocusRequest: _fallbackSearchFocusRequest,
                      onSearchChanged: _setSearchQuery,
                      onClearSearch: _clearSearchQuery,
                      onSearchFilters:
                          searchActive && (!canShowSidebar || _sidebarCollapsed)
                          ? _showSearchFilters
                          : null,
                      onMenuSelected: _handleToolbarMenu,
                    );
                    final main = BusyMaxBinaryPresentation(
                      alternateActive: searchActive,
                      child: Listener(
                        behavior: HitTestBehavior.translucent,
                        onPointerDown: _recordSchedulePointer,
                        child: _ScheduleBody(
                          isLoading: scheduleLoading,
                          isUnavailable: scheduleUnavailable,
                          mode: displayMode,
                          range: displayRange,
                          selectedDate: searchActive
                              ? displayRange.start
                              : _selectedDate,
                          firstWeekday: _firstWeekday(context),
                          dayStartMinute: settings.scheduleDayStartMinute,
                          dayEndMinute: settings.scheduleDayEndMinute,
                          hasAnySources:
                              visibility.hasCalendarSources ||
                              visibility.hasTaskLists,
                          hasAccounts: accounts.isNotEmpty,
                          items: items,
                          onOpenSettings: () =>
                              unawaited(context.push<void>('/settings')),
                          onRetry: _retrySchedule,
                          onRefresh: accounts.isEmpty
                              ? null
                              : () => unawaited(_refreshAll()),
                          onDaySelected: _setDate,
                          onYearDaySelected: _openDay,
                          onMonthSelected: _setMonth,
                          onWeekSelected: _setWeek,
                          onEmptySlot: (start) => unawaited(
                            _openCreateChoice(
                              accounts,
                              visibleSources,
                              start,
                              canCreateTask: canCreateTask,
                            ),
                          ),
                          onRangeCreated: writableSources.isNotEmpty
                              ? (interval) => unawaited(
                                  _openNewEvent(
                                    visibleSources,
                                    interval.start,
                                    end: interval.end,
                                  ),
                                )
                              : null,
                          onReschedule: _rescheduleEvent,
                          onCreateAtDay: (day, {anchorContext}) => unawaited(
                            _openCreateChoice(
                              accounts,
                              visibleSources,
                              DateTime(day.year, day.month, day.day, 9),
                              canCreateTask: canCreateTask,
                              anchorContext: anchorContext,
                            ),
                          ),
                          onNewEvent: () => unawaited(
                            _openNewEvent(visibleSources, _selectedDate),
                          ),
                          onNewTask: () => unawaited(_openNewTask(accounts)),
                          onPrevious: _previous,
                          onNext: _next,
                          onAgendaLoadMore:
                              !searchActive && _mode == ScheduleViewMode.agenda
                              ? _loadMoreAgendaDays
                              : null,
                          hasMoreAgendaOverdueTasks:
                              !searchActive &&
                              _mode == ScheduleViewMode.agenda &&
                              (snapshot.data?.hasMoreOverdueTasks ?? false),
                          hasMoreAgendaNoDateTasks:
                              !searchActive &&
                              _mode == ScheduleViewMode.agenda &&
                              (snapshot.data?.hasMoreNoDateTasks ?? false),
                          onAgendaLoadMoreOverdue:
                              !searchActive && _mode == ScheduleViewMode.agenda
                              ? _loadMoreAgendaOverdueTasks
                              : null,
                          onAgendaLoadMoreNoDate:
                              !searchActive && _mode == ScheduleViewMode.agenda
                              ? _loadMoreAgendaNoDateTasks
                              : null,
                          onItemSelected: (context, item, [globalPosition]) =>
                              unawaited(
                                _openItem(
                                  context,
                                  item,
                                  searchActive ? sources : visibleSources,
                                  globalPosition: globalPosition,
                                ),
                              ),
                          onItemAnchorAvailable: _handleItemAnchorAvailable,
                          onTaskCompletionChanged: _setTaskCompleted,
                          onChecklistItemCompletionChanged:
                              _setChecklistItemCompleted,
                          canCreateEvent: writableSources.isNotEmpty,
                          canCreateTask: canCreateTask,
                          searchActive: searchActive,
                          searchCriteria: _searchCriteria,
                          searchQuery: _searchQuery,
                          navigationIntent: _navigationIntent,
                          taskListMutationIntent: _taskListMutationIntent,
                          onTaskListMutationConsumed: (intent) {
                            if (!mounted) return;
                            if (_taskListMutationIntent?.generation ==
                                intent.generation) {
                              setState(() => _taskListMutationIntent = null);
                            }
                          },
                        ),
                      ),
                    );
                    return Scaffold(
                      backgroundColor: BusyMaxSurfaceColors.of(context).window,
                      body: LayoutBuilder(
                        builder: (context, constraints) {
                          final showSidebar = BusyMaxLayoutRules.showSidebar(
                            constraints.maxWidth,
                          );
                          _latestCanShowSidebar = showSidebar;
                          final sidebar = BusyMaxBinaryPresentation(
                            alternateActive:
                                searchActive && _searchCriteria != null,
                            child: buildSidebar(),
                          );
                          final cloudCoverage =
                              snapshot.hasData &&
                                  !scheduleLoading &&
                                  _searchCriteria?.date !=
                                      ScheduleSearchDate.any
                              ? ref
                                    .read(scheduleRepositoryProvider)
                                    .cloudCoverageCompleteFor(
                                      _searchCriteria?.range ?? range,
                                      filters:
                                          searchActive &&
                                              _searchCriteria != null
                                          ? _searchCriteria!.filters(
                                              _searchQuery,
                                            )
                                          : ScheduleFilters(
                                              accountIds: accountIds.toSet(),
                                              sourceIds: visibility
                                                  .visibleCalendarSourceIds,
                                              sourceFilterActive: true,
                                            ),
                                    )
                              : true;
                          final frame = LinuxPageFrame(
                            header: header,
                            body: cloudCoverage != true
                                ? Column(
                                    children: [
                                      ListTile(
                                        leading: Icon(
                                          cloudCoverage == null
                                              ? Icons.sync
                                              : Icons.cloud_off,
                                        ),
                                        title: Text(
                                          cloudCoverage == null
                                              ? context.l10n.scheduleLoading
                                              : context
                                                    .l10n
                                                    .scheduleRangeIncomplete,
                                        ),
                                        dense: true,
                                      ),
                                      Expanded(child: main),
                                    ],
                                  )
                                : main,
                            sidebarHeader: const BusyMaxLinuxBrandHeader(),
                            sidebarBody: sidebar,
                            sidebarAvailable: showSidebar,
                            sidebarExpanded: !_sidebarCollapsed,
                            sidebarTransitionGeneration:
                                _sidebarTransitionGeneration,
                          );
                          return _ScheduleTaskDetailsOverlay(
                            key: _taskDetailsOverlayKey,
                            target: _taskDetailsTarget,
                            onClose: () =>
                                unawaited(_requestCloseTaskDetails()),
                            onWindowCloseRequested: _confirmDiscardTaskDetails,
                            onDirtyChanged: (dirty) {
                              _taskDetailsDirty = dirty;
                            },
                            onMutationCommitted: _handleEditorTaskMutation,
                            child: frame,
                          );
                        },
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _scheduleShortcutScope(Widget child) => ScheduleItemAnchorScope(
    onAnchorAvailable: _handleItemAnchorAvailable,
    child: _buildScheduleShortcuts(child),
  );

  Widget _buildScheduleShortcuts(Widget child) {
    return Shortcuts(
      shortcuts: _scheduleShortcuts,
      child: Actions(
        actions: {_ScheduleShortcutIntent: _ScheduleShortcutAction(this)},
        child: Focus(
          focusNode: _workspaceFocusNode,
          autofocus: true,
          child: child,
        ),
      ),
    );
  }

  void _handleToolbarMenu(ScheduleToolbarMenuAction action) {
    switch (action) {
      case ScheduleToolbarMenuAction.refresh:
        _handleHeaderAction(BusyMaxHeaderAction.refresh);
      case ScheduleToolbarMenuAction.settings:
        _handleHeaderAction(BusyMaxHeaderAction.settings);
      case ScheduleToolbarMenuAction.keyboardShortcuts:
        _handleHeaderAction(BusyMaxHeaderAction.keyboardShortcuts);
      case ScheduleToolbarMenuAction.reportIssue:
        _handleHeaderAction(BusyMaxHeaderAction.reportIssue);
      case ScheduleToolbarMenuAction.about:
        _handleHeaderAction(BusyMaxHeaderAction.aboutBusyMax);
    }
  }

  void _handleHeaderAction(BusyMaxHeaderAction action) {
    if (!_canHandleRouteShortcut()) {
      if (_taskDetailsTarget != null || _anchoredPopoverController.isOpen) {
        unawaited(_dismissModalThenHandleHeaderAction(action));
      }
      return;
    }
    _dispatchHeaderAction(action);
  }

  Future<void> _dismissModalThenHandleHeaderAction(
    BusyMaxHeaderAction action,
  ) async {
    if (_handlingModalHeaderAction) {
      return;
    }
    _handlingModalHeaderAction = true;
    try {
      if (_taskDetailsTarget != null) {
        if (!await _confirmDiscardTaskDetails()) {
          return;
        }
        await _closeTaskDetails();
      } else if (_anchoredPopoverController.isOpen) {
        await _anchoredPopoverController.dismiss();
      } else {
        return;
      }
      if (!mounted || !_canHandleRouteShortcut()) {
        return;
      }
      _dispatchHeaderAction(action);
    } finally {
      _handlingModalHeaderAction = false;
    }
  }

  void _dispatchHeaderAction(BusyMaxHeaderAction action) {
    switch (action) {
      case BusyMaxHeaderAction.back:
        return;
      case BusyMaxHeaderAction.sidebarToggle:
        if (!_latestCanShowSidebar) {
          if (_searchActive) unawaited(_showSearchFilters());
          return;
        }
        setState(() {
          _sidebarCollapsed = !_sidebarCollapsed;
          _sidebarTransitionGeneration += 1;
        });
      case BusyMaxHeaderAction.today:
        _goToToday();
      case BusyMaxHeaderAction.previous:
        if (_mode == ScheduleViewMode.agenda) {
          return;
        }
        _previous();
      case BusyMaxHeaderAction.next:
        if (_mode == ScheduleViewMode.agenda) {
          return;
        }
        _next();
      case BusyMaxHeaderAction.viewModeDay:
        _setMode(ScheduleViewMode.day);
      case BusyMaxHeaderAction.viewModeWeek:
        _setMode(ScheduleViewMode.week);
      case BusyMaxHeaderAction.viewModeMonth:
        _setMode(ScheduleViewMode.month);
      case BusyMaxHeaderAction.viewModeYear:
        _setMode(ScheduleViewMode.year);
      case BusyMaxHeaderAction.viewModeAgenda:
        _setMode(ScheduleViewMode.agenda);
      case BusyMaxHeaderAction.search:
        if (_searchActive) {
          _closeSearch();
        } else {
          _openSearch();
          _focusSearch();
        }
      case BusyMaxHeaderAction.createEvent:
        if (_latestWritableSources.isEmpty) {
          return;
        }
        unawaited(
          _openNewEvent(_latestWritableSources, _defaultSelectedDateStart()),
        );
      case BusyMaxHeaderAction.createTask:
        if (!_latestCanCreateTask) {
          return;
        }
        unawaited(
          _openNewTask(_latestAccounts, due: _day(_defaultSelectedDateStart())),
        );
      case BusyMaxHeaderAction.refresh:
        unawaited(_refreshAll());
      case BusyMaxHeaderAction.settings:
        unawaited(context.push<void>('/settings'));
      case BusyMaxHeaderAction.keyboardShortcuts:
        unawaited(showBusyMaxKeyboardShortcutsDialog(context));
      case BusyMaxHeaderAction.reportIssue:
        unawaited(
          showBusyMaxFeedbackDialog(
            context,
            submissionService: ref.read(feedbackSubmissionServiceProvider),
          ),
        );
      case BusyMaxHeaderAction.aboutBusyMax:
        unawaited(showBusyMaxAboutDialog(context));
    }
  }

  ScheduleRange _range(BuildContext context) {
    final firstWeekday = _firstWeekday(context);
    if (_scope == ScheduleScope.upcoming) {
      return _agendaRangeFromToday();
    }
    return switch (_mode) {
      ScheduleViewMode.day => ScheduleRange.day(_selectedDate),
      ScheduleViewMode.week => ScheduleRange.week(
        _selectedDate,
        firstWeekday: firstWeekday,
      ),
      ScheduleViewMode.month => ScheduleRange.month(
        _selectedDate,
        firstWeekday: firstWeekday,
      ),
      ScheduleViewMode.year => ScheduleRange.year(_selectedDate),
      ScheduleViewMode.agenda => _agendaRangeFromToday(),
    };
  }

  ScheduleRange _agendaRangeFromToday() {
    final start = _day(DateTime.now());
    return ScheduleRange(
      start: start,
      end: start.add(Duration(days: _agendaLoadedDays)),
    );
  }

  ScheduleRange _rangeForSearchResults(
    List<ScheduleItem> items,
    ScheduleRange fallback,
  ) {
    final days = items
        .map((item) => item.start)
        .nonNulls
        .map(ScheduleProjection.day)
        .toList();
    if (days.isEmpty) {
      return fallback;
    }
    days.sort();
    return ScheduleRange(
      start: days.first,
      end: days.last.add(const Duration(days: 1)),
    );
  }

  void _initializeSearch() {
    final visibility = _searchVisibility;
    if (visibility == null) return;
    _initialSearchCriteria = ScheduleSearchCriteria(
      type: switch (_scope) {
        ScheduleScope.events => ScheduleSearchType.events,
        ScheduleScope.tasks => ScheduleSearchType.tasks,
        _ => ScheduleSearchType.all,
      },
      referenceDate: _day(DateTime.now()),
      firstWeekday: _firstWeekday(context),
      sourceIds: visibility.visibleCalendarSourceIds,
      taskListKeys: visibility.visibleTaskListKeys,
    );
    _searchCriteria = _initialSearchCriteria;
  }

  void _openSearch() {
    setState(() {
      _sidebarBeforeSearch = _sidebarCollapsed;
      _searchActive = true;
      _initializeSearch();
    });
  }

  Widget _searchFilterPanel({VoidCallback? refresh, bool sidebar = true}) =>
      ScheduleSearchFilters(
        value: _searchCriteria!,
        accounts: _latestAccounts,
        sources: _searchSources,
        taskLists: _searchTaskLists,
        sidebar: sidebar,
        showEndBorder: false,
        onChanged: (value) {
          setState(
            () => _searchCriteria = value.copyWith(
              firstWeekday: _firstWeekday(context),
            ),
          );
          refresh?.call();
        },
        onClear: () {
          setState(
            () => _searchCriteria = _initialSearchCriteria?.copyWith(
              firstWeekday: _firstWeekday(context),
            ),
          );
          refresh?.call();
        },
      );

  Future<void> _showSearchFilters() async {
    if (_searchCriteria == null) return;
    final dismissWhenWide = !BusyMaxLayoutRules.showSidebar(
      MediaQuery.sizeOf(context).width,
    );
    var dismissScheduled = false;
    await showBusyMaxModalDialog<void>(
      context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) {
          if (dismissWhenWide &&
              BusyMaxLayoutRules.showSidebar(
                MediaQuery.sizeOf(context).width,
              )) {
            if (!dismissScheduled) {
              dismissScheduled = true;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (context.mounted) Navigator.of(context).maybePop();
              });
            }
            return const SizedBox.shrink();
          }
          return BusyMaxDialogShell(
            title: dialogContext.l10n.searchFilters,
            children: [
              _searchFilterPanel(sidebar: false, refresh: () => update(() {})),
            ],
          );
        },
      ),
    );
  }

  Future<_ScheduleItemsResult> _scheduleItems({
    required ScheduleRepository repository,
    required ScheduleRange range,
    required bool searchActive,
    required Set<String> accountIds,
    required Set<String> sourceIds,
    required Set<ScheduleTaskListKey> taskListKeys,
  }) async {
    if (searchActive) {
      final criteria = _searchCriteria;
      if (criteria == null) return const _ScheduleItemsResult(items: []);
      return _ScheduleItemsResult(
        items: await repository.listItems(
          range: criteria.range ?? range,
          filters: criteria.filters(_searchQuery),
        ),
      );
    }
    final currentItems = repository.listItems(
      range: range,
      filters: ScheduleFilters(
        query: _searchQuery,
        accountIds: accountIds,
        sourceIds: sourceIds,
        taskListKeys: taskListKeys,
        sourceFilterActive: true,
        taskListFilterActive: true,
        includeCalendarEvents: _scope != ScheduleScope.tasks,
        includeTasks: _scope != ScheduleScope.events,
        taskCompletion: ScheduleTaskCompletion.all,
        showNoDateTasks: searchActive || _mode != ScheduleViewMode.agenda,
      ),
    );
    if (searchActive || _mode != ScheduleViewMode.agenda) {
      return _ScheduleItemsResult(items: await currentItems);
    }

    final overdueTasks = repository.listOverdueTasks(
      before: range.start,
      limit: _agendaOverdueTaskLimit,
      filters: ScheduleFilters(
        accountIds: accountIds,
        taskListKeys: taskListKeys,
        taskListFilterActive: true,
        includeTasks: _scope != ScheduleScope.events,
        taskCompletion: ScheduleTaskCompletion.open,
      ),
    );
    final noDateTasks = repository.listNoDateTasks(
      limit: _agendaNoDateTaskLimit,
      filters: ScheduleFilters(
        accountIds: accountIds,
        taskListKeys: taskListKeys,
        taskListFilterActive: true,
        includeTasks: _scope != ScheduleScope.events,
        taskCompletion: ScheduleTaskCompletion.all,
      ),
    );
    final datedItems = await currentItems;
    final overduePage = await overdueTasks;
    final noDatePage = await noDateTasks;
    final items = await repository.includeTaskAncestors(
      [...datedItems, ...overduePage.items, ...noDatePage.items],
      filters: ScheduleFilters(
        accountIds: accountIds,
        taskListKeys: taskListKeys,
        taskListFilterActive: true,
        includeTasks: _scope != ScheduleScope.events,
      ),
    );
    return _ScheduleItemsResult(
      items: items,
      hasMoreOverdueTasks: overduePage.hasMore,
      hasMoreNoDateTasks: noDatePage.hasMore,
    );
  }

  List<ScheduleItem> _agendaItems(
    List<ScheduleItem> items,
    ScheduleRange range,
  ) {
    final startDay = ScheduleProjection.day(range.start);
    return items.where((item) {
      final start = item.start;
      if (start == null) {
        return true;
      }
      if (item is CalendarScheduleItem) {
        return ScheduleProjection.intersects(item, range);
      }
      if (item is TaskScheduleItem) {
        final itemDay = ScheduleProjection.day(start);
        if (itemDay.isBefore(startDay)) {
          return !item.completed;
        }
        return start.isBefore(range.end);
      }
      return ScheduleProjection.intersects(item, range);
    }).toList();
  }

  Future<List<TaskListEntity>> _taskListsForAccounts(
    List<AccountEntity> accounts,
  ) async {
    final allLists = <TaskListEntity>[];
    for (final account in accounts.where((account) => account.isTaskCapable)) {
      final repository = ref.read(
        taskListsRepositoryForAccountProvider(account.id),
      );
      allLists.addAll(await repository.listTaskLists());
    }
    return allLists;
  }

  void _setDate(DateTime date) {
    setState(() {
      _navigationIntent = null;
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = _day(date);
      if (_mode == ScheduleViewMode.agenda) {
        _resetAgendaLoadedDays();
      }
    });
  }

  void _openDay(DateTime date) {
    setState(() {
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = _day(date);
      _mode = ScheduleViewMode.day;
      _lastSettingsMode = ScheduleViewMode.day;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(ScheduleViewMode.day),
    );
  }

  void _setWeek(DateTime weekStart) {
    setState(() {
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = _day(weekStart);
      _mode = ScheduleViewMode.week;
      _lastSettingsMode = ScheduleViewMode.week;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(ScheduleViewMode.week),
    );
  }

  void _setMonth(DateTime month) {
    setState(() {
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = DateTime(month.year, month.month);
      _mode = ScheduleViewMode.month;
      _lastSettingsMode = ScheduleViewMode.month;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(ScheduleViewMode.month),
    );
  }

  void _setYear(DateTime year) {
    setState(() {
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = DateTime(year.year);
      _mode = ScheduleViewMode.year;
      _lastSettingsMode = ScheduleViewMode.year;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(ScheduleViewMode.year),
    );
  }

  void _applyInitialScope() {
    switch (_scope) {
      case ScheduleScope.today:
        _selectedDate = _day(DateTime.now());
      case ScheduleScope.upcoming:
        _selectedDate = _day(DateTime.now());
        _mode = ScheduleViewMode.agenda;
      case ScheduleScope.tasks:
        _selectedDate = _day(DateTime.now());
        _mode = ScheduleViewMode.agenda;
      case ScheduleScope.all || ScheduleScope.events:
        break;
    }
  }

  void _syncModeFromSettings(ScheduleViewMode settingsMode) {
    final previousSettingsMode = _lastSettingsMode;
    if (previousSettingsMode == settingsMode) {
      return;
    }
    _lastSettingsMode = settingsMode;
    if (_scope != ScheduleScope.all && _scope != ScheduleScope.events) {
      return;
    }
    if (previousSettingsMode == null || _mode == previousSettingsMode) {
      if (_mode != ScheduleViewMode.agenda &&
          settingsMode == ScheduleViewMode.agenda) {
        _selectedDate = _day(DateTime.now());
        _resetAgendaLoadedDays();
      }
      _mode = settingsMode;
    }
  }

  void _goToToday() {
    if (_searchActive) return;
    setState(() {
      _navigationIntent = ScheduleNavigationIntent(
        cause: ScheduleNavigationCause.today,
        target: _day(DateTime.now()),
        direction: 0,
        generation: ++_navigationGeneration,
      );
      _selectedDate = _day(DateTime.now());
      if (_mode == ScheduleViewMode.agenda) {
        _resetAgendaLoadedDays();
      }
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
    });
  }

  void _setMode(ScheduleViewMode mode, {DateTime? agendaDate}) {
    if (_searchActive) return;
    if (_mode == mode) {
      if (mode == ScheduleViewMode.agenda && agendaDate != null) {
        _setDate(agendaDate);
      }
      return;
    }
    setState(() {
      _navigationIntent = null;
      _mode = mode;
      _lastSettingsMode = mode;
      if (mode == ScheduleViewMode.agenda) {
        _selectedDate = _day(agendaDate ?? DateTime.now());
        _resetAgendaLoadedDays();
      }
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(mode),
    );
  }

  void _focusSearch() {
    setState(() => _fallbackSearchFocusRequest += 1);
  }

  void _setSearchQuery(String value) {
    if (_searchQuery == value && _searchController.text == value) {
      return;
    }
    setState(() {
      _searchQuery = value;
      if (_searchController.text != value) {
        _searchController.value = TextEditingValue(
          text: value,
          selection: TextSelection.collapsed(offset: value.length),
        );
      }
    });
  }

  void _clearSearchQuery() {
    _setSearchQuery('');
  }

  void _closeSearch() {
    setState(() {
      _searchActive = false;
      _sidebarCollapsed = _sidebarBeforeSearch ?? _sidebarCollapsed;
      _sidebarBeforeSearch = null;
      _searchCriteria = null;
      _initialSearchCriteria = null;
      _searchQuery = '';
      _searchController.clear();
    });
    _workspaceFocusNode.requestFocus();
  }

  void _previous() {
    if (_searchActive) return;
    if (_mode == ScheduleViewMode.agenda) {
      return;
    }
    setState(() {
      final target = switch (_mode) {
        ScheduleViewMode.day => DateUtils.addDaysToDate(_selectedDate, -1),
        ScheduleViewMode.week => DateUtils.addDaysToDate(_selectedDate, -7),
        ScheduleViewMode.month => DateUtils.addMonthsToMonthDate(
          _selectedDate,
          -1,
        ),
        ScheduleViewMode.year => DateTime(
          _selectedDate.year - 1,
          _selectedDate.month,
          _selectedDate.day,
        ),
        ScheduleViewMode.agenda => _selectedDate,
      };
      _selectedDate = target;
      _navigationIntent = ScheduleNavigationIntent(
        cause: ScheduleNavigationCause.adjacentPeriod,
        target: target,
        direction: -1,
        generation: ++_navigationGeneration,
      );
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
    });
  }

  void _next() {
    if (_searchActive) return;
    if (_mode == ScheduleViewMode.agenda) {
      return;
    }
    setState(() {
      final target = switch (_mode) {
        ScheduleViewMode.day => DateUtils.addDaysToDate(_selectedDate, 1),
        ScheduleViewMode.week => DateUtils.addDaysToDate(_selectedDate, 7),
        ScheduleViewMode.month => DateUtils.addMonthsToMonthDate(
          _selectedDate,
          1,
        ),
        ScheduleViewMode.year => DateTime(
          _selectedDate.year + 1,
          _selectedDate.month,
          _selectedDate.day,
        ),
        ScheduleViewMode.agenda => _selectedDate,
      };
      _selectedDate = target;
      _navigationIntent = ScheduleNavigationIntent(
        cause: ScheduleNavigationCause.adjacentPeriod,
        target: target,
        direction: 1,
        generation: ++_navigationGeneration,
      );
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
    });
  }

  bool _isScheduleShortcutEnabled(_ScheduleShortcut command) {
    if (!_canHandleRouteShortcut()) {
      return false;
    }
    return switch (command) {
      _ScheduleShortcut.search => true,
      _ScheduleShortcut.sidebar => _latestCanShowSidebar || _searchActive,
      _ScheduleShortcut.dismissSearch => _searchActive,
      _ScheduleShortcut.newEvent =>
        _canHandleScheduleShortcut() && _latestWritableSources.isNotEmpty,
      _ScheduleShortcut.newTask =>
        _canHandleScheduleShortcut() && _latestCanCreateTask,
      _ScheduleShortcut.today ||
      _ScheduleShortcut.day ||
      _ScheduleShortcut.week ||
      _ScheduleShortcut.month ||
      _ScheduleShortcut.year ||
      _ScheduleShortcut.agenda => _canHandleScheduleShortcut(),
      _ScheduleShortcut.previous || _ScheduleShortcut.next =>
        _canHandleScheduleShortcut() && _mode != ScheduleViewMode.agenda,
    };
  }

  void _invokeScheduleShortcut(_ScheduleShortcut command) {
    switch (command) {
      case _ScheduleShortcut.search:
        if (!_searchActive) {
          _openSearch();
        }
        _focusSearch();
      case _ScheduleShortcut.sidebar:
        _handleHeaderAction(BusyMaxHeaderAction.sidebarToggle);
      case _ScheduleShortcut.dismissSearch:
        _closeSearch();
      case _ScheduleShortcut.previous:
        _previous();
      case _ScheduleShortcut.next:
        _next();
      case _ScheduleShortcut.newEvent:
        unawaited(
          _openNewEvent(_latestWritableSources, _defaultSelectedDateStart()),
        );
      case _ScheduleShortcut.newTask:
        unawaited(_openNewTask(_latestAccounts, due: _day(_selectedDate)));
      case _ScheduleShortcut.today:
        _goToToday();
      case _ScheduleShortcut.day:
        _setMode(ScheduleViewMode.day);
      case _ScheduleShortcut.week:
        _setMode(ScheduleViewMode.week);
      case _ScheduleShortcut.month:
        _setMode(ScheduleViewMode.month);
      case _ScheduleShortcut.year:
        _setMode(ScheduleViewMode.year);
      case _ScheduleShortcut.agenda:
        _setMode(ScheduleViewMode.agenda);
    }
  }

  DateTime _defaultSelectedDateStart() {
    return DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      9,
    );
  }

  bool _canHandleScheduleShortcut() {
    if (!_canHandleRouteShortcut() || _searchActive) {
      return false;
    }
    final focusContext = FocusManager.instance.primaryFocus?.context;
    if (focusContext == null) {
      return true;
    }
    return focusContext.widget is! EditableText &&
        focusContext.findAncestorWidgetOfExactType<EditableText>() == null;
  }

  bool _canHandleRouteShortcut() {
    if (!mounted || _taskDetailsTarget != null) {
      return false;
    }
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) {
      return false;
    }
    return true;
  }

  void _loadMoreAgendaDays() {
    if (_mode != ScheduleViewMode.agenda) {
      return;
    }
    setState(() {
      _agendaLoadedDays += _agendaPageDays;
    });
  }

  void _loadMoreAgendaOverdueTasks() {
    if (_mode != ScheduleViewMode.agenda) {
      return;
    }
    setState(() {
      _agendaOverdueTaskLimit += _agendaTaskBucketPageSize;
    });
  }

  void _loadMoreAgendaNoDateTasks() {
    if (_mode != ScheduleViewMode.agenda) {
      return;
    }
    setState(() {
      _agendaNoDateTaskLimit += _agendaTaskBucketPageSize;
    });
  }

  void _resetAgendaLoadedDays() {
    _agendaLoadedDays = _agendaInitialDays;
    _agendaOverdueTaskLimit = _agendaInitialTaskBucketLimit;
    _agendaNoDateTaskLimit = _agendaInitialTaskBucketLimit;
  }

  Future<void> _openCreateChoice(
    List<AccountEntity> accounts,
    List<CalendarSourceEntity> sources,
    DateTime start, {
    required bool canCreateTask,
    BuildContext? anchorContext,
  }) async {
    if (_createChoiceMenuSession != null) {
      return;
    }
    final writableSources = writableCalendarSources(sources);
    final recentAnchorPoint = _takeRecentSchedulePointerPosition();
    final anchorPoint = anchorContext == null ? recentAnchorPoint : null;
    final canCreateEvent = writableSources.isNotEmpty;
    if (!canCreateEvent && !canCreateTask) {
      return;
    }
    final directChoice = singleAvailableScheduleCreateChoice(
      canCreateEvent: canCreateEvent,
      canCreateTask: canCreateTask,
    );
    if (directChoice != null) {
      await _openScheduleCreateChoice(
        directChoice,
        accounts: accounts,
        writableSources: writableSources,
        start: start,
      );
      return;
    }
    final menuSession = BusyMaxMenuSession();
    _createChoiceMenuSession = menuSession;
    ScheduleCreateChoice? choice;
    try {
      choice = await showScheduleCreateMenu(
        context: context,
        anchorContext: anchorContext?.mounted == true
            ? anchorContext
            : _createChoiceAnchorContext(),
        anchorPoint: anchorPoint,
        preferAbove: anchorContext != null,
        session: menuSession,
      );
    } finally {
      if (identical(_createChoiceMenuSession, menuSession)) {
        _createChoiceMenuSession = null;
      }
    }
    if (!mounted || choice == null) {
      return;
    }
    await _openScheduleCreateChoice(
      choice,
      accounts: accounts,
      writableSources: writableSources,
      start: start,
    );
  }

  Future<void> _openScheduleCreateChoice(
    ScheduleCreateChoice choice, {
    required List<AccountEntity> accounts,
    required List<CalendarSourceEntity> writableSources,
    required DateTime start,
  }) async {
    switch (choice) {
      case ScheduleCreateChoice.event:
        await _openNewEvent(writableSources, start);
      case ScheduleCreateChoice.task:
        await _openNewTask(accounts, due: _day(start));
    }
  }

  void _recordSchedulePointer(PointerDownEvent event) {
    _recentSchedulePointerPosition = event.position;
    _recentSchedulePointerTime = _pointerAnchorClock.elapsed;
  }

  Offset? _takeRecentSchedulePointerPosition() {
    final position = _recentSchedulePointerPosition;
    final recordedAt = _recentSchedulePointerTime;
    _recentSchedulePointerPosition = null;
    _recentSchedulePointerTime = null;
    if (HardwareKeyboard.instance.logicalKeysPressed.isNotEmpty ||
        position == null ||
        recordedAt == null) {
      return null;
    }
    final age = _pointerAnchorClock.elapsed - recordedAt;
    return age <= _pointerAnchorLifetime ? position : null;
  }

  BuildContext _createChoiceAnchorContext() {
    final focusedContext = FocusManager.instance.primaryFocus?.context;
    if (focusedContext == null ||
        !focusedContext.mounted ||
        ModalRoute.of(focusedContext) != ModalRoute.of(context)) {
      return context;
    }
    final renderObject = focusedContext.findRenderObject();
    return renderObject is RenderBox && renderObject.hasSize
        ? focusedContext
        : context;
  }

  Future<void> _openNewEvent(
    List<CalendarSourceEntity> sources,
    DateTime start, {
    DateTime? end,
  }) async {
    final writableSources = writableCalendarSources(sources);
    if (writableSources.isEmpty) {
      return;
    }
    final settings = ref.read(appSettingsControllerProvider);
    final allWritableSources = writableCalendarSources(_searchSources);
    final source =
        preferredCreationDestination(
          allWritableSources,
          selected: settings.defaultCalendar,
          lastUsed: settings.lastUsedCalendar,
          destinationOf: (source) =>
              CreationDestination(accountId: source.accountId, id: source.id),
        ) ??
        writableSources.first;
    await _openEventEditor(
      EventEditorDraft.newEvent(
        accountId: source.accountId,
        sourceId: source.id,
        providerCalendarId: source.providerCalendarId,
        start: start,
        end: end ?? start.add(const Duration(hours: 1)),
      ).copyWith(
        startTimeZone: ref.read(localTimeZoneProvider),
        endTimeZone: ref.read(localTimeZoneProvider),
      ),
      allWritableSources.isEmpty ? writableSources : allWritableSources,
    );
  }

  Future<void> _openItem(
    BuildContext anchorContext,
    ScheduleItem item,
    List<CalendarSourceEntity> sources, {
    Offset? globalPosition,
  }) async {
    final locationDestination = resolveSavedScheduleLocation(
      item: item,
      repository: ref.read(locationResolutionRepositoryProvider),
    );
    final action = await showScheduleItemDetailsPopover(
      context: anchorContext,
      anchorContext: anchorContext,
      item: item,
      locationDestinationFuture: locationDestination,
      anchorPoint: globalPosition,
    );
    if (!mounted || action == null) {
      return;
    }
    switch (action) {
      case ScheduleItemDetailsAction.export:
        await _exportItem(item);
      case ScheduleItemDetailsAction.edit:
        if (item.capabilities.canEdit) {
          await _editItem(item, sources);
        }
      case ScheduleItemDetailsAction.delete:
        if (item.capabilities.canDelete) {
          await _deleteItem(item);
        }
      case ScheduleItemDetailsAction.joinMeeting:
        if (item is CalendarScheduleItem) {
          await _joinMeeting(item);
        }
      case ScheduleItemDetailsAction.attachments:
        if (item is CalendarScheduleItem) {
          await showLinuxEventAttachmentsDialog(context, item);
        }
      case ScheduleItemDetailsAction.acceptInvitation:
        if (item is CalendarScheduleItem) {
          await _respondToInvitation(item, CalendarInvitationResponse.accept);
        }
      case ScheduleItemDetailsAction.tentativeInvitation:
        if (item is CalendarScheduleItem) {
          await _respondToInvitation(
            item,
            CalendarInvitationResponse.tentative,
          );
        }
      case ScheduleItemDetailsAction.declineInvitation:
        if (item is CalendarScheduleItem) {
          await _respondToInvitation(item, CalendarInvitationResponse.decline);
        }
      case ScheduleItemDetailsAction.openLocation:
        await _openSavedLocation(await locationDestination);
    }
  }

  Future<void> _openSavedLocation(
    ExternalLocationDestination? destination,
  ) async {
    try {
      final launcher =
          widget.externalLocationLauncher ??
          ExternalLocationLauncher(
            platform: () => ExternalLocationPlatform.linux,
          );
      final result = await launcher.open(destination);
      if (result == ExternalLocationLaunchResult.opened) return;
    } on Object {
      // The external handoff is best-effort and never affects saved data.
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.l10n.externalLocationOpenFailed)),
      );
    }
  }

  Future<void> _editItem(
    ScheduleItem item,
    List<CalendarSourceEntity> sources,
  ) async {
    if (!item.capabilities.canEdit) {
      return;
    }
    if (item is CalendarScheduleItem) {
      final detail = await ref
          .read(calendarRepositoryProvider)
          .loadEventDetail(item.id);
      if (!mounted || detail == null) {
        return;
      }
      await _openEventEditor(EventEditorDraft.fromEventDetail(detail), sources);
      return;
    }
    if (item is TaskScheduleItem) {
      _openTaskDetails(item);
    }
  }

  Future<void> _exportItem(ScheduleItem item) async {
    try {
      String? rawICalendar;
      if (item is CalendarScheduleItem) {
        final repository = ref.read(calendarRepositoryProvider);
        final detail = await repository.loadEventDetail(item.id);
        final recurring =
            detail != null &&
            (detail.recurrence != null ||
                detail.providerRecurringEventId != null);
        final series =
            recurring &&
                canExportAuthoritativeEventSeries(
                  provider: item.provider,
                  providerEventId: item.providerEventId,
                  davCollectionId: detail.davCollectionId,
                )
            ? await _chooseSeriesExport()
            : false;
        if (series == null) return;
        if (series && item.provider == BusyProvider.google) {
          rawICalendar = await exportGoogleEventSeries(
            client: ref.read(
              googleCalendarApiClientForAccountProvider(item.accountId),
            ),
            calendarId: item.providerCalendarId,
            eventId: item.providerEventId!,
            nowUtc: DateTime.now().toUtc(),
          );
        } else if (series && item.provider == BusyProvider.microsoft) {
          rawICalendar = await exportMicrosoftEventSeries(
            client: ref.read(
              microsoftCalendarApiClientForAccountProvider(item.accountId),
            ),
            calendarId: item.providerCalendarId,
            eventId: item.providerEventId!,
            nowUtc: DateTime.now().toUtc(),
          );
        } else if (series || !recurring) {
          rawICalendar = await repository.nativeEventExport(item.id);
        }
      }
      if (item is TaskScheduleItem &&
          (item.provider == BusyProvider.nextcloud ||
              item.provider == BusyProvider.appleICloud)) {
        rawICalendar = await ref
            .read(tasksRepositoryForAccountProvider(item.accountId))
            .nativeTaskExport(item.sourceId, item.id);
      }
      final file = await exportScheduleItemWithSaveDialog(
        item,
        rawICalendar: rawICalendar,
      );
      if (file == null) {
        return;
      }
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.l10n.exportedFile(file.path))),
      );
    } on Object catch (error) {
      if (error is NetworkUnavailableException) {
        return;
      }
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.l10n.exportFailed(redactForLog(error)))),
      );
    }
  }

  Future<bool?> _chooseSeriesExport() => showBusyMaxModalEditorDialog<bool>(
    context,
    maxHeight: 300,
    builder: (dialogContext) => BusyMaxModalEditorScaffold(
      title: context.l10n.export,
      cancelLabel: context.l10n.cancel,
      saveLabel: context.l10n.export,
      onCancel: () => Navigator.of(dialogContext).pop(),
      onSave: null,
      children: [
        BusyMaxGroupedList(
          filled: true,
          children: [
            BusyMaxActionRow(
              title: context.l10n.singleOccurrence,
              onTap: () => Navigator.of(dialogContext).pop(false),
            ),
            BusyMaxActionRow(
              title: context.l10n.entireSeries,
              onTap: () => Navigator.of(dialogContext).pop(true),
            ),
          ],
        ),
      ],
    ),
  );

  void _openTaskDetails(TaskScheduleItem item) {
    unawaited(
      _openTaskDetailsTarget(
        _TaskDetailsTarget(
          accountId: item.accountId,
          taskListId: item.sourceId,
          taskId: item.id,
        ),
      ),
    );
  }

  Future<bool> _openTaskDetailsTarget(
    _TaskDetailsTarget target, {
    bool Function()? isRequestCurrent,
  }) async {
    if (_taskDetailsTarget == target) {
      _taskDetailsLifecycleGeneration += 1;
      _taskDetailsOverlayKey.currentState?.present();
      return true;
    }
    final replacingOpenTarget = _taskDetailsTarget != null;
    if (replacingOpenTarget && !await _confirmDiscardTaskDetails()) {
      return false;
    }
    if (!mounted || !(isRequestCurrent?.call() ?? true)) {
      return false;
    }
    _taskDetailsLifecycleGeneration += 1;
    setState(() {
      _taskDetailsTarget = target;
      _taskDetailsDirty = false;
    });
    _taskDetailsOverlayKey.currentState?.present();
    return true;
  }

  ScheduleTaskListKey? get _initialTaskListKey {
    final accountId = widget.initialTaskAccountId?.trim();
    final taskListId = widget.initialTaskListId?.trim();
    if (accountId == null ||
        accountId.isEmpty ||
        taskListId == null ||
        taskListId.isEmpty) {
      return null;
    }
    return ScheduleTaskListKey(accountId: accountId, taskListId: taskListId);
  }

  ScheduleTaskTarget? get _initialTaskRouteTarget {
    final listKey = _initialTaskListKey;
    final taskId = widget.initialTaskId?.trim();
    if (listKey == null || taskId == null || taskId.isEmpty) {
      return null;
    }
    return ScheduleTaskTarget(
      accountId: listKey.accountId,
      taskListId: listKey.taskListId,
      taskId: taskId,
    );
  }

  void _scheduleInitialTaskWatch() {
    final generation = ++_initialTaskWatchGeneration;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && generation == _initialTaskWatchGeneration) {
        unawaited(_startInitialTaskWatch(generation));
      }
    });
  }

  Future<void> _startInitialTaskWatch(int generation) async {
    final previousSubscription = _initialTaskTargetSubscription;
    _initialTaskTargetSubscription = null;
    if (!mounted || generation != _initialTaskWatchGeneration) {
      await previousSubscription?.cancel();
      return;
    }
    final request = _initialTaskRouteTarget;
    if (request == null) {
      await _reconcileTaskDetailsWithListRoute(generation);
      await previousSubscription?.cancel();
      return;
    }
    if (!await _reconcileTaskDetailsWithTaskRoute(request, generation)) {
      await previousSubscription?.cancel();
      return;
    }
    await previousSubscription?.cancel();
    if (!mounted || generation != _initialTaskWatchGeneration) {
      return;
    }
    _initialTaskTargetSubscription = ref
        .read(scheduleRepositoryProvider)
        .watchTaskTarget(
          accountId: request.accountId,
          taskListId: request.taskListId,
          taskId: request.taskId,
        )
        .listen((target) {
          if (target == null) {
            unawaited(_handleInitialTaskUnavailable(request, generation));
            return;
          }
          unawaited(_handleInitialTaskTarget(target, generation));
        });
  }

  Future<bool> _reconcileTaskDetailsWithTaskRoute(
    ScheduleTaskTarget request,
    int generation,
  ) async {
    final visibleTarget = _taskDetailsTarget;
    if (visibleTarget == null || visibleTarget.scheduleTarget == request) {
      return true;
    }
    if (!await _confirmDiscardTaskDetails()) {
      if (mounted &&
          generation == _initialTaskWatchGeneration &&
          _initialTaskRouteTarget == request) {
        _goToTaskRoute(visibleTarget);
      }
      return false;
    }
    if (!mounted ||
        generation != _initialTaskWatchGeneration ||
        _initialTaskRouteTarget != request ||
        _taskDetailsTarget != visibleTarget) {
      return false;
    }
    await _closeTaskDetails();
    return true;
  }

  Future<void> _reconcileTaskDetailsWithListRoute(int generation) async {
    final visibleTarget = _taskDetailsTarget;
    if (visibleTarget == null) {
      return;
    }
    if (!await _confirmDiscardTaskDetails()) {
      if (mounted &&
          generation == _initialTaskWatchGeneration &&
          _initialTaskRouteTarget == null) {
        _goToTaskRoute(visibleTarget);
      }
      return;
    }
    if (!mounted ||
        generation != _initialTaskWatchGeneration ||
        _initialTaskRouteTarget != null ||
        _taskDetailsTarget != visibleTarget) {
      return;
    }
    await _closeTaskDetails();
  }

  Future<void> _handleInitialTaskUnavailable(
    ScheduleTaskTarget request,
    int generation,
  ) async {
    final visibleTarget = _taskDetailsTarget;
    if (!mounted ||
        generation != _initialTaskWatchGeneration ||
        _initialTaskRouteTarget != request ||
        visibleTarget?.scheduleTarget != request) {
      return;
    }
    if (!await _confirmDiscardTaskDetails()) {
      return;
    }
    if (!mounted ||
        generation != _initialTaskWatchGeneration ||
        _initialTaskRouteTarget != request ||
        _taskDetailsTarget != visibleTarget) {
      return;
    }
    await _closeTaskDetails();
  }

  Future<void> _handleInitialTaskTarget(
    ScheduleTaskTarget target,
    int generation,
  ) async {
    if (!mounted ||
        generation != _initialTaskWatchGeneration ||
        _initialTaskHandled ||
        _initialTaskOpening ||
        _initialTaskRouteTarget != target) {
      return;
    }
    _initialTaskOpening = true;
    final detailsTarget = _TaskDetailsTarget(
      accountId: target.accountId,
      taskListId: target.taskListId,
      taskId: target.taskId,
    );
    final opened = await _openTaskDetailsTarget(
      detailsTarget,
      isRequestCurrent: () =>
          mounted &&
          generation == _initialTaskWatchGeneration &&
          _initialTaskRouteTarget == target,
    );
    if (!mounted || generation != _initialTaskWatchGeneration) {
      return;
    }
    _initialTaskOpening = false;
    if (opened) {
      _initialTaskHandled = true;
      return;
    }

    // A declined discard keeps the editor and URL as one atomic state.
    final visibleTarget = _taskDetailsTarget;
    if (visibleTarget != null && _initialTaskRouteTarget == target) {
      _goToTaskRoute(visibleTarget);
    }
  }

  Future<void> _requestCloseTaskDetails() async {
    if (!await _confirmDiscardTaskDetails()) {
      return;
    }
    await _closeTaskDetails();
  }

  Future<bool> _confirmDiscardTaskDetails() async {
    if (!_taskDetailsDirty) {
      return true;
    }
    return showBusyMaxConfirm(
      context,
      title: context.l10n.discardChanges,
      message: context.l10n.discardChangesConfirmation,
      confirmLabel: context.l10n.discardChangesAction,
      destructive: true,
      barrierColor: Colors.transparent,
    );
  }

  Future<void> _closeTaskDetails() {
    final pending = _taskDetailsDismissal;
    if (pending != null) return pending;
    final operation = _performTaskDetailsDismissal();
    _taskDetailsDismissal = operation;
    return operation.whenComplete(() {
      if (identical(_taskDetailsDismissal, operation)) {
        _taskDetailsDismissal = null;
      }
    });
  }

  Future<void> _performTaskDetailsDismissal() async {
    final target = _taskDetailsTarget;
    if (target == null) {
      return;
    }
    final generation = ++_taskDetailsLifecycleGeneration;
    await _taskDetailsOverlayKey.currentState?.dismiss();
    if (!mounted || generation != _taskDetailsLifecycleGeneration) return;
    setState(() {
      _taskDetailsTarget = null;
      _taskDetailsDirty = false;
    });
    if (!mounted || generation != _taskDetailsLifecycleGeneration) return;
    if (_initialTaskRouteTarget == target.scheduleTarget) {
      _goToTaskListRoute(target);
    }
  }

  void _goToTaskListRoute(_TaskDetailsTarget target) {
    GoRouter.maybeOf(context)?.go(
      _taskRouteLocation(
        accountId: target.accountId,
        taskListId: target.taskListId,
      ),
    );
  }

  void _goToTaskRoute(_TaskDetailsTarget target) {
    GoRouter.maybeOf(context)?.go(
      _taskRouteLocation(
        accountId: target.accountId,
        taskListId: target.taskListId,
        taskId: target.taskId,
      ),
    );
  }

  Future<void> _saveEvent(
    EventEditorDraft draft, {
    String? originalAccountId,
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
  }) async {
    await ref
        .read(calendarRepositoryProvider)
        .updateLocalEvent(draft, guestUpdatePolicy: guestUpdatePolicy);
    if (draft.eventId == null) {
      unawaited(
        ref
            .read(appSettingsControllerProvider.notifier)
            .rememberCalendar(
              CreationDestination(
                accountId: draft.accountId,
                id: draft.sourceId,
              ),
            ),
      );
    }
    final sourceAccountId = originalAccountId;
    if (sourceAccountId != null && sourceAccountId != draft.accountId) {
      unawaited(_syncMovedEvent(draft.accountId, sourceAccountId));
    } else {
      _requestCalendarMutationSync(draft.accountId);
    }
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _rescheduleEvent(
    ScheduleRescheduleRequest request,
    bool Function() isActive,
  ) async {
    try {
      final result = await ScheduleReschedulingCoordinator(
        repository: ref.read(calendarRepositoryProvider),
        chooseScope: (detail, following) => _chooseRecurringEventMutationScope(
          detail.provider,
          editing: true,
          supportsFollowingOverride: following,
        ),
        chooseGuestUpdates: (draft) => showCalendarGuestDeliveryDialog(
          context,
          provider: request.item.provider,
          action: CalendarGuestDeliveryAction.save,
        ),
        requestSync: (accountId) async => ref
            .read(
              pendingCalendarMutationSyncRequesterForAccountProvider(accountId),
            )
            .request(),
      ).commit(request, isActive: () => mounted && isActive());
      if (!mounted) return;
      setState(() {});
      if (result == ScheduleRescheduleResult.savedWithNotificationFailure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(context.l10n.scheduleRescheduleNotificationsFailed),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            error is StaleEventTiming
                ? context.l10n.scheduleRescheduleStale
                : context.l10n.scheduleRescheduleFailed,
          ),
        ),
      );
      setState(() {});
    }
  }

  void _requestCalendarMutationSync(String accountId) {
    unawaited(() async {
      await _syncCalendarMutation(accountId);
    }());
  }

  Future<bool> _syncCalendarMutation(String accountId) async {
    try {
      final account = await ref
          .read(accountsRepositoryProvider)
          .accountById(accountId);
      if (account?.isSyncEligible != true) {
        throw AccountNotSyncEligibleException(
          needsReconnect: account?.needsReconnect == true,
        );
      }
      await ref
          .read(accountSyncOperationsProvider)
          .syncCalendar(accountId, full: false);
      return true;
    } on Object catch (error) {
      if (!mounted) {
        return false;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.l10n.refreshFailed(
              syncFailureMessage(
                error,
                networkUnavailableMessage: context.l10n.networkOfflineTryAgain,
              ),
            ),
          ),
        ),
      );
      return false;
    }
  }

  Future<void> _syncMovedEvent(
    String destinationAccountId,
    String sourceAccountId,
  ) async {
    final destinationSynced = await _syncCalendarMutation(destinationAccountId);
    if (destinationSynced) {
      await _syncCalendarMutation(sourceAccountId);
    }
  }

  Future<void> _openEventEditor(
    EventEditorDraft draft,
    List<CalendarSourceEntity> sources,
  ) async {
    final editableSources = writableCalendarSources(sources);
    if (editableSources.every((source) => source.id != draft.sourceId)) {
      return;
    }
    final result = await showBusyMaxEventEditorDialog(
      context,
      initialDraft: draft,
      sources: editableSources,
      accounts: _latestAccounts,
      categorySuggestionsByAccount: _categorySuggestionsByAccount(),
    );
    if (!mounted || result == null) {
      return;
    }
    final deletedEventId = result.deletedEventId;
    if (deletedEventId != null) {
      await _deleteEvent(
        deletedEventId,
        recurringScope: result.deletionScope,
        guestUpdatePolicy: result.guestUpdatePolicy,
      );
      return;
    }
    final savedDraft = result.draft;
    if (savedDraft != null) {
      await _saveEvent(
        savedDraft,
        originalAccountId: draft.accountId,
        guestUpdatePolicy: result.guestUpdatePolicy,
      );
    }
  }

  Future<void> _deleteEvent(
    String eventId, {
    RecurringEventMutationScope? recurringScope,
    CalendarGuestUpdatePolicy guestUpdatePolicy =
        CalendarGuestUpdatePolicy.send,
  }) async {
    final accountId = await ref
        .read(calendarRepositoryProvider)
        .deleteLocalEvent(
          eventId,
          recurringScope: recurringScope,
          guestUpdatePolicy: guestUpdatePolicy,
        );
    _requestCalendarMutationSync(accountId);
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _deleteItem(ScheduleItem item) async {
    if (!item.capabilities.canDelete) {
      return;
    }
    RecurringEventMutationScope? recurringScope;
    if (item is CalendarScheduleItem && item.providerRecurringEventId != null) {
      recurringScope = await _chooseRecurringEventMutationScope(
        item.provider,
        supportsFollowingOverride: item.isNextcloudAttendee ? false : null,
      );
      if (recurringScope == null || !mounted) return;
    }
    var guestUpdatePolicy = CalendarGuestUpdatePolicy.send;
    if (item is CalendarScheduleItem &&
        item.isOrganizer == true &&
        _calendarItemHasExternalGuests(item)) {
      final choice = await showCalendarGuestDeliveryDialog(
        context,
        provider: item.provider,
        action: CalendarGuestDeliveryAction.delete,
      );
      if (choice == null) return;
      guestUpdatePolicy = choice;
    } else {
      final confirmed = await showBusyMaxConfirm(
        context,
        title: item is CalendarScheduleItem
            ? item.isNextcloudAttendee
                  ? context.l10n.nextcloudDeclineAndRemove
                  : context.l10n.deleteEvent
            : context.l10n.deleteTask,
        message: item is CalendarScheduleItem && item.isNextcloudAttendee
            ? context.l10n.nextcloudDeclineRemovalWarning
            : item is TaskScheduleItem
            ? item.isAssigned
                  ? '${context.l10n.deleteTaskConfirmation(item.title)}\n\n${context.l10n.deleteAssignedTaskWarning}'
                  : context.l10n.deleteTaskConfirmation(item.title)
            : context.l10n.deleteCalendarConfirmation(item.title),
        confirmLabel: item is CalendarScheduleItem && item.isNextcloudAttendee
            ? context.l10n.nextcloudDeclineAndRemove
            : context.l10n.delete,
        destructive: true,
      );
      if (!confirmed) return;
    }
    if (item is CalendarScheduleItem) {
      await _deleteEvent(
        item.id,
        recurringScope: recurringScope,
        guestUpdatePolicy: guestUpdatePolicy,
      );
      return;
    }
    if (item is TaskScheduleItem) {
      final intent = TaskListMutationIntent(
        presentation: TaskListMutationPresentation.removal,
        accountId: item.accountId,
        taskListId: item.sourceId,
        taskId: item.id,
        generation: ++_taskListMutationGeneration,
      );
      setState(() => _taskListMutationIntent = intent);
      try {
        await ref
            .read(tasksRepositoryForAccountProvider(item.accountId))
            .deleteTask(
              item.sourceId,
              item.id,
              confirmedAssignedSourceDeletion: item.isAssigned,
            );
        if (mounted) setState(() {});
      } on Object {
        if (mounted &&
            _taskListMutationIntent?.generation == intent.generation) {
          setState(() => _taskListMutationIntent = null);
        }
        rethrow;
      }
    }
  }

  Future<void> _respondToInvitation(
    CalendarScheduleItem item,
    CalendarInvitationResponse response,
  ) async {
    if (!item.canRespondToInvitation) return;
    try {
      RecurringEventMutationScope? scope;
      if (item.provider == BusyProvider.nextcloud &&
          item.providerRecurringEventId != null) {
        scope = await _chooseRecurringEventMutationScope(
          item.provider,
          editing: true,
          supportsFollowingOverride: false,
        );
        if (scope == null || !mounted) return;
      }
      final accountId = await ref
          .read(calendarRepositoryProvider)
          .respondToLocalEvent(item.id, response, recurringScope: scope);
      _requestCalendarMutationSync(accountId);
      if (mounted) setState(() {});
    } on Object catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.l10n.invitationResponseFailed(redactForLog(error)),
          ),
        ),
      );
    }
  }

  Future<void> _joinMeeting(CalendarScheduleItem item) async {
    final opened = await openScheduleWebLink(item.joinMeetingUrl);
    if (!opened && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.l10n.joinMeetingFailed)));
    }
  }

  Future<RecurringEventMutationScope?> _chooseRecurringEventMutationScope(
    BusyProvider provider, {
    bool editing = false,
    bool? supportsFollowingOverride,
  }) {
    final supportsFollowing =
        supportsFollowingOverride ??
        supportsThisAndFollowingEventMutation(provider);
    return showBusyMaxModalEditorDialog<RecurringEventMutationScope>(
      context,
      maxHeight: 420,
      builder: (dialogContext) => BusyMaxModalEditorScaffold(
        title: context.l10n.recurringEventScope,
        cancelLabel: context.l10n.cancel,
        saveLabel: editing ? context.l10n.save : context.l10n.delete,
        onCancel: () => Navigator.of(dialogContext).pop(),
        onSave: null,
        children: [
          BusyMaxGroupedList(
            filled: true,
            children: [
              BusyMaxActionRow(
                title: context.l10n.singleOccurrence,
                subtitle: context.l10n.chooseRecurringEventScope,
                leading: const Icon(Icons.event_outlined),
                onTap: () => Navigator.of(
                  dialogContext,
                ).pop(RecurringEventMutationScope.singleOccurrence),
              ),
              BusyMaxActionRow(
                title: context.l10n.thisAndFollowingEvents,
                subtitle: supportsFollowing
                    ? null
                    : context.l10n.thisAndFutureUnavailable,
                leading: Icon(
                  supportsFollowing
                      ? Icons.update_outlined
                      : Icons.update_disabled_outlined,
                ),
                enabled: supportsFollowing,
                onTap: supportsFollowing
                    ? () => Navigator.of(
                        dialogContext,
                      ).pop(RecurringEventMutationScope.thisAndFuture)
                    : null,
              ),
              BusyMaxActionRow(
                title: context.l10n.entireSeries,
                leading: const Icon(Icons.repeat),
                onTap: () => Navigator.of(
                  dialogContext,
                ).pop(RecurringEventMutationScope.entireSeries),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _openNewTask(
    List<AccountEntity> accounts, {
    DateTime? due,
  }) async {
    if (accounts.isEmpty) {
      return;
    }
    TaskListEntity? initialList;
    final routedListKey = _initialTaskListKey;
    if (routedListKey != null) {
      for (final list in _latestVisibleTaskLists) {
        if (list.accountId == routedListKey.accountId &&
            list.id == routedListKey.taskListId) {
          initialList = list;
          break;
        }
      }
      if (initialList == null &&
          accounts.any((account) => account.id == routedListKey.accountId)) {
        final routedAccountLists = await ref
            .read(
              taskListsRepositoryForAccountProvider(routedListKey.accountId),
            )
            .listTaskLists();
        if (!mounted) {
          return;
        }
        for (final list in routedAccountLists) {
          if (list.id == routedListKey.taskListId) {
            initialList = list;
            break;
          }
        }
      }
    }
    if (initialList == null) {
      final settings = ref.read(appSettingsControllerProvider);
      initialList = preferredCreationDestination(
        _searchTaskLists.where((list) => !list.pendingDelete),
        selected: settings.defaultTaskList,
        lastUsed: settings.lastUsedTaskList,
        destinationOf: (list) =>
            CreationDestination(accountId: list.accountId, id: list.id),
      );
    }
    final draft = await showBusyMaxNewTaskDialog(
      context,
      ref: ref,
      accounts: accounts,
      initialAccountId:
          initialList?.accountId ?? ref.read(activeAccountProvider),
      initialListId: initialList?.id,
      initialDueUtc: due,
    );
    if (draft == null) {
      return;
    }
    final taskId = await ref
        .read(tasksRepositoryForAccountProvider(draft.accountId))
        .createTask(draft.taskListId, draft.input);
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .rememberTaskList(
            CreationDestination(
              accountId: draft.accountId,
              id: draft.taskListId,
            ),
          ),
    );
    if (mounted) {
      setState(() {
        _taskListMutationIntent = TaskListMutationIntent(
          presentation: TaskListMutationPresentation.insertion,
          accountId: draft.accountId,
          taskListId: draft.taskListId,
          taskId: taskId,
          generation: ++_taskListMutationGeneration,
        );
      });
    }
  }

  Map<String, List<String>> _categorySuggestionsByAccount() {
    final byAccount = <String, Set<String>>{};
    for (final item in _latestItems) {
      if (item.categories.isEmpty) {
        continue;
      }
      byAccount
          .putIfAbsent(item.accountId, () => <String>{})
          .addAll(
            item.categories.where((category) => category.trim().isNotEmpty),
          );
    }
    return {
      for (final entry in byAccount.entries)
        entry.key: entry.value.toList()
          ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase())),
    };
  }

  Future<void> _setTaskCompleted(TaskScheduleItem item, bool completed) async {
    final fields = <String, Object?>{
      'status': completed ? 'completed' : 'needsAction',
      'completed': completed ? DateTime.now().toUtc().toIso8601String() : null,
    };
    final intent = TaskListMutationIntent(
      presentation: TaskListMutationPresentation.completion,
      accountId: item.accountId,
      taskListId: item.sourceId,
      taskId: item.id,
      completed: completed,
      generation: ++_taskListMutationGeneration,
    );
    setState(() => _taskListMutationIntent = intent);
    try {
      await ref
          .read(tasksRepositoryForAccountProvider(item.accountId))
          .patchTask(item.sourceId, item.id, TaskPatchInput(fields));
    } on Object {
      if (mounted && _taskListMutationIntent?.generation == intent.generation) {
        setState(() => _taskListMutationIntent = null);
      }
      rethrow;
    }
  }

  void _handleEditorTaskMutation(TaskMutationResult result) {
    if (!mounted) return;
    final createdId = result.createdTaskId;
    setState(() {
      _taskListMutationIntent = TaskListMutationIntent(
        presentation: switch (result.kind) {
          TaskMutationKind.deleted => TaskListMutationPresentation.removal,
          TaskMutationKind.moved => TaskListMutationPresentation.removal,
          TaskMutationKind.duplicated => TaskListMutationPresentation.insertion,
          TaskMutationKind.completion =>
            TaskListMutationPresentation.completion,
          _ => TaskListMutationPresentation.completion,
        },
        accountId: result.accountId,
        taskListId: result.taskListId,
        taskId: createdId ?? result.taskId,
        checklistItemId: result.checklistItemId,
        completed: result.completed,
        generation: ++_taskListMutationGeneration,
      );
    });
  }

  Future<void> _setChecklistItemCompleted(
    TaskScheduleItem parent,
    TaskChecklistItemEntity item,
    bool completed,
  ) async {
    final intent = TaskListMutationIntent(
      presentation: TaskListMutationPresentation.completion,
      accountId: parent.accountId,
      taskListId: parent.sourceId,
      taskId: parent.id,
      checklistItemId: item.id,
      completed: completed,
      generation: ++_taskListMutationGeneration,
    );
    setState(() => _taskListMutationIntent = intent);
    try {
      await ref
          .read(tasksRepositoryForAccountProvider(parent.accountId))
          .patchChecklistSubtask(
            taskListId: parent.sourceId,
            parentTaskId: parent.id,
            checklistItemId: item.id,
            completed: completed,
          );
    } on Object catch (error) {
      if (!mounted) return;
      if (_taskListMutationIntent?.generation == intent.generation) {
        setState(() => _taskListMutationIntent = null);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.l10n.syncFailed(
              syncFailureMessage(
                error,
                networkUnavailableMessage: context.l10n.networkOfflineTryAgain,
              ),
            ),
          ),
        ),
      );
    }
  }

  Future<void> _refreshAll() async {
    try {
      final accounts = await ref
          .read(accountsRepositoryProvider)
          .listSyncEligibleAccounts();
      if (accounts.isEmpty) {
        return;
      }
      await ref.read(allAccountsSyncRunnerProvider)();
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.l10n.allTasksRefreshed)));
    } on Object catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.l10n.refreshFailed(
              syncFailureMessage(
                error,
                networkUnavailableMessage: context.l10n.networkOfflineTryAgain,
              ),
            ),
          ),
        ),
      );
    }
  }

  void _retrySchedule() {
    ref.invalidate(accountsStreamProvider);
    setState(() {});
  }

  void _consumePendingCommand(
    List<CalendarSourceEntity> sources,
    List<AccountEntity> accounts,
    List<CalendarSourceEntity> notificationSources,
  ) {
    final command = ref.watch(scheduleWorkspaceCommandProvider);
    if (command == null) {
      return;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      ref.read(scheduleWorkspaceCommandProvider.notifier).state = null;
      switch (command.kind) {
        case ScheduleWorkspaceCommandKind.today:
          _goToToday();
        case ScheduleWorkspaceCommandKind.agenda:
          _setMode(ScheduleViewMode.agenda, agendaDate: command.date);
        case ScheduleWorkspaceCommandKind.newEvent:
          unawaited(_openNewEvent(sources, _selectedDate));
        case ScheduleWorkspaceCommandKind.newTask:
          unawaited(_openNewTask(accounts));
        case ScheduleWorkspaceCommandKind.openDate:
          _openCommandDate(command.date);
        case ScheduleWorkspaceCommandKind.openCalendarEvent:
          _queueAnchoredCommand(command, notificationSources);
        case ScheduleWorkspaceCommandKind.openTask:
          _queueAnchoredCommand(command, notificationSources);
      }
    });
  }

  void _queueAnchoredCommand(
    ScheduleWorkspaceCommand command,
    List<CalendarSourceEntity> sources,
  ) {
    _pendingAnchoredCommand = command;
    _pendingAnchoredSources = List<CalendarSourceEntity>.unmodifiable(sources);
    setState(() {
      _revealedNotificationTarget = command;
      _scope = ScheduleScope.all;
      _searchActive = false;
      _sidebarCollapsed = _sidebarBeforeSearch ?? _sidebarCollapsed;
      _sidebarBeforeSearch = null;
      _searchCriteria = null;
      _initialSearchCriteria = null;
      _searchQuery = '';
      _searchController.clear();
    });
    _openCommandDate(command.date ?? DateTime.now());
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _tryOpenPendingAnchoredCommand();
      }
    });
  }

  void _handleItemAnchorAvailable(ScheduleItem item, BuildContext context) {
    _itemAnchorContexts[_itemAnchorKey(item)] = context;
    _tryOpenPendingAnchoredCommand();
  }

  void _tryOpenPendingAnchoredCommand() {
    if (!mounted) {
      return;
    }
    final command = _pendingAnchoredCommand;
    if (command == null) {
      return;
    }
    final item = _findLatestCommandItem(command);
    if (item == null) {
      return;
    }
    final anchorContext = _itemAnchorContexts[_itemAnchorKey(item)];
    if (anchorContext == null || !anchorContext.mounted) {
      return;
    }
    final sources = _pendingAnchoredSources;
    _pendingAnchoredCommand = null;
    _pendingAnchoredSources = const <CalendarSourceEntity>[];
    unawaited(
      _openRevealedNotificationItem(anchorContext, item, sources, command),
    );
  }

  Future<void> _openRevealedNotificationItem(
    BuildContext anchorContext,
    ScheduleItem item,
    List<CalendarSourceEntity> sources,
    ScheduleWorkspaceCommand command,
  ) async {
    try {
      await _openItem(anchorContext, item, sources);
    } finally {
      if (mounted && _revealedNotificationTarget == command) {
        setState(() => _revealedNotificationTarget = null);
      }
    }
  }

  ScheduleItem? _findLatestCommandItem(ScheduleWorkspaceCommand command) {
    return switch (command.kind) {
      ScheduleWorkspaceCommandKind.openCalendarEvent =>
        _findCommandItem<CalendarScheduleItem>(_latestItems, command),
      ScheduleWorkspaceCommandKind.openTask =>
        _findCommandItem<TaskScheduleItem>(_latestItems, command),
      _ => null,
    };
  }

  void _openCommandDate(DateTime? date) {
    if (date == null) {
      return;
    }
    setState(() {
      if (_scope == ScheduleScope.today || _scope == ScheduleScope.upcoming) {
        _scope = ScheduleScope.all;
      }
      _selectedDate = _day(date);
      _mode = ScheduleViewMode.day;
      _lastSettingsMode = ScheduleViewMode.day;
    });
    unawaited(
      ref
          .read(appSettingsControllerProvider.notifier)
          .setScheduleViewMode(ScheduleViewMode.day),
    );
  }
}

String _itemAnchorKey(ScheduleItem item) {
  return '${item.kind.name}:${item.accountId}:${item.sourceId}:${item.id}';
}

T? _findCommandItem<T extends ScheduleItem>(
  List<ScheduleItem> items,
  ScheduleWorkspaceCommand command,
) {
  for (final item in items) {
    if (item is T && command.matchesItem(item)) {
      return item;
    }
  }
  return null;
}

class _ScheduleItemsResult {
  const _ScheduleItemsResult({
    required this.items,
    this.hasMoreOverdueTasks = false,
    this.hasMoreNoDateTasks = false,
  });

  final List<ScheduleItem> items;
  final bool hasMoreOverdueTasks;
  final bool hasMoreNoDateTasks;
}

class _ScheduleBody extends StatelessWidget {
  const _ScheduleBody({
    required this.isLoading,
    required this.isUnavailable,
    required this.mode,
    required this.range,
    required this.selectedDate,
    required this.firstWeekday,
    required this.dayStartMinute,
    required this.dayEndMinute,
    required this.hasAnySources,
    required this.hasAccounts,
    required this.items,
    required this.onOpenSettings,
    required this.onRetry,
    required this.onRefresh,
    required this.onDaySelected,
    required this.onYearDaySelected,
    required this.onMonthSelected,
    required this.onWeekSelected,
    required this.onEmptySlot,
    required this.onRangeCreated,
    required this.onReschedule,
    required this.onCreateAtDay,
    required this.onNewEvent,
    required this.onNewTask,
    required this.onPrevious,
    required this.onNext,
    required this.onAgendaLoadMore,
    required this.hasMoreAgendaOverdueTasks,
    required this.hasMoreAgendaNoDateTasks,
    required this.onAgendaLoadMoreOverdue,
    required this.onAgendaLoadMoreNoDate,
    required this.onItemSelected,
    required this.onItemAnchorAvailable,
    required this.onTaskCompletionChanged,
    required this.onChecklistItemCompletionChanged,
    required this.canCreateEvent,
    required this.canCreateTask,
    required this.searchActive,
    this.navigationIntent,
    this.taskListMutationIntent,
    this.onTaskListMutationConsumed,
    this.searchCriteria,
    this.searchQuery = '',
  });

  final bool isLoading;
  final bool isUnavailable;
  final ScheduleViewMode mode;
  final ScheduleRange range;
  final DateTime selectedDate;
  final int firstWeekday;
  final int dayStartMinute;
  final int dayEndMinute;
  final bool hasAnySources;
  final bool hasAccounts;
  final List<ScheduleItem> items;
  final VoidCallback onOpenSettings;
  final VoidCallback onRetry;
  final VoidCallback? onRefresh;
  final ValueChanged<DateTime> onDaySelected;
  final ValueChanged<DateTime> onYearDaySelected;
  final ValueChanged<DateTime> onMonthSelected;
  final ValueChanged<DateTime> onWeekSelected;
  final ValueChanged<DateTime> onEmptySlot;
  final ValueChanged<ScheduleInterval>? onRangeCreated;
  final ScheduleRescheduleCallback onReschedule;
  final ScheduleDayCreateCallback onCreateAtDay;
  final VoidCallback onNewEvent;
  final VoidCallback onNewTask;
  final VoidCallback onPrevious;
  final VoidCallback onNext;
  final VoidCallback? onAgendaLoadMore;
  final bool hasMoreAgendaOverdueTasks;
  final bool hasMoreAgendaNoDateTasks;
  final VoidCallback? onAgendaLoadMoreOverdue;
  final VoidCallback? onAgendaLoadMoreNoDate;
  final ScheduleItemSelectionCallback onItemSelected;
  final ScheduleItemAnchorCallback onItemAnchorAvailable;
  final void Function(TaskScheduleItem item, bool completed)
  onTaskCompletionChanged;
  final void Function(
    TaskScheduleItem parent,
    TaskChecklistItemEntity item,
    bool completed,
  )
  onChecklistItemCompletionChanged;
  final bool canCreateEvent;
  final bool canCreateTask;
  final bool searchActive;
  final ScheduleNavigationIntent? navigationIntent;
  final TaskListMutationIntent? taskListMutationIntent;
  final ValueChanged<TaskListMutationIntent>? onTaskListMutationConsumed;
  final ScheduleSearchCriteria? searchCriteria;
  final String searchQuery;

  @override
  Widget build(BuildContext context) {
    if (isUnavailable) {
      return ScheduleUnavailableState(onRetry: onRetry);
    }
    if (isLoading) {
      return const ScheduleLoadingState();
    }
    if (hasAccounts && !hasAnySources && !searchActive) {
      return ScheduleNoSourcesState(
        onOpenSettings: onOpenSettings,
        onRefresh: onRefresh,
      );
    }
    final modeView = BusyMaxKeyedCrossfade(
      transitionKey: mode,
      child: switch (mode) {
        ScheduleViewMode.day => ScheduleDayWeekView(
          key: const ValueKey('schedule-day-planner'),
          range: range,
          selectedDate: selectedDate,
          daysShowed: 1,
          dayStartMinute: dayStartMinute,
          dayEndMinute: dayEndMinute,
          items: items,
          onDaySelected: onDaySelected,
          onEmptySlot: onEmptySlot,
          onRangeCreated: onRangeCreated,
          onReschedule: onReschedule,
          onItemSelected: onItemSelected,
          onTaskCompletionChanged: onTaskCompletionChanged,
          navigationIntent: navigationIntent,
        ),
        ScheduleViewMode.week => ScheduleDayWeekView(
          key: const ValueKey('schedule-week-planner'),
          range: range,
          selectedDate: selectedDate,
          daysShowed: 7,
          dayStartMinute: dayStartMinute,
          dayEndMinute: dayEndMinute,
          items: items,
          onDaySelected: onDaySelected,
          onEmptySlot: onEmptySlot,
          onRangeCreated: onRangeCreated,
          onReschedule: onReschedule,
          onItemSelected: onItemSelected,
          onTaskCompletionChanged: onTaskCompletionChanged,
          navigationIntent: navigationIntent,
        ),
        ScheduleViewMode.month => _HorizontalSchedulePager(
          onPrevious: onPrevious,
          onNext: onNext,
          child: ScheduleMonthView(
            range: range,
            selectedDate: selectedDate,
            items: items,
            firstWeekday: firstWeekday,
            onDaySelected: onDaySelected,
            onCreateAtDay: onCreateAtDay,
            onReschedule: onReschedule,
            onItemSelected: onItemSelected,
            onTaskCompletionChanged: onTaskCompletionChanged,
          ),
        ),
        ScheduleViewMode.year => _HorizontalSchedulePager(
          onPrevious: onPrevious,
          onNext: onNext,
          child: ScheduleYearView(
            selectedDate: selectedDate,
            items: items,
            firstWeekday: firstWeekday,
            onDaySelected: onYearDaySelected,
            onMonthSelected: onMonthSelected,
            onWeekSelected: onWeekSelected,
            onCreateAtDay: (day) => onCreateAtDay(day),
          ),
        ),
        ScheduleViewMode.agenda => ScheduleAgendaView(
          searchCriteria: searchCriteria,
          searchQuery: searchQuery,
          range: range,
          items: items,
          hasMoreOverdueTasks: hasMoreAgendaOverdueTasks,
          hasMoreNoDateTasks: hasMoreAgendaNoDateTasks,
          onLoadMore: onAgendaLoadMore,
          onLoadMoreOverdue: onAgendaLoadMoreOverdue,
          onLoadMoreNoDate: onAgendaLoadMoreNoDate,
          onItemSelected: onItemSelected,
          onItemAnchorAvailable: onItemAnchorAvailable,
          onTaskCompletionChanged: onTaskCompletionChanged,
          onChecklistItemCompletionChanged: onChecklistItemCompletionChanged,
          taskListMutationIntent: taskListMutationIntent,
          onTaskListMutationConsumed: onTaskListMutationConsumed,
          emptyBuilder: searchActive
              ? (context) => searchCriteria?.hasSources == false
                    ? Center(child: Text(context.l10n.searchNoSources))
                    : const ScheduleSearchEmptyState()
              : (context) => ScheduleEmptyState(
                  onNewEvent: canCreateEvent ? onNewEvent : null,
                  onNewTask: canCreateTask ? onNewTask : null,
                ),
        ),
      },
    );
    final intent = navigationIntent;
    if (mode == ScheduleViewMode.month || mode == ScheduleViewMode.year) {
      final adjacent = intent?.cause == ScheduleNavigationCause.adjacentPeriod
          ? intent
          : null;
      return BusyMaxDirectionalSwitcher(
        generation: adjacent?.generation ?? 0,
        direction: adjacent?.direction ?? 0,
        child: modeView,
      );
    }
    return modeView;
  }
}

class _HorizontalSchedulePager extends StatelessWidget {
  const _HorizontalSchedulePager({
    required this.child,
    required this.onPrevious,
    required this.onNext,
  });

  final Widget child;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragEnd: (details) {
        final velocity = details.primaryVelocity;
        if (velocity == null || velocity.abs() < 250) {
          return;
        }
        if (velocity < 0) {
          onNext();
        } else {
          onPrevious();
        }
      },
      child: child,
    );
  }
}

class _ScheduleTaskDetailsOverlay extends StatefulWidget {
  const _ScheduleTaskDetailsOverlay({
    super.key,
    required this.child,
    required this.target,
    required this.onClose,
    required this.onWindowCloseRequested,
    required this.onDirtyChanged,
    required this.onMutationCommitted,
  });

  final Widget child;
  final _TaskDetailsTarget? target;
  final VoidCallback onClose;
  final BusyMaxWindowCloseHandler onWindowCloseRequested;
  final ValueChanged<bool> onDirtyChanged;
  final ValueChanged<TaskMutationResult> onMutationCommitted;

  @override
  State<_ScheduleTaskDetailsOverlay> createState() =>
      _ScheduleTaskDetailsOverlayState();
}

class _ScheduleTaskDetailsOverlayState
    extends State<_ScheduleTaskDetailsOverlay>
    with SingleTickerProviderStateMixin {
  final _modalFocusNode = FocusNode(debugLabel: 'scheduleTaskDetails');
  FocusNode? _previousFocus;
  late final AnimationController _controller = AnimationController(
    vsync: this,
    animationBehavior: AnimationBehavior.preserve,
    value: widget.target == null ? 0 : 1,
  );
  _TaskDetailsTarget? _displayedTarget;
  bool _exiting = false;
  bool _disableAnimations = false;

  @override
  void initState() {
    super.initState();
    if (widget.target != null) {
      _displayedTarget = widget.target;
      _previousFocus = FocusManager.instance.primaryFocus;
      _requestEditorFocus();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final disabled = MediaQuery.disableAnimationsOf(context);
    if (disabled != _disableAnimations) {
      _disableAnimations = disabled;
      if (disabled) {
        _controller.value = _exiting || widget.target == null ? 0 : 1;
      }
    }
  }

  @override
  void didUpdateWidget(covariant _ScheduleTaskDetailsOverlay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.target == null && widget.target != null) {
      _displayedTarget = widget.target;
      _exiting = false;
      _previousFocus = FocusManager.instance.primaryFocus;
      _requestEditorFocus();
      present();
    } else if (oldWidget.target != widget.target && widget.target != null) {
      _displayedTarget = widget.target;
      _exiting = false;
      _requestEditorFocus();
      present();
    } else if (oldWidget.target != null && widget.target == null) {
      _displayedTarget = null;
      _exiting = false;
      final previousFocus = _previousFocus;
      _previousFocus = null;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted &&
            widget.target == null &&
            (previousFocus?.context?.mounted ?? false)) {
          previousFocus!.requestFocus();
        }
      });
    }
  }

  void _requestEditorFocus() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && widget.target != null && !_exiting) {
        _modalFocusNode.requestFocus();
      }
    });
  }

  void present() {
    _exiting = false;
    if (_disableAnimations) {
      _controller.value = 1;
      return;
    }
    final distance = (1 - _controller.value).abs();
    if (distance == 0) return;
    _controller.animateTo(
      1,
      duration: BusyMaxMotion.taskEditorOpen * distance,
      curve: BusyMaxMotion.presentationCurve,
    );
  }

  Future<void> dismiss() async {
    if (_displayedTarget == null) return;
    if (mounted) setState(() => _exiting = true);
    if (_disableAnimations) {
      _controller.value = 0;
      return;
    }
    final distance = _controller.value.abs();
    if (distance == 0) return;
    try {
      await _controller
          .animateBack(
            0,
            duration: BusyMaxMotion.taskEditorClose * distance,
            curve: BusyMaxMotion.presentationCurve,
          )
          .orCancel;
    } on TickerCanceled {
      // A new editor request reversed the dismissal from its current value.
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _modalFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final target = _displayedTarget ?? widget.target;
    final modalActive = target != null;
    final editor = target == null
        ? const SizedBox.shrink()
        : BlockSemantics(
            child: Semantics(
              scopesRoute: true,
              namesRoute: true,
              label: context.l10n.editTask,
              explicitChildNodes: true,
              child: BusyMaxModalShortcutBoundary(
                child: Shortcuts(
                  shortcuts: const {
                    BusyMaxShortcutActivators.dismiss: DismissIntent(),
                  },
                  child: Actions(
                    actions: {
                      DismissIntent: CallbackAction<DismissIntent>(
                        onInvoke: (_) {
                          widget.onClose();
                          return null;
                        },
                      ),
                    },
                    child: FocusTraversalGroup(
                      policy: WidgetOrderTraversalPolicy(),
                      child: Focus(
                        autofocus: true,
                        focusNode: _modalFocusNode,
                        child: Center(
                          child: BusyMaxModalEditorSurface(
                            maxWidth: BusyMaxSizes.compactDetailsWidth,
                            maxHeight: 760,
                            child: BusyMaxWindowCloseGuard(
                              onCloseRequested: widget.onWindowCloseRequested,
                              child: TaskDetailsPane(
                                key: ValueKey(target),
                                accountId: target.accountId,
                                taskListId: target.taskListId,
                                taskId: target.taskId,
                                onClose: widget.onClose,
                                onDirtyChanged: widget.onDirtyChanged,
                                onTaskMutationCommitted:
                                    widget.onMutationCommitted,
                                dialogBarrierColor: Colors.transparent,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
    return AnimatedBuilder(
      animation: _controller,
      child: widget.child,
      builder: (context, child) => Stack(
        children: [
          ExcludeFocus(
            excluding: modalActive,
            child: ExcludeSemantics(excluding: modalActive, child: child!),
          ),
          if (modalActive) ...[
            ModalBarrier(
              color: busyMaxModalBarrierColor(context).withValues(
                alpha: busyMaxModalBarrierColor(context).a * _controller.value,
              ),
              dismissible: false,
            ),
            IgnorePointer(
              ignoring: _exiting,
              child: ExcludeFocus(
                excluding: _exiting,
                child: ExcludeSemantics(
                  excluding: _exiting,
                  child: Opacity(
                    opacity: _controller.value,
                    child: Transform.scale(
                      scale: .985 + .015 * _controller.value,
                      child: editor,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _TaskDetailsTarget {
  const _TaskDetailsTarget({
    required this.accountId,
    required this.taskListId,
    required this.taskId,
  });

  final String accountId;
  final String taskListId;
  final String taskId;

  ScheduleTaskTarget get scheduleTarget => ScheduleTaskTarget(
    accountId: accountId,
    taskListId: taskListId,
    taskId: taskId,
  );

  @override
  bool operator ==(Object other) {
    return other is _TaskDetailsTarget &&
        other.accountId == accountId &&
        other.taskListId == taskListId &&
        other.taskId == taskId;
  }

  @override
  int get hashCode => Object.hash(accountId, taskListId, taskId);
}

String _taskRouteLocation({
  required String accountId,
  required String taskListId,
  String? taskId,
}) {
  return Uri(
    pathSegments: [
      '',
      'tasks',
      accountId,
      taskListId,
      if (taskId != null) taskId,
    ],
  ).toString();
}

class _ScheduleShortcutAction extends ContextAction<_ScheduleShortcutIntent> {
  _ScheduleShortcutAction(this.state);

  final _ScheduleWorkspaceState state;

  @override
  bool isEnabled(_ScheduleShortcutIntent intent, [BuildContext? context]) {
    return state._isScheduleShortcutEnabled(intent.command);
  }

  @override
  Object? invoke(_ScheduleShortcutIntent intent, [BuildContext? context]) {
    state._invokeScheduleShortcut(intent.command);
    return null;
  }
}

int _firstWeekday(BuildContext context) {
  return BusyMaxWeekPreferencesScope.firstWeekdayOf(context);
}

DateTime _day(DateTime date) => DateTime(date.year, date.month, date.day);
