import 'windows_contacts_settings.dart';
import '../../l10n/oauth_error_description.dart';
import '../../core/auth/oauth_models.dart';
import '../../core/auth/authorization_attempt.dart';
import '../../l10n/registration_description.dart';
import 'windows_registration_setup_dialog.dart';
import '../../core/auth/oauth_registration.dart';
import 'windows_time_picker.dart';

import 'dart:async';

import 'windows_nextcloud_dialogs.dart';

import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'windows_workspace_shell.dart';

import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../l10n/generated/app_localizations.dart';
import '../../app/app_bootstrap.dart';
import '../../features/accounts/data/accounts_repository.dart';
import '../../features/auth/data/auth_repository.dart';
import '../../dav/dav_errors.dart';
import '../../dav/http/dav_http_transport.dart';
import 'windows_dav_account_dialogs.dart';
import '../../features/calendar/data/calendar_repository.dart';
import '../../features/calendar/data/cloud_calendar_sharing_service.dart';
import '../../features/calendar/data/microsoft_shared_calendar_service.dart';
import '../../features/notifications/desktop_notification_backend.dart';
import '../../features/sync/sync_auth_error.dart';
import '../../features/settings/presentation/launch_at_login_refresh.dart';
import '../../l10n/app_locale.dart';
import '../../l10n/week_preferences_scope.dart';
import '../../platform/common/desktop_services.dart';
import '../../providers/busy_provider.dart';
import '../../webcal/webcal_subscription_service.dart';
import '../common/busymax_glyph.dart';
import 'windows_account_removal_dialog.dart';
import 'windows_busymax_glyphs.dart';
import 'windows_calendar_activation_flows.dart';
import 'windows_cloud_calendar_sharing_dialog.dart';
import 'windows_diagnostics_dialog.dart';
import 'windows_feedback_dialog.dart';
import 'windows_keyboard_shortcuts_dialog.dart';

const _busyMaxRepositoryUrl = 'https://github.com/busystack/busymax/';
const _apacheLicenseUrl = 'https://www.apache.org/licenses/LICENSE-2.0';
const _systemLocaleTag = 'system';

class WindowsSettingsPage extends ConsumerStatefulWidget {
  const WindowsSettingsPage({super.key, this.initialPage});

  final String? initialPage;

  @override
  ConsumerState<WindowsSettingsPage> createState() =>
      _WindowsSettingsPageState();
}

class _WindowsSettingsPageState extends ConsumerState<WindowsSettingsPage> {
  late final LaunchAtLoginRefreshObserver _autostartRefresh;
  AuthorizationCancellation? _sharedConsentCancellation;
  final _scrollController = ScrollController();
  final _accountsKey = GlobalKey();
  final _accountsFocus = FocusNode();
  BusyProvider? _connectingDavProvider;
  DavCancellationToken? _davCancellation;
  AuthorizationCancellation? _authorizationCancellation;
  String? _davError;

  void _revealAccounts() {
    if (!mounted || widget.initialPage != 'accounts') return;
    final target = _accountsKey.currentContext;
    if (target != null) {
      unawaited(Scrollable.ensureVisible(target));
      _accountsFocus.requestFocus();
    } else if (_scrollController.hasClients) {
      // ListView builds lazily. Advance until the account section is laid out,
      // then align and focus its first connection action.
      final position = _scrollController.position;
      final next = (position.pixels + position.viewportDimension).clamp(
        0.0,
        position.maxScrollExtent,
      );
      if (next == position.pixels) return;
      _scrollController.jumpTo(next);
      WidgetsBinding.instance.addPostFrameCallback((_) => _revealAccounts());
    }
  }

  @override
  void didUpdateWidget(covariant WindowsSettingsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialPage != oldWidget.initialPage) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _revealAccounts());
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _revealAccounts());
    _autostartRefresh = LaunchAtLoginRefreshObserver(
      () => ref.invalidate(launchAtLoginStateProvider),
    );
  }

  @override
  void dispose() {
    _sharedConsentCancellation?.cancel();
    _authorizationCancellation?.cancel();
    _davCancellation?.cancel();
    _scrollController.dispose();
    _accountsFocus.dispose();
    _autostartRefresh.dispose();
    super.dispose();
  }

  Future<void> _openSharedCalendarOwned(String id) async {
    _sharedConsentCancellation?.cancel();
    final cancellation = AuthorizationCancellation();
    _sharedConsentCancellation = cancellation;
    try {
      await _openWindowsSharedCalendar(context, ref, id, cancellation);
    } finally {
      cancellation.cancel();
      if (identical(_sharedConsentCancellation, cancellation)) {
        _sharedConsentCancellation = null;
      }
    }
  }

  Future<void> _setup(BusyProvider provider) async {
    if (_authorizationCancellation != null) return;
    final cancellation = AuthorizationCancellation();
    setState(() => _authorizationCancellation = cancellation);
    try {
      final handle = await showWindowsRegistrationSetup(context, ref, provider);
      if (handle == null || !mounted || cancellation.isCancelled) return;
      final controller = ref.read(authSessionControllerProvider.notifier);
      final request = AuthorizationRequest.newConnection(
        handle,
        cancellation: cancellation,
      );
      if (provider == BusyProvider.google) {
        await controller.signIn(request: request);
      } else {
        await controller.signInWithMicrosoft(request: request);
      }
    } finally {
      cancellation.cancel();
      if (identical(_authorizationCancellation, cancellation)) {
        if (mounted) {
          setState(() => _authorizationCancellation = null);
        } else {
          _authorizationCancellation = null;
        }
      }
    }
  }

  Future<void> _signIn(Future<void> Function() action) async {
    setState(() => _davError = null);
    try {
      await action();
    } finally {
      if (mounted) {
        try {
          await ref.read(desktopWindowServiceProvider).showWindow();
        } on Object {
          // Authentication state remains authoritative if foregrounding is
          // temporarily denied by Windows.
        }
      }
    }
    if (!mounted) return;
  }

  Future<void> _connectDav(BusyProvider provider) async {
    WindowsAppleCredentialInput? apple;
    String? server;
    if (provider == BusyProvider.appleICloud) {
      apple = await showWindowsAppleICloudDialog(context);
    } else {
      server = await showWindowsNextcloudServerDialog(context);
    }
    if (!mounted ||
        (provider == BusyProvider.appleICloud && apple == null) ||
        (provider == BusyProvider.nextcloud && server == null)) {
      return;
    }
    setState(() {
      _connectingDavProvider = provider;
      _davError = null;
    });
    final cancellation = DavCancellationToken();
    _davCancellation = cancellation;
    try {
      final onboarding = ref.read(davAccountOnboardingServiceProvider);
      if (provider == BusyProvider.appleICloud) {
        await onboarding.connectAppleICloud(
          email: apple!.email,
          appSpecificPassword: apple.password,
          cancellationToken: cancellation,
        );
      } else {
        await onboarding.connectNextcloud(
          enteredServer: server!,
          cancellationToken: cancellation,
        );
      }
      if (!mounted || cancellation.isCancelled) return;
      await ref.read(authSessionControllerProvider.notifier).load();
    } on Object catch (error) {
      if (error is DavException && error.kind == DavErrorKind.cancelled) return;
      if (mounted) {
        setState(() => _davError = authErrorMessage(error));
      }
    } finally {
      _davCancellation = null;
      if (mounted) setState(() => _connectingDavProvider = null);
    }
  }

  Future<void> _cancelConnection() async {
    if (_connectingDavProvider != null) {
      _davCancellation?.cancel();
      if (_connectingDavProvider == BusyProvider.nextcloud) {
        ref.read(davAccountOnboardingServiceProvider).cancelNextcloudLogin();
      }
      return;
    }
    await ref
        .read(authSessionControllerProvider.notifier)
        .cancelSignIn(cancellation: _authorizationCancellation);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final settings = ref.watch(appSettingsControllerProvider);
    final controller = ref.read(appSettingsControllerProvider.notifier);
    final autostart = ref.watch(launchAtLoginStateProvider);
    final changingAutostart = ref.watch(launchAtLoginControllerProvider);
    final accounts = ref.watch(accountManagementStreamProvider);
    final calendarSources = ref.watch(calendarSourcesStreamProvider);
    final subscriptions = ref.watch(webCalSubscriptionsProvider);
    final config = ref.watch(buildConfigProvider);
    final notificationReadiness = ref.watch(
      desktopNotificationReadinessProvider,
    );
    final session = ref.watch(authSessionControllerProvider);
    final busy =
        session.status == AuthSessionStatus.signingIn ||
        _connectingDavProvider != null ||
        _authorizationCancellation != null;
    return ScaffoldPage.scrollable(
      scrollController: _scrollController,
      header: PageHeader(
        leading: (GoRouter.maybeOf(context)?.canPop() ?? false)
            ? PaneBackButton(
                key: const ValueKey('windows-settings-back'),
                onPressed: () => WindowsWorkspaceShell.popSettings(context),
              )
            : null,
        title: Text(l10n.settings),
      ),
      bottomBar: ref.watch(appSettingsPersistenceFailedProvider)
          ? Padding(
              padding: const EdgeInsets.all(16),
              child: InfoBar(
                title: Text(l10n.settingsSaveFailed),
                severity: InfoBarSeverity.error,
                action: Button(
                  onPressed: () => unawaited(controller.retrySave()),
                  child: Text(l10n.retry),
                ),
              ),
            )
          : null,
      children: [
        _SectionTitle(l10n.appearance),
        Card(
          child: _SettingsRow(
            icon: BusyMaxGlyph.settings,
            title: l10n.theme,
            child: ComboBox<BusyMaxThemeModePreference>(
              value: settings.themeModePreference,
              items: [
                ComboBoxItem(
                  value: BusyMaxThemeModePreference.system,
                  child: Text(l10n.themeSystem),
                ),
                ComboBoxItem(
                  value: BusyMaxThemeModePreference.light,
                  child: Text(l10n.themeLight),
                ),
                ComboBoxItem(
                  value: BusyMaxThemeModePreference.dark,
                  child: Text(l10n.themeDark),
                ),
              ],
              onChanged: (value) {
                if (value != null) controller.setThemeModePreference(value);
              },
            ),
          ),
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.scheduleDisplaySettings),
        Card(
          child: Column(
            children: [
              _SettingsRow(
                icon: BusyMaxGlyph.settings,
                title: l10n.timeFormat,
                child: ComboBox<BusyMaxTimeFormatPreference>(
                  value: settings.timeFormatPreference,
                  items: [
                    for (final value in BusyMaxTimeFormatPreference.values)
                      ComboBoxItem(
                        value: value,
                        child: Text(switch (value) {
                          BusyMaxTimeFormatPreference.system =>
                            l10n.themeSystem,
                          BusyMaxTimeFormatPreference.twelveHour =>
                            l10n.timeFormatTwelveHour,
                          BusyMaxTimeFormatPreference.twentyFourHour =>
                            l10n.timeFormatTwentyFourHour,
                        }),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      controller.setTimeFormatPreference(value);
                    }
                  },
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.calendar,
                title: l10n.firstDayOfWeek,
                child: ComboBox<BusyMaxFirstDayOfWeekPreference>(
                  value: settings.firstDayOfWeekPreference,
                  items: [
                    for (final value in BusyMaxFirstDayOfWeekPreference.values)
                      ComboBoxItem(
                        value: value,
                        child: Text(
                          busyMaxFirstDayOfWeekPreferenceLabel(context, value),
                        ),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      controller.setFirstDayOfWeekPreference(value);
                    }
                  },
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.calendar,
                title: l10n.scheduleDayStartsAt,
                child: WindowsTimePicker(
                  selected: _minuteDateTime(settings.scheduleDayStartMinute),
                  onChanged: (value) => controller.setScheduleDayStartMinute(
                    value.hour * 60 + value.minute,
                  ),
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.calendar,
                title: l10n.scheduleDayEndsAt,
                child: WindowsTimePicker(
                  selected: _minuteDateTime(settings.scheduleDayEndMinute),
                  endOfDay: settings.scheduleDayEndMinute == 1440,
                  onChanged: (value) => controller.setScheduleDayEndMinute(
                    value.hour == 0 && value.minute == 0
                        ? 24 * 60
                        : value.hour * 60 + value.minute,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.settingsSystem),
        Card(
          child: Column(
            children: [
              _SettingsRow(
                icon: BusyMaxGlyph.settings,
                title: l10n.currentLocale,
                child: ComboBox<String>(
                  value: settings.localeTag ?? _systemLocaleTag,
                  items: [
                    ComboBoxItem(
                      value: _systemLocaleTag,
                      child: Text(l10n.themeSystem),
                    ),
                    for (final option in busyMaxLocaleOptions)
                      ComboBoxItem(
                        value: option.tag,
                        child: Text(option.endonym),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      controller.setLocaleTag(
                        value == _systemLocaleTag ? null : value,
                      );
                    }
                  },
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.more,
                title: l10n.runInBackgroundWhenClosed,
                child: ToggleSwitch(
                  checked: settings.runInBackgroundWhenClosed,
                  onChanged: controller.setRunInBackgroundWhenClosed,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.information,
                title: l10n.showTrayIcon,
                child: ToggleSwitch(
                  checked: settings.showTrayIcon,
                  onChanged: controller.setShowTrayIcon,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.signOut,
                title: l10n.startMinimizedToTray,
                child: ToggleSwitch(
                  checked: settings.startMinimizedToTray,
                  onChanged: controller.setStartMinimizedToTray,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.sync,
                title: l10n.launchAtLogin,
                subtitle: _autostartDescription(l10n, autostart),
                child: changingAutostart || autostart.isLoading
                    ? const ProgressRing()
                    : autostart.when(
                        loading: () => const ProgressRing(),
                        error: (_, _) => Button(
                          onPressed: () =>
                              ref.invalidate(launchAtLoginStateProvider),
                          child: Text(l10n.retry),
                        ),
                        data: (state) => ToggleSwitch(
                          key: const ValueKey('launch-at-login-switch'),
                          checked: state.isEnabled,
                          onChanged: !state.canChange
                              ? null
                              : (enabled) => unawaited(
                                  _setWindowsAutostart(context, ref, enabled),
                                ),
                        ),
                      ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        InfoBar(
          title: Text(l10n.windowsReminderExitNotice),
          severity: InfoBarSeverity.info,
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.notifications),
        if (!notificationReadiness.canNotify) ...[
          WindowsNotificationReadinessInfoBar(readiness: notificationReadiness),
          const SizedBox(height: 8),
        ],
        Card(
          child: Column(
            children: [
              _SettingsRow(
                icon: BusyMaxGlyph.reminder,
                title: l10n.eventReminders,
                child: ToggleSwitch(
                  checked: settings.notifyEventReminders,
                  onChanged: controller.setNotifyEventReminders,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.task,
                title: l10n.taskReminders,
                child: ToggleSwitch(
                  checked: settings.notifyTaskReminders,
                  onChanged: controller.setNotifyTaskReminders,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.today,
                title: l10n.notifyDueToday,
                child: ToggleSwitch(
                  checked: settings.notifyDueToday,
                  onChanged: controller.setNotifyDueToday,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.sync,
                title: l10n.notifySyncFailures,
                child: ToggleSwitch(
                  checked: settings.notifySyncFailures,
                  onChanged: controller.setNotifySyncFailures,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.warning,
                title: l10n.notifyConflicts,
                child: ToggleSwitch(
                  checked: settings.notifyConflicts,
                  onChanged: controller.setNotifyConflicts,
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.privacy,
                title: l10n.notificationDetailLevel,
                child: ComboBox<NotificationDetailLevel>(
                  value: settings.notificationDetailLevel,
                  items: [
                    ComboBoxItem(
                      value: NotificationDetailLevel.private,
                      child: Text(l10n.notificationDetailPrivate),
                    ),
                    ComboBoxItem(
                      value: NotificationDetailLevel.normal,
                      child: Text(l10n.notificationDetailNormal),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      controller.setNotificationDetailLevel(value);
                    }
                  },
                ),
              ),
              const Divider(),
              _SettingsRow(
                icon: BusyMaxGlyph.reminder,
                title: l10n.quietHours,
                subtitle: l10n.quietHoursDescription,
                child: ToggleSwitch(
                  checked: settings.quietHoursEnabled,
                  onChanged: controller.setQuietHoursEnabled,
                ),
              ),
              if (settings.quietHoursEnabled) ...[
                const Divider(),
                _SettingsRow(
                  icon: BusyMaxGlyph.previous,
                  title: l10n.quietHoursStart,
                  child: WindowsTimePicker(
                    selected: _timeStringDateTime(settings.quietHoursStart),
                    onChanged: (value) =>
                        controller.setQuietHoursStart(_timeString(value)),
                  ),
                ),
                const Divider(),
                _SettingsRow(
                  icon: BusyMaxGlyph.next,
                  title: l10n.quietHoursEnd,
                  child: WindowsTimePicker(
                    selected: _timeStringDateTime(settings.quietHoursEnd),
                    onChanged: (value) =>
                        controller.setQuietHoursEnd(_timeString(value)),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.privacy),
        Card(
          child: _SettingsRow(
            icon: BusyMaxGlyph.privacy,
            title: l10n.redactTaskContentInDiagnostics,
            child: ToggleSwitch(
              checked: settings.redactTaskContentInDiagnostics,
              onChanged: controller.setRedactTaskContentInDiagnostics,
            ),
          ),
        ),
        const SizedBox(height: 20),
        const WindowsContactsSettings(),
        KeyedSubtree(key: _accountsKey, child: _SectionTitle(l10n.accounts)),
        Card(
          child: accounts.when(
            loading: () => const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: ProgressRing()),
            ),
            error: (_, _) => InfoBar(
              title: Text(l10n.operationFailed),
              severity: InfoBarSeverity.error,
            ),
            data: (values) => Column(
              children: [
                if (session.message != null || _davError != null)
                  InfoBar(
                    title: Text(
                      _davError ??
                          localizedOAuthFailure(
                            l10n,
                            session.failureKind,
                            session.message!,
                          ),
                    ),
                    severity: InfoBarSeverity.error,
                  ),
                ListTile(
                  leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                  focusNode: _accountsFocus,
                  title: Text(l10n.addNextcloudAccount),
                  onPressed: busy
                      ? null
                      : () => _connectDav(BusyProvider.nextcloud),
                ),
                ListTile(
                  leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                  title: Text(l10n.addGoogleAccount),
                  subtitle: config.googleSetupAvailable
                      ? null
                      : Text(l10n.providerNotConfigured),
                  onPressed: busy || !config.googleSetupAvailable
                      ? null
                      : () => _signIn(() => _setup(BusyProvider.google)),
                ),
                ListTile(
                  leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                  title: Text(l10n.addMicrosoftAccount),
                  subtitle: config.microsoftSetupAvailable
                      ? null
                      : Text(l10n.providerNotConfigured),
                  onPressed: busy || !config.microsoftSetupAvailable
                      ? null
                      : () => _signIn(() => _setup(BusyProvider.microsoft)),
                ),
                ListTile(
                  leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                  title: Text(l10n.addAppleICloudAccount),
                  onPressed: busy
                      ? null
                      : () => _connectDav(BusyProvider.appleICloud),
                ),
                if (busy) ...[
                  const ProgressRing(),
                  Button(
                    onPressed: _cancelConnection,
                    child: Text(l10n.cancelAccountConnection),
                  ),
                ],
                if (values.isNotEmpty) const Divider(),
                for (var index = 0; index < values.length; index++) ...[
                  if (values[index].provider == BusyProvider.google ||
                      values[index].provider == BusyProvider.microsoft)
                    _WindowsRegistrationCard(account: values[index]),
                  ListTile(
                    leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.account)),
                    title: Semantics(
                      header: true,
                      child: Text(
                        values[index].displayName ??
                            values[index].email ??
                            values[index].id,
                        style: FluentTheme.of(context).typography.bodyStrong,
                      ),
                    ),
                    subtitle: Text(values[index].provider.storageValue),
                    trailing: DropDownButton(
                      title: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.more)),
                      items: [
                        if (values[index].provider == BusyProvider.nextcloud)
                          MenuFlyoutItem(
                            text: Text(l10n.nextcloudTrash),
                            onPressed: () => showWindowsNextcloudTrashDialog(
                              context,
                              accountId: values[index].id,
                            ),
                          ),
                        if (values[index].provider == BusyProvider.microsoft &&
                            values[index].isSignedIn)
                          MenuFlyoutItem(
                            text: Text(l10n.openSharedCalendar),
                            onPressed: () => unawaited(
                              _openSharedCalendarOwned(values[index].id),
                            ),
                          ),
                        if (values[index].isSignedIn &&
                            (calendarSources.valueOrNull ??
                                    const <CalendarSourceEntity>[])
                                .any(
                                  (source) =>
                                      source.accountId == values[index].id &&
                                      CloudCalendarSharingService.canManageSource(
                                        source,
                                      ),
                                ))
                          MenuFlyoutItem(
                            text: Text(l10n.manageCalendarSharing),
                            onPressed: () => unawaited(
                              showWindowsCloudCalendarSharingDialog(
                                context,
                                sources: [
                                  for (final source
                                      in calendarSources.valueOrNull ??
                                          const <CalendarSourceEntity>[])
                                    if (source.accountId == values[index].id &&
                                        CloudCalendarSharingService.canManageSource(
                                          source,
                                        ))
                                      source,
                                ],
                              ),
                            ),
                          ),
                        MenuFlyoutItem(
                          leading: Icon(
                            windowsBusyMaxGlyph(BusyMaxGlyph.delete),
                          ),
                          text: Text(l10n.removeAccount),
                          closeAfterClick: false,
                          onPressed: () {
                            // Close the menu before pushing the confirmation;
                            // an asynchronous menu pop can race the dialog.
                            Navigator.of(context).pop();
                            unawaited(
                              _removeWindowsAccount(
                                context,
                                ref,
                                values[index],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  if (values[index].calendarsEnabled &&
                      (values[index].provider == BusyProvider.google ||
                          values[index].provider ==
                              BusyProvider.microsoft)) ...[
                    const Divider(),
                    _WindowsAccountCalendars(
                      sources: [
                        for (final source
                            in calendarSources.valueOrNull ?? const [])
                          if (source.accountId == values[index].id) source,
                      ],
                      onSelected: (source, selected) => unawaited(
                        ref
                            .read(calendarRepositoryProvider)
                            .setSourceSelected(source.id, selected),
                      ),
                      onProviderVisibilityChanged: (source, visible) =>
                          unawaited(
                            _setWindowsCalendarProviderVisibility(
                              context,
                              ref,
                              source,
                              visible,
                            ),
                          ),
                    ),
                  ],
                  if (values[index].provider == BusyProvider.nextcloud)
                    for (final collection
                        in ref
                                .watch(davCollectionsStreamProvider)
                                .valueOrNull ??
                            const [])
                      if (collection.accountId == values[index].id &&
                          (collection.supportsEvents ||
                              collection.supportsTasks))
                        ListTile(
                          title: Text(collection.name),
                          subtitle: Text(l10n.nextcloudCollectionSettings),
                          onPressed: () => showWindowsNextcloudCollectionDialog(
                            context,
                            accountId: collection.accountId,
                            collectionId: collection.id,
                          ),
                        ),
                  if (index != values.length - 1) const Divider(),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.calendarImport),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.calendar)),
                title: Text(l10n.importIcsFile),
                subtitle: Text(l10n.calendarImportDescription),
                onPressed: () => showWindowsIcsImportFlow(context, ref),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.add)),
                title: Text(l10n.addCalendarSubscription),
                subtitle: Text(l10n.calendarSubscriptionsDescription),
                onPressed: () =>
                    showWindowsWebCalSubscriptionFlow(context, ref),
              ),
              ...subscriptions.maybeWhen(
                data: (values) => [
                  for (final subscription in values) ...[
                    const Divider(),
                    ListTile(
                      leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.calendar)),
                      title: Text(subscription.name),
                      subtitle: Text(subscription.safeOrigin),
                      trailing: DropDownButton(
                        title: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.more)),
                        items: [
                          MenuFlyoutItem(
                            leading: Icon(
                              windowsBusyMaxGlyph(BusyMaxGlyph.refresh),
                            ),
                            text: Text(l10n.refresh),
                            onPressed: () => unawaited(
                              _refreshWindowsSubscription(
                                context,
                                ref,
                                subscription,
                              ),
                            ),
                          ),
                          MenuFlyoutItem(
                            leading: Icon(
                              windowsBusyMaxGlyph(BusyMaxGlyph.edit),
                            ),
                            text: Text(l10n.rename),
                            onPressed: () => unawaited(
                              _renameWindowsSubscription(
                                context,
                                ref,
                                subscription,
                              ),
                            ),
                          ),
                          MenuFlyoutItem(
                            leading: Icon(
                              windowsBusyMaxGlyph(BusyMaxGlyph.settings),
                            ),
                            text: Text(l10n.calendarColor),
                            onPressed: () => unawaited(
                              _colorWindowsSubscription(
                                context,
                                ref,
                                subscription,
                              ),
                            ),
                          ),
                          MenuFlyoutItem(
                            leading: Icon(
                              windowsBusyMaxGlyph(BusyMaxGlyph.delete),
                            ),
                            text: Text(l10n.unsubscribe),
                            closeAfterClick: false,
                            onPressed: () {
                              Navigator.of(context).pop();
                              unawaited(
                                _unsubscribeWindowsSubscription(
                                  context,
                                  ref,
                                  subscription,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
                orElse: () => const <Widget>[],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _SectionTitle(l10n.aboutBusyMax),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.information)),
                title: Text(l10n.aboutBusyMax),
                subtitle: Text(l10n.aboutBusyMaxDescription),
                onPressed: () => showWindowsAboutDialog(
                  context,
                  packageVersion: config.windowsPackageVersion,
                  privacyPolicyUrl: config.privacyPolicyUrl,
                  supportUrl: config.supportUrl,
                  homepageUrl: config.homepageUrl,
                ),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.privacy)),
                title: Text(l10n.privacy),
                onPressed: _httpsUri(config.privacyPolicyUrl) == null
                    ? null
                    : () => launchUrl(_httpsUri(config.privacyPolicyUrl)!),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.feedback)),
                title: Text(l10n.sendFeedback),
                onPressed: () => showWindowsFeedbackDialog(context, ref),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.diagnostics)),
                title: Text(l10n.diagnostics),
                onPressed: () => showWindowsDiagnosticsDialog(context, ref),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.more)),
                title: Text(l10n.keyboardShortcuts),
                onPressed: () => showWindowsKeyboardShortcutsDialog(context),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.feedback)),
                title: Text(l10n.windowsSupport),
                onPressed: _httpsUri(config.supportUrl) == null
                    ? null
                    : () => launchUrl(_httpsUri(config.supportUrl)!),
              ),
              const Divider(),
              ListTile(
                leading: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.information)),
                title: Text(l10n.website),
                onPressed: _httpsUri(config.homepageUrl) == null
                    ? null
                    : () => launchUrl(_httpsUri(config.homepageUrl)!),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
      ],
    );
  }
}

class _WindowsAccountCalendars extends StatelessWidget {
  const _WindowsAccountCalendars({
    required this.sources,
    required this.onSelected,
    required this.onProviderVisibilityChanged,
  });

  final List<CalendarSourceEntity> sources;
  final void Function(CalendarSourceEntity source, bool selected) onSelected;
  final void Function(CalendarSourceEntity source, bool visible)
  onProviderVisibilityChanged;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final showsProviderVisibility = sources.any(
      (source) => source.capabilities.canChangeProviderVisibility,
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Semantics(
            header: true,
            child: Text(
              l10n.calendars,
              style: FluentTheme.of(context).typography.caption
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 8),
          if (sources.isEmpty)
            Text(l10n.noCalendarsSynced)
          else ...[
            _WindowsCalendarSettingsColumnHeader(
              showsProviderVisibility: showsProviderVisibility,
            ),
            for (final source in sources) ...[
              _WindowsCalendarSettingsRow(
                key: ValueKey('settings-calendar-${source.id}'),
                source: source,
                showsProviderVisibility: showsProviderVisibility,
                onSelected: onSelected,
                onProviderVisibilityChanged: onProviderVisibilityChanged,
              ),
              if (source != sources.last) const Divider(),
            ],
          ],
        ],
      ),
    );
  }
}

const _windowsCalendarSettingsColumnWidth = 92.0;

class _WindowsCalendarSettingsColumnHeader extends StatelessWidget {
  const _WindowsCalendarSettingsColumnHeader({
    required this.showsProviderVisibility,
  });

  final bool showsProviderVisibility;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final style = FluentTheme.of(context).typography.caption
        ?.copyWith(fontWeight: FontWeight.w600);
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 4),
      child: Row(
        children: [
          const Expanded(child: SizedBox()),
          _WindowsCalendarSettingsColumnLabel(
            key: const ValueKey('settings-calendar-column-schedule'),
            label: l10n.scheduleSettings,
            style: style,
          ),
          if (showsProviderVisibility)
            _WindowsCalendarSettingsColumnLabel(
              key: const ValueKey('settings-calendar-column-provider'),
              label: l10n.googleProvider,
              style: style,
            ),
        ],
      ),
    );
  }
}

class _WindowsCalendarSettingsColumnLabel extends StatelessWidget {
  const _WindowsCalendarSettingsColumnLabel({
    super.key,
    required this.label,
    required this.style,
  });

  final String label;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _windowsCalendarSettingsColumnWidth,
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center,
        style: style,
      ),
    );
  }
}

class _WindowsCalendarSettingsRow extends ConsumerWidget {
  const _WindowsCalendarSettingsRow({
    super.key,
    required this.source,
    required this.showsProviderVisibility,
    required this.onSelected,
    required this.onProviderVisibilityChanged,
  });

  final CalendarSourceEntity source;
  final bool showsProviderVisibility;
  final void Function(CalendarSourceEntity source, bool selected) onSelected;
  final void Function(CalendarSourceEntity source, bool visible)
  onProviderVisibilityChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final canChangeProviderVisibility =
        source.capabilities.canChangeProviderVisibility;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(windowsBusyMaxGlyph(BusyMaxGlyph.calendar), size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              source.summary,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          _WindowsCalendarSettingsSwitchCell(
            child: ToggleSwitch(
              key: ValueKey('settings-calendar-schedule-${source.id}'),
              checked: source.selected && !source.hidden,
              onChanged: source.hidden
                  ? null
                  : (selected) => onSelected(source, selected),
              semanticLabel: l10n.showInSchedule,
            ),
          ),
          if (showsProviderVisibility)
            _WindowsCalendarSettingsSwitchCell(
              child: ToggleSwitch(
                key: ValueKey('settings-calendar-provider-${source.id}'),
                checked: !source.hidden,
                onChanged: canChangeProviderVisibility
                    ? (visible) => onProviderVisibilityChanged(source, visible)
                    : null,
                semanticLabel: l10n.visibility,
              ),
            ),
          if (source.provider == BusyProvider.microsoft &&
              source.capabilities.removalMode ==
                  CalendarRemovalMode.removeFromList)
            IconButton(
              key: ValueKey('settings-calendar-remove-${source.id}'),
              icon: Icon(windowsBusyMaxGlyph(BusyMaxGlyph.delete)),
              onPressed: () async {
                final confirmed = await showDialog<bool>(
                  context: context,
                  barrierDismissible: false,
                  builder: (dialogContext) => ContentDialog(
                    title: Text(l10n.removeFromMyCalendars),
                    content: Text(
                      l10n.removeOpenedSharedCalendarConfirmation(
                        source.summary,
                      ),
                    ),
                    actions: [
                      Button(
                        onPressed: () => Navigator.pop(dialogContext, false),
                        child: Text(l10n.cancel),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.pop(dialogContext, true),
                        child: Text(l10n.removeAction),
                      ),
                    ],
                  ),
                );
                if (confirmed != true || !context.mounted) return;
                try {
                  await ref
                      .read(calendarRepositoryProvider)
                      .deleteLocalSource(source.id);
                } on Object catch (error) {
                  if (context.mounted) {
                    await _showWindowsMessage(
                      context,
                      l10n.calendarUpdateFailed('$error'),
                    );
                  }
                }
              },
            ),
        ],
      ),
    );
  }
}

class _WindowsCalendarSettingsSwitchCell extends StatelessWidget {
  const _WindowsCalendarSettingsSwitchCell({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _windowsCalendarSettingsColumnWidth,
      child: Center(child: child),
    );
  }
}

class WindowsNotificationReadinessInfoBar extends StatelessWidget {
  const WindowsNotificationReadinessInfoBar({
    required this.readiness,
    super.key,
  });

  final DesktopNotificationReadiness readiness;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final unpackaged =
        readiness.state ==
        DesktopNotificationReadinessState.unavailableUnpackaged;
    return InfoBar(
      title: Text(l10n.windowsNotificationsUnavailable),
      content: Text(
        unpackaged
            ? l10n.windowsNotificationsUnpackaged
            : l10n.windowsNotificationsInstalledFailure,
      ),
      severity: unpackaged ? InfoBarSeverity.warning : InfoBarSeverity.error,
    );
  }
}

Future<void> _setWindowsCalendarProviderVisibility(
  BuildContext context,
  WidgetRef ref,
  CalendarSourceEntity source,
  bool visible,
) async {
  try {
    await ref
        .read(calendarRepositoryProvider)
        .setSourceProviderHidden(source.id, !visible);
    ref
        .read(
          pendingCalendarMutationSyncRequesterForAccountProvider(
            source.accountId,
          ),
        )
        .request();
  } on Object catch (error) {
    if (context.mounted) {
      final l10n = AppLocalizations.of(context);
      await _showWindowsMessage(
        context,
        l10n.calendarUpdateFailed(
          syncFailureMessage(
            error,
            networkUnavailableMessage: l10n.networkOfflineTryAgain,
          ),
        ),
      );
    }
  }
}

Future<void> _setWindowsAutostart(
  BuildContext context,
  WidgetRef ref,
  bool enabled,
) async {
  try {
    await ref
        .read(launchAtLoginControllerProvider.notifier)
        .setEnabled(enabled);
  } on Object {
    if (context.mounted) {
      await _showWindowsMessage(
        context,
        AppLocalizations.of(context).launchAtLoginFailed,
      );
    }
  }
}

Future<void> _removeWindowsAccount(
  BuildContext context,
  WidgetRef ref,
  AccountEntity account,
) async {
  final l10n = AppLocalizations.of(context);
  final options = await showWindowsAccountRemovalDialog(
    context,
    accountLabel: account.displayLabel,
    canRevokeGoogleAuthorization:
        account.provider == BusyProvider.google && account.isSignedIn,
  );
  if (options == null || !context.mounted) return;
  try {
    final isDav =
        account.provider == BusyProvider.appleICloud ||
        account.provider == BusyProvider.nextcloud;
    final authResult = isDav
        ? null
        : await ref
              .read(authRepositoryProvider)
              .removeAccount(
                accountId: account.id,
                revokeAuthorization: options.revokeGoogleAuthorization,
              );
    final davResult = isDav
        ? await ref
              .read(davAccountOnboardingServiceProvider)
              .removeAccount(account.id)
        : null;
    final remaining = await ref
        .read(accountsRepositoryProvider)
        .listVisibleAccounts();
    ref.read(selectedAccountIdProvider.notifier).state =
        remaining.firstOrNull?.id;
    await ref.read(authSessionControllerProvider.notifier).load();
    if (!context.mounted) return;
    if (authResult?.authorizationRevocationFailed ?? false) {
      await _showWindowsMessage(context, l10n.accountRemovedGoogleRevokeFailed);
    } else if (davResult?.remoteRevocationAttempted == true &&
        !davResult!.remoteRevocationSucceeded) {
      await _showWindowsMessage(
        context,
        l10n.nextcloudAccountRemovedRevokeFailed,
      );
    }
  } on Object catch (error) {
    if (context.mounted) {
      await _showWindowsMessage(
        context,
        localizedAccountRemovalError(l10n, error),
      );
    }
  }
}

Future<void> _refreshWindowsSubscription(
  BuildContext context,
  WidgetRef ref,
  WebCalSubscriptionEntity subscription,
) => _runWindowsSubscriptionOperation(
  context,
  () => ref
      .read(webCalSubscriptionServiceProvider)
      .refreshSubscription(subscription.id, force: true),
);

Future<void> _renameWindowsSubscription(
  BuildContext context,
  WidgetRef ref,
  WebCalSubscriptionEntity subscription,
) async {
  final l10n = AppLocalizations.of(context);
  final value = await _showWindowsTextPrompt(
    context,
    title: l10n.rename,
    label: l10n.subscriptionName,
    initialValue: subscription.name,
    actionLabel: l10n.rename,
  );
  if (value == null || !context.mounted) return;
  await _runWindowsSubscriptionOperation(
    context,
    () => ref
        .read(webCalSubscriptionServiceProvider)
        .renameSubscription(subscription.id, value),
  );
}

Future<void> _colorWindowsSubscription(
  BuildContext context,
  WidgetRef ref,
  WebCalSubscriptionEntity subscription,
) async {
  final l10n = AppLocalizations.of(context);
  final value = await _showWindowsTextPrompt(
    context,
    title: l10n.calendarColor,
    label: l10n.subscriptionColor,
    initialValue: subscription.color ?? '',
    actionLabel: l10n.save,
    message: l10n.subscriptionColorHelp,
  );
  if (value == null || !context.mounted) return;
  await _runWindowsSubscriptionOperation(
    context,
    () => ref
        .read(webCalSubscriptionServiceProvider)
        .changeSubscriptionColor(subscription.id, value),
  );
}

Future<void> _unsubscribeWindowsSubscription(
  BuildContext context,
  WidgetRef ref,
  WebCalSubscriptionEntity subscription,
) async {
  final l10n = AppLocalizations.of(context);
  final confirmed = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => ContentDialog(
      title: Text(l10n.unsubscribeCalendarTitle(subscription.name)),
      content: Text(l10n.unsubscribeCalendarConfirmation),
      actions: [
        Button(
          onPressed: () => Navigator.pop(dialogContext, false),
          child: Text(l10n.cancel),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext, true),
          child: Text(l10n.unsubscribe),
        ),
      ],
    ),
  );
  if (confirmed != true || !context.mounted) return;
  await _runWindowsSubscriptionOperation(
    context,
    () => ref
        .read(webCalSubscriptionServiceProvider)
        .unsubscribe(subscription.id),
  );
}

Future<void> _runWindowsSubscriptionOperation(
  BuildContext context,
  Future<void> Function() operation,
) async {
  try {
    await operation();
  } on Object {
    if (context.mounted) {
      final l10n = AppLocalizations.of(context);
      await _showWindowsMessage(
        context,
        l10n.subscriptionOperationFailed(l10n.operationFailed),
      );
    }
  }
}

Future<void> _openWindowsSharedCalendar(
  BuildContext context,
  WidgetRef ref,
  String accountId,
  AuthorizationCancellation cancellation,
) async {
  final l10n = AppLocalizations.of(context);
  final owner = await _showWindowsTextPrompt(
    context,
    title: l10n.openSharedCalendar,
    label: l10n.calendarOwnerEmail,
    initialValue: '',
    actionLabel: l10n.openSharedCalendar,
  );
  if (!context.mounted || owner == null || owner.trim().isEmpty) return;
  try {
    final result = await ref
        .read(microsoftSharedCalendarServiceProvider)
        .openPrimaryCalendar(
          accountId: accountId,
          owner: owner,
          cancellation: cancellation,
        );
    if (context.mounted &&
        result.outcome == MicrosoftSharedCalendarOpenOutcome.rangeUnavailable) {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => ContentDialog(
          title: Text(l10n.openSharedCalendar),
          content: Text(l10n.scheduleRangeIncomplete),
          actions: [
            Button(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.close),
            ),
          ],
        ),
      );
    }
  } on Object catch (error) {
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => ContentDialog(
        title: Text(l10n.operationFailed),
        content: SelectableText('$error'),
        actions: [
          Button(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(l10n.close),
          ),
        ],
      ),
    );
  }
}

Future<String?> _showWindowsTextPrompt(
  BuildContext context, {
  required String title,
  required String label,
  required String initialValue,
  required String actionLabel,
  String? message,
}) async {
  final controller = TextEditingController(text: initialValue);
  final value = await showDialog<String>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => ContentDialog(
      title: Text(title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (message != null) ...[Text(message), const SizedBox(height: 12)],
          InfoLabel(
            label: label,
            child: TextBox(controller: controller, autofocus: true),
          ),
        ],
      ),
      actions: [
        Button(
          onPressed: () => Navigator.pop(dialogContext),
          child: Text(AppLocalizations.of(dialogContext).cancel),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext, controller.text),
          child: Text(actionLabel),
        ),
      ],
    ),
  );
  controller.dispose();
  return value;
}

Future<void> _showWindowsMessage(BuildContext context, String message) {
  return showDialog<void>(
    context: context,
    builder: (context) => ContentDialog(
      content: Text(message),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context).close),
        ),
      ],
    ),
  );
}

String _autostartDescription(
  AppLocalizations l10n,
  AsyncValue<DesktopAutostartState> value,
) => value.maybeWhen(
  error: (_, _) => l10n.launchAtLoginReadFailed,
  data: (state) => switch (state) {
    DesktopAutostartState.enabledByPolicy => l10n.windowsStartupEnabledByPolicy,
    DesktopAutostartState.disabledByUser => l10n.windowsStartupDisabledByUser,
    DesktopAutostartState.disabledByPolicy =>
      l10n.windowsStartupDisabledByPolicy,
    DesktopAutostartState.unavailable => l10n.windowsStartupUnavailable,
    _ => l10n.launchAtLoginDescription,
  },
  orElse: () => l10n.launchAtLoginDescription,
);

Uri? _httpsUri(String value) {
  final uri = Uri.tryParse(value.trim());
  return uri?.scheme == 'https' && uri!.host.isNotEmpty ? uri : null;
}

DateTime _minuteDateTime(int minute) =>
    DateTime(2000, 1, 1, (minute ~/ 60) % 24, minute % 60);

DateTime _timeStringDateTime(String value) {
  final parts = value.split(':');
  return DateTime(
    2000,
    1,
    1,
    parts.isEmpty ? 0 : int.tryParse(parts[0]) ?? 0,
    parts.length < 2 ? 0 : int.tryParse(parts[1]) ?? 0,
  );
}

String _timeString(DateTime value) =>
    '${value.hour.toString().padLeft(2, '0')}:'
    '${value.minute.toString().padLeft(2, '0')}';

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsetsDirectional.only(bottom: 8),
    child: Semantics(
      header: true,
      child: Text(text, style: FluentTheme.of(context).typography.subtitle),
    ),
  );
}

class _SettingsRow extends StatelessWidget {
  const _SettingsRow({
    required this.icon,
    required this.title,
    required this.child,
    this.subtitle,
  });

  final BusyMaxGlyph icon;
  final String title;
  final String? subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final textScale = MediaQuery.textScalerOf(context).scale(1);
      final compact = constraints.maxWidth < 520 || textScale > 1.3;
      final label = Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(windowsBusyMaxGlyph(icon)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title),
                if (subtitle != null)
                  Text(
                    subtitle!,
                    style: FluentTheme.of(context).typography.caption,
                  ),
              ],
            ),
          ),
        ],
      );
      return Padding(
        padding: const EdgeInsets.all(16),
        child: compact
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  label,
                  const SizedBox(height: 12),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: child,
                  ),
                ],
              )
            : Row(
                children: [
                  Expanded(child: label),
                  const SizedBox(width: 16),
                  child,
                ],
              ),
      );
    },
  );
}

Future<void> showWindowsAboutDialog(
  BuildContext context, {
  required String packageVersion,
  required String privacyPolicyUrl,
  required String supportUrl,
  required String homepageUrl,
}) async {
  final packageInfo = await PackageInfo.fromPlatform();
  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    builder: (context) {
      final l10n = AppLocalizations.of(context);
      return ContentDialog(
        title: Text(l10n.aboutBusyMax),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l10n.aboutBusyMaxDescription),
            const SizedBox(height: 12),
            Text('${l10n.windowsProductVersionLabel}: ${packageInfo.version}'),
            Text(
              '${l10n.windowsPackageVersionLabel}: '
              '${packageVersion.isEmpty ? l10n.windowsUnpackaged : packageVersion}',
            ),
            const SizedBox(height: 12),
            Text('Copyright © 2026 BusyStack'),
            Text(l10n.apacheLicenseName),
            const SizedBox(height: 8),
            HyperlinkButton(
              onPressed: () =>
                  unawaited(launchUrl(Uri.parse(_apacheLicenseUrl))),
              child: Text(l10n.license),
            ),
            HyperlinkButton(
              onPressed: () =>
                  unawaited(launchUrl(Uri.parse(_busyMaxRepositoryUrl))),
              child: Text(l10n.sourceCode),
            ),
            if (_httpsUri(privacyPolicyUrl) case final privacyUri?)
              HyperlinkButton(
                onPressed: () => unawaited(launchUrl(privacyUri)),
                child: Text(l10n.privacy),
              ),
            if (_httpsUri(supportUrl) case final supportUri?)
              HyperlinkButton(
                onPressed: () => unawaited(launchUrl(supportUri)),
                child: Text(l10n.windowsSupport),
              ),
            if (_httpsUri(homepageUrl) case final homepageUri?)
              HyperlinkButton(
                onPressed: () => unawaited(launchUrl(homepageUri)),
                child: Text(l10n.website),
              ),
          ],
        ),
        actions: [
          Button(
            onPressed: () => unawaited(showWindowsLicensesDialog(context)),
            child: Text(l10n.windowsThirdPartyLicenses),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.close),
          ),
        ],
      );
    },
  );
}

Future<void> showWindowsLicensesDialog(BuildContext context) async {
  final entries = await LicenseRegistry.licenses.toList();
  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    builder: (context) => ContentDialog(
      title: Text(AppLocalizations.of(context).windowsThirdPartyLicenses),
      constraints: const BoxConstraints(maxWidth: 720, maxHeight: 640),
      content: ListView.builder(
        itemCount: entries.length,
        itemBuilder: (context, index) {
          final entry = entries[index];
          return Expander(
            header: Text(entry.packages.join(', ')),
            content: SelectableText(
              entry.paragraphs.map((paragraph) => paragraph.text).join('\n\n'),
            ),
          );
        },
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: Text(AppLocalizations.of(context).close),
        ),
      ],
    ),
  );
}

class _WindowsRegistrationCard extends ConsumerStatefulWidget {
  const _WindowsRegistrationCard({required this.account});
  final AccountEntity account;
  @override
  ConsumerState<_WindowsRegistrationCard> createState() =>
      _WindowsRegistrationCardState();
}

class _WindowsRegistrationCardState
    extends ConsumerState<_WindowsRegistrationCard> {
  bool connecting = false;
  AuthorizationCancellation? _authorizationCancellation;
  @override
  void dispose() {
    _authorizationCancellation?.cancel();
    super.dispose();
  }

  AccountEntity get account => widget.account;
  @override
  Widget build(BuildContext context) {
    final summary = ref
        .watch(registrationSummariesProvider)
        .valueOrNull?[account.id];
    final l10n = AppLocalizations.of(context);
    Future<void> connect(bool replace) async {
      if (connecting) return;
      setState(() => connecting = true);
      final cancellation = AuthorizationCancellation();
      _authorizationCancellation = cancellation;
      try {
        AuthorizationRequest request;
        if (replace) {
          final handle = await showWindowsRegistrationSetup(
            context,
            ref,
            account.provider,
          );
          if (handle == null) return;
          request = AuthorizationRequest.replace(account.id, handle);
        } else {
          request = AuthorizationRequest.reconnect(account.id);
        }
        if (!mounted || cancellation.isCancelled) return;
        request = request.withCancellation(cancellation);
        final repository = ref.read(authRepositoryProvider);
        if (account.provider == BusyProvider.google) {
          await repository.signIn(request: request);
        } else {
          await repository.signInWithMicrosoft(request: request);
        }
        await ref.read(signedInSyncRunnerProvider)(account.id, false);
      } on Object catch (error) {
        if (error is OAuthException &&
            error.classification == OAuthFailureKind.cancelled) {
          return;
        }
        if (context.mounted) {
          await displayInfoBar(
            context,
            builder: (_, close) => InfoBar(
              title: Text(
                localizedAuthorizationError(
                  AppLocalizations.of(context),
                  error,
                ),
              ),
              severity: InfoBarSeverity.error,
              onClose: close,
            ),
          );
        }
      } finally {
        cancellation.cancel();
        if (identical(_authorizationCancellation, cancellation)) {
          _authorizationCancellation = null;
          if (mounted) setState(() => connecting = false);
        }
      }
    }

    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            summary == null
                ? l10n.registrationUnresolved
                : l10n.registrationDescription(summary),
          ),
          if (summary?.showRetirementNotice == true)
            InfoBar(
              severity: InfoBarSeverity.warning,
              title: Text(
                l10n.registrationRetirementNotice(
                  account.provider.displayName,
                  account.provider == BusyProvider.google
                      ? l10n.registrationGoogleProject
                      : l10n.registrationMicrosoftApp,
                ),
              ),
            ),
          Button(
            onPressed: connecting ? null : () => connect(true),
            child: Text(
              summary?.showRetirementNotice == true
                  ? l10n.registrationMigrate
                  : l10n.registrationReplace,
            ),
          ),
          if (connecting)
            Button(
              onPressed: () {
                _authorizationCancellation?.cancel();
                setState(() => connecting = false);
              },
              child: Text(l10n.cancelAccountConnection),
            ),
          Button(
            onPressed: connecting ? null : () => connect(false),
            child: Text(l10n.connectAccountAction),
          ),
        ],
      ),
    );
  }
}
