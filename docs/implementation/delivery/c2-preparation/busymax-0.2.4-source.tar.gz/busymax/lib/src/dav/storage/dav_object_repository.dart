import 'dart:convert';
import '../../features/maps/data/location_resolution_repository.dart';

import 'package:crypto/crypto.dart';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../db/app_database.dart';
import '../../ical/ical_event_projection.dart';
import '../../providers/busy_provider.dart';
import '../dav_errors.dart';
import '../ical/ical_document.dart';
import '../ical/ical_recurrence.dart';
import '../ical/ical_semantics.dart';
import '../ical/ical_timezone.dart';
import '../mutation/dav_mutation_patch.dart';
import '../mutation/dav_pending_operation_selection.dart';
import '../nextcloud/nextcloud_scheduling_policy.dart';
import 'dav_collection_capabilities.dart';

const davRawObjectParserVersion = 1;
const davProjectionVersion = 5;
const davSyncStateSchemaVersion = 1;

Map<String, Object?> nextcloudParticipantProjection(
  Map<String, Object?> raw,
  NextcloudSchedulingPolicy policy,
) {
  final address = raw['value']?.toString() ?? '';
  final parameters = {
    for (final p in raw['parameters'] as List? ?? const [])
      if (p is Map && p['values'] is List)
        p['name']: (p['values'] as List).firstOrNull?.toString(),
  };
  final normalized = normalizeCalendarAddress(address);
  return {
    ...raw,
    'email': normalized.startsWith('mailto:')
        ? normalized.substring(7)
        : address,
    'displayName': parameters['CN'],
    'optional': parameters['ROLE'] == 'OPT-PARTICIPANT',
    'self': policy.ownsAddress(address),
    'responseStatus': switch (parameters['PARTSTAT']) {
      'ACCEPTED' => 'accepted',
      'TENTATIVE' => 'tentative',
      'DECLINED' => 'declined',
      _ => 'needsAction',
    },
    if (parameters['SCHEDULE-STATUS'] != null)
      'scheduleStatus': parameters['SCHEDULE-STATUS'],
  };
}

final class DavPreparedObject {
  const DavPreparedObject._({
    required this.hrefKey,
    required this.requestUri,
    required this.etag,
    required this.contentType,
    required this.rawIcsBody,
    required this.rawBodyHash,
    required this.semantic,
  });

  factory DavPreparedObject.parse({
    required String hrefKey,
    required Uri requestUri,
    required String? etag,
    required String? contentType,
    required String rawIcsBody,
    int maximumResourceBytes = 16 * 1024 * 1024,
  }) {
    final trimmedHref = hrefKey.trim();
    if (trimmedHref.isEmpty ||
        !trimmedHref.startsWith('/') ||
        requestUri.userInfo.isNotEmpty ||
        requestUri.hasFragment ||
        requestUri.hasQuery) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavInvalidObjectIdentity',
        safeMessage: 'A DAV object had an invalid resource identity.',
      );
    }
    final bytes = utf8.encode(rawIcsBody);
    if (bytes.length > maximumResourceBytes) {
      throw const DavException(
        kind: DavErrorKind.maximumResourceSize,
        code: 'DavCalendarObjectTooLarge',
        safeMessage: 'A calendar object exceeded the configured size limit.',
      );
    }
    return DavPreparedObject._(
      hrefKey: trimmedHref,
      requestUri: requestUri,
      etag: etag,
      contentType: contentType,
      rawIcsBody: rawIcsBody,
      rawBodyHash: sha256.convert(bytes).toString(),
      semantic: IcalSemanticDocument.parse(rawIcsBody),
    );
  }

  final String hrefKey;
  final Uri requestUri;
  final String? etag;
  final String? contentType;
  final String rawIcsBody;
  final String rawBodyHash;
  final IcalSemanticDocument semantic;
}

final class DavCollectionCommit {
  DavCollectionCommit({
    required this.accountId,
    required this.collectionId,
    required this.provider,
    required this.objects,
    required Set<String> deletedHrefKeys,
    required this.completeMembership,
    required Set<String> membershipHrefKeys,
    required this.finalCursorKind,
    required this.finalCursorValue,
    required this.baselineGeneration,
    required this.completedAtUtc,
    required this.projectionRangeStartUtc,
    required this.projectionRangeEndUtc,
    this.forceReprojection = false,
  }) : deletedHrefKeys = Set.unmodifiable(deletedHrefKeys),
       membershipHrefKeys = Set.unmodifiable(membershipHrefKeys) {
    final objectKeys = objects.map((object) => object.hrefKey).toList();
    if (objectKeys.toSet().length != objectKeys.length ||
        objectKeys.any(this.deletedHrefKeys.contains) ||
        (completeMembership &&
            objectKeys.any((key) => !this.membershipHrefKeys.contains(key)))) {
      throw ArgumentError('The DAV collection commit is internally invalid.');
    }
    if (finalCursorValue.isEmpty || baselineGeneration < 0) {
      throw ArgumentError('The DAV cursor state is invalid.');
    }
  }

  final String accountId;
  final String collectionId;
  final BusyProvider provider;
  final List<DavPreparedObject> objects;
  final Set<String> deletedHrefKeys;
  final bool completeMembership;
  final Set<String> membershipHrefKeys;
  final String finalCursorKind;
  final String finalCursorValue;
  final int baselineGeneration;
  final DateTime completedAtUtc;
  final DateTime projectionRangeStartUtc;
  final DateTime projectionRangeEndUtc;
  final bool forceReprojection;
}

final class DavObjectRepository {
  DavObjectRepository({
    required AppDatabase database,
    String Function()? idFactory,
    IcalRecurrenceExpander? recurrenceExpander,
  }) : _database = database,
       _idFactory = idFactory ?? const Uuid().v4,
       _recurrenceExpander = recurrenceExpander ?? IcalRecurrenceExpander();

  final AppDatabase _database;
  final String Function() _idFactory;
  final IcalRecurrenceExpander _recurrenceExpander;

  Future<DavObject?> objectByHref(String collectionId, String hrefKey) {
    return (_database.select(_database.davObjects)..where(
          (row) =>
              row.collectionId.equals(collectionId) &
              row.hrefKey.equals(hrefKey),
        ))
        .getSingleOrNull();
  }

  Future<List<DavObject>> liveObjects(String collectionId) {
    return (_database.select(_database.davObjects)..where(
          (row) =>
              row.collectionId.equals(collectionId) &
              row.serverDeleted.equals(false),
        ))
        .get();
  }

  Future<SyncCursor?> cursor(String collectionId) {
    return (_database.select(_database.syncCursors)..where(
          (row) =>
              row.davCollectionId.equals(collectionId) &
              row.transport.equals('caldav') &
              row.syncScopeKind.equals('collection'),
        ))
        .getSingleOrNull();
  }

  Future<int> nextBaselineGeneration(String collectionId) async {
    final current = await cursor(collectionId);
    return (current?.baselineGeneration ?? 0) + 1;
  }

  Future<void> markSyncStarted({
    required String accountId,
    required String collectionId,
    required BusyProvider provider,
    required int generation,
  }) async {
    final existing = await cursor(collectionId);
    await _database
        .into(_database.syncCursors)
        .insertOnConflictUpdate(
          SyncCursorsCompanion.insert(
            id: existing?.id ?? 'dav-sync-$collectionId',
            accountId: accountId,
            provider: provider.storageValue,
            transport: 'caldav',
            syncScopeKind: 'collection',
            davCollectionId: Value(collectionId),
            cursorKind: existing?.cursorKind ?? 'snapshot_generation',
            cursorValue: existing?.cursorValue ?? '0',
            baselineGeneration: Value(existing?.baselineGeneration ?? 0),
            inProgressCursor: const Value(null),
            inProgressGeneration: Value(generation),
            lastCompleteSyncAt: Value(existing?.lastCompleteSyncAt),
            lastFailureCode: const Value(null),
            stateSchemaVersion: const Value(davSyncStateSchemaVersion),
          ),
        );
  }

  Future<void> markSyncFailed({
    required String collectionId,
    required String errorCode,
  }) async {
    await (_database.update(_database.syncCursors)..where(
          (row) =>
              row.davCollectionId.equals(collectionId) &
              row.transport.equals('caldav'),
        ))
        .write(
          SyncCursorsCompanion(
            inProgressCursor: const Value(null),
            inProgressGeneration: const Value(null),
            lastFailureCode: Value(errorCode),
          ),
        );
  }

  /// Rebuilds bounded occurrence/task projections from the effective local
  /// resource, including durable pending create/update/move overlays.
  /// Advancing the UI horizon never requires a server-wide download and does
  /// not alter the durable transport cursor or pending operation.
  Future<Set<String>> reprojectCollectionFromStored({
    required String accountId,
    required String collectionId,
    required BusyProvider provider,
    required DateTime projectionRangeStartUtc,
    required DateTime projectionRangeEndUtc,
    DateTime? completedAtUtc,
  }) async {
    final collection = await (_database.select(
      _database.davCollections,
    )..where((row) => row.id.equals(collectionId))).getSingle();
    if (collection.accountId != accountId) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavCollectionAccountMismatch',
        safeMessage: 'The DAV collection did not belong to the account.',
      );
    }
    final objects = await liveObjects(collectionId);
    final parsed = <String, IcalSemanticDocument>{};
    for (final object in objects) {
      parsed[object.id] = IcalSemanticDocument.parse(object.rawIcsBody);
    }
    final cursorState = await cursor(collectionId);
    final now = (completedAtUtc ?? DateTime.now()).toUtc();
    return _database.transaction(() async {
      final affected = <String>{};
      var completelyCovered = true;
      for (final object in objects) {
        final pending = await _effectivePendingOperation(object.id);
        // A pending whole-resource delete is already absent from the effective
        // local calendar at every date, so it needs no new occurrence rows.
        if (pending?.operationType == 'dav.delete') continue;
        final semantic = pending == null
            ? parsed[object.id]!
            : IcalSemanticDocument.parse(
                _pendingCandidateRaw(pending, nowUtc: now),
              );
        final componentIds = await _replaceComponentIndex(object.id, semantic);
        final projected = await _replaceProjectionsSafely(
          commit: DavCollectionCommit(
            accountId: accountId,
            collectionId: collectionId,
            provider: provider,
            objects: const [],
            deletedHrefKeys: const {},
            completeMembership: false,
            membershipHrefKeys: const {},
            finalCursorKind: cursorState?.cursorKind ?? 'snapshot_generation',
            finalCursorValue: cursorState?.cursorValue ?? '0',
            baselineGeneration: cursorState?.baselineGeneration ?? 0,
            completedAtUtc: now,
            projectionRangeStartUtc: projectionRangeStartUtc,
            projectionRangeEndUtc: projectionRangeEndUtc,
          ),
          collection: collection,
          objectId: object.id,
          etag: object.etag,
          semantic: semantic,
          componentIds: componentIds,
        );
        if (!projected) {
          completelyCovered = false;
          continue;
        }
        if (pending != null) {
          await _restorePendingProjectionState(pending, now);
        }
        affected.add(object.id);
      }
      await _resolveProjectedTaskParents(collectionId);
      if (cursorState != null) {
        await (_database.update(
          _database.syncCursors,
        )..where((row) => row.id.equals(cursorState.id))).write(
          SyncCursorsCompanion(
            // Successful objects now contain rows for the requested window.
            // If any sibling failed, retaining the old claim would describe
            // rows that were just replaced and could suppress a later repair.
            stateJson: Value(
              completelyCovered
                  ? jsonEncode({
                      'projectionRangeStartUtc': projectionRangeStartUtc
                          .toUtc()
                          .toIso8601String(),
                      'projectionRangeEndUtc': projectionRangeEndUtc
                          .toUtc()
                          .toIso8601String(),
                      'projectionVersion': davProjectionVersion,
                    })
                  : null,
            ),
          ),
        );
      }
      await (_database.update(
        _database.davCollections,
      )..where((row) => row.id.equals(collectionId))).write(
        DavCollectionsCompanion(
          projectionVersion: const Value(davProjectionVersion),
          updatedAtUtc: Value(now.toIso8601String()),
        ),
      );
      return affected;
    });
  }

  /// Rebuilds projections from a validated pending mutation candidate without
  /// replacing the server-confirmed raw body or ETag. The pending operation
  /// remains the durable local overlay and synchronization conflict baseline.
  Future<Set<String>> projectLocalMutationCandidate({
    required String accountId,
    required String collectionId,
    required BusyProvider provider,
    required String objectId,
    required String candidateRawIcs,
    DateTime? projectedAtUtc,
  }) async {
    final account = await (_database.select(
      _database.accounts,
    )..where((row) => row.id.equals(accountId))).getSingleOrNull();
    final collection = await (_database.select(
      _database.davCollections,
    )..where((row) => row.id.equals(collectionId))).getSingleOrNull();
    final object = await (_database.select(
      _database.davObjects,
    )..where((row) => row.id.equals(objectId))).getSingleOrNull();
    if (account == null ||
        collection == null ||
        object == null ||
        account.provider != provider.storageValue ||
        collection.accountId != accountId ||
        object.accountId != accountId ||
        object.collectionId != collectionId ||
        object.serverDeleted) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavLocalCandidateContextInvalid',
        safeMessage: 'The pending DAV projection context was invalid.',
      );
    }
    final semantic = IcalSemanticDocument.parse(candidateRawIcs);
    final now = (projectedAtUtc ?? DateTime.now()).toUtc();
    final cursorState = await cursor(collectionId);
    final projectionRange = _projectionRange(cursorState, now);
    final context = DavCollectionCommit(
      accountId: accountId,
      collectionId: collectionId,
      provider: provider,
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: cursorState?.cursorKind ?? 'snapshot_generation',
      finalCursorValue: cursorState?.cursorValue ?? '0',
      baselineGeneration: object.baselineGeneration,
      completedAtUtc: now,
      projectionRangeStartUtc: projectionRange.start,
      projectionRangeEndUtc: projectionRange.end,
    );
    return _database.transaction(() async {
      final componentIds = await _replaceComponentIndex(objectId, semantic);
      await _replaceProjectionsSafely(
        commit: context,
        collection: collection,
        objectId: objectId,
        etag: object.etag,
        semantic: semantic,
        componentIds: componentIds,
      );
      await (_database.update(
        _database.calendarEvents,
      )..where((row) => row.davObjectId.equals(objectId))).write(
        CalendarEventsCompanion(
          syncStatus: const Value('pending'),
          updatedAtLocal: Value(now.millisecondsSinceEpoch),
        ),
      );
      await (_database.update(
        _database.tasks,
      )..where((row) => row.davObjectId.equals(objectId))).write(
        TasksCompanion(
          localDirty: const Value(true),
          updatedLocalAtUtc: Value(now.toIso8601String()),
        ),
      );
      await _resolveProjectedTaskParents(collectionId);
      return {objectId};
    });
  }

  /// Restores one object's projections from its server-confirmed raw body.
  ///
  /// The pending overlay must already have been removed in the caller's
  /// transaction so projection state cannot be restored from the discarded
  /// candidate again.
  Future<void> restoreServerProjectionAfterDiscard({
    required String accountId,
    required String objectId,
    required DateTime restoredAtUtc,
  }) async {
    final account = await (_database.select(
      _database.accounts,
    )..where((row) => row.id.equals(accountId))).getSingleOrNull();
    final object = await (_database.select(
      _database.davObjects,
    )..where((row) => row.id.equals(objectId))).getSingleOrNull();
    final collection = object == null
        ? null
        : await (_database.select(_database.davCollections)
                ..where((row) => row.id.equals(object.collectionId)))
              .getSingleOrNull();
    if (account == null ||
        object == null ||
        collection == null ||
        object.accountId != accountId ||
        collection.accountId != accountId ||
        object.serverDeleted) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavDiscardBaselineUnavailable',
        safeMessage: 'The DAV server baseline could not be restored.',
      );
    }
    final now = restoredAtUtc.toUtc();
    final range = _projectionRange(await cursor(collection.id), now);
    final semantic = IcalSemanticDocument.parse(object.rawIcsBody);
    final context = DavCollectionCommit(
      accountId: accountId,
      collectionId: collection.id,
      provider: BusyProviderCodec.requireStorageValue(account.provider),
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: 'discard_restore',
      finalCursorValue: '0',
      baselineGeneration: object.baselineGeneration,
      completedAtUtc: now,
      projectionRangeStartUtc: range.start,
      projectionRangeEndUtc: range.end,
    );
    final componentIds = await _replaceComponentIndex(object.id, semantic);
    await _replaceProjections(
      commit: context,
      collection: collection,
      objectId: object.id,
      etag: object.etag,
      semantic: semantic,
      componentIds: componentIds,
    );
    await (_database.update(
      _database.davObjects,
    )..where((row) => row.id.equals(object.id))).write(
      const DavObjectsCompanion(
        lastParseStatus: Value('parsed'),
        lastParseErrorCode: Value(null),
      ),
    );
    await _resolveProjectedTaskParents(collection.id);
  }

  /// Gives a native import the same raw resource identity and bounded
  /// projection used by synchronization. A null ETag is explicitly unconfirmed;
  /// the caller must attach its conditional create in the same transaction.
  Future<String> projectPendingImport({
    required String accountId,
    required String collectionId,
    required DavPreparedObject object,
    required DateTime nowUtc,
  }) async {
    if (object.etag != null ||
        await objectByHref(collectionId, object.hrefKey) != null) {
      throw ArgumentError(
        'A pending import must be a new unconfirmed resource.',
      );
    }
    final collection = await (_database.select(
      _database.davCollections,
    )..where((r) => r.id.equals(collectionId))).getSingle();
    final account = await (_database.select(
      _database.accounts,
    )..where((r) => r.id.equals(accountId))).getSingle();
    if (collection.accountId != accountId ||
        account.provider != BusyProvider.nextcloud.storageValue) {
      throw ArgumentError('Invalid native import destination.');
    }
    final range = _projectionRange(await cursor(collectionId), nowUtc);
    final context = DavCollectionCommit(
      accountId: accountId,
      collectionId: collectionId,
      provider: BusyProvider.nextcloud,
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: 'snapshot_generation',
      finalCursorValue: '0',
      baselineGeneration: 0,
      completedAtUtc: nowUtc,
      projectionRangeStartUtc: range.start,
      projectionRangeEndUtc: range.end,
    );
    final id = await _upsertPreparedObject(
      commit: context,
      collection: collection,
      prepared: object,
    );
    await (_database.update(_database.calendarEvents)
          ..where((r) => r.davObjectId.equals(id)))
        .write(const CalendarEventsCompanion(syncStatus: Value('pending')));
    await (_database.update(
      _database.tasks,
    )..where((r) => r.davObjectId.equals(id))).write(
      const TasksCompanion(localDirty: Value(true), localCreated: Value(true)),
    );
    await _resolveProjectedTaskParents(collectionId);
    return id;
  }

  /// Stores the server-confirmed representation from a conditional mutation
  /// without advancing the collection sync cursor. A follow-up incremental
  /// sync remains responsible for obtaining the provider's next opaque token.
  Future<Set<String>> commitConfirmedMutation({
    required String accountId,
    required String collectionId,
    required BusyProvider provider,
    DavPreparedObject? canonicalObject,
    String? deletedHrefKey,
    DateTime? completedAtUtc,
  }) async {
    if ((canonicalObject == null) == (deletedHrefKey == null)) {
      throw ArgumentError(
        'A confirmed mutation must contain exactly one object outcome.',
      );
    }
    final collection = await (_database.select(
      _database.davCollections,
    )..where((row) => row.id.equals(collectionId))).getSingle();
    if (collection.accountId != accountId) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavCollectionAccountMismatch',
        safeMessage: 'The DAV collection did not belong to the account.',
      );
    }
    final cursorState = await cursor(collectionId);
    final now = (completedAtUtc ?? DateTime.now()).toUtc();
    final projectionRange = _projectionRange(cursorState, now);
    final context = DavCollectionCommit(
      accountId: accountId,
      collectionId: collectionId,
      provider: provider,
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: cursorState?.cursorKind ?? 'snapshot_generation',
      finalCursorValue: cursorState?.cursorValue ?? '0',
      baselineGeneration: cursorState?.baselineGeneration ?? 0,
      completedAtUtc: now,
      projectionRangeStartUtc: projectionRange.start,
      projectionRangeEndUtc: projectionRange.end,
    );
    return _database.transaction(() async {
      if (canonicalObject != null) {
        final id = await _upsertPreparedObject(
          commit: context,
          collection: collection,
          prepared: canonicalObject,
          ignorePendingOperations: true,
        );
        await _resolveProjectedTaskParents(collectionId);
        return {id};
      }
      final object = await objectByHref(collectionId, deletedHrefKey!);
      if (object == null) return const <String>{};
      await _markObjectDeleted(object, context, ignorePendingOperations: true);
      await _resolveProjectedTaskParents(collectionId);
      return {object.id};
    });
  }

  /// Atomically replaces a confirmed source resource with the canonical
  /// resource returned from its destination collection after WebDAV MOVE.
  Future<Set<String>> commitConfirmedMove({
    required String accountId,
    required String sourceCollectionId,
    required String destinationCollectionId,
    required BusyProvider provider,
    required String sourceHrefKey,
    required DavPreparedObject canonicalDestinationObject,
    DateTime? completedAtUtc,
  }) async {
    if (sourceCollectionId == destinationCollectionId) {
      throw ArgumentError('A DAV move requires two different collections.');
    }
    final account = await (_database.select(
      _database.accounts,
    )..where((row) => row.id.equals(accountId))).getSingleOrNull();
    final collections =
        await (_database.select(_database.davCollections)..where(
              (row) =>
                  row.id.isIn([sourceCollectionId, destinationCollectionId]),
            ))
            .get();
    final source = collections
        .where((collection) => collection.id == sourceCollectionId)
        .firstOrNull;
    final destination = collections
        .where((collection) => collection.id == destinationCollectionId)
        .firstOrNull;
    if (account == null ||
        account.provider != provider.storageValue ||
        source == null ||
        destination == null ||
        source.accountId != accountId ||
        destination.accountId != accountId ||
        !_hrefIsMemberOf(
          canonicalDestinationObject.hrefKey,
          destination.hrefKey,
        )) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavMoveContextInvalid',
        safeMessage: 'The confirmed DAV move context was invalid.',
      );
    }
    final now = (completedAtUtc ?? DateTime.now()).toUtc();
    final sourceCursor = await cursor(sourceCollectionId);
    final destinationCursor = await cursor(destinationCollectionId);
    final sourceRange = _projectionRange(sourceCursor, now);
    final destinationRange = _projectionRange(destinationCursor, now);
    final sourceContext = DavCollectionCommit(
      accountId: accountId,
      collectionId: sourceCollectionId,
      provider: provider,
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: sourceCursor?.cursorKind ?? 'snapshot_generation',
      finalCursorValue: sourceCursor?.cursorValue ?? '0',
      baselineGeneration: sourceCursor?.baselineGeneration ?? 0,
      completedAtUtc: now,
      projectionRangeStartUtc: sourceRange.start,
      projectionRangeEndUtc: sourceRange.end,
    );
    final destinationContext = DavCollectionCommit(
      accountId: accountId,
      collectionId: destinationCollectionId,
      provider: provider,
      objects: const [],
      deletedHrefKeys: const {},
      completeMembership: false,
      membershipHrefKeys: const {},
      finalCursorKind: destinationCursor?.cursorKind ?? 'snapshot_generation',
      finalCursorValue: destinationCursor?.cursorValue ?? '0',
      baselineGeneration: destinationCursor?.baselineGeneration ?? 0,
      completedAtUtc: now,
      projectionRangeStartUtc: destinationRange.start,
      projectionRangeEndUtc: destinationRange.end,
    );
    return _database.transaction(() async {
      final affected = <String>{};
      final resolutions = LocationResolutionRepository(_database);
      final sourceObject = await objectByHref(
        sourceCollectionId,
        sourceHrefKey,
      );
      final remembered = sourceObject == null
          ? const <RememberedLocationSnapshot>[]
          : await resolutions.capture(
              accountId: accountId,
              davObjectId: sourceObject.id,
            );
      final effectiveDestinationContext = _includingRememberedLocationCoverage(
        destinationContext,
        remembered,
      );
      if (sourceObject != null) {
        await _markObjectDeleted(
          sourceObject,
          sourceContext,
          ignorePendingOperations: true,
        );
        affected.add(sourceObject.id);
      }
      final destinationObjectId = await _upsertPreparedObject(
        commit: effectiveDestinationContext,
        collection: destination,
        prepared: canonicalDestinationObject,
        ignorePendingOperations: true,
      );
      affected.add(destinationObjectId);
      await resolutions.restore(
        remembered,
        accountId: accountId,
        sourceId:
            canonicalDestinationObject
                    .semantic
                    .components
                    .firstOrNull
                    ?.componentType ==
                'VTODO'
            ? 'dav-task-list-$destinationCollectionId'
            : 'dav-calendar-$destinationCollectionId',
        davObjectId: destinationObjectId,
      );
      await _resolveProjectedTaskParents(sourceCollectionId);
      await _resolveProjectedTaskParents(destinationCollectionId);
      return affected;
    });
  }

  /// Atomically promotes a fully fetched and parsed collection change set.
  /// Network work and parsing happen before this method is entered, so any
  /// database/projection error rolls back to the prior complete baseline.
  Future<Set<String>> commit(DavCollectionCommit commit) {
    return _database.transaction(() async {
      final account = await (_database.select(
        _database.accounts,
      )..where((row) => row.id.equals(commit.accountId))).getSingleOrNull();
      final collection = await (_database.select(
        _database.davCollections,
      )..where((row) => row.id.equals(commit.collectionId))).getSingleOrNull();
      if (account == null ||
          collection == null ||
          collection.accountId != commit.accountId ||
          account.provider != commit.provider.storageValue) {
        throw const DavException(
          kind: DavErrorKind.protocol,
          code: 'DavCollectionAccountMismatch',
          safeMessage: 'The DAV collection did not belong to the account.',
        );
      }

      final changedObjectIds = <String>{};
      for (final prepared in commit.objects) {
        final objectId = await _upsertPreparedObject(
          commit: commit,
          collection: collection,
          prepared: prepared,
        );
        changedObjectIds.add(objectId);
      }

      final deletedObjectIds = <String>{};
      final explicitDeleted =
          await (_database.select(_database.davObjects)..where(
                (row) =>
                    row.collectionId.equals(commit.collectionId) &
                    row.hrefKey.isIn(commit.deletedHrefKeys),
              ))
              .get();
      for (final object in explicitDeleted) {
        await _markObjectDeleted(object, commit);
        deletedObjectIds.add(object.id);
      }

      if (commit.completeMembership) {
        final allObjects = await (_database.select(
          _database.davObjects,
        )..where((row) => row.collectionId.equals(commit.collectionId))).get();
        for (final object in allObjects) {
          if (commit.membershipHrefKeys.contains(object.hrefKey)) {
            await (_database.update(
              _database.davObjects,
            )..where((row) => row.id.equals(object.id))).write(
              DavObjectsCompanion(
                baselineGeneration: Value(commit.baselineGeneration),
              ),
            );
          } else if (!object.serverDeleted) {
            await _markObjectDeleted(object, commit);
            deletedObjectIds.add(object.id);
          }
        }
      }

      if (commit.forceReprojection) {
        final live =
            await (_database.select(_database.davObjects)..where(
                  (row) =>
                      row.collectionId.equals(commit.collectionId) &
                      row.serverDeleted.equals(false),
                ))
                .get();
        for (final object in live) {
          final pending = await _effectivePendingOperation(object.id);
          if (changedObjectIds.contains(object.id) && pending == null) continue;
          // A whole-resource delete is absent throughout the effective local
          // calendar, so it is already covered without occurrence rows.
          if (pending?.operationType == 'dav.delete') continue;
          final semantic = pending == null
              ? IcalSemanticDocument.parse(object.rawIcsBody)
              : IcalSemanticDocument.parse(
                  _pendingCandidateRaw(
                    pending,
                    nowUtc: commit.completedAtUtc.toUtc(),
                  ),
                );
          final componentIds = await _replaceComponentIndex(
            object.id,
            semantic,
          );
          final projected = await _replaceProjectionsSafely(
            commit: commit,
            collection: collection,
            objectId: object.id,
            etag: object.etag,
            semantic: semantic,
            componentIds: componentIds,
          );
          if (projected && pending != null) {
            await _restorePendingProjectionState(
              pending,
              commit.completedAtUtc.toUtc(),
            );
          }
          changedObjectIds.add(object.id);
        }
      }

      await _resolveProjectedTaskParents(commit.collectionId);

      final completed = commit.completedAtUtc.toUtc();
      final cursorId = 'dav-sync-${commit.collectionId}';
      final failedProjection =
          await (_database.select(_database.davObjects)
                ..where(
                  (row) =>
                      row.collectionId.equals(commit.collectionId) &
                      row.serverDeleted.equals(false) &
                      row.lastParseStatus.equals('projection_failed'),
                )
                ..limit(1))
              .getSingleOrNull();
      await _database
          .into(_database.syncCursors)
          .insertOnConflictUpdate(
            SyncCursorsCompanion.insert(
              id: cursorId,
              accountId: commit.accountId,
              provider: commit.provider.storageValue,
              transport: 'caldav',
              syncScopeKind: 'collection',
              davCollectionId: Value(commit.collectionId),
              cursorKind: commit.finalCursorKind,
              cursorValue: commit.finalCursorValue,
              baselineGeneration: Value(commit.baselineGeneration),
              inProgressCursor: const Value(null),
              inProgressGeneration: const Value(null),
              lastCompleteSyncAt: Value(completed.millisecondsSinceEpoch),
              lastFailureCode: const Value(null),
              stateSchemaVersion: const Value(davSyncStateSchemaVersion),
              // The opaque transport token can advance independently, but a
              // partial projection must not advertise a complete date range.
              stateJson: Value(
                failedProjection == null
                    ? jsonEncode({
                        'projectionRangeStartUtc': commit
                            .projectionRangeStartUtc
                            .toUtc()
                            .toIso8601String(),
                        'projectionRangeEndUtc': commit.projectionRangeEndUtc
                            .toUtc()
                            .toIso8601String(),
                        'projectionVersion': davProjectionVersion,
                      })
                    : null,
              ),
            ),
          );
      await (_database.update(
        _database.davCollections,
      )..where((row) => row.id.equals(commit.collectionId))).write(
        DavCollectionsCompanion(
          syncToken: Value(
            commit.finalCursorKind == 'dav_sync_token'
                ? commit.finalCursorValue
                : null,
          ),
          serverMissing: const Value(false),
          lastSyncAtUtc: Value(completed.toIso8601String()),
          parserVersion: const Value(davRawObjectParserVersion),
          projectionVersion: const Value(davProjectionVersion),
          updatedAtUtc: Value(completed.toIso8601String()),
        ),
      );
      await (_database.update(
        _database.accounts,
      )..where((row) => row.id.equals(commit.accountId))).write(
        AccountsCompanion(
          lastSuccessfulSyncAtUtc: Value(completed.toIso8601String()),
          updatedAtUtc: Value(completed.toIso8601String()),
        ),
      );
      return {...changedObjectIds, ...deletedObjectIds};
    });
  }

  Future<String> _upsertPreparedObject({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required DavPreparedObject prepared,
    bool ignorePendingOperations = false,
  }) async {
    final existing =
        await (_database.select(_database.davObjects)..where(
              (row) =>
                  row.collectionId.equals(commit.collectionId) &
                  row.hrefKey.equals(prepared.hrefKey),
            ))
            .getSingleOrNull();
    final objectId = existing?.id ?? _idFactory();
    final now = commit.completedAtUtc.toUtc().toIso8601String();
    final rawChanged = existing?.rawBodyHash != prepared.rawBodyHash;
    final semanticChanged =
        existing?.semanticHash != prepared.semantic.semanticHash;
    await _database
        .into(_database.davObjects)
        .insertOnConflictUpdate(
          DavObjectsCompanion.insert(
            id: objectId,
            accountId: commit.accountId,
            collectionId: commit.collectionId,
            hrefKey: prepared.hrefKey,
            requestUri: prepared.requestUri.toString(),
            etag: Value(prepared.etag),
            contentType: Value(prepared.contentType),
            dominantComponentType: Value(
              prepared.semantic.dominantComponentType,
            ),
            componentMask: Value(prepared.semantic.componentMask),
            primaryUid: Value(prepared.semantic.primaryUid),
            rawIcsBody: prepared.rawIcsBody,
            rawBodyHash: prepared.rawBodyHash,
            semanticHash: Value(prepared.semantic.semanticHash),
            serverDeleted: const Value(false),
            baselineGeneration: Value(commit.baselineGeneration),
            firstSeenAtUtc: existing?.firstSeenAtUtc ?? now,
            lastFetchedAtUtc: now,
            lastChangedAtUtc: rawChanged
                ? now
                : existing?.lastChangedAtUtc ?? now,
            lastParseStatus: const Value('parsed'),
            lastParseErrorCode: const Value(null),
            parserVersion: const Value(davRawObjectParserVersion),
          ),
        );

    if (rawChanged ||
        semanticChanged ||
        (existing?.etag == null && prepared.etag != null) ||
        existing?.parserVersion != davRawObjectParserVersion ||
        existing?.serverDeleted == true ||
        commit.forceReprojection ||
        ignorePendingOperations) {
      final componentIds = await _replaceComponentIndex(
        objectId,
        prepared.semantic,
      );
      if (ignorePendingOperations ||
          !await _hasActivePendingOperation(objectId)) {
        await _replaceProjectionsSafely(
          commit: commit,
          collection: collection,
          objectId: objectId,
          etag: prepared.etag,
          semantic: prepared.semantic,
          componentIds: componentIds,
        );
      }
    }
    return objectId;
  }

  Future<Map<String, String>> _replaceComponentIndex(
    String objectId,
    IcalSemanticDocument semantic,
  ) async {
    final existing = await (_database.select(
      _database.davObjectComponents,
    )..where((row) => row.davObjectId.equals(objectId))).get();
    final existingIds = {
      for (final row in existing)
        _componentKey(row.componentType, row.uid, row.recurrenceIdKey): row.id,
    };
    final returnedIds = <String>{};
    final result = <String, String>{};
    for (final entry in semantic.buildIndex()) {
      final key = _componentKey(
        entry.componentType,
        entry.uid,
        entry.recurrenceIdKey,
      );
      final id = existingIds[key] ?? _idFactory();
      returnedIds.add(id);
      result[key] = id;
      await _database
          .into(_database.davObjectComponents)
          .insertOnConflictUpdate(
            DavObjectComponentsCompanion.insert(
              id: id,
              davObjectId: objectId,
              componentType: entry.componentType,
              uid: entry.uid,
              recurrenceIdKey: Value(entry.recurrenceIdKey),
              sequence: Value(entry.sequence),
              dtstampUtc: Value(entry.dtstampUtc),
              lastModifiedUtc: Value(entry.lastModifiedUtc),
              semanticHash: entry.semanticHash,
              parserProfileVersion: Value(entry.parserProfileVersion),
            ),
          );
    }
    await (_database.delete(_database.davObjectComponents)..where(
          (row) =>
              row.davObjectId.equals(objectId) & row.id.isNotIn(returnedIds),
        ))
        .go();
    return result;
  }

  Future<void> _replaceProjections({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required String objectId,
    required String? etag,
    required IcalSemanticDocument semantic,
    required Map<String, String> componentIds,
  }) async {
    final resolutions = LocationResolutionRepository(_database);
    final remembered = await resolutions.capture(
      accountId: commit.accountId,
      davObjectId: objectId,
    );
    final effectiveCommit = _includingRememberedLocationCoverage(
      commit,
      remembered,
    );
    await _replaceProjectionsBody(
      commit: effectiveCommit,
      collection: collection,
      objectId: objectId,
      etag: etag,
      semantic: semantic,
      componentIds: componentIds,
    );
    await resolutions.restore(
      remembered,
      accountId: commit.accountId,
      sourceId: semantic.components.firstOrNull?.componentType == 'VTODO'
          ? 'dav-task-list-${commit.collectionId}'
          : 'dav-calendar-${commit.collectionId}',
      davObjectId: objectId,
    );
  }

  /// Keep a fetched resource and advance the collection cursor even when a
  /// resource-specific recurrence or time-zone projection cannot be rendered.
  /// The raw iCalendar body remains available for a later reprojection.
  Future<bool> _replaceProjectionsSafely({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required String objectId,
    required String? etag,
    required IcalSemanticDocument semantic,
    required Map<String, String> componentIds,
  }) async {
    try {
      await _replaceProjections(
        commit: commit,
        collection: collection,
        objectId: objectId,
        etag: etag,
        semantic: semantic,
        componentIds: componentIds,
      );
      await (_database.update(
        _database.davObjects,
      )..where((row) => row.id.equals(objectId))).write(
        const DavObjectsCompanion(
          lastParseStatus: Value('parsed'),
          lastParseErrorCode: Value(null),
        ),
      );
      return true;
    } on DavException catch (error) {
      if (!_isResourceProjectionFailure(error)) rethrow;
      // A failure can happen after some occurrence rows have been written.
      // Remove those partial rows before retaining the raw baseline.
      await _deleteProjections(objectId);
      await (_database.update(
        _database.davObjects,
      )..where((row) => row.id.equals(objectId))).write(
        DavObjectsCompanion(
          lastParseStatus: const Value('projection_failed'),
          lastParseErrorCode: Value(error.code),
        ),
      );
      return false;
    }
  }

  Future<void> _replaceProjectionsBody({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required String objectId,
    required String? etag,
    required IcalSemanticDocument semantic,
    required Map<String, String> componentIds,
  }) async {
    await _deleteProjections(objectId);
    if (semantic.components.isEmpty) return;
    final componentType = semantic.components.first.componentType;
    if (componentType == 'VEVENT') {
      if (!collection.eventProjectionEnabled) return;
      await _projectEvents(
        commit: commit,
        collection: collection,
        objectId: objectId,
        etag: etag,
        semantic: semantic,
        componentIds: componentIds,
      );
    } else if (componentType == 'VTODO') {
      if (!collection.taskProjectionEnabled) return;
      await _projectTasks(
        commit: commit,
        collection: collection,
        objectId: objectId,
        etag: etag,
        semantic: semantic,
        componentIds: componentIds,
      );
    }
  }

  Future<void> _projectEvents({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required String objectId,
    required String? etag,
    required IcalSemanticDocument semantic,
    required Map<String, String> componentIds,
  }) async {
    final scheduling = commit.provider == BusyProvider.nextcloud
        ? await NextcloudSchedulingPolicy.load(_database, collection)
        : null;
    final sourceId = 'dav-calendar-${commit.collectionId}';
    final source = await (_database.select(
      _database.calendarSources,
    )..where((row) => row.id.equals(sourceId))).getSingleOrNull();
    if (source == null) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavCalendarProjectionSourceMissing',
        safeMessage: 'The calendar projection source was missing.',
      );
    }
    final projections =
        IcalEventProjector(
          recurrenceExpander: _recurrenceExpander,
        ).projectSemantic(
          semantic,
          rangeStartUtc: commit.projectionRangeStartUtc,
          rangeEndUtc: commit.projectionRangeEndUtc,
          transport: 'caldav',
        );
    final now = commit.completedAtUtc.toUtc().millisecondsSinceEpoch;
    for (final projected in projections) {
      final attendees = scheduling == null
          ? projected.attendeesJson
          : jsonEncode([
              for (final raw
                  in (jsonDecode(projected.attendeesJson) as List)
                      .whereType<Map>())
                nextcloudParticipantProjection(
                  Map<String, Object?>.from(raw),
                  scheduling,
                ),
            ]);
      final organizer = scheduling == null || projected.organizerJson == null
          ? projected.organizerJson
          : jsonEncode(
              nextcloudParticipantProjection(
                Map<String, Object?>.from(
                  jsonDecode(projected.organizerJson!) as Map,
                ),
                scheduling,
              ),
            );
      final organizerAddress = organizer == null
          ? null
          : (jsonDecode(organizer) as Map)['value']?.toString();
      final ownOrganizer =
          scheduling == null ||
              organizerAddress == null ||
              scheduling.addresses.isEmpty
          ? null
          : scheduling.ownsAddress(organizerAddress);
      final selfAttendee = (jsonDecode(attendees) as List).whereType<Map>().any(
        (a) => a['self'] == true,
      );
      final rawProjection = scheduling == null
          ? projected.rawJson
          : jsonEncode({
              ...Map<String, Object?>.from(
                jsonDecode(projected.rawJson) as Map,
              ),
              'isOrganizer': ownOrganizer,
              'canManageAttendees':
                  scheduling.canInvite &&
                  (organizerAddress == null || ownOrganizer == true),
              'canRespond':
                  scheduling.canReply &&
                  selfAttendee &&
                  collectionCapabilitiesFromStored(collection).canUpdateEvent,
              'federated': scheduling.federated,
            });
      final componentId =
          componentIds[_componentKey(
            'VEVENT',
            projected.uid,
            projected.recurrenceIdKey,
          )]!;
      final eventId = _stableProjectionId(
        'dav-event',
        '$objectId\u0000${projected.occurrenceKey}',
      );
      await _database
          .into(_database.calendarEvents)
          .insertOnConflictUpdate(
            CalendarEventsCompanion.insert(
              id: eventId,
              accountId: commit.accountId,
              calendarSourceId: sourceId,
              provider: commit.provider.storageValue,
              providerCalendarId: collection.hrefKey,
              providerEventId: objectId,
              davCollectionId: Value(commit.collectionId),
              davObjectId: Value(objectId),
              davComponentId: Value(componentId),
              icalUid: Value(projected.uid),
              recurrenceIdKey: Value(projected.recurrenceIdKey),
              occurrenceKey: Value(projected.occurrenceKey),
              projectionVersion: const Value(davProjectionVersion),
              providerRecurringEventId: Value(
                projected.recurring ? projected.uid : null,
              ),
              providerOriginalStartKey: Value(
                projected.recurring ? projected.occurrenceKey : null,
              ),
              etagOrChangeKey: Value(etag),
              status: Value(projected.status),
              title: projected.title,
              description: Value(projected.description),
              location: Value(projected.location),
              locationLatitude: Value(projected.locationPoint?.latitude),
              locationLongitude: Value(projected.locationPoint?.longitude),
              allDay: Value(projected.allDay),
              startDate: Value(projected.startDate),
              startDateTime: Value(projected.startDateTime),
              startTimeZone: Value(projected.startTimeZone),
              endDate: Value(projected.endDate),
              endDateTime: Value(projected.endDateTime),
              endTimeZone: Value(projected.endTimeZone),
              recurrenceJson: Value(projected.recurrenceJson),
              remindersJson: Value(projected.remindersJson),
              attendeesJson: Value(attendees),
              categoriesJson: Value(projected.categoriesJson),
              organizerJson: Value(organizer),
              colorHex: Value(collection.color),
              visibility: Value(projected.visibility),
              transparencyOrShowAs: Value(projected.transparency),
              webLink: Value(projected.webLink),
              attachmentsJson: Value(projected.attachmentsJson),
              isCancelled: Value(projected.cancelled),
              isDeleted: const Value(false),
              rawJson: Value(rawProjection),
              createdAtServer: Value(projected.createdAtServer),
              updatedAtServer: Value(projected.updatedAtServer),
              createdAtLocal: now,
              updatedAtLocal: now,
              syncStatus: const Value('synced'),
              baselineRawJson: Value(rawProjection),
            ),
          );
    }
  }

  Future<void> _projectTasks({
    required DavCollectionCommit commit,
    required DavCollection collection,
    required String objectId,
    required String? etag,
    required IcalSemanticDocument semantic,
    required Map<String, String> componentIds,
  }) async {
    final taskListId = 'dav-task-list-${commit.collectionId}';
    final taskList =
        await (_database.select(_database.taskLists)..where(
              (row) =>
                  row.accountId.equals(commit.accountId) &
                  row.id.equals(taskListId),
            ))
            .getSingleOrNull();
    if (taskList == null) {
      throw const DavException(
        kind: DavErrorKind.protocol,
        code: 'DavTaskProjectionListMissing',
        safeMessage: 'The task-list projection source was missing.',
      );
    }
    final master = semantic.components.firstWhere(
      (component) => component.recurrenceId == null,
    );
    final timeZoneResolver = IcalTimeZoneResolver.fromDocument(semantic);
    final now = commit.completedAtUtc.toUtc().toIso8601String();
    for (final component in semantic.components) {
      final componentId =
          componentIds[_componentKey(
            component.componentType,
            component.uid!,
            component.recurrenceIdKey,
          )]!;
      final taskId = _stableProjectionId(
        'dav-task',
        '$objectId\u0000${component.recurrenceIdKey ?? 'master'}',
      );
      final due = component.due ?? (component == master ? null : master.due);
      final start =
          component.start ?? (component == master ? null : master.start);
      final completed =
          component.completed ??
          (component.taskUiState == IcalTaskUiState.completed
              ? master.completed
              : null);
      final extensions = {
        ...master.extensionProperties,
        ...component.extensionProperties,
      };
      final alarms = component.alarms.isEmpty
          ? master.alarms
          : component.alarms;
      final reminder = _taskReminderProjection(
        alarms,
        start: start,
        due: due,
        timeZoneResolver: timeZoneResolver,
      );
      final startUtc = start == null
          ? null
          : _resolvedTemporalUtc(start, timeZoneResolver);
      final dueUtc = due == null
          ? null
          : _resolvedTemporalUtc(due, timeZoneResolver);
      final metadata = {
        'transport': 'caldav',
        'uid': component.uid,
        if (start != null) 'nativeStart': _temporalJson(start),
        if (due != null) 'nativeDue': _temporalJson(due),
        if (startUtc != null) 'startUtc': startUtc.toIso8601String(),
        if (dueUtc != null) 'dueUtc': dueUtc.toIso8601String(),
        if (component.recurrenceId != null)
          'recurrenceId': _temporalJson(component.recurrenceId!),
        'alarms': _alarmProjection(alarms),
      };
      final taskStatus = switch (component.taskUiState) {
        IcalTaskUiState.completed => 'completed',
        IcalTaskUiState.inProgress => 'inProcess',
        IcalTaskUiState.open => 'needsAction',
        IcalTaskUiState.cancelled => 'cancelled',
      };
      final priority = component.priority ?? master.priority;
      final sortOrder = nextcloudTaskSortOrder(
        component,
        fallback: component == master ? null : master,
      );
      await _database
          .into(_database.tasks)
          .insertOnConflictUpdate(
            TasksCompanion.insert(
              accountId: commit.accountId,
              taskListId: taskListId,
              id: taskId,
              davCollectionId: Value(commit.collectionId),
              davObjectId: Value(objectId),
              davComponentId: Value(componentId),
              icalUid: Value(component.uid),
              recurrenceIdKey: Value(component.recurrenceIdKey),
              icalPriority: Value(priority),
              percentComplete: Value(
                component.percentComplete ?? master.percentComplete,
              ),
              taskLocation: Value(effectiveIcalLocation([component, master])),
              locationLatitude: Value(
                effectiveIcalLocationPoint([component, master])?.latitude,
              ),
              locationLongitude: Value(
                effectiveIcalLocationPoint([component, master])?.longitude,
              ),
              taskUrl: Value(component.url ?? master.url),
              taskClassification: Value(
                component.classification ?? master.classification,
              ),
              taskPinned: Value(_extensionFlag(extensions, 'X-PINNED')),
              taskHideSubtasks: Value(
                _extensionFlag(extensions, 'X-OC-HIDESUBTASKS'),
              ),
              taskHideCompletedSubtasks: Value(
                _extensionFlag(extensions, 'X-OC-HIDECOMPLETEDSUBTASKS'),
              ),
              taskAlarmsJson: Value(jsonEncode(_alarmProjection(alarms))),
              parentUid: Value(component.parentUid ?? master.parentUid),
              sortOrder: Value(sortOrder),
              providerExtensionProjectionJson: Value(jsonEncode(extensions)),
              projectionVersion: const Value(davProjectionVersion),
              kind: const Value('tasks#task'),
              etag: Value(etag),
              title: component.summary ?? master.summary ?? '',
              updatedUtc: Value(
                _storageTemporalNullable(
                  component.lastModified ?? master.lastModified,
                ),
              ),
              parent: Value(component.parentUid ?? master.parentUid),
              position: Value('$sortOrder'),
              notes: Value(component.description ?? master.description),
              status: Value(taskStatus),
              dueUtc: Value(_storageTemporalNullable(due ?? start)),
              microsoftReminderDateTime: Value(reminder?.dateTime),
              microsoftReminderTimeZone: Value(reminder?.timeZone),
              microsoftIsReminderOn: Value(reminder != null),
              completedUtc: Value(_storageTemporalNullable(completed)),
              providerStatus: Value(component.status ?? master.status),
              recurrenceJson: Value(
                jsonEncode({
                  'rules': master.recurrenceRules,
                  'dates': master.recurrenceDates,
                  'excludedDates': master.exceptionDates,
                }),
              ),
              importance: Value(_importanceForIcalPriority(priority)),
              categoriesJson: Value(
                jsonEncode(
                  component.categories.isEmpty
                      ? master.categories
                      : component.categories,
                ),
              ),
              providerMetadataJson: Value(jsonEncode(metadata)),
              deleted: const Value(false),
              hidden: const Value(false),
              rawJson: jsonEncode(metadata),
              serverMissing: const Value(false),
              localDirty: const Value(false),
              pendingDelete: const Value(false),
              pendingMove: const Value(false),
              localCreated: const Value(false),
              lastSyncedAtUtc: Value(now),
              createdLocalAtUtc: now,
              updatedLocalAtUtc: now,
            ),
          );
    }
  }

  Future<void> _markObjectDeleted(
    DavObject object,
    DavCollectionCommit commit, {
    bool ignorePendingOperations = false,
  }) async {
    // An entirely local resource cannot be a server tombstone merely because
    // an inventory doesn't list it yet. Keep its pending create and projection.
    if (!ignorePendingOperations &&
        object.etag == null &&
        await _hasActivePendingOperation(object.id)) {
      return;
    }
    final now = commit.completedAtUtc.toUtc().toIso8601String();
    await (_database.update(
      _database.davObjects,
    )..where((row) => row.id.equals(object.id))).write(
      DavObjectsCompanion(
        serverDeleted: const Value(true),
        baselineGeneration: Value(commit.baselineGeneration),
        lastChangedAtUtc: Value(now),
      ),
    );
    if (ignorePendingOperations ||
        !await _hasActivePendingOperation(object.id)) {
      await _deleteProjections(object.id);
    } else {
      await (_database.update(_database.calendarEvents)
            ..where((row) => row.davObjectId.equals(object.id)))
          .write(const CalendarEventsCompanion(syncStatus: Value('conflict')));
    }
  }

  Future<void> _resolveProjectedTaskParents(String collectionId) async {
    final tasks = await (_database.select(
      _database.tasks,
    )..where((row) => row.davCollectionId.equals(collectionId))).get();
    final masterIdByUid = <String, String>{};
    for (final task in tasks) {
      final uid = task.icalUid;
      if (uid != null && task.recurrenceIdKey == null) {
        masterIdByUid[uid] = task.id;
      }
    }
    for (final task in tasks) {
      final resolvedParentId = task.parentUid == null
          ? null
          : masterIdByUid[task.parentUid!];
      if (task.parent == resolvedParentId) continue;
      await (_database.update(_database.tasks)..where(
            (row) =>
                row.accountId.equals(task.accountId) &
                row.taskListId.equals(task.taskListId) &
                row.id.equals(task.id),
          ))
          .write(TasksCompanion(parent: Value(resolvedParentId)));
    }
  }

  Future<bool> _hasActivePendingOperation(String objectId) async {
    return await _effectivePendingOperation(objectId) != null;
  }

  Future<PendingOp?> _effectivePendingOperation(String objectId) async {
    final operations = await (_database.select(
      _database.pendingOps,
    )..where((row) => row.davObjectId.equals(objectId))).get();
    return effectiveDavPendingOperation(operations, objectId);
  }

  String _pendingCandidateRaw(PendingOp operation, {required DateTime nowUtc}) {
    try {
      if (operation.operationType == 'dav.create') {
        final request = jsonDecode(operation.requestJson);
        final rawIcs = request is Map ? request['rawIcs'] : null;
        if (rawIcs is String && rawIcs.isNotEmpty) return rawIcs;
      } else if (operation.operationType == 'dav.update') {
        final baseline = operation.baselineRawIcs;
        final patch = operation.mutationPatchJson;
        if (baseline != null && patch != null) {
          return DavMutationPatch.fromJsonString(
            patch,
          ).applyTo(baseline, nowUtc: nowUtc);
        }
      } else if (operation.operationType == 'dav.move') {
        final baseline = operation.baselineRawIcs;
        if (baseline != null) {
          final patch = operation.mutationPatchJson;
          return patch == null
              ? baseline
              : DavMutationPatch.fromJsonString(
                  patch,
                ).applyTo(baseline, nowUtc: nowUtc);
        }
      }
    } on DavException {
      rethrow;
    } on Object {
      // Convert malformed durable state into the same safe protocol error as
      // other invalid pending-operation payloads.
    }
    throw const DavException(
      kind: DavErrorKind.protocol,
      code: 'DavPendingProjectionCandidateInvalid',
      safeMessage: 'A pending DAV change could not be projected.',
    );
  }

  Future<void> _restorePendingProjectionState(
    PendingOp operation,
    DateTime nowUtc,
  ) async {
    final objectId = operation.davObjectId!;
    final eventStatus = operation.state == 'conflict' ? 'conflict' : 'pending';
    var eventChanges = CalendarEventsCompanion(
      syncStatus: Value(eventStatus),
      updatedAtLocal: Value(nowUtc.millisecondsSinceEpoch),
    );
    var taskChanges = TasksCompanion(
      localDirty: const Value(true),
      localCreated: Value(operation.operationType == 'dav.create'),
      pendingMove: Value(operation.operationType == 'dav.move'),
      updatedLocalAtUtc: Value(nowUtc.toIso8601String()),
    );
    if (operation.operationType == 'dav.move' &&
        operation.destinationCollectionId != null) {
      final destination =
          await (_database.select(_database.davCollections)..where(
                (row) => row.id.equals(operation.destinationCollectionId!),
              ))
              .getSingleOrNull();
      if (destination != null) {
        eventChanges = eventChanges.copyWith(
          calendarSourceId: Value('dav-calendar-${destination.id}'),
          providerCalendarId: Value(destination.hrefKey),
          davCollectionId: Value(destination.id),
        );
        taskChanges = taskChanges.copyWith(
          taskListId: Value('dav-task-list-${destination.id}'),
          davCollectionId: Value(destination.id),
        );
      }
    }
    await (_database.update(
      _database.calendarEvents,
    )..where((row) => row.davObjectId.equals(objectId))).write(eventChanges);
    await (_database.update(
      _database.tasks,
    )..where((row) => row.davObjectId.equals(objectId))).write(taskChanges);
  }

  Future<void> _deleteProjections(String objectId) async {
    await (_database.delete(
      _database.calendarEvents,
    )..where((row) => row.davObjectId.equals(objectId))).go();
    await (_database.delete(
      _database.tasks,
    )..where((row) => row.davObjectId.equals(objectId))).go();
  }
}

DavCollectionCommit _includingRememberedLocationCoverage(
  DavCollectionCommit commit,
  Iterable<RememberedLocationSnapshot> remembered,
) {
  var start = commit.projectionRangeStartUtc.toUtc();
  var end = commit.projectionRangeEndUtc.toUtc();
  const margin = Duration(days: 1);
  for (final snapshot in remembered) {
    final anchor = snapshot.projectionAnchorUtc?.toUtc();
    if (anchor == null) continue;
    if (!anchor.isAfter(start)) start = anchor.subtract(margin);
    if (!anchor.isBefore(end)) end = anchor.add(margin);
  }
  if (start == commit.projectionRangeStartUtc.toUtc() &&
      end == commit.projectionRangeEndUtc.toUtc()) {
    return commit;
  }
  return DavCollectionCommit(
    accountId: commit.accountId,
    collectionId: commit.collectionId,
    provider: commit.provider,
    objects: commit.objects,
    deletedHrefKeys: commit.deletedHrefKeys,
    completeMembership: commit.completeMembership,
    membershipHrefKeys: commit.membershipHrefKeys,
    finalCursorKind: commit.finalCursorKind,
    finalCursorValue: commit.finalCursorValue,
    baselineGeneration: commit.baselineGeneration,
    completedAtUtc: commit.completedAtUtc,
    projectionRangeStartUtc: start,
    projectionRangeEndUtc: end,
    forceReprojection: commit.forceReprojection,
  );
}

({DateTime start, DateTime end}) _projectionRange(
  SyncCursor? cursor,
  DateTime nowUtc,
) {
  final fallback = (
    start: DateTime.utc(nowUtc.year - 1, nowUtc.month, nowUtc.day),
    end: DateTime.utc(nowUtc.year + 2, nowUtc.month, nowUtc.day),
  );
  final stateJson = cursor?.stateJson;
  if (stateJson == null || stateJson.isEmpty) return fallback;
  try {
    final decoded = jsonDecode(stateJson);
    if (decoded is! Map<String, Object?>) return fallback;
    final startRaw = decoded['projectionRangeStartUtc'];
    final endRaw = decoded['projectionRangeEndUtc'];
    if (startRaw is! String || endRaw is! String) return fallback;
    final start = DateTime.tryParse(startRaw)?.toUtc();
    final end = DateTime.tryParse(endRaw)?.toUtc();
    if (start == null || end == null || !end.isAfter(start)) return fallback;
    return (start: start, end: end);
  } on FormatException {
    return fallback;
  }
}

bool _isResourceProjectionFailure(DavException error) => switch (error.kind) {
  DavErrorKind.invalidCalendarData ||
  DavErrorKind.unsupportedComponent ||
  DavErrorKind.limitExceeded => true,
  _ => false,
};

bool _hrefIsMemberOf(String memberHref, String collectionHref) {
  final prefix = collectionHref.endsWith('/')
      ? collectionHref
      : '$collectionHref/';
  if (!memberHref.startsWith(prefix)) return false;
  final relative = memberHref.substring(prefix.length);
  return relative.isNotEmpty && !relative.contains('/');
}

String _componentKey(String type, String uid, String? recurrenceIdKey) =>
    '$type\u0000$uid\u0000${recurrenceIdKey ?? ''}';

String _stableProjectionId(String prefix, String source) =>
    '$prefix-${sha256.convert(utf8.encode(source))}';

String? _storageTemporalNullable(IcalTemporalValue? value) =>
    value == null ? null : _storageTemporal(value);

String _storageTemporal(IcalTemporalValue value) {
  String two(int number) => number.toString().padLeft(2, '0');
  final wall = value.localValue;
  final date =
      '${wall.year.toString().padLeft(4, '0')}-'
      '${two(wall.month)}-${two(wall.day)}';
  if (value.kind == IcalTemporalKind.date) return date;
  if (value.kind == IcalTemporalKind.utcDateTime) {
    return icalTemporalToUtc(value).toIso8601String();
  }
  return '${date}T${two(wall.hour)}:${two(wall.minute)}:${two(wall.second)}';
}

String? _timeZoneName(IcalTemporalValue value) => switch (value.kind) {
  IcalTemporalKind.utcDateTime => 'UTC',
  IcalTemporalKind.tzidDateTime => value.timeZoneId,
  IcalTemporalKind.date || IcalTemporalKind.floatingDateTime => null,
};

Map<String, Object?> _temporalJson(IcalTemporalValue value) => {
  'raw': value.rawValue,
  'kind': value.kind.name,
  if (value.timeZoneId != null) 'timeZoneId': value.timeZoneId,
};

List<Map<String, Object?>> _alarmProjection(List<IcalComponent> alarms) => [
  for (final alarm in alarms)
    {
      'properties': [
        for (final property in alarm.properties)
          {
            'name': property.name,
            'value': property.rawValue,
            if (property.parameters.isNotEmpty)
              'parameters': [
                for (final parameter in property.parameters)
                  {'name': parameter.name, 'values': parameter.values},
              ],
          },
      ],
    },
];

({String dateTime, String? timeZone})? _taskReminderProjection(
  List<IcalComponent> alarms, {
  required IcalTemporalValue? start,
  required IcalTemporalValue? due,
  required IcalTimeZoneResolver timeZoneResolver,
}) {
  for (final alarm in alarms) {
    final action = alarm.firstProperty('ACTION')?.rawValue.toUpperCase();
    if (action != 'DISPLAY' && action != 'AUDIO') {
      continue;
    }
    final trigger = alarm.firstProperty('TRIGGER');
    if (trigger == null) continue;
    try {
      final duration = parseIcalDuration(trigger.rawValue.toUpperCase());
      if (duration != null) {
        final relatedToEnd =
            trigger.parameterValue('RELATED')?.toUpperCase() == 'END';
        final reference = relatedToEnd ? due : start;
        if (reference == null) continue;
        final referenceUtc = _resolvedTemporalUtc(reference, timeZoneResolver);
        if (referenceUtc != null) {
          return (
            dateTime: referenceUtc
                .add(duration.duration)
                .toUtc()
                .toIso8601String(),
            timeZone: 'UTC',
          );
        }
        final wall = reference.localValue.add(duration.duration);
        final temporal = IcalTemporalValue(
          rawValue: trigger.rawValue,
          kind: reference.kind == IcalTemporalKind.date
              ? IcalTemporalKind.floatingDateTime
              : reference.kind,
          localValue: wall,
          timeZoneId: reference.timeZoneId,
        );
        return (
          dateTime: _storageTemporal(temporal),
          timeZone: _timeZoneName(temporal),
        );
      }
    } on DavException {
      // The trigger may instead be an absolute DATE-TIME.
    }
    try {
      final absolute = parseIcalTemporal(trigger);
      if (absolute?.kind != IcalTemporalKind.utcDateTime) continue;
      return (dateTime: _storageTemporal(absolute!), timeZone: 'UTC');
    } on DavException {
      // Unsupported alarms remain preserved but are not exposed as editable.
    }
  }
  return null;
}

DateTime? _resolvedTemporalUtc(
  IcalTemporalValue value,
  IcalTimeZoneResolver resolver,
) {
  return switch (value.kind) {
    IcalTemporalKind.utcDateTime || IcalTemporalKind.tzidDateTime =>
      icalTemporalToUtc(value, resolver: resolver),
    IcalTemporalKind.date || IcalTemporalKind.floatingDateTime => null,
  };
}

bool _extensionFlag(Map<String, List<String>> extensions, String name) {
  final value = extensions[name]?.firstOrNull?.trim().toUpperCase();
  return value == 'TRUE' || value == '1';
}

String _importanceForIcalPriority(int? priority) {
  if (priority != null && priority >= 1 && priority <= 4) return 'high';
  if (priority != null && priority >= 6 && priority <= 9) return 'low';
  return 'normal';
}
