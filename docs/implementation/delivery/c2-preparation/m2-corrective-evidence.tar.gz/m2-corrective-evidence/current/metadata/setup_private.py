from pathlib import Path
import json,yaml,shutil,hashlib,subprocess
h=Path(__file__).resolve().parent;root=h.parents[1];sdk=Path('/tmp/m2-c2-flutter-sdk');cache=Path('/tmp/m2-c2-pub-cache');owner=Path('/home/albert/flutter-sdk/bin/cache')
def ignored(directory,names):
 p=Path(directory)
 if p==owner:return {'flutter_web_sdk','downloads'}&set(names)
 if p==owner/'artifacts/engine':return {n for n in names if n.startswith(('android','ios','darwin','windows'))}
 return set()
shutil.copytree(owner,sdk/'bin/cache',ignore=ignored,dirs_exist_ok=True)
rows=[]
for name,d in yaml.safe_load((root/'busymax/pubspec.lock').read_text())['packages'].items():
 if d['source']!='hosted':continue
 version=d['version'];folder=name+'-'+version;src=Path('/home/albert/.pub-cache/hosted/pub.dev')/folder;dst=cache/'hosted/pub.dev'/folder;assert src.is_dir(),folder
 shutil.copytree(src,dst,dirs_exist_ok=True)
 sourcehash=Path('/home/albert/.pub-cache/hosted-hashes/pub.dev')/(folder+'.sha256');targethash=cache/'hosted-hashes/pub.dev'/sourcehash.name;targethash.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(sourcehash,targethash);assert sourcehash.read_text().strip()==d['description']['sha256'],folder
 rows.append({'package':name,'version':version,'published_sha256':d['description']['sha256']})
for p in ['profile/config','profile/data','profile/cache','tmp']:(h/p).mkdir(parents=True,exist_ok=True)
(h/'private-toolchain.json').write_text(json.dumps({'sdk':str(sdk),'sdk_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=sdk,text=True).strip(),'copied_sdk_cache':'Pinned Dart and Linux/test engine assets copied; other-platform binary caches omitted, source and versions unchanged. Owner SDK untouched.','pub_cache':str(cache),'public_packages_only':rows,'free_bytes':shutil.disk_usage(root).free},indent=2)+'\n')
p=h/'run.py';s=(h.parent/'lifecycle/run.py').read_text().replace('/tmp/m2-correction-flutter-sdk','/tmp/m2-c2-flutter-sdk').replace('/tmp/m2-correction-pub-cache','/tmp/m2-c2-pub-cache');p.write_text(s)
print('private SDK / locked public cache copied',len(rows),'packages; free',shutil.disk_usage(root).free)
