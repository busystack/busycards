from pathlib import Path
import hashlib,json,subprocess,datetime
h=Path(__file__).resolve().parent;root=h.parents[1];initial=json.loads((h/'baseline.json').read_text());rows=[]
for old in initial['repositories']:
 p=root/old['repo']
 def git(*a):return subprocess.check_output(['git',*a],cwd=p,text=True).strip()
 pins={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in old['pins']}
 row={'repo':old['repo'],'branch':git('branch','--show-current'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'staged':git('diff','--cached','--name-status'),'unstaged':git('diff','--name-status'),'untracked':git('ls-files','--others','--exclude-standard').splitlines(),'pins':pins};assert row['branch']==old['branch'] and not row['staged'];rows.append(row)
 row['unchanged_since_baseline'] = row['head']==old['head'] and row['unstaged']==old['unstaged'] and row['untracked']==old['untracked'] and pins==old['pins']
 if old['repo'] in ['busymax','busystack_contacts','busystack_dav','busystack_graph']:assert pins==old['pins']
repo=root/'busycards';patch=subprocess.check_output(['git','diff','--','.idea/busycards.iml','.idea/libraries/Dart_Packages.xml'],cwd=repo);old=json.loads((h/'environment.json').read_text());d={'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':rows,'all_pins_unchanged':all(r['pins']==i['pins'] for r,i in zip(rows,initial['repositories'])),'owner_ide_patch_sha256_before':old['owner_ide_patch_sha256'],'owner_ide_patch_sha256_after':hashlib.sha256(patch).hexdigest(),'owner_ide_patch_unchanged':hashlib.sha256(patch).hexdigest()==old['owner_ide_patch_sha256']};(h/'final-state.json').write_text(json.dumps(d,indent=2)+'\n');print('All seven branches/pins and unchanged implementations/owner IDE residuals verified')
