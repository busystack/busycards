from pathlib import Path
import hashlib,json,subprocess
h=Path(__file__).resolve().parent;root=h.parents[1];repo=root/'busycards'
docs=['docs/implementation/'+f for f in ['milestone-2-report.md','milestone-2-results.json','milestone-2-ledger.md','milestone-2-integration.md']]
leaves=['busymax-0.2.4-source.tar.gz','busymax-0.2.4-linux-x64.tar.gz','busymax-0.2.4-linux-x64-symbols.tar.gz','m2-corrective-evidence.tar.gz','busymax-source-manifest.json','busymax-linux-x64-manifest.json','busymax-linux-x64-symbols-manifest.json','evidence-manifest.json','manifest.json','SHA256SUMS','README.md']
files=docs+['docs/implementation/delivery/c2-preparation/'+f for f in leaves]
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('branch','--show-current')=='main';assert not git('diff','--cached','--name-only')
assert sorted(p.name for p in (repo/'docs/implementation/delivery/c2-preparation').iterdir())==sorted(leaves)
assert sorted(git('diff','--name-only','--','docs/implementation').splitlines())==sorted(docs)
owner_before=subprocess.check_output(['git','diff','--','.idea/busycards.iml','.idea/libraries/Dart_Packages.xml'],cwd=repo)
parent=git('rev-parse','HEAD');subprocess.run(['git','diff','--check','--',*docs],cwd=repo,check=True)
subprocess.run(['git','add','--',*files],cwd=repo,check=True);assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(files)
subprocess.run(['git','commit','-m','docs(m2): seal C2 preparation evidence and artifact provenance'],cwd=repo,check=True)
assert subprocess.check_output(['git','diff','--','.idea/busycards.iml','.idea/libraries/Dart_Packages.xml'],cwd=repo)==owner_before
r={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parent':parent,'branch':git('branch','--show-current'),'task_owned_files':files,'owner_ide_patch_sha256_preserved':hashlib.sha256(owner_before).hexdigest(),'staged_empty':not git('diff','--cached','--name-only'),'remaining_status':git('status','--short')}
(h/'busycards-doc-commit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
