"""Run the repositories' affected platform commands with isolated task data."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def run(command, repo, env):
    print(json.dumps({'command':command,'cwd':str(repo)}),flush=True)
    subprocess.run(command,cwd=repo,env=env,check=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('app',choices=['busymax','busybox']);p.add_argument('gate',choices=['linux','android']);p.add_argument('--resume-linux',action='store_true');a=p.parse_args()
    repo=ROOT/a.app;env=os.environ.copy()
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
    prereq=json.loads((HERE/(a.app+'-prerequisites.json')).read_text())['unchanged_pins_and_generated_sources']
    for name, expected in prereq.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
    if a.gate=='linux':
        live=repo
        repo=HERE/'extracted'/(a.app+'-source')/a.app
        assert repo.is_dir()
        for name,expected in prereq.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
        if a.app=='busybox':
            helper=repo/'native/microsoft_auth_helper/target/dist'
            helper.parent.mkdir(parents=True,exist_ok=True)
            if not helper.exists(): shutil.copytree(live/'native/microsoft_auth_helper/target/dist',helper,symlinks=True)
            for original in (live/'native/microsoft_auth_helper/target/dist').rglob('*'):
                if original.is_file(): assert hashlib.sha256(original.read_bytes()).digest()==hashlib.sha256((helper/original.relative_to(live/'native/microsoft_auth_helper/target/dist')).read_bytes()).digest(),str(original)
        if a.app=='busymax':
            build_output=Path('/tmp/m2-c2-fresh-busymax-build')
            if not (repo/'build').is_symlink():
                assert not build_output.exists()
                if (repo/'build').exists():
                    # Fresh Dart generation creates native-hook prerequisites.
                    # Preserve these task-owned files on the temporary filesystem.
                    shutil.move(str(repo/'build'),str(build_output))
                else:
                    build_output.mkdir(mode=0o700)
                (repo/'build').symlink_to(build_output,target_is_directory=True)
            assert (repo/'build').resolve()==build_output.resolve()
            record={'fresh_source':str(repo),'build_output':str(build_output),'reason':'Task-owned build outputs on the available private /tmp filesystem; no owner build output reused or removed.'}
            (HERE/'fresh-build-location.json').write_text(json.dumps(record,indent=2)+'\n')
        print('Fresh verified source layout, no reused app build outputs: '+str(repo),flush=True)
    print('Reusing hash-identical locked resolution and generated-source prerequisites recorded in lifecycle receipts.',flush=True)
    if a.gate=='linux':
        if a.app=='busymax':
            run(['flutter','build','linux','--release','-t','lib/main_linux.dart','--split-debug-info=build/linux/x64/release/symbols'],repo,env)
            gtk_config=HERE/'native-test-profile/config'
            (gtk_config/'gtk-3.0').mkdir(parents=True,exist_ok=True)
            (gtk_config/'gtk-3.0/settings.ini').write_text('[Settings]\ngtk-icon-theme-name=Yaru\n')
            gtk_env=env.copy();gtk_env['XDG_CONFIG_HOME']=str(gtk_config)
            run(['xvfb-run','-a','flutter','test','--no-pub','integration_test/gtk_header_icons_integration_test.dart','-d','linux'],repo,gtk_env)
            # Rebuild the normal entry point after the GTK integration test.
            run(['flutter','build','linux','--debug','-t','lib/main_linux.dart'],repo,env)
            run(['python3','test/tool/registration_native_helper_test.py'],repo,env)
            run(['cmake','-S','native/registration_reader','-B','build/linux/registration-reader-tests'],repo,env)
            run(['cmake','--build','build/linux/registration-reader-tests','--target','busymax_registration_reader_tests'],repo,env)
            run(['ctest','--test-dir','build/linux/registration-reader-tests','--output-on-failure'],repo,env)
            for asset in ['docs/google_setup.md','docs/microsoft_setup.md']:
                assert (repo/'build/linux/x64/release/bundle/data/flutter_assets'/asset).is_file(),asset
            run(['bash',str(HERE/'max_native_gates.sh')],repo,env)
            for cmd in [
                ['desktop-file-validate','linux/io.busystack.busymax.desktop'],
                ['appstreamcli','validate','--pedantic','--no-net','linux/io.busystack.busymax.metainfo.xml'],
                ['ldd','build/linux/x64/release/bundle/busymax'],
                ['readelf','-d','build/linux/x64/release/bundle/busymax']
            ]:
                if a.resume_linux and any(part.endswith(('test_distribution.sh','test_microsoft_helper_protocol.dart','verify_microsoft_helper.dart')) for part in cmd): continue
                run(cmd,repo,env)
        else:
            if not a.resume_linux: run(['./tool/build-release.sh','--split-debug-info=build/linux/x64/release/symbols'],repo,env)
            bundle='build/linux/x64/release/bundle'
            if not a.resume_linux: run(['dart','run','tool/sanitize_release_paths.dart',bundle,str(repo)],repo,env)
            helper=str(repo/bundle/'lib/busybox-microsoft-auth')
            for cmd in [
                ['bash','native/microsoft_auth_helper/tests/test_distribution.sh',helper],
                ['dart','run','tool/test_microsoft_helper_protocol.dart',helper],
                ['dart','run','tool/verify_microsoft_helper.dart',helper],
                ['bash','native/microsoft_auth_helper/tests/run_cache_fixtures.sh',helper],
                ['flutter','build','linux','--debug'],
                ['dbus-run-session','--','xvfb-run','-a','ctest','--test-dir','build/linux/x64/debug','--output-on-failure'],
                ['desktop-file-validate','linux/io.busystack.busybox.desktop'],
                ['appstreamcli','validate','--pedantic','--no-net','linux/io.busystack.busybox.metainfo.xml'],
                ['ldd',bundle+'/busybox-mail'],
                ['readelf','-d',bundle+'/busybox-mail']
            ]:
                if a.resume_linux and any(part.endswith(('test_distribution.sh','test_microsoft_helper_protocol.dart','verify_microsoft_helper.dart')) for part in cmd): continue
                run(cmd,repo,env)
    else:
        assert a.app=='busymax'
        local=repo/'android/local.properties'
        original=local.read_bytes()
        config=repo/'android/busymax.android.properties'
        assert not config.exists() and not (repo/'android/key.properties').exists(), 'No owner configuration or production signing used.'
        env.update(GRADLE_USER_HOME=str(HERE.parent/'gradle'),ANDROID_USER_HOME=str(HERE.parent/'android-user'),BUNDLETOOL_JAR=str(HERE.parent/'tools/bundletool-all-1.18.3.jar'))
        try:
            lines=original.decode().splitlines()
            lines=[line for line in lines if not line.startswith('flutter.sdk=')]
            lines.append('flutter.sdk=/tmp/m2-c2-flutter-sdk')
            local.write_text('\n'.join(lines)+'\n')
            run(['tool/android/check_prerequisites.sh'],repo,env)
            # The Dart/generation/analysis/complete suite prerequisites were
            # already verified on these identical inputs. Run the native targets
            # from tool/android/verify.sh directly, without duplicating that suite.
            run([str(repo/'android/gradlew'),'--project-dir',str(repo/'android'),'--offline','--no-daemon','--max-workers=2',':busymax_android_platform:testDebugUnitTest',':app:lintDebug'],repo,env)
            run(['tool/android/test_registration_modes.sh'],repo,env)
        finally:
            local.write_bytes(original)
        assert not config.exists()
        (HERE/'android-local-preservation.json').write_text(json.dumps({'owner_local_properties_sha256':hashlib.sha256(original).hexdigest(),'restored_byte_identically':local.read_bytes()==original,'production_signing':False,'provider_configuration_restored_absent':not config.exists()},indent=2)+'\n')
    for name,expected in prereq.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/a.app).strip()

if __name__=='__main__': main()
