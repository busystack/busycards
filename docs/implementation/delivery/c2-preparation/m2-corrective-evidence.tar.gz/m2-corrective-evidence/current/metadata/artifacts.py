"""Package the committed affected applications and verify fresh extraction."""
from pathlib import Path, PurePosixPath
import argparse, gzip, hashlib, json, os, shutil, subprocess, tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / '.m2-correction/delivery/c2-preparation-final'
EPOCH = 1790899200
EXCLUDED = {'.git', '.idea', '.vscode', '.dart_tool', '__pycache__', 'ephemeral'}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

def inventory(root):
    rows = []
    for p in sorted(root.rglob('*')):
        if p.is_symlink():
            assert p.resolve().is_relative_to(root.resolve()), p
            rows.append({'path': p.relative_to(root).as_posix(), 'target': os.readlink(p), 'mode': oct(p.lstat().st_mode & 0o777)})
        elif p.is_file():
            rows.append({'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p), 'mode': oct(0o755 if p.stat().st_mode & 0o111 else 0o644)})
    return rows

def extract(archive, destination):
    destination.mkdir(parents=True, exist_ok=False)
    with tarfile.open(archive) as stream:
        for m in stream.getmembers():
            p = PurePosixPath(m.name)
            assert not p.is_absolute() and '..' not in p.parts and not m.islnk(), m.name
            assert m.isfile() or m.isdir() or m.issym(), m.name
            if m.issym():
                assert not PurePosixPath(m.linkname).is_absolute(), m.name
        stream.extractall(destination, filter='data')
    for p in destination.rglob('*'):
        if p.is_symlink(): assert p.resolve().is_relative_to(destination.resolve()), p

def archive_tree(source, destination, prefix):
    with destination.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=EPOCH) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
        for p in [source, *sorted(source.rglob('*'))]:
            name = prefix if p == source else prefix + '/' + p.relative_to(source).as_posix()
            info = archive.gettarinfo(str(p), name)
            assert not info.islnk(), name
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = EPOCH
            if info.isfile():
                info.mode = 0o755 if p.stat().st_mode & 0o111 else 0o644
                with p.open('rb') as stream: archive.addfile(info, stream)
            else: archive.addfile(info)

def source(app):
    repo = ROOT / app
    status = git(repo, 'status', '--porcelain')
    if app == 'busycards':
        assert all('.idea/' in line or 'native/microsoft_auth_helper/__pycache__/' in line for line in status.splitlines()), status
        command = ['python3', 'tool/package.py', '--source-only']
        version = '0.1.0'
        excluded = EXCLUDED | {'.flutter-plugins-dependencies', 'build', 'validation', 'target'}
    else:
        assert not status, 'Affected source must be committed and clean.'
        command = ['python3', 'tool/package_source.py']
        version = '0.2.4' if app == 'busymax' else '0.0.1'
        excluded = EXCLUDED
    subprocess.run(command, cwd=repo, check=True)
    name = f'{app}-{version}-source.tar.gz'
    output = OUT / name
    origin = repo / ('validation/artifacts' if app == 'busycards' else 'dist/source') / name
    shutil.copyfile(origin, output)
    layout = HERE / 'extracted' / (app + '-source')
    extract(output, layout)
    roots = [app, *[d['name'] for d in json.loads((repo / 'tool/shared_dependencies.json').read_text())['dependencies']]]
    assert sorted(p.name for p in layout.iterdir()) == sorted(roots)
    rows = []
    for r in roots:
        authoritative = ROOT / r
        expected = []
        for f in git(authoritative, 'ls-files').splitlines():
            p = PurePosixPath(f)
            if excluded.intersection(p.parts) or p.suffix == '.pyc': continue
            expected.append(f)
            candidate = layout / r / f
            original = authoritative / f
            assert candidate.is_file() or candidate.is_symlink(), f
            if original.is_symlink(): assert os.readlink(candidate) == os.readlink(original), f
            else:
                assert sha(candidate) == sha(original), f
                expected_mode = 0o755 if original.stat().st_mode & 0o111 else 0o644
                assert candidate.stat().st_mode & 0o777 == expected_mode, f
        assert sorted(p['path'] for p in inventory(layout / r)) == sorted(expected)
        rows.append({'repository': r, 'revision': git(authoritative, 'rev-parse', 'HEAD'), 'files': len(expected)})
    first = sha(output)
    subprocess.run(command, cwd=repo, check=True)
    assert sha(origin) == first
    record = {'app': app, 'revision': git(repo, 'rev-parse', 'HEAD'), 'file': name, 'bytes': output.stat().st_size, 'sha256': first, 'epoch': EPOCH, 'fresh_extraction': str(layout), 'sibling_layout': rows, 'verification': 'Every source file hash and executable mode matches the committed application or unchanged declared sibling; deterministic archive recreated with the same hash.'}
    (OUT / f'{app}-source-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)

def native(app, symbols=False):
    repo = ROOT / app
    assert not git(repo, 'status', '--porcelain')
    version = '0.2.4' if app == 'busymax' else '0.0.1'
    leaf = 'symbols' if symbols else 'bundle'
    source = HERE / 'extracted' / (app+'-source') / app / 'build/linux/x64/release' / leaf
    assert source.is_dir() and any(source.iterdir())
    kind = 'linux-x64-symbols' if symbols else 'linux-x64'
    output = OUT / f'{app}-{version}-{kind}.tar.gz'
    prefix = f'{app}-{version}' + ('-symbols' if symbols else '')
    if not symbols:
        binary = source / ('busybox-mail' if app == 'busybox' else app)
        assert os.access(binary, os.X_OK)
        assert (source / 'data/flutter_assets/AssetManifest.bin').is_file()
        assert not any(p.name == 'native_assets.json' for p in source.rglob('*'))
        if app == 'busybox':
            assert os.access(source / 'lib/busybox-microsoft-auth', os.X_OK)
            assert any(p.name == 'java' for p in source.rglob('runtime/bin/java'))
            assert (source / 'lib/libsqlcipher.so').is_file()
    before = inventory(source)
    archive_tree(source, output, prefix)
    first = sha(output)
    layout = HERE / 'extracted' / f'{app}-{kind}'
    extract(output, layout)
    assert inventory(layout / prefix) == before
    for file in (layout/prefix).rglob('*'):
        if file.is_file() and not file.is_symlink(): assert file.stat().st_mode&0o777 == (0o755 if file.stat().st_mode&0o111 else 0o644)
    archive_tree(source, output, prefix)
    assert sha(output) == first
    record = {'app': app, 'revision': git(repo, 'rev-parse', 'HEAD'), 'file': output.name, 'bytes': output.stat().st_size, 'sha256': first, 'epoch': EPOCH, 'fresh_extraction': str(layout), 'inventory': before, 'verified': ['fresh safe extraction', 'all bytes, links and executable modes; regular permissions normalized to 0644/0755', 'deterministic archive construction'], 'not_claimed': ['independent cross-prefix Flutter AOT byte identity', 'installed confinement', 'physical driver qualification']}
    (OUT / f'{app}-{kind}-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k:v for k,v in record.items() if k != 'inventory'}), flush=True)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('kind', choices=['source', 'native', 'symbols']); p.add_argument('app', choices=['busymax', 'busybox', 'busycards']); a = p.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if a.kind == 'source': source(a.app)
    else: native(a.app, a.kind == 'symbols')
