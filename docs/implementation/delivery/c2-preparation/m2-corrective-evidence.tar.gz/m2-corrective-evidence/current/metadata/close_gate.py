from pathlib import Path
import subprocess,os,json,sys,hashlib,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
Path('/tmp/m2c-lifecycle').mkdir(mode=0o700,exist_ok=True)
b=Path(__file__).resolve().parents[1];app,binary,mode=sys.argv[1:];env=os.environ.copy()
env.update(M2_APP=app,M2_BINARY=str(Path(binary).resolve()),M2_CAPTURE_SUFFIX='-c2-preparation-'+mode,BUSYFILES_DESKTOP_SESSION_TMPDIR='/tmp/m2c-lifecycle',GTK_USE_PORTAL='0',GDK_BACKEND='x11')
for k in ['LIBGL_ALWAYS_SOFTWARE','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
if 'mesa' in mode:
 env.update(__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json',LIBGL_ALWAYS_SOFTWARE='1')
if 'settled' in mode:env['M2_WAIT_READY']='1'
if mode.endswith('gdb'):env['M2_GDB']='1'
command=['timeout','--signal=TERM','--kill-after=5s','90s','xvfb-run','-a','-s','-screen 0 1600x1100x24',str(b.parent/'busyfiles/scripts/with-isolated-desktop-session.sh'),'env','GDK_BACKEND=x11','/usr/bin/python3',str(b/'c2-preparation/record_native_close.py')]
print(json.dumps({'command':command,'app':app,'binary':env['M2_BINARY'],'rendering':mode}),flush=True)
r=subprocess.run(command,env=env)
record={'binary':env['M2_BINARY'],'binary_sha256':hashlib.file_digest(open(binary,'rb'),'sha256').hexdigest(),'bundle_assets':{str(p.relative_to(Path(binary).parent)):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [Path(binary).parent/'lib/libapp.so',Path(binary).parent/'lib/libflutter_linux_gtk.so',Path(binary).parent/'data/flutter_assets/kernel_blob.bin'] if p.is_file()},'mode':mode,'command':command,'exit_status':r.returncode,'capture_directory':str(b/'native'/('independent-final-'+app+env['M2_CAPTURE_SUFFIX'])),'physical_driver_qualification':False}
(b/'c2-preparation'/('native-close-'+app+'-'+mode+'.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(r.returncode)
