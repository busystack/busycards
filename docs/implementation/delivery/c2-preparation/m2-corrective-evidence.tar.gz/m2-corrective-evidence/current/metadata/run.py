import argparse,datetime,hashlib,json,os,pathlib,subprocess,sys,time,re
root=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser(); parser.add_argument('label'); parser.add_argument('repo'); parser.add_argument('command',nargs=argparse.REMAINDER); a=parser.parse_args()
cwd=root.parent.parent/a.repo; command=a.command
if command and command[0]=='--': command=command[1:]
env=os.environ.copy(); env['PATH']='/tmp/m2-c2-flutter-sdk/bin:'+env['PATH']; env['PUB_CACHE']='/tmp/m2-c2-pub-cache'; env['XDG_CONFIG_HOME']=str(root/'profile/config'); env['XDG_DATA_HOME']=str(root/'profile/data'); env['XDG_CACHE_HOME']=str(root/'profile/cache'); env['DART_SUPPRESS_ANALYTICS']='true'; env['CI']='true'; env['TMPDIR']=str(root/'tmp')
start=datetime.datetime.now(datetime.timezone.utc)
try:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True,stderr=subprocess.DEVNULL).strip()
except subprocess.CalledProcessError:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root.parent.parent/cwd.name,text=True).strip()
def fingerprint():
 h=hashlib.sha256()
 try:
  files=set(subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=cwd,stderr=subprocess.DEVNULL).split(b'\0'))
 except subprocess.CalledProcessError:
  files={os.fsencode(str(p.relative_to(cwd))) for p in cwd.rglob('*') if p.is_file() and not {'build','.dart_tool','target','.git'}.intersection(p.relative_to(cwd).parts)}
 for f in sorted(files):
  if f:
   p=cwd/os.fsdecode(f); h.update(f+b'\0'); h.update(p.read_bytes() if p.is_file() else b'<absent>')
 return h.hexdigest()
start_fingerprint=fingerprint()

log=root/'logs'/(a.label+'.log')
with log.open('w') as out:
 process=subprocess.Popen(command,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 heartbeat=time.monotonic()
 for line in process.stdout:
  out.write(line); out.flush()
  if time.monotonic()-heartbeat>=30:
   status=re.match(r'^([0-9]{2}:[0-9]{2} \+[0-9]+(?: ~[0-9]+)?(?: -[0-9]+)?):',line)
   print(a.label+': '+(status.group(1) if status else 'operation active'),flush=True);heartbeat=time.monotonic()
 result=subprocess.CompletedProcess(command,process.wait())
end_fingerprint=fingerprint()
record={'fingerprint_algorithm':'sha256 sorted unique Git tracked and unignored paths plus file bytes v2','label':a.label,'command':command,'cwd':str(cwd),'head':head,'tracked_fingerprint':start_fingerprint,'end_fingerprint':end_fingerprint,'stable_tree':start_fingerprint==end_fingerprint,'started_utc':start.isoformat(),'elapsed_seconds':(datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),'exit_status':result.returncode,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'toolchain':'Flutter 3.47.5 / Dart 3.13.4 / Java 25.0.1; private SDK copy and cache'}
with (root/'results.jsonl').open('a') as out: out.write(json.dumps(record)+'\n')
print(json.dumps(record)); print(log.read_text()[-10000:]); sys.exit(result.returncode)
