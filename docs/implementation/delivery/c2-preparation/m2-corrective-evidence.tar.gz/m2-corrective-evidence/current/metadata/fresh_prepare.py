from pathlib import Path
import hashlib,json,subprocess
h=Path(__file__).resolve().parent;root=h.parents[1];repo=h/'extracted/busymax-source/busymax';live=root/'busymax'
files=subprocess.check_output(['git','ls-files','-z'],cwd=live).split(b'\0');before={f.decode():hashlib.sha256((repo/f.decode()).read_bytes()).hexdigest() for f in files if f and (repo/f.decode()).is_file()}
for c in [['flutter','pub','get','--offline','--enforce-lockfile'],['flutter','gen-l10n'],['dart','run','build_runner','build','--delete-conflicting-outputs','--force-jit']]:
 print(json.dumps({'command':c,'cwd':str(repo)}),flush=True);subprocess.run(c,cwd=repo,check=True)
for name,digest in before.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
(h/'fresh-source-input-verification.json').write_text(json.dumps({'app':'busymax','revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip(),'original_files_verified':len(before),'all_original_file_hashes_unchanged_after_locked_generation':True,'no_other_application_build_or_helper_dependency':True},indent=2)+'\n');print('Fresh original source inputs verified',len(before),flush=True)
