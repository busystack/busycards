from pathlib import Path
import hashlib,json,subprocess
h=Path(__file__).resolve().parent;repo=h.parents[1]/'busymax'
files=['lib/src/contacts/busymax_contacts_controller.dart','lib/src/features/auth/data/auth_repository.dart','test/contacts/parent_removal_lifecycle_test.dart']
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
rows=[json.loads(x) for x in (h/'results.jsonl').read_text().splitlines()]
full=next(r for r in rows if r['label']=='busymax-c2-full-captured-final');assert full['exit_status']==0 and full['stable_tree']
assert not git('diff','--cached','--name-only');assert sorted(git('diff','--name-only').splitlines())==sorted(files);assert not git('ls-files','--others','--exclude-standard')
assert hashlib.sha256((h/full['log']).read_bytes()).hexdigest()==full['log_sha256']
(h/'final-busymax.patch').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=repo))
subprocess.run(['git','add','--',*files],cwd=repo,check=True)
assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(files)
subprocess.run(['git','commit','-m','fix(contacts): recover bindings after removal preparation failure'],cwd=repo,check=True)
assert not git('status','--porcelain')
x=hashlib.sha256()
for f in sorted(set(subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=repo).split(b'\0'))):
 if f:x.update(f+b'\0');p=repo/f.decode();x.update(p.read_bytes() if p.is_file() else b'<absent>')
assert x.hexdigest()==full['end_fingerprint']
r={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'parent':git('rev-parse','HEAD^'),'tested_content_fingerprint':x.hexdigest(),'full_suite_receipt':full['label'],'task_owned_files':files,'clean_worktree':True,'patch_sha256':hashlib.sha256((h/'final-busymax.patch').read_bytes()).hexdigest()}
(h/'busymax-commit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
