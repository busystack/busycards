from pathlib import Path
import os,subprocess,time,json,ctypes
import gi
gi.require_version('Atspi','2.0');gi.require_version('Gtk','3.0')
from gi.repository import Atspi,GLib
from PIL import ImageGrab
b=Path(__file__).resolve().parents[1];app_name=os.environ['M2_APP'];out=b/'native'/('independent-final-'+app_name+os.environ.get('M2_CAPTURE_SUFFIX',''));out.mkdir(exist_ok=False)
config=Path(os.environ['XDG_CONFIG_HOME'])/'gtk-3.0';config.mkdir(exist_ok=True);(config/'settings.ini').write_text('[Settings]\ngtk-theme-name=Yaru\ngtk-font-name=DejaVu Sans 11\ngtk-icon-theme-name=Yaru\ngtk-enable-animations=false\n')
subprocess.run(['gnome-keyring-daemon','--unlock','--components=secrets'],input=b'synthetic-independent-profile',check=True,stdout=subprocess.DEVNULL)
wm_env=os.environ.copy();wm_env.update(XDG_DATA_DIRS=str(b/'tools/openbox/usr/share')+':/usr/share',LD_LIBRARY_PATH=str(b/'tools/openbox/usr/lib/x86_64-linux-gnu'))
wm=subprocess.Popen([str(b/'tools/openbox/usr/bin/openbox'),'--config-file',str(b/'tools/openbox/etc/xdg/openbox/rc.xml')],env=wm_env,stdout=open(out/'wm.log','w'),stderr=subprocess.STDOUT)
profile=Path(os.environ['XDG_DATA_HOME']);home=profile/'empty-home';home.mkdir();env=os.environ.copy();env.update(GTK_MODULES='gail:atk-bridge',NO_AT_BRIDGE='0',HOME=str(home),TMPDIR=str(profile/'tmp'));(profile/'tmp').mkdir()
command=['bwrap','--ro-bind','/','/','--bind',str(home),'/home/albert','--ro-bind',str(b.parent),str(b.parent)]
for key in ['XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR']:command+=['--bind',env[key],env[key]]
debugger=['gdb','--batch','--return-child-result','-ex','run','-ex','thread apply all bt','--args'] if os.environ.get('M2_GDB')=='1' else []
command+=['--proc','/proc','--dev','/dev','--die-with-parent','--']+debugger+[os.environ['M2_BINARY']]
log=open(out/'application.log','w');app=subprocess.Popen(command,cwd=profile,env=env,stdout=log,stderr=log)
def pause(seconds):
 until=time.monotonic()+seconds
 while time.monotonic()<until:
  while GLib.MainContext.default().pending():GLib.MainContext.default().iteration(False)
  time.sleep(.02)
def walk(n,depth=0):
 rows=[]
 try:
  if n.get_name():rows.append({'name':n.get_name(),'role':n.get_role_name()})
  if depth<15:
   for i in range(n.get_child_count()):rows+=walk(n.get_child_at_index(i),depth+1)
 except Exception:pass
 return rows
try:
 Atspi.set_timeout(3000,5000);entries=[];window=None
 for attempt in range(50):
  assert app.poll() is None,'The independent application must stay running'
  pause(.5);entries=walk(Atspi.get_desktop(0));lines=subprocess.check_output([str(b/'tools/wmctrl/usr/bin/wmctrl'),'-lpG'],text=True).splitlines()
  matches=[l.split(None,8) for l in lines if len(l.split(None,8))==9 and app_name.lower() in l.split(None,8)[8].lower()]
  if len(matches)==1 and len(entries)>5:window=matches[0];break
 assert window and entries,'A real managed native application window and accessible controls must be present'
 pause(2)
 if os.environ.get('M2_WAIT_READY')=='1':
  for ready_attempt in range(100):
   entries=walk(Atspi.get_desktop(0))
   if not any('Loading schedule' in row['name'] for row in entries): break
   assert app.poll() is None,'Application must remain alive during startup'
   pause(.5)
  assert not any('Loading schedule' in row['name'] for row in entries),'Schedule startup must settle before native close'
  pause(2)
 ImageGrab.grab(xdisplay=os.environ['DISPLAY']).save(out/'ordinary-empty.png');(out/'controls.json').write_text(json.dumps(entries,indent=2)+'\n')
 subprocess.run([str(b/'tools/wmctrl/usr/bin/wmctrl'),'-ic',window[0]],check=True)
 code=app.wait(timeout=15);assert code==0,code
 record={'app':app_name,'binary':os.environ['M2_BINARY'],'managed_window':window,'native_close_exit':code,'backend':'private X11/Xvfb/Openbox','rendering_request':{k:os.environ.get(k) for k in ['LIBGL_ALWAYS_SOFTWARE','__EGL_VENDOR_LIBRARY_FILENAMES']},'gdb':bool(debugger),'waited_for_schedule_startup':os.environ.get('M2_WAIT_READY')=='1','physical_driver_qualification':False,'scope':'actual default main; app plus declared source dependencies only; empty private HOME/XDG/database/Secret Service; no installed other-app helper','claims':['actual native shell startup and accessible controls','native window close/shutdown'],'not_claimed':['provider enrollment','strict Snap confinement','exhaustive rendering matrix']}
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
finally:
 (out/'exit-receipt.json').write_text(json.dumps({'binary':os.environ['M2_BINARY'],'exit_status':app.poll(),'rendering':os.environ.get('M2_CAPTURE_SUFFIX'),'native_window_observed':bool(window)},indent=2)+'\n')
 if app.poll() is None:app.terminate();app.wait(timeout=10)
 wm.terminate();wm.wait(timeout=10);log.close()
