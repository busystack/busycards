from pathlib import Path
import subprocess,sys,json,hashlib
root=Path(__file__).resolve().parents[2]; repo=sys.argv[1]; app=root/repo
files=['pubspec.yaml','pubspec.lock','tool/shared_dependencies.json']
generated=list((app/'lib/l10n/generated').glob('*'))+[app/('lib/src/db/app_database.g.dart' if repo=='busymax' else 'lib/src/storage/mail_database.g.dart')]
def hashes(paths):return {str(p.relative_to(app)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
before=hashes(generated+[app/f for f in files]); rows=[]
commands=[['flutter','pub','get','--offline','--enforce-lockfile'],['flutter','gen-l10n'],['dart','run','build_runner','build']+(['--delete-conflicting-outputs','--force-jit'] if repo=='busymax' else [])]
if repo=='busybox':commands += [['flutter','gen-l10n'],['dart','run','build_runner','build']]
if '--checks-only' in sys.argv:
 previous=json.loads((root/'.m2-correction/c2-preparation'/f'{repo}-prerequisites.json').read_text())
 assert previous['unchanged_pins_and_generated_sources']==before
 print(json.dumps({'reuse':'Completed locked dependency/generation prerequisites; all pinned and generated inputs are hash-identical','source':f'{repo}-prerequisites.json'}),flush=True)
 commands=[]
for c in commands:
 print(json.dumps({'command':c,'cwd':str(app)}),flush=True);r=subprocess.run(c,cwd=app);rows.append({'command':c,'exit_status':r.returncode})
 if r.returncode:sys.exit(r.returncode)
after=hashes(generated+[app/f for f in files]);assert before==after, {p:(before.get(p),after.get(p)) for p in before.keys()|after.keys() if before.get(p)!=after.get(p)}
touched=subprocess.check_output(['git','diff','--name-only'],cwd=app,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=app,text=True).splitlines()
commands=[['dart','format','--output=none','--set-exit-if-changed',*[p for p in touched if p.endswith('.dart')]],['git','diff','--check'],['flutter','analyze','--no-pub']]
if repo=='busymax':commands += [['dart','run','tool/check_platform_boundaries.dart']]
else:commands += [['bash','tool/test-build-release.sh']]
for c in commands:
 print(json.dumps({'command':c,'cwd':str(app)}),flush=True);r=subprocess.run(c,cwd=app);rows.append({'command':c,'exit_status':r.returncode})
 if r.returncode:sys.exit(r.returncode)
(root/'.m2-correction/c2-preparation'/f'{repo}-prerequisites.json').write_text(json.dumps({'unchanged_pins_and_generated_sources':before,'commands':rows},indent=2)+'\n')
