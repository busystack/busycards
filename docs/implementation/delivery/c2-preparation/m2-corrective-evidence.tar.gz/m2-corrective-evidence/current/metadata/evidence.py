from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,tarfile
h=Path(__file__).resolve().parent;root=h.parents[1];out=root/'.m2-correction/delivery/c2-preparation-final';epoch=1790899200;old=root/'.m2-correction/delivery/lifecycle-final/m2-corrective-evidence.tar.gz';oldsha='7e6f8a544c8ddfc602638560274d9f6a77c19a6da24e40d9d850fe90323305c2'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 assert sha(old)==oldsha
 rows=[json.loads(x) for x in (h/'results.jsonl').read_text().splitlines()];assert len({r['label'] for r in rows})==len(rows)
 for r in rows:assert sha(h/r['log'])==r['log_sha256'],r['label']
 selected={}
 def select(p,name):assert name not in selected and p.is_file() and not p.is_symlink();selected[name]=p
 for p in h.iterdir():
  if p.is_file() and p.suffix in {'.json','.jsonl','.py','.sh','.dart','.patch','.md'}:select(p,'current/metadata/'+p.name)
 for p in (h/'logs').glob('*.log'):select(p,'current/commands/'+p.name)
 for p in (h/'input-locks').rglob('*'):
  if p.is_file():select(p,'current/pins/'+p.relative_to(h/'input-locks').as_posix())
 for f in ['lib/src/contacts/busymax_contacts_controller.dart','lib/src/features/auth/data/auth_repository.dart','test/contacts/parent_removal_lifecycle_test.dart']:select(root/'busymax'/f,'current/final-source/busymax/'+f)
 for directory in (root/'.m2-correction/native').glob('*-c2-preparation-*'):
  for p in directory.rglob('*'):
   if p.is_file() and not p.is_symlink() and p.suffix in {'.png','.json','.txt','.log'}:
    assert not {'profile','data','config','cache','keyrings','empty-home'}.intersection(p.relative_to(directory).parts)
    select(p,'current/native/'+p.relative_to(root/'.m2-correction/native').as_posix())
 for p in out.glob('*-manifest.json'):
  if p.name!='evidence-manifest.json':select(p,'current/artifact-metadata/'+p.name)
 records={};target=out/'m2-corrective-evidence.tar.gz';out.mkdir(parents=True,exist_ok=True)
 def add(t,data,name,execute=False):
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and name not in records
  x=tarfile.TarInfo('m2-corrective-evidence/'+name);x.size=len(data);x.mode=0o755 if execute else 0o644;x.mtime=epoch;x.uid=x.gid=0;t.addfile(x,io.BytesIO(data));records[name]={'path':name,'bytes':len(data),'mode':oct(x.mode),'sha256':hashlib.sha256(data).hexdigest()}
 with target.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=epoch) as z,tarfile.open(fileobj=z,mode='w') as t:
  with tarfile.open(old) as prev:
   inventory=json.load(prev.extractfile('m2-corrective-evidence/manifest.json'));expected={r['path']:r for r in inventory['files']}
   exact={'lifecycle/commands/box-full-verified-sequential.log','lifecycle/commands/box-final-format-analysis.log','lifecycle/commands/box-linux-final-completion.log','lifecycle/metadata/busybox-commit.json','lifecycle/metadata/reference-build-identity.json','lifecycle/metadata/unchanged-runtime-inputs.json','lifecycle/metadata/prior-delivery-verification.json','historical/metadata/reference-build-results.json','historical/commands/max-baseline-independent-close-native-trace.log','historical/commands/apps-final-independent-default-native-shell-mesa-qualified.log','historical/commands/apps-final-independent-default-native-shell-writable-tmp.log'}
   for m in prev:
    name=m.name.removeprefix('m2-corrective-evidence/')
    want=name in exact or name.startswith('lifecycle/metadata/native-close-busymax-reference-') or name.startswith('lifecycle/commands/reference-debug-') or name.startswith('historical/native/independent-final-busymax-baseline-native-trace/') or name.startswith('historical/native/independent-final-busymax-baseline-mesa-qualified/')
    if want and m.isfile() and name.endswith(('.json','.log','.txt','.png')):
     data=prev.extractfile(m).read();e=expected[name];assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'];add(t,data,'reused/'+name,bool(m.mode&0o111));exact.discard(name)
   assert not exact,exact
  for name,p in sorted(selected.items()):add(t,p.read_bytes(),name,bool(p.stat().st_mode&0o111))
  inv={'schema':3,'source_revision':json.loads((h/'busymax-commit.json').read_text())['commit'],'files':list(records.values()),'predecessor_evidence_sha256':oldsha,'scope':'Actual current command logs, receipts, source patches, regression inputs, pins and native captures; selected verified unchanged BusyBox and unresolved reference-close evidence. No real credentials/personal data, profiles, keys, SDK/caches or runtime payloads.'};data=(json.dumps(inv,indent=2)+'\n').encode();x=tarfile.TarInfo('m2-corrective-evidence/manifest.json');x.mode=0o644;x.mtime=epoch;x.size=len(data);t.addfile(x,io.BytesIO(data))
 dest=h/'extracted/evidence';dest.mkdir(parents=True,exist_ok=False)
 with tarfile.open(target) as t:t.extractall(dest,filter='data')
 for r in inv['files']:
  p=dest/'m2-corrective-evidence'/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'] and oct(p.stat().st_mode&0o777)==r['mode']
 d={'file':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'entries':len(records)+1,'fresh_extraction_verified':True,'predecessor_evidence_sha256':oldsha,'source_revision':inv['source_revision'],'scope':inv['scope']};(out/'evidence-manifest.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
if __name__=='__main__':main()
